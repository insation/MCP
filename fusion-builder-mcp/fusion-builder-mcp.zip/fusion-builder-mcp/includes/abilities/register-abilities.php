<?php
/**
 * WordPress Abilities API registration.
 *
 * Dual-registers every FusionBuilderMCP tool as a WordPress Ability via wp_register_ability()
 * (introduced in WP 6.9). The tools also continue to be served via the custom
 * /fusion-builder-mcp HTTP endpoint — this file does not replace that endpoint, it
 * mirrors the same tools onto the WP-native Abilities API so that:
 *
 *   - Other WP plugins / first-party WP MCP clients that consume the Abilities
 *     API see FusionBuilderMCP's tools without needing the custom endpoint.
 *   - Sites can keep the FusionBuilderMCP HTTP endpoint disabled (custom-slug or
 *     firewalled) and still expose tools through the official WP MCP Adapter.
 *
 * The WP HTTP endpoint at /fusion-builder-mcp remains the canonical transport for
 * cloud-hosted clients (Claude Desktop, Cursor, etc.) using the bearer-token
 * flow this plugin provisions.
 *
 * @package FusionBuilderMCP
 * @since 1.1.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

use InsationAI\FusionBuilderMCP\Services\ContentPatchingService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use InsationAI\FusionBuilderMCP\Logger\WordPressLogger;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

/**
 * Map of OAuth scope → minimum WordPress capability used by the Abilities
 * permission_callback. Mirrors what the OAuth scope check enforces inside
 * AbstractTool::checkScopeAuthorization().
 */
const INSATIONAI_FBMCP_SCOPE_CAPABILITY_MAP = [
    'mcp:read'   => 'read',
    'mcp:write'  => 'edit_posts',
    'mcp:delete' => 'delete_posts',
    'mcp:admin'  => 'manage_options',
];

/**
 * Tool category for the Abilities API — used for grouping in admin UIs that
 * surface registered abilities.
 */
function insationai_fbmcp_ability_category_for(string $toolName): string
{
    if (str_starts_with($toolName, 'plugin_')) {
        return 'wordpress-plugins';
    }
    if (str_starts_with($toolName, 'theme_')) {
        return 'wordpress-themes';
    }
    if (str_starts_with($toolName, 'media_')) {
        return 'wordpress-media';
    }
    if (str_starts_with($toolName, 'execute_')) {
        return 'code-execution';
    }
    if (
        str_starts_with($toolName, 'list_users') ||
        str_starts_with($toolName, 'get_user') ||
        str_starts_with($toolName, 'create_user') ||
        str_starts_with($toolName, 'update_user') ||
        str_starts_with($toolName, 'delete_user') ||
        str_starts_with($toolName, 'list_roles') ||
        str_starts_with($toolName, 'manage_user_roles') ||
        str_starts_with($toolName, 'manage_capabilities')
    ) {
        return 'wordpress-users';
    }
    if (
        $toolName === 'list_comments' ||
        $toolName === 'get_comment' ||
        $toolName === 'create_comment' ||
        $toolName === 'update_comment' ||
        $toolName === 'delete_comment' ||
        $toolName === 'moderate_comment'
    ) {
        return 'wordpress-comments';
    }
    if (
        str_ends_with($toolName, '_option') ||
        $toolName === 'list_options' ||
        str_ends_with($toolName, '_transient') ||
        $toolName === 'manage_theme_mods'
    ) {
        return 'wordpress-options';
    }
    if (
        $toolName === 'list_menus' ||
        $toolName === 'get_menu' ||
        $toolName === 'manage_menu' ||
        $toolName === 'manage_menu_items' ||
        $toolName === 'assign_menu_location'
    ) {
        return 'wordpress-menus';
    }
    if (
        $toolName === 'list_sidebars' ||
        $toolName === 'list_widgets' ||
        $toolName === 'manage_widget' ||
        $toolName === 'manage_block_widgets'
    ) {
        return 'wordpress-widgets';
    }
    if (
        $toolName === 'list_patterns' ||
        $toolName === 'manage_pattern' ||
        $toolName === 'list_reusable_blocks'
    ) {
        return 'wordpress-patterns';
    }
    if (
        $toolName === 'get_customizer_settings' ||
        $toolName === 'update_customizer_setting' ||
        $toolName === 'export_customizer'
    ) {
        return 'wordpress-customizer';
    }
    if (
        $toolName === 'list_scheduled_events' ||
        $toolName === 'schedule_event' ||
        $toolName === 'unschedule_event' ||
        $toolName === 'run_event_now'
    ) {
        return 'wordpress-cron';
    }
    if (
        $toolName === 'list_rewrite_rules' ||
        $toolName === 'flush_rewrite_rules' ||
        $toolName === 'add_rewrite_rule'
    ) {
        return 'wordpress-rewrites';
    }
    if (
        $toolName === 'db_query' ||
        $toolName === 'db_table_info' ||
        $toolName === 'optimize_tables' ||
        $toolName === 'repair_tables' ||
        str_starts_with($toolName, 'cleanup_') ||
        $toolName === 'search_replace'
    ) {
        return 'wordpress-database';
    }
    if (
        $toolName === 'system_info' ||
        $toolName === 'site_health_check' ||
        str_starts_with($toolName, 'debug_log_') ||
        $toolName === 'list_hooks_on_action'
    ) {
        return 'wordpress-diagnostics';
    }
    if (
        $toolName === 'list_sites' ||
        $toolName === 'get_site' ||
        $toolName === 'manage_site' ||
        $toolName === 'manage_network_users' ||
        $toolName === 'network_activate_plugin'
    ) {
        return 'wordpress-multisite';
    }
    if (
        str_contains($toolName, 'term') ||
        str_contains($toolName, 'tax') ||
        str_starts_with($toolName, 'discover_taxonomies')
    ) {
        return 'wordpress-taxonomy';
    }
    return 'wordpress-content';
}

/**
 * Register all FusionBuilderMCP tools as WordPress Abilities (WP 6.9+).
 *
 * No-op on WP < 6.9 (when wp_register_ability is undefined). The /fusion-builder-mcp
 * HTTP endpoint continues to work in either case.
 */
function insationai_fbmcp_register_abilities(): void
{
    if (!function_exists('wp_register_ability')) {
        return;
    }

    // Sanity: don't register on a site that hasn't authorized FusionBuilderMCP yet.
    if (class_exists('\InsationAI\FusionBuilderMCP\Validator') && !\InsationAI\FusionBuilderMCP\Validator::isAuthorized()) {
        return;
    }

    $wpService = new WordPressService();
    $validationService = new ValidationService();
    $logger = new WordPressLogger();
    $patchingService = new ContentPatchingService($wpService, $logger);

    $tools = \InsationAI\FusionBuilderMCP\ToolRegistry::buildEnabledTools(
        $wpService,
        $validationService,
        $logger,
        $patchingService
    );


    foreach ($tools as $tool) {
        insationai_fbmcp_register_one_ability($tool);
    }
}

function insationai_fbmcp_register_one_ability(AbstractTool $tool): void
{
    $name = $tool->getName();
    $scope = $tool->getRequiredScope();
    $capability = INSATIONAI_FBMCP_SCOPE_CAPABILITY_MAP[$scope] ?? 'manage_options';
    $isDestructive = in_array($scope, ['mcp:write', 'mcp:delete', 'mcp:admin'], true);
    $isReadonly = $scope === 'mcp:read';

    wp_register_ability("insationai-emcp/{$name}", [
        'label'              => $name,
        'description'        => $tool->getDescription(),
        'category'           => insationai_fbmcp_ability_category_for($name),
        'input_schema'       => $tool->getInputSchema(),
        'output_schema'      => [
            'type' => 'object',
            'description' => 'Tool execution result. Shape varies per tool — see description.',
            'additionalProperties' => true,
        ],
        'execute_callback'   => static function ($input) use ($tool) {
            // The Abilities API runs in standard WP request context. The user
            // is whoever WP says — wp_get_current_user(). Build a minimal user
            // context so AbstractTool's scope check has something to look at.
            $current = wp_get_current_user();
            if ($current && $current->ID) {
                $tool->setUserContext([
                    'id' => (int) $current->ID,
                    'login' => (string) $current->user_login,
                    'username' => (string) $current->user_login,
                    'roles' => (array) $current->roles,
                    // Map: an authenticated WP user gets all scopes their
                    // capabilities cover. The capability check inside
                    // permission_callback already gated the call.
                    'scopes' => insationai_fbmcp_scopes_for_user($current),
                ]);
            }

            try {
                return $tool->execute(is_array($input) ? $input : []);
            } catch (\Throwable $e) {
                return new \WP_Error(
                    'insationai_fbmcp_tool_error',
                    $e->getMessage(),
                    ['status' => 400]
                );
            }
        },
        'permission_callback' => static function () use ($capability) {
            return current_user_can($capability);
        },
        'meta' => [
            'show_in_rest' => true,
            'mcp' => ['public' => true],
            'annotations' => [
                'readonly'    => $isReadonly,
                'destructive' => $isDestructive,
                'idempotent'  => false,
                'instructions' => 'Tool source: FusionBuilderMCP. See ' . home_url('/wp-admin/admin.php?page=fusion-builder-mcp-tools') . ' for token management.',
            ],
        ],
    ]);
}

function insationai_fbmcp_scopes_for_user(\WP_User $user): array
{
    $scopes = [];
    if (user_can($user, 'read')) {
        $scopes[] = 'mcp:read';
    }
    if (user_can($user, 'edit_posts')) {
        $scopes[] = 'mcp:write';
    }
    if (user_can($user, 'delete_posts')) {
        $scopes[] = 'mcp:delete';
    }
    if (user_can($user, 'manage_options')) {
        $scopes[] = 'mcp:admin';
    }
    return $scopes;
}

// WP 6.9+ requires abilities to be registered on the `wp_abilities_api_init`
// hook — registering earlier (e.g. on `init`) is rejected by core with a
// _doing_it_wrong() notice and the ability is NOT registered. We hook there
// when the Abilities API exists, and fall back to `init` priority 20 on older
// WordPress that predates it (where the function_exists('wp_register_ability')
// guard inside the function makes it a harmless no-op anyway). did_action()
// guards the rare case where this file loads after the hook already fired.
if (function_exists('wp_register_ability')) {
    if (did_action('wp_abilities_api_init')) {
        insationai_fbmcp_register_abilities();
    } else {
        add_action('wp_abilities_api_init', 'insationai_fbmcp_register_abilities', 20);
    }
} else {
    add_action('init', 'insationai_fbmcp_register_abilities', 20);
}
