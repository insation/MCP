<?php
/**
 * MCP HTTP Endpoint
 *
 * Handles HTTP requests to the MCP server
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Validate site authorization before processing request
if (!class_exists('\InsationAI\FusionBuilderMCP\Validator')) {
    require_once INSATIONAI_FBMCP_PLUGIN_DIR . 'src/Validator.php';
}

if (!\InsationAI\FusionBuilderMCP\Validator::isAuthorized()) {
    \InsationAI\FusionBuilderMCP\Validator::logUnauthorizedAttempt('endpoint');

    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', WP_CONTENT_DIR . '/debug.log');

// Import authentication and other classes
use InsationAI\FusionBuilderMCP\Auth\AuthenticationManager;
use Laminas\HttpHandlerRunner\Emitter\SapiEmitter;
use Mcp\Server;
use Mcp\Server\Session\FileSessionStore;
use Mcp\Server\Transport\StreamableHttpTransport;
use Nyholm\Psr7\Factory\Psr17Factory;
use Nyholm\Psr7Server\ServerRequestCreator;

// Import our services and tools
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use InsationAI\FusionBuilderMCP\Services\ContentPatchingService;
use InsationAI\FusionBuilderMCP\Logger\WordPressLogger;



















// Load configuration from WordPress options
$config = insationai_fbmcp_get_config();

// Initialize authentication manager
$authManager = new AuthenticationManager($config);

// Validate authentication
$authResult = $authManager->authenticate();
if (!$authResult['authenticated']) {
    $authManager->sendUnauthorizedResponse($authResult['error'], $authResult['headers']);
    exit;
}

// Store user context for tools
$userContext = $authResult['user'];

// Set the current user in WordPress so capability checks work
if ($userContext !== null && isset($userContext['id'])) {
    wp_set_current_user($userContext['id']);
}

// Initialize services
$wpService = new WordPressService();
$validationService = new ValidationService();
$logger = new WordPressLogger();
$patchingService = new ContentPatchingService($wpService, $logger);

// Log that endpoint was hit
$logger->info('MCP HTTP endpoint accessed', [
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
    'user_id' => $userContext['id'] ?? 'unknown'
]);

// Initialize tools through the central registry. This automatically applies
// the disabled-tools allow-list configured in the admin Tools tab, includes
// multisite-only tools when running on a multisite, and includes the optional
// ExecutePhp tool when its own opt-in flag is set.
$tools = \InsationAI\FusionBuilderMCP\ToolRegistry::buildEnabledTools(
    $wpService,
    $validationService,
    $logger,
    $patchingService
);


// Create PSR-7 request factory
$psr17Factory = new Psr17Factory();
$creator = new ServerRequestCreator($psr17Factory, $psr17Factory, $psr17Factory, $psr17Factory);

// Get the incoming request
$request = $creator->fromGlobals();

// Build server info description with capabilities
$capabilities = [
    'safe_mode' => get_option('insationai_fbmcp_safe_mode', false),
    'oauth_feature_enabled' => INSATIONAI_FBMCP_OAUTH_FEATURE_ENABLED,
    'authentication_enabled' => $authManager->isAuthenticationEnabled(),
    'authentication_method' => $authManager->getAuthenticationMethod(),
    'oauth_enabled' => get_option('insationai_fbmcp_oauth_enabled', false),
];

$description = 'FusionBuilderMCP - WordPress MCP Server - Capabilities: ' . json_encode($capabilities);

// Create sessions directory if it doesn't exist
$sessionsDir = WP_CONTENT_DIR . '/fusion-builder-mcp-sessions';
if (!is_dir($sessionsDir)) {
    wp_mkdir_p($sessionsDir);
}

// Create the MCP server
$serverBuilder = Server::builder()
    ->setServerInfo('FusionBuilderMCP', INSATIONAI_FBMCP_VERSION, $description)
    ->setSession(new FileSessionStore($sessionsDir));

// Set user context on all tools (for OAuth scope validation)
if ($userContext !== null) {
    foreach ($tools as $tool) {
        $tool->setUserContext($userContext);
    }
}

// Register all tools with dynamic parameter handling
// The MCP SDK uses reflection to get parameter names, so we need to create closures
// with correctly named parameters.
//
// IMPORTANT: the closure captures two variables via `use (...)`. Those captured
// variable names must NEVER collide with a tool's parameter name, or PHP throws
// "Cannot use lexical variable $x as a parameter name" at eval time. We use
// deliberately unusual names (__emcp_tool, __emcp_logger) that no tool schema
// would ever use as a parameter.
foreach ($tools as $__emcp_tool) {
    $schema = $__emcp_tool->getSchema();
    $paramNames = array_keys($schema);

    // Build parameter list string for function signature
    $paramStr = implode(', ', array_map(fn($name) => "mixed \${$name} = null", $paramNames));

    // Build code to collect non-null parameters into a local array.
    $collectParamsCode = "        \$__emcp_params = [];\n";
    foreach ($paramNames as $name) {
        $collectParamsCode .= "        if (\${$name} !== null) { \$__emcp_params['{$name}'] = \${$name}; }\n";
    }

    // Build the complete function code (alternative to heredoc)
    // phpcs:disable Squiz.PHP.Eval.Discouraged -- Required for dynamic parameter names without heredoc
    $functionCode = '
        return function(' . $paramStr . ') use ($__emcp_tool, $__emcp_logger) {
    ' . $collectParamsCode . '
            try {
                $result = $__emcp_tool->execute($__emcp_params);
                return $result["data"] ?? $result;
            } catch (\\Exception $e) {
                $__emcp_logger->error("Tool error: " . $__emcp_tool->getName(), [
                    "error" => $e->getMessage()
                ]);
                // Return error result per MCP protocol (instead of throwing)
                // This allows the error message to be passed to the client
                $errors = method_exists($e, "getErrors") ? $e->getErrors() : [];
                return ["error" => $e->getMessage(), "errors" => $errors];
            }
        };
    ';
    // phpcs:enable

    // The captured $__emcp_logger must exist in this scope for the `use` to bind.
    $__emcp_logger = $logger;

    // Use eval to create the wrapper with correct parameter names
    // phpcs:ignore Squiz.PHP.Eval.Discouraged -- Required for dynamic tool parameter handling
    $wrapper = eval($functionCode);

    $serverBuilder->addTool(
        $wrapper,
        name: $__emcp_tool->getName(),
        description: $__emcp_tool->getDescription(),
        inputSchema: $__emcp_tool->getInputSchema()
    );
}

// Add site info resource
$serverBuilder->addResource(
    function (): array {
        $theme = wp_get_theme();
        $timezone = get_option('timezone_string');

        // If timezone string is empty, try to get it from gmt_offset
        if (empty($timezone)) {
            $gmt_offset = get_option('gmt_offset');
            $timezone = $gmt_offset ? 'UTC' . ($gmt_offset >= 0 ? '+' : '') . $gmt_offset : 'UTC';
        }

        return [
            'site_name' => get_bloginfo('name'),
            'site_description' => get_bloginfo('description'),
            'site_url' => get_bloginfo('url'),
            'home_url' => home_url(),
            'admin_email' => get_bloginfo('admin_email'),
            'language' => get_bloginfo('language'),
            'timezone' => $timezone,
            'wordpress_version' => get_bloginfo('version'),
            'active_theme' => $theme->get('Name'),
            'active_theme_version' => $theme->get('Version'),
            'posts_count' => wp_count_posts('post')->publish,
            'pages_count' => wp_count_posts('page')->publish,
        ];
    },
    uri: 'wordpress://site/info',
    name: 'site_info',
    description: 'WordPress site information and statistics',
    mimeType: 'application/json'
);

$server = $serverBuilder->build();

// Create HTTP transport
$transport = new StreamableHttpTransport($request, $psr17Factory, $psr17Factory);

// Run the server and get response
$response = $server->run($transport);

// Emit the response using SAPI emitter
(new SapiEmitter())->emit($response);
