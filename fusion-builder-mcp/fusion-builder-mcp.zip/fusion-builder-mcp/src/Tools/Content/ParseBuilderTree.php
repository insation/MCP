<?php
/**
 * Parse Builder Tree Tool
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Content;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

class ParseBuilderTree extends AbstractTool
{
    protected FusionBuilderService $fb;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        FusionBuilderService $fb,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->fb = $fb;
    }

    public function getName(): string
    {
        return 'parse_builder_tree';
    }

    public function getDescription(): string
    {
        return 'Parse a post/page\'s Fusion Builder content into a fully recursive nested tree of elements. Each node has its shortcode, attributes, a stable dotted path (e.g. "0.0.1" = container > column > element) usable directly with modify_element/insert_element, an is_registered_element classification flag, and its recursively-parsed children. Resolves structural wrappers (fusion_builder_container/column) even though they are not registered library elements. Read-only and non-destructive.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => [
                'optional',
                'int',
                ['min' => 1],
                'description' => 'A post/page ID to read and parse. Provide this OR content.',
            ],
            'content' => [
                'optional',
                'string',
                'description' => 'A raw Fusion shortcode string to parse directly. Provide this OR post_id.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!$this->fb->isFusionBuilderActive()) {
            return $this->error('Fusion Builder is not active.');
        }

        $hasPost = isset($parameters['post_id']) && (int) $parameters['post_id'] > 0;
        $hasContent = isset($parameters['content']) && $parameters['content'] !== '';

        if (!$hasPost && !$hasContent) {
            return $this->error('Provide either post_id or content.');
        }

        $source = null;
        $raw = '';
        try {
            if ($hasPost) {
                $bc = $this->fb->getBuilderContent((int) $parameters['post_id']);
                $raw = (string) $bc['content'];
                $source = ['post_id' => (int) $parameters['post_id'], 'builder_active' => $bc['builder_active']];
            } else {
                $raw = (string) $parameters['content'];
                $source = ['post_id' => null];
            }

            $tree = $this->fb->parseElementTree($raw);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'source'          => $source,
            'root_count'      => count($tree),
            'elements'        => $tree,
            'parse_note'      => 'Fully recursive nested tree. Each node has a dotted path (e.g. "0.0.1") addressable directly by modify_element/insert_element. is_registered_element flags whether a node is a manifest element (false for structural wrappers like fusion_builder_container/column, which are still resolved).',
        ]);
    }
}
