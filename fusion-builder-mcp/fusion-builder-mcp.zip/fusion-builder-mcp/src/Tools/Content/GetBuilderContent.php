<?php
/**
 * Get Builder Content Tool
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Content;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

class GetBuilderContent extends AbstractTool
{
    protected FusionBuilderService $fb;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        FusionBuilderService $fb,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->fb = $fb;
    }

    public function getName(): string
    {
        return 'get_builder_content';
    }

    public function getDescription(): string
    {
        return 'Read a post or page\'s Fusion Builder content: whether the builder is active for it, the raw Fusion shortcode string stored in post_content, and the Fusion page-options meta. Read-only. Use parse_builder_tree to get a structured element breakdown of the same content.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => [
                'required',
                'int',
                ['min' => 1],
                'description' => 'The post/page ID.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!$this->fb->isFusionBuilderActive()) {
            return $this->error('Fusion Builder is not active.');
        }

        $postId = (int) $parameters['post_id'];

        try {
            $content = $this->fb->getBuilderContent($postId);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($content);
    }
}
