<?php
/**
 * Move Element Tool — relocate the Fusion element at a dotted path to a
 * position before/after another element. Atomic extract-then-reinsert
 * (the whole subtree moves with it). Dry-run by default; real write
 * hard-gated + per-call confirm.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.5.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

class MoveElement extends AbstractWriteTool
{
    public function getName(): string
    {
        return 'move_element';
    }

    public function getDescription(): string
    {
        return 'Move the Fusion element at a dotted path to a new position immediately before or after another element (the anchor). The element moves with its entire nested subtree. Dry-run by default (returns the exact proposed post_content, writes nothing); confirm=true to write (subject to the release write-gate). Guards: the anchor cannot be the element itself nor nested inside it. Snapshots first; revertible via revert_builder_change.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => ['required', 'int', ['min' => 1], 'description' => 'The post/page ID.'],
            'source_path' => ['required', 'string', ['notEmpty' => true], 'description' => 'Dotted path of the element to move, from parse_builder_tree, e.g. "0.0.1" (any depth). Moves with its whole subtree.'],
            'anchor_path' => ['required', 'string', ['notEmpty' => true], 'description' => 'Dotted path of the element to move relative to. Must not be the source or nested inside it.'],
            'position' => ['required', 'string', 'description' => "'before' or 'after' the anchor."],
            'confirm' => ['optional', 'bool', 'description' => 'true to actually write (subject to the release write-gate). Omit/false = dry-run preview.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $postId = (int) $parameters['post_id'];
        $confirm = !empty($parameters['confirm']);

        try {
            $plan = $this->fb->computeMoveByPath(
                $postId,
                (string) $parameters['source_path'],
                (string) $parameters['anchor_path'],
                (string) $parameters['position']
            );
        } catch (\Throwable $e) {
            return $this->error($e->getMessage());
        }

        return $this->previewOrCommit($postId, $plan, $confirm);
    }
}
