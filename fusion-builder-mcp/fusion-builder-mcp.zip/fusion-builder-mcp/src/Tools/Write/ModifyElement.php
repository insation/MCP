<?php
/**
 * Modify Element Tool — change one attribute on an existing top-level
 * Fusion element. Dry-run by default; real write hard-gated.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

class ModifyElement extends AbstractWriteTool
{
    public function getName(): string
    {
        return 'modify_element';
    }

    public function getDescription(): string
    {
        return 'Set/override one attribute on an existing top-level Fusion element in a post. Dry-run by default (returns the exact proposed post_content, writes nothing); pass confirm=true to write (subject to the release write-gate). Every real write snapshots post_content first and is revertible via revert_builder_change.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => ['required', 'int', ['min' => 1], 'description' => 'The post/page ID.'],
            'path' => ['required', 'string', ['notEmpty' => true], 'description' => 'Dotted path to the element from parse_builder_tree, e.g. "0.0.1" (works at any nesting depth — container > column > element).'],
            'attribute' => ['required', 'string', ['notEmpty' => true], 'description' => 'Attribute/param name to set, e.g. color.'],
            'value' => ['required', 'string', 'description' => 'New attribute value.'],
            'confirm' => ['optional', 'bool', 'description' => 'true to actually write (subject to the release write-gate). Omit/false = dry-run.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $postId = (int) $parameters['post_id'];
        $confirm = !empty($parameters['confirm']);

        try {
            $plan = $this->fb->computeModifyByPath(
                $postId,
                (string) $parameters['path'],
                (string) $parameters['attribute'],
                (string) $parameters['value']
            );
        } catch (\Throwable $e) {
            return $this->error($e->getMessage());
        }

        return $this->previewOrCommit($postId, $plan, $confirm);
    }
}
