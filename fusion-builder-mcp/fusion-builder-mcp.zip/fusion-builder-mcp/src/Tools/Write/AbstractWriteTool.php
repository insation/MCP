<?php
/**
 * Abstract Write Tool — shared dry-run / confirm / hard-gate logic for
 * all builder-write tools.
 *
 * Safety model (every concrete tool inherits this):
 *  - Default behavior is DRY-RUN: compute and return the exact proposed
 *    post_content, write nothing.
 *  - A real write requires BOTH: the caller passing confirm=true AND the
 *    INSATIONAI_FBMCP_WRITES_ENABLED constant being true (the hard gate;
 *    false in 1.1.0).
 *  - Every real write snapshots post_content first and is revertible.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

abstract class AbstractWriteTool extends AbstractTool
{
    protected FusionBuilderService $fb;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        FusionBuilderService $fb,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->fb = $fb;
    }

    /**
     * True only if the hard gate constant permits real writes.
     */
    protected function writesHardEnabled(): bool
    {
        return defined('INSATIONAI_FBMCP_WRITES_ENABLED')
            && constant('INSATIONAI_FBMCP_WRITES_ENABLED') === true;
    }

    /**
     * Given a computed change plan and the caller's confirm flag, either
     * return the dry-run preview or commit (snapshotting first). Concrete
     * tools call this after building their plan via a compute*() method.
     *
     * @param array<string,mixed> $plan
     * @return array<string,mixed>
     */
    protected function previewOrCommit(int $postId, array $plan, bool $confirm): array
    {
        // Always include the preview so the caller sees exactly what
        // would be / was written.
        $preview = [
            'mode'             => 'dry_run',
            'post_id'          => $postId,
            'operation'        => $plan['operation'] ?? 'unknown',
            'changed'          => $plan['changed'] ?? null,
            'original_content' => $plan['original_content'] ?? null,
            'proposed_content' => $plan['proposed_content'] ?? null,
        ];
        foreach (['target', 'inserted', 'created', 'anchor', 'will_set_builder_active', 'descendant_count', 'descendant_summary', 'destroys_subtree', 'is_structural_wrapper', 'moved_subtree_count'] as $k) {
            if (array_key_exists($k, $plan)) {
                $preview[$k] = $plan[$k];
            }
        }

        if (!$confirm) {
            $preview['note'] = 'Dry-run (confirm not set). No write performed. Review proposed_content, then call again with confirm=true to write.';
            return $this->success($preview);
        }

        if (!$this->writesHardEnabled()) {
            $preview['mode'] = 'dry_run_forced';
            $preview['note'] = 'confirm=true was passed, but builder writes are hard-disabled in this release (INSATIONAI_FBMCP_WRITES_ENABLED is false). No write performed. This is the 1.1.0 safety posture — real writes are enabled in a later release after dry-run output is verified.';
            return $this->success($preview);
        }

        // Real write path: commitChange snapshots BEFORE writing.
        try {
            $result = $this->fb->commitChange($postId, $plan);
        } catch (\Throwable $e) {
            return $this->error('Write failed: ' . $e->getMessage());
        }
        $result['mode'] = 'committed';
        $result['proposed_content'] = $plan['proposed_content'] ?? null;
        return $this->success($result);
    }

    public function getRequiredScope(): string
    {
        return 'write';
    }
}
