<?php
/**
 * Revert Builder Change Tool — restore a post's post_content from the
 * snapshot taken before the last committed write. The reversal path.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

class RevertBuilderChange extends AbstractWriteTool
{
    public function getName(): string
    {
        return 'revert_builder_change';
    }

    public function getDescription(): string
    {
        return 'Restore a post\'s builder content from the snapshot taken automatically before the last committed write. Use this to undo a create/insert/modify/delete. Reports the snapshot it would restore; pass confirm=true to perform the restore.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => ['required', 'int', ['min' => 1], 'description' => 'The post/page ID to revert.'],
            'confirm' => ['optional', 'bool', 'description' => 'true to perform the restore. Omit/false = report the available snapshot only.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $postId = (int) $parameters['post_id'];
        $confirm = !empty($parameters['confirm']);

        $snap = $this->fb->getPostSnapshot($postId);
        if ($snap === null) {
            return $this->error("No snapshot exists for post {$postId}. Nothing to revert (a snapshot is created only when a write is committed).");
        }

        if (!$confirm) {
            return $this->success([
                'mode'            => 'preview',
                'post_id'         => $postId,
                'snapshot_taken_at' => $snap['taken_at'] ?? null,
                'would_restore_content_length' => strlen((string) ($snap['post_content'] ?? '')),
                'note'            => 'Snapshot available. Call again with confirm=true to restore the pre-write content.',
            ]);
        }

        // The restore itself is a write; respect the same hard gate.
        if (!$this->writesHardEnabled()) {
            return $this->success([
                'mode'   => 'blocked',
                'post_id' => $postId,
                'note'   => 'Restore requires builder writes to be enabled (INSATIONAI_FBMCP_WRITES_ENABLED is false in this release). Since writes are hard-disabled, no committed write could have occurred, so there is nothing that needs reverting via a real write.',
            ]);
        }

        try {
            $result = $this->fb->revertPost($postId);
        } catch (\Throwable $e) {
            return $this->error('Revert failed: ' . $e->getMessage());
        }
        return $this->success($result);
    }
}
