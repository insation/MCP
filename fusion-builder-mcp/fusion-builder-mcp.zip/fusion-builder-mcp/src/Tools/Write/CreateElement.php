<?php
/**
 * Create Element Tool — append a new Fusion element to a post's builder
 * content (sets builder active if the post wasn't a builder post).
 * Dry-run by default; real write hard-gated.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

class CreateElement extends AbstractWriteTool
{
    public function getName(): string
    {
        return 'create_element';
    }

    public function getDescription(): string
    {
        return 'Append a new Fusion element to the end of a post\'s builder content (marks the post as builder-active if it was not already). Dry-run by default (returns proposed post_content, writes nothing); confirm=true to write (subject to the release write-gate). Snapshots first; revertible.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => ['required', 'int', ['min' => 1], 'description' => 'The post/page ID.'],
            'shortcode' => ['required', 'string', ['notEmpty' => true], 'description' => 'Element shortcode to create, e.g. fusion_title.'],
            'attributes_json' => ['optional', 'string', 'description' => 'JSON object of attributes, e.g. {"size":"1"}.'],
            'inner' => ['optional', 'string', 'description' => 'Inner content/shortcodes (omit for self-closing).'],
            'confirm' => ['optional', 'bool', 'description' => 'true to actually write (subject to the release write-gate).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $postId = (int) $parameters['post_id'];
        $confirm = !empty($parameters['confirm']);

        $attrs = [];
        if (!empty($parameters['attributes_json'])) {
            $decoded = json_decode((string) $parameters['attributes_json'], true);
            if (!is_array($decoded)) {
                return $this->error('attributes_json must be a valid JSON object.');
            }
            $attrs = $decoded;
        }
        $inner = isset($parameters['inner']) && $parameters['inner'] !== ''
            ? (string) $parameters['inner'] : null;

        try {
            $plan = $this->fb->computeCreateElement(
                $postId,
                (string) $parameters['shortcode'],
                $attrs,
                $inner
            );
        } catch (\Throwable $e) {
            return $this->error($e->getMessage());
        }

        return $this->previewOrCommit($postId, $plan, $confirm);
    }
}
