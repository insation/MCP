<?php
/**
 * Insert Element Tool — insert a new Fusion element before/after an
 * existing anchor element. Dry-run by default; real write hard-gated.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

class InsertElement extends AbstractWriteTool
{
    public function getName(): string
    {
        return 'insert_element';
    }

    public function getDescription(): string
    {
        return 'Insert a new Fusion element immediately before or after an existing top-level anchor element in a post. Dry-run by default (returns proposed post_content, writes nothing); confirm=true to write (subject to the release write-gate). Snapshots first; revertible.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => ['required', 'int', ['min' => 1], 'description' => 'The post/page ID.'],
            'shortcode' => ['required', 'string', ['notEmpty' => true], 'description' => 'New element shortcode to insert.'],
            'attributes_json' => ['optional', 'string', 'description' => 'JSON object of attributes for the new element, e.g. {"color":"custom"}.'],
            'inner' => ['optional', 'string', 'description' => 'Inner content/shortcodes for the new element (omit for self-closing).'],
            'anchor_path' => ['required', 'string', ['notEmpty' => true], 'description' => 'Dotted path of the existing anchor element from parse_builder_tree, e.g. "0.0.1" (any depth).'],
            'position' => ['required', 'string', 'description' => "'before' or 'after'."],
            'confirm' => ['optional', 'bool', 'description' => 'true to actually write (subject to the release write-gate).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $postId = (int) $parameters['post_id'];
        $confirm = !empty($parameters['confirm']);

        $attrs = [];
        if (!empty($parameters['attributes_json'])) {
            $decoded = json_decode((string) $parameters['attributes_json'], true);
            if (!is_array($decoded)) {
                return $this->error('attributes_json must be a valid JSON object.');
            }
            $attrs = $decoded;
        }
        $inner = isset($parameters['inner']) && $parameters['inner'] !== ''
            ? (string) $parameters['inner'] : null;

        try {
            $plan = $this->fb->computeInsertByPath(
                $postId,
                (string) $parameters['shortcode'],
                $attrs,
                $inner,
                (string) $parameters['anchor_path'],
                (string) $parameters['position']
            );
        } catch (\Throwable $e) {
            return $this->error($e->getMessage());
        }

        return $this->previewOrCommit($postId, $plan, $confirm);
    }
}
