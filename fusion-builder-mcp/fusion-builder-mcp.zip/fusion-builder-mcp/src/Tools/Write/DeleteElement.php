<?php
/**
 * Delete Element Tool — remove the Fusion element addressed by dotted
 * path (any depth). Dry-run by default; real write hard-gated + per-call
 * confirm. Surfaces what the deletion would also destroy.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.4.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Write;

class DeleteElement extends AbstractWriteTool
{
    public function getName(): string
    {
        return 'delete_element';
    }

    public function getDescription(): string
    {
        return 'Delete the Fusion element at a dotted path (any nesting depth) from a post. Dry-run by default (returns the exact proposed post_content and a summary of what would be removed, writes nothing); confirm=true to write (subject to the release write-gate). IMPORTANT: deleting an element also deletes everything nested inside it — deleting a container or column removes all its children. The dry-run response reports descendant_count and descendant_summary so a subtree deletion is never silent. Snapshots first; revertible via revert_builder_change.';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => ['required', 'int', ['min' => 1], 'description' => 'The post/page ID.'],
            'path' => ['required', 'string', ['notEmpty' => true], 'description' => 'Dotted path of the element to delete from parse_builder_tree, e.g. "0.0.1" (any depth). Deleting it also deletes its entire subtree.'],
            'confirm' => ['optional', 'bool', 'description' => 'true to actually write (subject to the release write-gate). Omit/false = dry-run preview including what would be destroyed.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $postId = (int) $parameters['post_id'];
        $confirm = !empty($parameters['confirm']);

        try {
            $plan = $this->fb->computeDeleteByPath(
                $postId,
                (string) $parameters['path']
            );
        } catch (\Throwable $e) {
            return $this->error($e->getMessage());
        }

        return $this->previewOrCommit($postId, $plan, $confirm);
    }
}
