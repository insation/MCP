<?php
/**
 * Get Fusion Builder Info Tool
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Elements;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

class GetFusionBuilderInfo extends AbstractTool
{
    protected FusionBuilderService $fb;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        FusionBuilderService $fb,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->fb = $fb;
    }

    public function getName(): string
    {
        return 'get_fusion_builder_info';
    }

    public function getDescription(): string
    {
        return 'Get an overview of the Fusion Builder environment: whether Fusion Builder is active, its version, and the number of registered elements available in the element library. A good first call before using the other tools.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        if (!$this->fb->isFusionBuilderActive()) {
            return $this->success([
                'fusion_builder_active' => false,
                'note' => 'Fusion Builder (the Avada Website Builder, sometimes shown as "Avada Builder") is not active.',
            ]);
        }

        $result = [
            'fusion_builder_active' => true,
            'live_version'          => $this->fb->getFusionBuilderVersion(),
        ];

        // Element data is served from the bundled manifest (harvested from
        // Fusion's own resolved registry). Report its metadata, and flag if
        // the live Fusion version differs from the harvested one so callers
        // know the manifest may be slightly stale.
        $meta = $this->fb->getManifestMeta();
        $result['element_source'] = 'bundled_manifest';
        $result['manifest']       = $meta;

        if (!empty($meta['available'])) {
            $result['element_count'] = $meta['element_count'];
            $live = $this->fb->getFusionBuilderVersion();
            $man  = $meta['manifest_fusion_version'] ?? null;
            // Structured, machine-readable drift state so a consuming agent
            // can programmatically decide whether to caveat element-schema
            // answers — without any fragile auto-reharvest machinery.
            $result['manifest_version_state'] = [
                'live_version'     => $live,
                'manifest_version' => $man,
                'in_sync'          => ($live !== null && $man !== null && $live === $man),
                'comparable'       => ($live !== null && $man !== null),
            ];
            if ($live !== null && $man !== null && $live !== $man) {
                $result['manifest_version_state']['drift'] = true;
                $result['version_note'] = "Live Fusion Builder is {$live} but the bundled element manifest was harvested from {$man}. Element data is accurate for {$man}; element schemas may be slightly stale. Regenerate the manifest (re-harvest procedure) if the versions diverge significantly. Structural parsing and all write tools are unaffected — they are registry-independent.";
            }
        } else {
            $result['element_count'] = null;
            $result['registry_note'] = $meta['error'] ?? 'Manifest unavailable.';
        }

        return $this->success($result);
    }
}
