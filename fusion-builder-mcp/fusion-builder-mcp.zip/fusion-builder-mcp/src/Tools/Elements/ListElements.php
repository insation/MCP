<?php
/**
 * List Elements Tool
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Elements;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

class ListElements extends AbstractTool
{
    protected FusionBuilderService $fb;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        FusionBuilderService $fb,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->fb = $fb;
    }

    public function getName(): string
    {
        return 'list_elements';
    }

    public function getDescription(): string
    {
        return 'List every registered Fusion Builder element (the full element library, ~132 elements: layout containers/columns, content elements, and Fusion Form fields). Returns each element\'s shortcode, display name, and category. This is the registry-driven catalog — use get_element_schema for the full settings of a specific element.';
    }

    public function getSchema(): array
    {
        return [
            'search' => [
                'optional',
                'string',
                'description' => 'Case-insensitive substring filter on shortcode or display name.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!$this->fb->isFusionBuilderActive()) {
            return $this->error('Fusion Builder is not active.');
        }

        try {
            $registry = $this->fb->getElementRegistry();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $needle = isset($parameters['search']) && $parameters['search'] !== ''
            ? strtolower((string) $parameters['search'])
            : null;

        $elements = [];
        foreach ($registry as $shortcode => $module) {
            $name = '';
            if (is_array($module)) {
                $name = (string) ($module['name'] ?? $module['admin_label'] ?? '');
            }
            if ($needle !== null) {
                $hay = strtolower((string) $shortcode . ' ' . $name);
                if (strpos($hay, $needle) === false) {
                    continue;
                }
            }
            $entry = ['shortcode' => (string) $shortcode, 'name' => $name];
            if (is_array($module)) {
                foreach (['category', 'element_child', 'multi'] as $k) {
                    if (isset($module[$k])) {
                        $entry[$k] = $module[$k];
                    }
                }
            }
            $elements[] = $entry;
        }

        return $this->success([
            'count'    => count($elements),
            'elements' => $elements,
        ]);
    }
}
