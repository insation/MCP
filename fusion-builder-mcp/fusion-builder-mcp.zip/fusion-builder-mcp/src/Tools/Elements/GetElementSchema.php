<?php
/**
 * Get Element Schema Tool
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Tools\Elements;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

class GetElementSchema extends AbstractTool
{
    protected FusionBuilderService $fb;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        FusionBuilderService $fb,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->fb = $fb;
    }

    public function getName(): string
    {
        return 'get_element_schema';
    }

    public function getDescription(): string
    {
        return 'Get the full registered definition of a single Fusion Builder element by its shortcode — its display name, category, and the complete params/settings schema (every setting the element exposes, with types and defaults as Fusion registered them). Use list_elements to discover shortcodes.';
    }

    public function getSchema(): array
    {
        return [
            'shortcode' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The element shortcode, e.g. fusion_text, fusion_button, fusion_builder_column.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!$this->fb->isFusionBuilderActive()) {
            return $this->error('Fusion Builder is not active.');
        }

        $shortcode = (string) $parameters['shortcode'];

        try {
            $module = $this->fb->getElement($shortcode);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if ($module === null) {
            return $this->error(
                "No registered Fusion Builder element with shortcode '{$shortcode}'. Use list_elements to see valid shortcodes."
            );
        }

        return $this->success([
            'shortcode' => $shortcode,
            'module'    => $module,
        ]);
    }
}
