<?php
/**
 * Tool Registry — FusionBuilderMCP
 *
 * Central source of truth for tool metadata. Both the runtime registrars
 * (mcp-http.php, register-abilities.php) and the admin Tools toggle UI
 * consume this so they stay in lockstep.
 *
 * Tools are only built when Elementor is active. When Elementor is missing,
 * buildAllTools / buildEnabledTools return an empty array. The admin Tools
 * tab still renders (so users can see what would be available), but
 * tools/list returns nothing to MCP clients until Elementor is loaded.
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP;

use InsationAI\FusionBuilderMCP\Services\FusionBuilderService;
use InsationAI\FusionBuilderMCP\Services\ValidationService;
use InsationAI\FusionBuilderMCP\Services\WordPressService;
use InsationAI\FusionBuilderMCP\Services\ContentPatchingService;
use InsationAI\FusionBuilderMCP\Logger\WordPressLogger;
use InsationAI\FusionBuilderMCP\Tools\AbstractTool;

class ToolRegistry
{
    public const DISABLED_OPTION = 'insationai_fbmcp_disabled_tools';

    /**
     * Build every tool instance.
     *
     * @return AbstractTool[]
     */
    public static function buildAllTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $fb = new FusionBuilderService();
        if (!$fb->isFusionBuilderActive()) {
            return [];
        }

        return [
            // ── Elements (registry-driven; covers the full element library) ──
            new Tools\Elements\GetFusionBuilderInfo($wp, $validator, $fb, $logger),
            new Tools\Elements\ListElements($wp, $validator, $fb, $logger),
            new Tools\Elements\GetElementSchema($wp, $validator, $fb, $logger),

            // ── Builder Content (read-only) ──────────────────────────────
            new Tools\Content\GetBuilderContent($wp, $validator, $fb, $logger),
            new Tools\Content\ParseBuilderTree($wp, $validator, $fb, $logger),

            // ── Builder Writes (dry-run by default; hard-gated) ──────────
            new Tools\Write\CreateElement($wp, $validator, $fb, $logger),
            new Tools\Write\InsertElement($wp, $validator, $fb, $logger),
            new Tools\Write\ModifyElement($wp, $validator, $fb, $logger),
            new Tools\Write\DeleteElement($wp, $validator, $fb, $logger),
            new Tools\Write\MoveElement($wp, $validator, $fb, $logger),
            new Tools\Write\RevertBuilderChange($wp, $validator, $fb, $logger),
        ];
    }

    /**
     * Build enabled tools (filters out admin-disabled ones).
     *
     * @return AbstractTool[]
     */
    public static function buildEnabledTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $all = self::buildAllTools($wp, $validator, $logger, $patching);
        $disabled = self::getDisabledToolNames();
        if (empty($disabled) || empty($all)) {
            return $all;
        }
        return array_values(array_filter(
            $all,
            static fn(AbstractTool $t) => !in_array($t->getName(), $disabled, true)
        ));
    }

    /**
     * @return string[]
     */
    public static function getDisabledToolNames(): array
    {
        $stored = get_option(self::DISABLED_OPTION, []);
        return is_array($stored) ? array_values(array_filter(array_map('strval', $stored))) : [];
    }

    /**
     * @param string[] $names
     */
    public static function setDisabledToolNames(array $names): void
    {
        $clean = array_values(array_unique(array_filter(array_map('sanitize_text_field', $names))));
        update_option(self::DISABLED_OPTION, $clean);
    }

    /**
     * Stable category slug for a tool name.
     */
    public static function categoryFor(string $toolName): string
    {
        $documents = [
            'list_elementor_documents', 'get_elementor_document', 'get_document_data',
            'replace_document_data', 'duplicate_document', 'delete_elementor_document',
            'get_document_settings', 'update_document_settings', 'count_elementor_documents',
            'get_elementor_version',
        ];
        if (in_array($toolName, $documents, true)) {
            return 'documents';
        }

        $elements = [
            'find_element', 'get_element', 'list_elements', 'count_elements_in_document',
            'get_element_parent', 'get_element_path', 'find_widgets_by_type',
            'find_elements_by_class', 'insert_element', 'update_element', 'replace_element',
            'delete_element', 'duplicate_element', 'move_element',
            'wrap_element_in_container', 'unwrap_element',
        ];
        if (in_array($toolName, $elements, true)) {
            return 'elements';
        }

        $widgets = [
            'list_widget_types', 'get_widget_schema', 'list_registered_widget_categories',
            'count_widgets_by_type', 'find_unused_widget_types', 'get_widget_default_settings',
            'validate_widget_settings', 'bulk_replace_widget_type',
        ];
        if (in_array($toolName, $widgets, true)) {
            return 'widgets';
        }

        $templates = [
            'list_templates', 'get_template', 'create_template', 'update_template',
            'delete_template', 'duplicate_template', 'export_template', 'import_template',
            'apply_template_to_document', 'save_element_as_template', 'count_templates',
            'get_template_conditions',
        ];
        if (in_array($toolName, $templates, true)) {
            return 'templates';
        }

        $kit = [
            'get_active_kit', 'get_kit_settings', 'update_kit_settings', 'list_global_colors',
            'list_global_fonts', 'update_global_color', 'add_global_color',
            'delete_global_color', 'get_kit_custom_css', 'list_all_kits',
        ];
        if (in_array($toolName, $kit, true)) {
            return 'kit';
        }

        $revisions = [
            'list_document_revisions', 'get_revision_data', 'restore_revision',
            'delete_revision', 'prune_document_revisions',
        ];
        if (in_array($toolName, $revisions, true)) {
            return 'revisions';
        }

        $pageSettings = [
            'get_page_settings', 'update_page_settings', 'get_page_template', 'set_page_template',
        ];
        if (in_array($toolName, $pageSettings, true)) {
            return 'page-settings';
        }

        $customCss = [
            'get_page_custom_css', 'set_page_custom_css', 'get_element_custom_css',
        ];
        if (in_array($toolName, $customCss, true)) {
            return 'custom-css';
        }

        $dynamicTags = [
            'list_dynamic_tags', 'list_dynamic_tag_groups', 'find_dynamic_tag_usage',
            'get_dynamic_tag_config',
        ];
        if (in_array($toolName, $dynamicTags, true)) {
            return 'dynamic-tags';
        }

        $experiments = [
            'list_experiments', 'get_experiment', 'set_experiment_state',
        ];
        if (in_array($toolName, $experiments, true)) {
            return 'experiments';
        }

        $diagnostics = [
            'get_elementor_system_info', 'validate_document_data', 'find_orphaned_elementor_data',
            'get_elementor_settings', 'check_elementor_requirements', 'get_document_css_status',
        ];
        if (in_array($toolName, $diagnostics, true)) {
            return 'diagnostics';
        }

        $cache = [
            'clear_elementor_cache', 'regenerate_document_css', 'regenerate_all_css',
            'sync_global_css', 'get_cache_status',
        ];
        if (in_array($toolName, $cache, true)) {
            return 'cache';
        }

        $maintenance = ['get_maintenance_mode', 'set_maintenance_mode'];
        if (in_array($toolName, $maintenance, true)) {
            return 'maintenance';
        }

        $search = [
            'search_document_content', 'replace_in_document', 'replace_url_across_documents',
        ];
        if (in_array($toolName, $search, true)) {
            return 'search';
        }

        $roles = ['get_editor_role_access', 'set_editor_role_access'];
        if (in_array($toolName, $roles, true)) {
            return 'roles';
        }

        $fonts = ['list_fonts', 'list_font_groups', 'find_font_usage'];
        if (in_array($toolName, $fonts, true)) {
            return 'fonts';
        }

        $styleVariations = [
            'export_kit_styles', 'apply_kit_style_variation', 'compare_kit_styles',
            'save_kit_style_variation_as_kit',
        ];
        if (in_array($toolName, $styleVariations, true)) {
            return 'style-variations';
        }

        // Future categories will go here as we expand
        return 'misc';
    }

    /**
     * Human-readable label for a category slug.
     */
    public static function categoryLabel(string $slug): string
    {
        $labels = [
            'documents'  => __('Documents', 'fusion-builder-mcp'),
            'elements'   => __('Element Tree', 'fusion-builder-mcp'),
            'widgets'    => __('Widget Types', 'fusion-builder-mcp'),
            'templates'  => __('Templates & Library', 'fusion-builder-mcp'),
            'kit'        => __('Global Kit & Styles', 'fusion-builder-mcp'),
            'revisions'  => __('Revisions', 'fusion-builder-mcp'),
            'page-settings' => __('Page Settings', 'fusion-builder-mcp'),
            'custom-css' => __('Custom CSS', 'fusion-builder-mcp'),
            'dynamic-tags' => __('Dynamic Tags', 'fusion-builder-mcp'),
            'experiments' => __('Experiments', 'fusion-builder-mcp'),
            'diagnostics'=> __('Diagnostics', 'fusion-builder-mcp'),
            'cache'      => __('Cache & CSS Regen', 'fusion-builder-mcp'),
            'maintenance'=> __('Maintenance Mode', 'fusion-builder-mcp'),
            'search'     => __('Search & Replace', 'fusion-builder-mcp'),
            'roles'      => __('Editor Roles', 'fusion-builder-mcp'),
            'fonts'      => __('Fonts', 'fusion-builder-mcp'),
            'style-variations' => __('Style Variations', 'fusion-builder-mcp'),
            'misc'       => __('Misc', 'fusion-builder-mcp'),
        ];
        return $labels[$slug] ?? ucfirst(str_replace('-', ' ', $slug));
    }
}
