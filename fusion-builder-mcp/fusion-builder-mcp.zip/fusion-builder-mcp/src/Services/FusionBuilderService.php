<?php
/**
 * Fusion Builder Service
 *
 * Accessor + guarded write layer over Fusion Builder's element registry
 * and the builder content of posts. The write layer (create/insert/modify/
 * delete with dry-run default + mandatory pre-write snapshot + one-call
 * revert) is implemented here: builder writes go into real pages'
 * post_content, so every mutation snapshots first and is reversible, and
 * structural parsing is registry-independent (it resolves container/column
 * wrappers that are not registered library elements).
 *
 * @package InsationAI\FusionBuilderMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\FusionBuilderMCP\Services;

class FusionBuilderService
{
    /**
     * Whether Fusion Builder is active. White-label-safe: never detects by
     * plugin display name (Fusion Builder is commonly shown as "Avada
     * Builder"). Mirrors the main-file gate.
     */
    public function isFusionBuilderActive(): bool
    {
        if (defined('FUSION_BUILDER_VERSION')) {
            return true;
        }
        if (function_exists('FusionBuilder')) {
            return true;
        }
        if (class_exists('FusionBuilder')) {
            return true;
        }
        if (function_exists('get_option')) {
            $active = (array) get_option('active_plugins', []);
            if (function_exists('is_multisite') && is_multisite()) {
                $active = array_merge(
                    $active,
                    array_keys((array) get_site_option('active_sitewide_plugins', []))
                );
            }
            foreach ($active as $path) {
                if (is_string($path)
                    && substr($path, -strlen('/fusion-builder.php')) === '/fusion-builder.php') {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Guard: throw if Fusion Builder is not available.
     *
     * @throws \RuntimeException
     */
    public function requireFusionBuilder(): void
    {
        if (!$this->isFusionBuilderActive()) {
            throw new \RuntimeException(
                'Fusion Builder (the Avada Website Builder, sometimes shown as "Avada Builder") is not active. FusionBuilderMCP requires it.'
            );
        }
    }

    /**
     * The installed Fusion Builder version, if exposed.
     */
    public function getFusionBuilderVersion(): ?string
    {
        return defined('FUSION_BUILDER_VERSION') ? (string) constant('FUSION_BUILDER_VERSION') : null;
    }


    /**
     * The bundled element manifest, lazily loaded and cached.
     *
     * This is the AUTHORITATIVE source. It was harvested once from a live
     * site via Fusion's own fusion_builder_before_init registration
     * (FusionBuilderMCP harvest_registry) — i.e. it is Fusion's own fully
     * PHP-resolved element output, not a fragile static parse. Reading it
     * has ZERO runtime-context dependency, which is what eliminates the
     * editor-gated / uncatchable-fatal failure mode that the live-registry
     * approach hit across releases 1.0.0–1.0.7.
     *
     * @var array<string,mixed>|null
     */
    private ?array $manifestCache = null;

    /**
     * @return array<string, array<string,mixed>>
     * @throws \RuntimeException
     */
    private function loadManifest(): array
    {
        if (is_array($this->manifestCache)) {
            return $this->manifestCache;
        }

        $path = defined('INSATIONAI_FBMCP_PLUGIN_DIR')
            ? constant('INSATIONAI_FBMCP_PLUGIN_DIR') . 'data/elements-manifest.json'
            : __DIR__ . '/../../data/elements-manifest.json';

        if (!is_readable($path)) {
            throw new \RuntimeException('Bundled element manifest not found at ' . $path);
        }

        $raw = file_get_contents($path);
        if ($raw === false || $raw === '') {
            throw new \RuntimeException('Bundled element manifest is empty or unreadable.');
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded) || !isset($decoded['elements']) || !is_array($decoded['elements'])) {
            throw new \RuntimeException('Bundled element manifest is malformed.');
        }

        $this->manifestCache = $decoded;
        return $decoded;
    }

    /**
     * Metadata about the bundled manifest (version, element count, source).
     *
     * @return array<string,mixed>
     */
    public function getManifestMeta(): array
    {
        try {
            $m = $this->loadManifest();
        } catch (\RuntimeException $e) {
            return ['available' => false, 'error' => $e->getMessage()];
        }
        return [
            'available'             => true,
            'manifest_fusion_version' => $m['fusion_version'] ?? null,
            'element_count'         => $m['element_count'] ?? (isset($m['elements']) ? count($m['elements']) : null),
            'harvested_at'          => $m['harvested_at'] ?? null,
            'source'                => $m['source'] ?? null,
        ];
    }

    /**
     * The full element registry, keyed by shortcode.
     *
     * Authoritative source is the bundled manifest (no runtime-context
     * dependency). The live runtime registry is NOT consulted: releases
     * 1.0.0–1.0.7 proved it is editor-gated and forcing it from a REST
     * request produces an uncatchable fatal. The manifest is Fusion's own
     * resolved output for the harvested version, which is accurate and
     * stable.
     *
     * @return array<string, array<string,mixed>>
     * @throws \RuntimeException
     */
    public function getElementRegistry(): array
    {
        $manifest = $this->loadManifest();
        $elements = $manifest['elements'];
        if (empty($elements)) {
            throw new \RuntimeException('Bundled element manifest contains no elements.');
        }
        return $elements;
    }

    /**
     * A single element module by shortcode, or null if not present.
     *
     * @return array<string,mixed>|null
     * @throws \RuntimeException
     */
    public function getElement(string $shortcode): ?array
    {
        $registry = $this->getElementRegistry();
        return $registry[$shortcode] ?? null;
    }

    /* ===================================================================
     * GUARDED WRITE LAYER
     *
     * Builder writes modify real pages' post_content — the highest-risk
     * surface in the project (no graceful fallback, unlike a global
     * option). Every mutating method:
     *   1. takes a full pre-write snapshot of post_content + status meta
     *   2. performs the change on an in-memory copy
     *   3. writes via wp_update_post (WordPress core, not raw SQL)
     *   4. is reversible via revertPost() from the snapshot
     * Tools default to dry-run; a real write requires explicit confirm.
     * ================================================================= */

    private const SNAPSHOT_OPTION_PREFIX = 'insationai_fbmcp_snapshot_';

    /**
     * Take a full snapshot of a post's builder state BEFORE any write.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function snapshotPost(int $postId): array
    {
        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $snapshot = [
            'post_id'              => (int) $postId,
            'taken_at'             => gmdate('c'),
            'post_content'         => (string) $post->post_content,
            'fusion_builder_status' => get_post_meta($postId, 'fusion_builder_status', true),
            'fusion_page_options'  => get_post_meta($postId, '_fusion', true),
        ];
        update_option(self::SNAPSHOT_OPTION_PREFIX . $postId, $snapshot, false);
        return $snapshot;
    }

    /**
     * Get the last snapshot for a post, if any.
     *
     * @return array<string,mixed>|null
     */
    public function getPostSnapshot(int $postId): ?array
    {
        $snap = get_option(self::SNAPSHOT_OPTION_PREFIX . $postId, null);
        return is_array($snap) ? $snap : null;
    }

    /**
     * Restore a post from its last snapshot. Reversal path.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function revertPost(int $postId): array
    {
        $snap = $this->getPostSnapshot($postId);
        if ($snap === null) {
            throw new \RuntimeException("No snapshot exists for post {$postId}; cannot revert.");
        }
        $res = wp_update_post([
            'ID'           => $postId,
            'post_content' => (string) ($snap['post_content'] ?? ''),
        ], true);
        if (is_wp_error($res)) {
            throw new \RuntimeException('Revert failed: ' . $res->get_error_message());
        }
        if (array_key_exists('fusion_builder_status', $snap)) {
            update_post_meta($postId, 'fusion_builder_status', $snap['fusion_builder_status']);
        }
        return [
            'reverted'        => true,
            'post_id'         => $postId,
            'restored_from'   => $snap['taken_at'] ?? null,
        ];
    }

    /**
     * Validate a shortcode is a registered Fusion element.
     *
     * @throws \RuntimeException
     */
    private function assertRegisteredShortcode(string $shortcode): void
    {
        $registry = $this->getElementRegistry();
        if (!isset($registry[$shortcode])) {
            throw new \RuntimeException(
                "'{$shortcode}' is not a registered Fusion Builder element. Use list_elements for valid shortcodes."
            );
        }
    }

    /**
     * Build a single Fusion shortcode string from a shortcode + attributes
     * (+ optional inner content). Uses the same attribute syntax Fusion
     * itself emits: [shortcode key="value" ...]inner[/shortcode].
     * Self-closing when no inner content is given.
     *
     * @param array<string,scalar> $attributes
     */
    public function buildShortcode(string $shortcode, array $attributes = [], ?string $inner = null): string
    {
        $attrParts = [];
        foreach ($attributes as $k => $v) {
            $key = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) $k);
            if ($key === '') {
                continue;
            }
            // Fusion uses double-quoted attribute values; escape stray quotes.
            $val = str_replace('"', '&quot;', (string) $v);
            $attrParts[] = $key . '="' . $val . '"';
        }
        $attrStr = $attrParts ? ' ' . implode(' ', $attrParts) : '';
        if ($inner === null) {
            return '[' . $shortcode . $attrStr . ']';
        }
        return '[' . $shortcode . $attrStr . ']' . $inner . '[/' . $shortcode . ']';
    }

    /**
     * Compute the result of CREATING builder content on a post by
     * appending (or, if empty, setting) a new element's shortcode at the
     * end of post_content, WITHOUT writing.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function computeCreateElement(
        int $postId,
        string $shortcode,
        array $attributes,
        ?string $inner
    ): array {
        $this->requireFusionBuilder();
        $this->assertRegisteredShortcode($shortcode);

        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $content = (string) $post->post_content;
        $fragment = $this->buildShortcode($shortcode, $attributes, $inner);
        $newContent = ($content === '') ? $fragment : ($content . "\n" . $fragment);

        return [
            'post_id'          => $postId,
            'operation'        => 'create_element',
            'created'          => $fragment,
            'original_content' => $content,
            'proposed_content' => $newContent,
            'changed'          => true,
            'will_set_builder_active' => !$this->isBuilderPost($postId),
        ];
    }

    /**
     * Commit a previously-computed change to post_content. Snapshots
     * FIRST, then writes via wp_update_post. The plan array is the return
     * of one of the compute*() methods.
     *
     * @param array<string,mixed> $plan
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function commitChange(int $postId, array $plan): array
    {
        $this->requireFusionBuilder();
        if (!isset($plan['proposed_content']) || !is_string($plan['proposed_content'])) {
            throw new \RuntimeException('Invalid change plan: missing proposed_content.');
        }

        // SNAPSHOT BEFORE WRITE — non-negotiable.
        $snapshot = $this->snapshotPost($postId);

        $res = wp_update_post([
            'ID'           => $postId,
            'post_content' => $plan['proposed_content'],
        ], true);
        if (is_wp_error($res)) {
            throw new \RuntimeException('Write failed: ' . $res->get_error_message());
        }

        // If creating builder content on a non-builder post, mark active.
        if (!empty($plan['will_set_builder_active'])) {
            update_post_meta($postId, 'fusion_builder_status', 'active');
        }

        // Independent verification read-back.
        $after = get_post($postId);
        $written = $after ? (string) $after->post_content : '';

        return [
            'committed'        => true,
            'post_id'          => $postId,
            'operation'        => $plan['operation'] ?? 'unknown',
            'snapshot_taken_at' => $snapshot['taken_at'],
            'write_verified'   => $written === $plan['proposed_content'],
            'revert_hint'      => 'Use revert_builder_change with this post_id to restore the pre-write snapshot.',
        ];
    }

    /**
     * Whether a post uses the Fusion Builder.
     *
     * Source-confirmed: Fusion stores 'fusion_builder_status' = 'active'
     * post meta when the builder is enabled for a post
     * (class-fusion-builder.php:1537,1634).
     *
     * @throws \RuntimeException
     */
    public function isBuilderPost(int $postId): bool
    {
        $this->requireFusionBuilder();
        $status = get_post_meta($postId, 'fusion_builder_status', true);
        return is_string($status) && $status === 'active';
    }

    /**
     * Read a post's raw builder content (the Fusion shortcode string stored
     * in post_content) plus builder status and Fusion page-options meta.
     * READ-ONLY.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getBuilderContent(int $postId): array
    {
        $this->requireFusionBuilder();

        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }

        $pageOptions = get_post_meta($postId, '_fusion', true);

        return [
            'post_id'        => (int) $post->ID,
            'post_type'      => $post->post_type,
            'post_status'    => $post->post_status,
            'title'          => $post->post_title,
            'builder_active' => $this->isBuilderPost($postId),
            'content'        => (string) $post->post_content,
            'page_options'   => is_array($pageOptions) ? $pageOptions : [],
        ];
    }

    /**
     * Parse a Fusion shortcode string into a shallow structural tree:
     * a flat list of top-level elements with shortcode, attributes, and
     * raw inner content. READ-ONLY, non-destructive.
     *
     * Uses WordPress's native shortcode mechanism scoped to the registered
     * Fusion element shortcodes — the same approach Fusion's own Studio
     * import uses (class-awb-studio-import.php:276,284:
     * get_shortcode_regex() + shortcode_parse_atts()). Deliberately shallow
     * for the first cut: a robust full recursive descent over all ~132
     * element types is its own deliberate step in the next phase.
     *
     * @return array<int, array<string,mixed>>
     * @throws \RuntimeException
     */
    /**
     * A generic Fusion-shortcode regex that matches ANY fusion_* / awb_*
     * shortcode — NOT scoped to the registered element list.
     *
     * Critical difference from the old shallow parser: the structural
     * wrappers fusion_builder_container and fusion_builder_column are NOT
     * in the harvested manifest (they self-register via add_shortcode, not
     * through the fusion_builder_map registry global). A registry-scoped
     * parser cannot even see the containers — exactly why the 1.1.0 write
     * tools failed on real nested pages. The recursive parser finds
     * structure independently of the registry and uses the manifest only
     * to CLASSIFY nodes.
     */
    private function fusionShortcodeRegex(): string
    {
        $tag = '(?:fusion_[a-z0-9_]+|awb_[a-z0-9_]+)';
        return '\\[(\\[?)(' . $tag . ')(?![\\w-])([^\\]\\/]*(?:\\/(?!\\])[^\\]\\/]*)*?)'
            . '(?:(\\/)\\]|\\](?:([^\\[]*(?:\\[(?!\\/\\2\\])[^\\[]*)*)\\[\\/\\2\\])?)(\\]?)';
    }

    /**
     * Recursively parse a Fusion shortcode string into a tree of nodes,
     * each with a stable dotted path (e.g. "0.1.2"). Registry-INDEPENDENT
     * for structure; the manifest only adds an is_registered_element flag.
     *
     * @return array<int,array<string,mixed>>
     */
    private function parseNodes(string $content, string $parentPath = ''): array
    {
        $regex = '/' . $this->fusionShortcodeRegex() . '/s';
        $nodes = [];
        $idx = 0;
        try {
            $registry = $this->getElementRegistry();
        } catch (\Throwable $e) {
            $registry = [];
        }

        if (preg_match_all($regex, $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $tag = $m[2] ?? '';
                if ($tag === '') {
                    continue;
                }
                $atts = isset($m[3]) ? shortcode_parse_atts(trim((string) $m[3])) : [];
                $inner = isset($m[5]) ? (string) $m[5] : '';
                $path = ($parentPath === '' ? '' : $parentPath . '.') . $idx;

                $node = [
                    'path'                  => $path,
                    'shortcode'             => $tag,
                    'attributes'            => is_array($atts) ? $atts : [],
                    'raw'                   => (string) $m[0],
                    'has_inner'             => $inner !== '' && trim($inner) !== '',
                    'is_registered_element' => is_array($registry) && isset($registry[$tag]),
                    'children'              => $inner !== '' ? $this->parseNodes($inner, $path) : [],
                ];
                if ($inner !== '' && empty($node['children'])) {
                    $node['inner_text'] = $inner;
                }
                $nodes[] = $node;
                $idx++;
            }
        }
        return $nodes;
    }

    /**
     * Public recursive parse. Returns the full nested tree with paths.
     *
     * @return array<int,array<string,mixed>>
     * @throws \RuntimeException
     */
    public function parseElementTree(string $content): array
    {
        $this->requireFusionBuilder();
        if (trim($content) === '') {
            return [];
        }
        return $this->parseNodes($content);
    }

    /**
     * Locate a single node by its dotted path within a parsed tree.
     *
     * @param array<int,array<string,mixed>> $tree
     * @return array<string,mixed>|null
     */
    private function findNodeByPath(array $tree, string $path): ?array
    {
        $segs = explode('.', $path);
        $nodes = $tree;
        $node = null;
        foreach ($segs as $s) {
            $i = (int) $s;
            if (!isset($nodes[$i])) {
                return null;
            }
            $node = $nodes[$i];
            $nodes = $node['children'] ?? [];
        }
        return $node;
    }

    /**
     * Rebuild a node's raw shortcode from (possibly modified) attributes,
     * preserving inner content byte-for-byte (we only ever rewrite the
     * opening tag's attributes, never children).
     *
     * @param array<string,mixed> $node
     */
    private function rebuildNodeRaw(array $node, ?array $overrideAttrs = null): string
    {
        $tag = (string) $node['shortcode'];
        $attrs = $overrideAttrs !== null ? $overrideAttrs : ($node['attributes'] ?? []);
        $raw = (string) $node['raw'];
        $inner = null;
        $closeTag = '[/' . $tag . ']';
        $openEnd = strpos($raw, ']');
        if ($openEnd !== false && substr($raw, -strlen($closeTag)) === $closeTag) {
            $inner = substr($raw, $openEnd + 1, strlen($raw) - $openEnd - 1 - strlen($closeTag));
        }
        return $this->buildShortcode($tag, is_array($attrs) ? $attrs : [], $inner);
    }

    /**
     * Modify ONE attribute on a node addressed by dotted PATH (any depth),
     * returning original + proposed post_content WITHOUT writing. The
     * nested-aware replacement for the old top-level-only modify.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function computeModifyByPath(
        int $postId,
        string $path,
        string $attrName,
        string $attrValue
    ): array {
        $this->requireFusionBuilder();
        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $content = (string) $post->post_content;
        $tree = $this->parseNodes($content);
        $node = $this->findNodeByPath($tree, $path);
        if ($node === null) {
            throw new \RuntimeException(
                "No element at path '{$path}' in post {$postId}. Use parse_builder_tree to see valid paths."
            );
        }
        $oldRaw = (string) $node['raw'];
        $cleanAttr = preg_replace('/[^a-zA-Z0-9_\-]/', '', $attrName);
        $newAttrs = is_array($node['attributes']) ? $node['attributes'] : [];
        $newAttrs[$cleanAttr] = $attrValue;
        $newRaw = $this->rebuildNodeRaw($node, $newAttrs);

        $pos = strpos($content, $oldRaw);
        if ($pos === false) {
            throw new \RuntimeException('Internal: addressed node raw not found in content.');
        }
        $newContent = substr($content, 0, $pos) . $newRaw
            . substr($content, $pos + strlen($oldRaw));

        return [
            'post_id'          => $postId,
            'operation'        => 'modify_attribute',
            'target'           => ['path' => $path, 'shortcode' => $node['shortcode'], 'attribute' => $attrName, 'value' => $attrValue],
            'original_content' => $content,
            'proposed_content' => $newContent,
            'changed'          => $content !== $newContent,
        ];
    }

    /**
     * Insert a new element before/after a node addressed by dotted PATH
     * (any depth), WITHOUT writing.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function computeInsertByPath(
        int $postId,
        string $newShortcode,
        array $newAttributes,
        ?string $newInner,
        string $anchorPath,
        string $position
    ): array {
        $this->requireFusionBuilder();
        $this->assertRegisteredShortcode($newShortcode);
        if (!in_array($position, ['before', 'after'], true)) {
            throw new \RuntimeException("position must be 'before' or 'after'.");
        }
        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $content = (string) $post->post_content;
        $tree = $this->parseNodes($content);
        $node = $this->findNodeByPath($tree, $anchorPath);
        if ($node === null) {
            throw new \RuntimeException("No anchor element at path '{$anchorPath}' in post {$postId}.");
        }
        $fragment = $this->buildShortcode($newShortcode, $newAttributes, $newInner);
        $anchorRaw = (string) $node['raw'];
        $pos = strpos($content, $anchorRaw);
        if ($pos === false) {
            throw new \RuntimeException('Internal: anchor node raw not found.');
        }
        if ($position === 'before') {
            $newContent = substr($content, 0, $pos) . $fragment . substr($content, $pos);
        } else {
            $end = $pos + strlen($anchorRaw);
            $newContent = substr($content, 0, $end) . $fragment . substr($content, $end);
        }
        return [
            'post_id'          => $postId,
            'operation'        => 'insert_element',
            'inserted'         => $fragment,
            'anchor'           => ['path' => $anchorPath, 'shortcode' => $node['shortcode'], 'position' => $position],
            'original_content' => $content,
            'proposed_content' => $newContent,
            'changed'          => $content !== $newContent,
        ];
    }

    /**
     * Count all descendant element nodes under a node (recursively).
     *
     * @param array<string,mixed> $node
     */
    private function countDescendants(array $node): int
    {
        $n = 0;
        foreach (($node['children'] ?? []) as $child) {
            $n += 1 + $this->countDescendants($child);
        }
        return $n;
    }

    /**
     * Flat list of "shortcode@path" for a node's descendants — surfaced so
     * a caller can SEE exactly what a delete would also destroy.
     *
     * @param array<string,mixed> $node
     * @return array<int,string>
     */
    private function descendantSummary(array $node): array
    {
        $out = [];
        foreach (($node['children'] ?? []) as $child) {
            $out[] = (string) $child['shortcode'] . '@' . (string) $child['path'];
            foreach ($this->descendantSummary($child) as $g) {
                $out[] = $g;
            }
        }
        return $out;
    }

    /**
     * Delete the element addressed by dotted PATH (any depth), WITHOUT
     * writing. Returns the original + proposed post_content.
     *
     * DESTRUCTION-AWARENESS: deleting a node deletes its entire subtree.
     * Deleting a structural wrapper (fusion_builder_container/column) thus
     * removes everything inside it. The returned plan ALWAYS reports
     * descendant_count and descendant_summary so the deletion of a subtree
     * can never be silent — the dry-run shows exactly what disappears
     * before any real write, and a real write still needs confirm=true.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function computeDeleteByPath(int $postId, string $path): array
    {
        $this->requireFusionBuilder();
        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $content = (string) $post->post_content;
        $tree = $this->parseNodes($content);
        $node = $this->findNodeByPath($tree, $path);
        if ($node === null) {
            throw new \RuntimeException(
                "No element at path '{$path}' in post {$postId}. Use parse_builder_tree to see valid paths."
            );
        }
        $oldRaw = (string) $node['raw'];
        $pos = strpos($content, $oldRaw);
        if ($pos === false) {
            throw new \RuntimeException('Internal: addressed node raw not found in content.');
        }
        // Remove exactly the addressed node's full raw span (which already
        // includes its entire nested subtree).
        $before = substr($content, 0, $pos);
        $after  = substr($content, $pos + strlen($oldRaw));
        $newContent = $before . $after;

        $descCount = $this->countDescendants($node);

        return [
            'post_id'            => $postId,
            'operation'          => 'delete_element',
            'target'             => ['path' => $path, 'shortcode' => $node['shortcode']],
            'descendant_count'   => $descCount,
            'descendant_summary' => $this->descendantSummary($node),
            'destroys_subtree'   => $descCount > 0,
            'is_structural_wrapper' => $node['is_registered_element'] === false,
            'original_content'   => $content,
            'proposed_content'   => $newContent,
            'changed'            => $content !== $newContent,
        ];
    }

    /**
     * Move the element at $sourcePath to a position before/after the
     * element at $anchorPath, WITHOUT writing. This is an atomic
     * extract-then-reinsert: the source node's FULL raw (its entire
     * nested subtree) is removed, then re-inserted relative to the anchor.
     *
     * Critical guards:
     *  - source and anchor must both resolve.
     *  - the anchor must NOT be the source itself, and must NOT be nested
     *    INSIDE the source subtree — you cannot move a node into itself
     *    (that would corrupt the tree / lose content). Detected by raw
     *    containment, which is reliable because each node's raw is the
     *    exact, unique substring spanning its whole subtree.
     *  - anchor position is resolved AFTER source removal, so the string
     *    shift from extraction is handled correctly.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function computeMoveByPath(
        int $postId,
        string $sourcePath,
        string $anchorPath,
        string $position
    ): array {
        $this->requireFusionBuilder();
        if (!in_array($position, ['before', 'after'], true)) {
            throw new \RuntimeException("position must be 'before' or 'after'.");
        }
        if ($sourcePath === $anchorPath) {
            throw new \RuntimeException('Source and anchor are the same element; nothing to move.');
        }
        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $content = (string) $post->post_content;
        $tree = $this->parseNodes($content);

        $source = $this->findNodeByPath($tree, $sourcePath);
        if ($source === null) {
            throw new \RuntimeException(
                "No source element at path '{$sourcePath}' in post {$postId}. Use parse_builder_tree to see valid paths."
            );
        }
        $anchor = $this->findNodeByPath($tree, $anchorPath);
        if ($anchor === null) {
            throw new \RuntimeException(
                "No anchor element at path '{$anchorPath}' in post {$postId}."
            );
        }

        $sourceRaw = (string) $source['raw'];
        $anchorRaw = (string) $anchor['raw'];

        // Guard: anchor must not be inside the source subtree. Because a
        // node's raw is the exact unique span of its whole subtree, the
        // anchor being a substring of the source raw means it is nested
        // within (or equal to) the thing being moved.
        if ($sourceRaw !== $anchorRaw && strpos($sourceRaw, $anchorRaw) !== false) {
            throw new \RuntimeException(
                "Cannot move element '{$sourcePath}' relative to '{$anchorPath}': the anchor is nested inside the element being moved."
            );
        }

        // Step 1: remove the source's full raw (exactly one occurrence).
        $sPos = strpos($content, $sourceRaw);
        if ($sPos === false) {
            throw new \RuntimeException('Internal: source node raw not found in content.');
        }
        $without = substr($content, 0, $sPos) . substr($content, $sPos + strlen($sourceRaw));

        // Step 2: locate the anchor in the post-removal string and splice
        // the source raw back in before/after it.
        $aPos = strpos($without, $anchorRaw);
        if ($aPos === false) {
            throw new \RuntimeException('Internal: anchor node raw not found after source removal.');
        }
        if ($position === 'before') {
            $newContent = substr($without, 0, $aPos) . $sourceRaw . substr($without, $aPos);
        } else {
            $end = $aPos + strlen($anchorRaw);
            $newContent = substr($without, 0, $end) . $sourceRaw . substr($without, $end);
        }

        return [
            'post_id'          => $postId,
            'operation'        => 'move_element',
            'target'           => ['source_path' => $sourcePath, 'shortcode' => $source['shortcode']],
            'anchor'           => ['path' => $anchorPath, 'shortcode' => $anchor['shortcode'], 'position' => $position],
            'moved_subtree_count' => $this->countDescendants($source),
            'original_content' => $content,
            'proposed_content' => $newContent,
            'changed'          => $content !== $newContent,
        ];
    }
}
