<?php
/**
 * Plugin Name: ElementorProMCP
 * Plugin URI: https://insationai.com/
 * Description: Turn Elementor Pro into a secure MCP server for AI assistants — Theme Builder, WooCommerce Builder, forms, popups, per-site licensing. By InsationAI.
 * Version: 2.0.0
 * Author: InsationAI
 * Author URI: https://insationai.com/
 * Requires PHP: 8.2
 * Requires at least: 6.0
 * Text Domain: elementor-pro-mcp
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('INSATIONAI_EPRMCP_VERSION', '2.0.0');
define('INSATIONAI_EPRMCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('INSATIONAI_EPRMCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('INSATIONAI_EPRMCP_PLUGIN_FILE', __FILE__);

// Feature flag: OAuth functionality (ENABLED by default in ElementorProMCP)
// Set to false to disable OAuth 2.1 authentication
define('INSATIONAI_EPRMCP_OAUTH_FEATURE_ENABLED', true);

// Load Composer autoloader
if (file_exists(INSATIONAI_EPRMCP_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'vendor/autoload.php';
}

// Load the license service at the earliest point so BOTH the MCP endpoint
// kill-switch (template_redirect priority 1) and the admin UI can call it.
require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/license/class-license-service.php';

/**
 * Plugin Activation
 *
 * Wraps the real activation flow in a try/catch + error_handler so that any
 * fatal during activation is logged to wp-content/debug.log and surfaced
 * via an admin notice. Without this, WordPress just shows the generic
 * "Plugin could not be activated because it triggered a fatal error" with
 * no detail.
 */
function insationai_eprmcp_activate() {
    try {
        require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'install/activate.php';
        insationai_eprmcp_run_activation();
        // Schedule daily license re-validation.
        if (class_exists('InsationAI_EPRMCP_License_Service')) {
            InsationAI_EPRMCP_License_Service::schedule_cron();
        }
    } catch (\Throwable $e) {
        $msg = sprintf(
            'ElementorProMCP activation failed: %s in %s:%d',
            $e->getMessage(),
            $e->getFile(),
            $e->getLine()
        );
        error_log('[ElementorProMCP] ' . $msg);
        error_log('[ElementorProMCP] Trace: ' . $e->getTraceAsString());
        set_transient('insationai_eprmcp_activation_fatal', $msg, 600);
        // Re-throw so WP knows activation failed
        throw $e;
    }
}
register_activation_hook(__FILE__, 'insationai_eprmcp_activate');

/**
 * Show a detailed admin notice if the last activation attempt fataled.
 */
add_action('admin_notices', function () {
    $msg = get_transient('insationai_eprmcp_activation_fatal');
    if (!$msg) {
        return;
    }
    if (!current_user_can('activate_plugins')) {
        return;
    }
    echo '<div class="notice notice-error is-dismissible"><p>';
    echo '<strong>ElementorProMCP activation error:</strong><br><code>' . esc_html($msg) . '</code>';
    echo '<br><small>Full trace logged to wp-content/debug.log (if WP_DEBUG_LOG is enabled).</small>';
    echo '</p></div>';
    delete_transient('insationai_eprmcp_activation_fatal');
});

/**
 * Plugin Deactivation
 */
function insationai_eprmcp_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
    // Stop the daily license cron. We intentionally do NOT auto-deactivate the
    // license activation here — a transient plugin deactivation should not
    // consume a deactivate call; the admin clears the key explicitly via the
    // License tab when moving the license to another site.
    if (class_exists('InsationAI_EPRMCP_License_Service')) {
        InsationAI_EPRMCP_License_Service::unschedule_cron();
    }
}
register_deactivation_hook(__FILE__, 'insationai_eprmcp_deactivate');

/**
 * Initialize plugin
 */
function insationai_eprmcp_init() {
    // Register rewrite rules
    insationai_eprmcp_register_rewrite_rules();

    // Register query vars
    add_filter('query_vars', 'insationai_eprmcp_register_query_vars');

    // Initialize update checker
    insationai_eprmcp_init_update_checker();
}
add_action('init', 'insationai_eprmcp_init');

/**
 * Detect if Elementor (the free plugin) is active.
 *
 * @return bool
 */
function insationai_eprmcp_elementor_active(): bool {
    // Elementor defines the \Elementor\Plugin class on plugins_loaded.
    return class_exists('\Elementor\Plugin');
}

/**
 * Detect if Elementor Pro is active. The Theme Builder, display conditions,
 * locations and the Pro/WooCommerce widgets all live in Elementor Pro, so this
 * plugin requires Pro — free Elementor alone is not enough.
 *
 * Elementor Pro defines the ELEMENTOR_PRO_VERSION constant when it loads.
 *
 * @return bool
 */
function insationai_eprmcp_elementor_pro_active(): bool {
    return defined('ELEMENTOR_PRO_VERSION');
}

/**
 * Three-state dependency check used by the tool registrars and the admin
 * notice:
 *   - 'ok'           → both Elementor and Elementor Pro are active
 *   - 'no_pro'       → Elementor is active but Elementor Pro is not
 *   - 'no_elementor' → Elementor itself is not active
 *
 * @return string
 */
function insationai_eprmcp_dependency_state(): string {
    if (!insationai_eprmcp_elementor_active()) {
        return 'no_elementor';
    }
    if (!insationai_eprmcp_elementor_pro_active()) {
        return 'no_pro';
    }
    return 'ok';
}

/**
 * Admin notice when a dependency is missing. Tools won't register without
 * BOTH Elementor and Elementor Pro. The message is specific about which
 * dependency is absent so the user knows exactly what to install.
 */
function insationai_eprmcp_dependency_notice() {
    $state = insationai_eprmcp_dependency_state();
    if ($state === 'ok') {
        return;
    }
    if (!current_user_can('activate_plugins')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    // Only show on plugin admin pages to avoid being noisy everywhere
    $is_relevant_screen = !$screen || in_array($screen->id ?? '', [
        'dashboard', 'plugins', 'toplevel_page_insationai-tools', 'toplevel_page_elementor-pro-mcp-tools',
        'insationai-tools_page_elementor-pro-mcp-tools', 'admin_page_elementor-pro-mcp-tools',
    ], true);
    if (!$is_relevant_screen) {
        return;
    }

    if ($state === 'no_elementor') {
        $msg = __('Elementor is not active. ElementorProMCP requires both Elementor and Elementor Pro — its tools will not be available until both are installed and activated.', 'elementor-pro-mcp');
    } else { // no_pro
        $msg = __('Elementor Pro is not active. ElementorProMCP needs Elementor Pro for the Theme Builder, display conditions and Pro widgets — its tools will not be available until Elementor Pro is installed and activated.', 'elementor-pro-mcp');
    }

    echo '<div class="notice notice-warning"><p>';
    echo '<strong>' . esc_html__('ElementorProMCP:', 'elementor-pro-mcp') . '</strong> ';
    echo esc_html($msg);
    echo '</p></div>';
}
add_action('admin_notices', 'insationai_eprmcp_dependency_notice');

/**
 * Dual-register ElementorProMCP tools as WP Abilities (WP 6.9+).
 *
 * Loaded unconditionally — register-abilities.php no-ops on older WP. Lives
 * in plugins_loaded so AbstractTool's namespace is autoloaded before the
 * Abilities API hook fires on init.
 */
function insationai_eprmcp_load_abilities_bridge() {
    require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/abilities/register-abilities.php';
}
add_action('plugins_loaded', 'insationai_eprmcp_load_abilities_bridge');

/**
 * Initialize automatic update checker.
 *
 * Updates are delivered via the WC Key Manager Software API on insation.ai
 * and are LICENSE-GATED (product owner decision): the checker only runs when
 * this install is licensed and active. An unlicensed/lapsed install does not
 * check for or receive updates — consistent with the strict licensing model.
 *
 * NOTE: src/UpdateChecker.php declares `namespace ElementorProMCP;` — the
 * instantiation below MUST use \ElementorProMCP\UpdateChecker. (Using the
 * WordpressMCP namespace here is the exact bug that fatally crashed the
 * ElementorMCP build; it is deliberately corrected for this plugin.)
 */
function insationai_eprmcp_init_update_checker() {
    // License gate: no license = no update checks at all.
    if (
        ! class_exists('InsationAI_EPRMCP_License_Service')
        || ! InsationAI_EPRMCP_License_Service::is_licensed()
    ) {
        return;
    }
    if (! class_exists('\\ElementorProMCP\\UpdateChecker')) {
        require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'src/UpdateChecker.php';
    }
    new \ElementorProMCP\UpdateChecker(
        'elementor-pro-mcp/elementor-pro-mcp.php',
        'https://insation.ai/?wckm-api=get_version'
    );

    // Wire the manual "Check for updates" handler + result notice. These
    // existed in UpdateChecker but were never hooked while the updater was
    // disabled; without this the Updates-tab button would be a dead link.
    add_action('admin_init', array('\\ElementorProMCP\\UpdateChecker', 'handleManualUpdateCheck'));
    add_action('admin_notices', array('\\ElementorProMCP\\UpdateChecker', 'displayUpdateCheckNotice'));
}

/**
 * Handle plugin version upgrades for backward compatibility
 *
 * Automatically migrates existing installations when plugin is updated.
 * This ensures users upgrading from 1.0.0 (no iwp_mcp_active check)
 * to 1.0.1+ (has iwp_mcp_active check) continue to work seamlessly.
 */
function insationai_eprmcp_handle_version_upgrade() {
    global $wpdb;

    $installed_version = get_option('insationai_eprmcp_version');

    // If version hasn't changed, nothing to do
    if ($installed_version === INSATIONAI_EPRMCP_VERSION) {
        return;
    }

    // Check if this is an existing installation (has user tokens table and tokens)
    $table_name = $wpdb->prefix . 'insationai_eprmcp_user_tokens';
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'");

    if ($table_exists === $table_name) {
        // Check if there are any existing tokens
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
        $has_tokens = $wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}`") > 0;

        if ($has_tokens) {
            // This is an existing installation being upgraded
            // Auto-set iwp_mcp_active to preserve access for existing users
            $current_value = get_option('iwp_mcp_active');

            if ($current_value !== 'true') {
                update_option('iwp_mcp_active', 'true');

                // Log the migration
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log(sprintf(
                        '[ElementorProMCP] Auto-migrated existing installation from version %s to %s - set iwp_mcp_active=true',
                        $installed_version ?: 'unknown',
                        INSATIONAI_EPRMCP_VERSION
                    ));
                }
            }
        }
    }

    // Update stored version
    update_option('insationai_eprmcp_version', INSATIONAI_EPRMCP_VERSION);
}

/**
 * Register rewrite rules for MCP endpoints and OAuth discovery
 */
function insationai_eprmcp_register_rewrite_rules() {
    $slug = get_option('insationai_eprmcp_endpoint_slug', 'elementor-pro-mcp');

    // MCP HTTP endpoint: /elementor-pro-mcp (always enabled)
    add_rewrite_rule(
        '^' . $slug . '/?$',
        'index.php?insationai_eprmcp_endpoint=1',
        'top'
    );

    // OAuth routes (only if feature is enabled)
    if (INSATIONAI_EPRMCP_OAUTH_FEATURE_ENABLED) {
        // RFC 8414 compliant OAuth metadata discovery
        // /.well-known/oauth-authorization-server/elementor-pro-mcp
        add_rewrite_rule(
            '^\.well-known/oauth-authorization-server/' . $slug . '/?$',
            'index.php?insationai_eprmcp_oauth_meta=authorization-server',
            'top'
        );

        add_rewrite_rule(
            '^\.well-known/oauth-protected-resource/' . $slug . '/?$',
            'index.php?insationai_eprmcp_oauth_meta=protected-resource',
            'top'
        );

        add_rewrite_rule(
            '^\.well-known/jwks\.json/' . $slug . '/?$',
            'index.php?insationai_eprmcp_oauth_meta=jwks',
            'top'
        );

        // OAuth authorization and token endpoints
        add_rewrite_rule(
            '^' . $slug . '/oauth/(authorize|token)/?$',
            'index.php?insationai_eprmcp_oauth=$matches[1]',
            'top'
        );
    }
}

/**
 * Register custom query vars
 */
function insationai_eprmcp_register_query_vars($vars) {
    $vars[] = 'insationai_eprmcp_endpoint';
    $vars[] = 'insationai_eprmcp_oauth_meta';
    $vars[] = 'insationai_eprmcp_oauth';
    return $vars;
}

/**
 * Handle template redirect for MCP endpoints
 */
function insationai_eprmcp_handle_request() {
    // Validate site authorization for runtime requests
    if (get_query_var('insationai_eprmcp_endpoint') || get_query_var('insationai_eprmcp_oauth_meta') || get_query_var('insationai_eprmcp_oauth')) {
        // Load validator class if not already loaded
        if (!class_exists('\InsationAI\ElementorProMCP\Validator')) {
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'src/Validator.php';
        }

        if (!\InsationAI\ElementorProMCP\Validator::isAuthorized()) {
            \InsationAI\ElementorProMCP\Validator::logUnauthorizedAttempt('runtime');

            // Return 403 Forbidden
            status_header(403);
            nocache_headers();
            echo 'Forbidden';
            exit;
        }
    }

    // Handle MCP HTTP endpoint — gated on a valid, active license.
    // STRICT model (product owner decision): if the plugin is not licensed
    // (including: no key, invalid/expired key, OR the license server is
    // unreachable — no grace period), the MCP endpoint does not serve.
    if (get_query_var('insationai_eprmcp_endpoint')) {
        if (
            class_exists('InsationAI_EPRMCP_License_Service')
            && InsationAI_EPRMCP_License_Service::is_licensed()
        ) {
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/endpoints/mcp-http.php';
            exit;
        }
        status_header(403);
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        $reason = 'license_inactive';
        if (class_exists('InsationAI_EPRMCP_License_Service')) {
            $st = InsationAI_EPRMCP_License_Service::get_state();
            $reason = isset($st['reason_code']) ? $st['reason_code'] : $reason;
        }
        echo wp_json_encode(array(
            'error'   => 'license_inactive',
            'reason'  => $reason,
            'message' => 'This ElementorProMCP installation is not licensed. '
                       . 'Enter and activate a valid license key in '
                       . 'WP Admin → InsationAI Tools to enable the MCP endpoint.',
        ));
        exit;
    }

    // OAuth endpoints (only if feature is enabled)
    if (!INSATIONAI_EPRMCP_OAUTH_FEATURE_ENABLED) {
        return;
    }

    // Handle OAuth metadata endpoints
    if ($meta = get_query_var('insationai_eprmcp_oauth_meta')) {
        insationai_eprmcp_serve_oauth_metadata($meta);
        exit;
    }

    // Handle OAuth flow endpoints
    if ($oauth = get_query_var('insationai_eprmcp_oauth')) {
        insationai_eprmcp_handle_oauth_flow($oauth);
        exit;
    }
}
add_action('template_redirect', 'insationai_eprmcp_handle_request', 1);

/**
 * Serve OAuth metadata endpoints
 */
function insationai_eprmcp_serve_oauth_metadata($type) {
    switch ($type) {
        case 'authorization-server':
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/well-known/oauth-authorization-server.php';
            break;
        case 'protected-resource':
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/well-known/oauth-protected-resource.php';
            break;
        case 'jwks':
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/well-known/jwks.php';
            break;
    }
}

/**
 * Handle OAuth flow endpoints
 */
function insationai_eprmcp_handle_oauth_flow($flow) {
    switch ($flow) {
        case 'authorize':
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/oauth/authorize.php';
            break;
        case 'token':
            require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'includes/oauth/token.php';
            break;
    }
}

/**
 * Detect if WordpressMCP is active by checking for its main plugin file.
 *
 * @return bool
 */
function insationai_eprmcp_wordpressmcp_active(): bool {
    // Signal 1 — the WordpressMCP main plugin file defines this constant when
    // it loads. By the time admin_menu fires, all active plugins have loaded,
    // so this is reliable regardless of what folder WordpressMCP installed into.
    if (defined('INSATIONAI_WPMCP_VERSION')) {
        return true;
    }

    // Signal 2 — scan the active plugins list for the WordpressMCP main file by
    // FILENAME, not by a hardcoded folder path. WordPress may install the plugin
    // under 'insationai-wordpress-mcp', 'insationai-wordpress-mcp-1', or any
    // name derived from the uploaded zip; matching on the trailing
    // '/insationai-wordpress-mcp.php' (or a bare filename) handles every case.
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $active = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }
    foreach ($active as $plugin_path) {
        if (basename($plugin_path) === 'insationai-wordpress-mcp.php') {
            return true;
        }
    }

    // Signal 3 — a WordpressMCP-defined function exists (covers the edge case
    // where the constant check was missed but the plugin's code is loaded).
    if (function_exists('insationai_wpmcp_register_abilities')) {
        return true;
    }

    return false;
}

/**
 * Add admin menu.
 *
 * Behavior depends on whether WordpressMCP is active on the same site:
 *
 *   - If WordpressMCP is active → ElementorProMCP attaches itself as a submenu
 *     under WordpressMCP's "InsationAI Tools" parent menu (slug: "insationai-tools").
 *     This way the user sees a single grouped "InsationAI Tools" item with both
 *     WordpressMCP and ElementorProMCP as children, plus shared "Upload New Version".
 *
 *   - If WordpressMCP is NOT active → ElementorProMCP creates its own top-level
 *     "InsationAI Tools" menu at position 67. The first time WordpressMCP is
 *     activated alongside it, the two will coexist under separate parent slugs
 *     until ElementorProMCP's parent is re-registered. (Either deactivate/reactivate
 *     ElementorProMCP after installing WordpressMCP, or just live with two top-level
 *     entries — they don't conflict functionally.)
 *
 * Hook priority 12 fires AFTER WordpressMCP (priority 10) and ElementorMCP
 * (priority 11), so when all three plugins are active this one's submenu sorts
 * last under the shared "InsationAI Tools" parent, and we can reliably detect
 * WordpressMCP's parent menu before attaching to it.
 */
function insationai_eprmcp_add_admin_menu() {
    $parent_slug = 'elementor-pro-mcp-tools';
    $hasParent   = false;

    if (insationai_eprmcp_wordpressmcp_active()) {
        // Attach under WordpressMCP's parent menu
        $parent_slug = 'insationai-tools';
        $hasParent   = true;
    } else {
        // Stand-alone: create our own top-level menu, positioned just below
        // where WordpressMCP would put its own (66) — slot 68 keeps it below
        // ElementorMCP's stand-alone slot 67.
        add_menu_page(
            __('InsationAI Tools', 'elementor-pro-mcp'),
            __('InsationAI Tools', 'elementor-pro-mcp'),
            'manage_options',
            $parent_slug,
            'insationai_eprmcp_settings_page',
            'dashicons-superhero-alt',
            68
        );
    }

    // ElementorProMCP submenu — always present, attaching to whichever parent we chose
    add_submenu_page(
        $parent_slug,
        __('ElementorProMCP', 'elementor-pro-mcp'),
        __('ElementorProMCP', 'elementor-pro-mcp'),
        'manage_options',
        'elementor-pro-mcp-tools',  // page slug stays stable so the Settings link works
        'insationai_eprmcp_settings_page'
    );

    // NOTE: "Upload New Version" is intentionally NOT registered here.
    //   - Companion mode (WordpressMCP active): WordpressMCP registers the
    //     shared "Upload New Version" item on its own late priority-99 hook,
    //     so it already sorts below the ElementorProMCP entry. We add nothing.
    //   - Stand-alone mode: insationai_eprmcp_add_upload_submenu() adds it on a
    //     late hook with an explicit bottom position. See below.
}
add_action('admin_menu', 'insationai_eprmcp_add_admin_menu', 12);

/**
 * Register "Upload New Version" LAST — stand-alone mode only.
 *
 * Runs on admin_menu priority 99. When WordpressMCP is active it owns the
 * shared "Upload New Version" entry (also at priority 99) under the
 * "insationai-tools" parent, so this function does nothing to avoid a
 * duplicate. When ElementorProMCP runs stand-alone, this adds the entry under
 * ElementorProMCP's own parent menu with an explicit PHP_INT_MAX position so it
 * sorts to the very bottom of the submenu.
 */
function insationai_eprmcp_add_upload_submenu() {
    // Companion mode: WordpressMCP handles the shared upload entry.
    if (insationai_eprmcp_wordpressmcp_active()) {
        return;
    }

    add_submenu_page(
        'elementor-pro-mcp-tools',
        __('Upload New Version', 'elementor-pro-mcp'),
        __('Upload New Version', 'elementor-pro-mcp'),
        'install_plugins',
        'plugin-install.php?tab=upload',
        '',
        PHP_INT_MAX  // $position — forces this item to the bottom of the submenu
    );
}
add_action('admin_menu', 'insationai_eprmcp_add_upload_submenu', 99);

/**
 * Add Settings link to plugin action links
 */
function insationai_eprmcp_add_settings_link($links) {
    $settings_link = sprintf(
        '<a href="%s">%s</a>',
        admin_url('admin.php?page=elementor-pro-mcp-tools'),
        __('Settings', 'elementor-pro-mcp')
    );
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'insationai_eprmcp_add_settings_link');

/**
 * Render admin settings page
 */
function insationai_eprmcp_settings_page() {
    require_once INSATIONAI_EPRMCP_PLUGIN_DIR . 'admin/settings.php';
}

/**
 * Get configuration array from WordPress options
 *
 * @return array Configuration array compatible with AuthenticationManager
 */
function insationai_eprmcp_get_config() {
    $config = [
        'safe_mode' => get_option('insationai_eprmcp_safe_mode', false),
        'oauth' => [
            'enabled' => get_option('insationai_eprmcp_oauth_enabled', false),
            'issuer' => get_option('insationai_eprmcp_oauth_issuer', home_url('/elementor-pro-mcp')),
            'resource_identifier' => get_option('insationai_eprmcp_oauth_resource_identifier', home_url('/elementor-pro-mcp')),
            'private_key_path' => get_option('insationai_eprmcp_oauth_private_key_path', ''),
            'public_key_path' => get_option('insationai_eprmcp_oauth_public_key_path', ''),
            'access_token_ttl' => get_option('insationai_eprmcp_oauth_access_token_ttl', 3600),
            'refresh_token_ttl' => get_option('insationai_eprmcp_oauth_refresh_token_ttl', 2592000),
            'authorization_code_ttl' => get_option('insationai_eprmcp_oauth_authorization_code_ttl', 600),
        ],
    ];

    // Define WP_MCP_SAFE_MODE constant for tools
    if ($config['safe_mode'] && !defined('WP_MCP_SAFE_MODE')) {
        define('WP_MCP_SAFE_MODE', true);
    }

    return $config;
}

/**
 * AJAX handler to dismiss activation error notice
 */
function insationai_eprmcp_dismiss_activation_error() {
    // Verify user has permission
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
        return;
    }

    // Delete the transient
    delete_transient('insationai_eprmcp_activation_errors');
    wp_send_json_success();
}
add_action('wp_ajax_insationai_eprmcp_dismiss_activation_error', 'insationai_eprmcp_dismiss_activation_error');


/**
 * Serve a custom robots.txt body when one is configured via the
 * manage_robots_txt tool. Runs only if a non-empty body is stored.
 */
add_filter('robots_txt', function ($output, $public) {
    $custom = get_option('insationai_eprmcp_robots_txt', '');
    if (is_string($custom) && $custom !== '') {
        return $custom;
    }
    return $output;
}, 99, 2);

/**
 * Apply redirects configured via the manage_redirects tool.
 *
 * Runs at template_redirect priority 1 so it fires before most plugins. Only
 * matches the exact request path (URI without query string). On match, sends
 * the configured status code and exits.
 */
add_action('template_redirect', function () {
    $redirects = get_option('insationai_eprmcp_redirects', []);
    if (!is_array($redirects) || empty($redirects)) {
        return;
    }
    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = parse_url($request_uri, PHP_URL_PATH);
    if (!is_string($path)) {
        return;
    }
    foreach ($redirects as $rule) {
        if (!is_array($rule) || empty($rule['source']) || empty($rule['target'])) {
            continue;
        }
        if ($rule['source'] === $path) {
            $status = (int) ($rule['status'] ?? 301);
            wp_redirect(esc_url_raw($rule['target']), $status);
            exit;
        }
    }
}, 1);

/**
 * AJAX handler — save the Tools tab toggle state.
 */
add_action('wp_ajax_insationai_eprmcp_save_tools', function () {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    check_ajax_referer('insationai_eprmcp_tools_toggle');

    $disabled = isset($_POST['disabled']) && is_array($_POST['disabled'])
        ? array_map('sanitize_text_field', wp_unslash($_POST['disabled']))
        : [];

    \InsationAI\ElementorProMCP\ToolRegistry::setDisabledToolNames($disabled);

    wp_send_json_success([
        'disabled_count' => count($disabled),
    ]);
});
