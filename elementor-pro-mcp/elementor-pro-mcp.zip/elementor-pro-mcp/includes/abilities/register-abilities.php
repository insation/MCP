<?php
/**
 * WordPress Abilities API registration.
 *
 * Dual-registers every ElementorProMCP tool as a WordPress Ability via wp_register_ability()
 * (introduced in WP 6.9). The tools also continue to be served via the custom
 * /elementor-pro-mcp HTTP endpoint — this file does not replace that endpoint, it
 * mirrors the same tools onto the WP-native Abilities API so that:
 *
 *   - Other WP plugins / first-party WP MCP clients that consume the Abilities
 *     API see ElementorProMCP's tools without needing the custom endpoint.
 *   - Sites can keep the ElementorProMCP HTTP endpoint disabled (custom-slug or
 *     firewalled) and still expose tools through the official WP MCP Adapter.
 *
 * The WP HTTP endpoint at /elementor-pro-mcp remains the canonical transport for
 * cloud-hosted clients (Claude Desktop, Cursor, etc.) using the bearer-token
 * flow this plugin provisions.
 *
 * @package ElementorProMCP
 * @since 1.1.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

use InsationAI\ElementorProMCP\Services\ContentPatchingService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

/**
 * Map of OAuth scope → minimum WordPress capability used by the Abilities
 * permission_callback. Mirrors what the OAuth scope check enforces inside
 * AbstractTool::checkScopeAuthorization().
 */
const INSATIONAI_EPRMCP_SCOPE_CAPABILITY_MAP = [
    'mcp:read'   => 'read',
    'mcp:write'  => 'edit_posts',
    'mcp:delete' => 'delete_posts',
    'mcp:admin'  => 'manage_options',
];

/**
 * Tool category for the Abilities API — used for grouping in admin UIs that
 * surface registered abilities. Delegates to ToolRegistry::categoryFor() so the
 * Abilities API, the MCP endpoint, and the admin Tools tab all agree on one
 * single source of truth.
 */
function insationai_eprmcp_ability_category_for(string $toolName): string
{
    return \InsationAI\ElementorProMCP\ToolRegistry::categoryFor($toolName);
}

/**
 * Register all ElementorProMCP tools as WordPress Abilities (WP 6.9+).
 *
 * No-op on WP < 6.9 (when wp_register_ability is undefined). The /elementor-pro-mcp
 * HTTP endpoint continues to work in either case.
 */
function insationai_eprmcp_register_abilities(): void
{
    if (!function_exists('wp_register_ability')) {
        return;
    }

    // Sanity: don't register on a site that hasn't authorized ElementorProMCP yet.
    if (class_exists('\InsationAI\ElementorProMCP\Validator') && !\InsationAI\ElementorProMCP\Validator::isAuthorized()) {
        return;
    }

    $wpService = new WordPressService();
    $validationService = new ValidationService();
    $logger = new WordPressLogger();
    $patchingService = new ContentPatchingService($wpService, $logger);

    $tools = \InsationAI\ElementorProMCP\ToolRegistry::buildEnabledTools(
        $wpService,
        $validationService,
        $logger,
        $patchingService
    );


    foreach ($tools as $tool) {
        insationai_eprmcp_register_one_ability($tool);
    }
}

function insationai_eprmcp_register_one_ability(AbstractTool $tool): void
{
    $name = $tool->getName();
    $scope = $tool->getRequiredScope();
    $capability = INSATIONAI_EPRMCP_SCOPE_CAPABILITY_MAP[$scope] ?? 'manage_options';
    $isDestructive = in_array($scope, ['mcp:write', 'mcp:delete', 'mcp:admin'], true);
    $isReadonly = $scope === 'mcp:read';

    wp_register_ability("insationai-eprmcp/{$name}", [
        'label'              => $name,
        'description'        => $tool->getDescription(),
        'category'           => insationai_eprmcp_ability_category_for($name),
        'input_schema'       => $tool->getInputSchema(),
        'output_schema'      => [
            'type' => 'object',
            'description' => 'Tool execution result. Shape varies per tool — see description.',
            'additionalProperties' => true,
        ],
        'execute_callback'   => static function ($input) use ($tool) {
            // The Abilities API runs in standard WP request context. The user
            // is whoever WP says — wp_get_current_user(). Build a minimal user
            // context so AbstractTool's scope check has something to look at.
            $current = wp_get_current_user();
            if ($current && $current->ID) {
                $tool->setUserContext([
                    'id' => (int) $current->ID,
                    'login' => (string) $current->user_login,
                    'username' => (string) $current->user_login,
                    'roles' => (array) $current->roles,
                    // Map: an authenticated WP user gets all scopes their
                    // capabilities cover. The capability check inside
                    // permission_callback already gated the call.
                    'scopes' => insationai_eprmcp_scopes_for_user($current),
                ]);
            }

            try {
                return $tool->execute(is_array($input) ? $input : []);
            } catch (\Throwable $e) {
                return new \WP_Error(
                    'insationai_eprmcp_tool_error',
                    $e->getMessage(),
                    ['status' => 400]
                );
            }
        },
        'permission_callback' => static function () use ($capability) {
            return current_user_can($capability);
        },
        'meta' => [
            'show_in_rest' => true,
            'mcp' => ['public' => true],
            'annotations' => [
                'readonly'    => $isReadonly,
                'destructive' => $isDestructive,
                'idempotent'  => false,
                'instructions' => 'Tool source: ElementorProMCP. See ' . home_url('/wp-admin/admin.php?page=elementor-pro-mcp-tools') . ' for token management.',
            ],
        ],
    ]);
}

function insationai_eprmcp_scopes_for_user(\WP_User $user): array
{
    $scopes = [];
    if (user_can($user, 'read')) {
        $scopes[] = 'mcp:read';
    }
    if (user_can($user, 'edit_posts')) {
        $scopes[] = 'mcp:write';
    }
    if (user_can($user, 'delete_posts')) {
        $scopes[] = 'mcp:delete';
    }
    if (user_can($user, 'manage_options')) {
        $scopes[] = 'mcp:admin';
    }
    return $scopes;
}

// WP 6.9+ requires abilities to be registered on the `wp_abilities_api_init`
// hook — registering earlier (e.g. on `init`) is rejected by core with a
// _doing_it_wrong() notice and the ability is NOT registered. We hook there
// when the Abilities API exists, and fall back to `init` priority 20 on older
// WordPress that predates it (where the function_exists('wp_register_ability')
// guard inside the function makes it a harmless no-op anyway). did_action()
// guards the rare case where this file loads after the hook already fired.
if (function_exists('wp_register_ability')) {
    if (did_action('wp_abilities_api_init')) {
        insationai_eprmcp_register_abilities();
    } else {
        add_action('wp_abilities_api_init', 'insationai_eprmcp_register_abilities', 20);
    }
} else {
    add_action('init', 'insationai_eprmcp_register_abilities', 20);
}
