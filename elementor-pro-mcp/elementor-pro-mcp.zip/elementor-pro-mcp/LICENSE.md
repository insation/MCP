# License

ElementorProMCP is licensed under the **GNU General Public License v2.0 or later (GPL-2.0-or-later)**.

The full GPL-2.0 license text is available at: https://www.gnu.org/licenses/gpl-2.0.html

## What this means

You are free to:

- **Use** ElementorProMCP on any WordPress site (personal, commercial, hosted, agency)
- **Modify** the source code for any purpose
- **Distribute** original or modified copies, provided you retain the GPL-2.0-or-later license terms
- **Combine** ElementorProMCP with other GPL-compatible code

## Warranty

ElementorProMCP is provided "as-is" without warranty of any kind, express or implied. See the GPL-2.0 license text for the full disclaimer.

## Copyright

Copyright (c) 2026 InsationAI and contributors.

Portions of this codebase are derived from prior GPL-2.0-licensed work; redistribution under GPL-2.0-or-later preserves all attribution required by the GPL.
