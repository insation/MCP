<?php
/**
 * Elementor Service
 *
 * Lightweight wrapper around Elementor's plugin singleton. Keeps tools free
 * of hard \Elementor\Plugin references and centralizes the "Elementor
 * available?" check.
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Services;

use InsationAI\ElementorProMCP\Exceptions\ToolException;

class ElementorService
{
    /**
     * Throw if Elementor is not loaded. Tools call this at the top of doExecute.
     *
     * @throws ToolException
     */
    public function requireElementor(): void
    {
        if (!class_exists('\Elementor\Plugin')) {
            throw ToolException::wordpressError(
                'Elementor (free) is not installed or active. ElementorProMCP requires Elementor to function.'
            );
        }
    }

    /**
     * Get the Elementor Plugin singleton.
     *
     * @return \Elementor\Plugin
     */
    public function plugin(): object
    {
        $this->requireElementor();
        return \Elementor\Plugin::$instance;
    }

    /**
     * Get a document by post ID. Returns the Elementor Document object.
     *
     * @param int $post_id
     * @return object|null Document instance, or null if not Elementor-built.
     */
    public function getDocument(int $post_id): ?object
    {
        $doc = $this->plugin()->documents->get($post_id);
        if (!$doc || !is_object($doc)) {
            return null;
        }
        // Some calls return ProxyClass — confirm it's an actual Document
        if (!method_exists($doc, 'is_built_with_elementor')) {
            return null;
        }
        return $doc->is_built_with_elementor() ? $doc : null;
    }

    /**
     * Get the raw Elementor data tree (array of element dictionaries) for a post.
     * Decoded from the _elementor_data post meta.
     *
     * @param int $post_id
     * @return array<int, array<string, mixed>>
     */
    public function getDocumentData(int $post_id): array
    {
        $doc = $this->getDocument($post_id);
        if (!$doc) {
            return [];
        }
        $data = $doc->get_elements_data();
        return is_array($data) ? $data : [];
    }

    /**
     * Save data back to a document. Uses Elementor's own save_elements method
     * which handles validation, sanitization, and CSS regen invalidation.
     *
     * @param int $post_id
     * @param array<int, array<string, mixed>> $data
     * @return bool True on success.
     */
    public function saveDocumentData(int $post_id, array $data): bool
    {
        $doc = $this->getDocument($post_id);
        if (!$doc) {
            return false;
        }
        return (bool) $doc->save([
            'elements' => $data,
        ]);
    }

    /**
     * Recursively walk every element in a document tree, yielding [path, element].
     * The path is an integer array describing how to navigate from the root to
     * this element (e.g. [0, 1, 2] = root[0].elements[1].elements[2]).
     *
     * @param array<int, array<string, mixed>> $elements
     * @param array<int> $pathPrefix
     * @return \Generator<array{path: array<int>, element: array<string, mixed>}>
     */
    public function walkElements(array $elements, array $pathPrefix = []): \Generator
    {
        foreach ($elements as $i => $el) {
            $path = array_merge($pathPrefix, [$i]);
            yield ['path' => $path, 'element' => $el];
            if (!empty($el['elements']) && is_array($el['elements'])) {
                yield from $this->walkElements($el['elements'], $path);
            }
        }
    }

    /**
     * Find an element by its `id` field anywhere in the tree.
     *
     * @return array{path: array<int>, element: array<string, mixed>}|null
     */
    public function findElementById(array $elements, string $elementId): ?array
    {
        foreach ($this->walkElements($elements) as $entry) {
            if (($entry['element']['id'] ?? null) === $elementId) {
                return $entry;
            }
        }
        return null;
    }

    /**
     * Replace the element at the given path within $elements. Returns the
     * modified tree.
     *
     * @param array<int, array<string, mixed>> $elements
     * @param array<int> $path
     * @param array<string, mixed>|null $newElement Pass null to delete.
     * @return array<int, array<string, mixed>>
     */
    public function replaceAtPath(array $elements, array $path, ?array $newElement): array
    {
        if (empty($path)) {
            return $elements;
        }
        return $this->writeAtPath($elements, $path, $newElement);
    }

    private function writeAtPath(array $elements, array $path, ?array $newElement): array
    {
        if (count($path) === 1) {
            $i = $path[0];
            if ($newElement === null) {
                array_splice($elements, $i, 1);
            } else {
                $elements[$i] = $newElement;
            }
            return array_values($elements);
        }
        $i = array_shift($path);
        if (!isset($elements[$i])) {
            return $elements;
        }
        $children = $elements[$i]['elements'] ?? [];
        $elements[$i]['elements'] = $this->writeAtPath($children, $path, $newElement);
        return $elements;
    }

    /**
     * Insert $newElement at $path. The last index of $path becomes its
     * position among its siblings.
     */
    public function insertAtPath(array $elements, array $path, array $newElement): array
    {
        if (empty($path)) {
            return $elements;
        }
        return $this->doInsertAtPath($elements, $path, $newElement);
    }

    private function doInsertAtPath(array $elements, array $path, array $newElement): array
    {
        if (count($path) === 1) {
            $i = $path[0];
            array_splice($elements, $i, 0, [$newElement]);
            return array_values($elements);
        }
        $i = array_shift($path);
        if (!isset($elements[$i])) {
            return $elements;
        }
        $children = $elements[$i]['elements'] ?? [];
        $elements[$i]['elements'] = $this->doInsertAtPath($children, $path, $newElement);
        return $elements;
    }

    /**
     * Generate a new random Elementor element ID (7-char hex, matching Elementor's format).
     */
    public function newElementId(): string
    {
        return substr(md5(uniqid('emcp_', true)), 0, 7);
    }

    /**
     * Recursively assign fresh element IDs to an element and all of its
     * descendants. Used when duplicating or inserting an element so the tree
     * never contains two elements with the same id (which corrupts Elementor's
     * editor and CSS generation).
     *
     * @param array<string, mixed> $element
     * @return array<string, mixed>
     */
    public function regenerateIds(array $element): array
    {
        $element['id'] = $this->newElementId();
        if (!empty($element['elements']) && is_array($element['elements'])) {
            $element['elements'] = array_map(
                fn($child) => $this->regenerateIds($child),
                $element['elements']
            );
        }
        return $element;
    }

    /**
     * Validate that an element dictionary has the minimum shape Elementor
     * requires: an elType, and (for widgets) a widgetType. Returns an array
     * of human-readable problems; empty array means the element looks valid.
     *
     * @param array<string, mixed> $element
     * @return string[]
     */
    public function validateElementShape(array $element): array
    {
        $problems = [];
        $elType = $element['elType'] ?? null;
        if (!is_string($elType) || $elType === '') {
            $problems[] = 'Missing or empty "elType".';
        } elseif (!in_array($elType, ['section', 'column', 'container', 'widget'], true)) {
            $problems[] = "Unrecognized elType '{$elType}' (expected section, column, container, or widget).";
        }
        if ($elType === 'widget' && empty($element['widgetType'])) {
            $problems[] = 'elType is "widget" but "widgetType" is missing.';
        }
        if (isset($element['settings']) && !is_array($element['settings'])) {
            $problems[] = '"settings" must be an object.';
        }
        if (isset($element['elements']) && !is_array($element['elements'])) {
            $problems[] = '"elements" must be an array.';
        }
        return $problems;
    }

    /**
     * Find the integer path to an element by id, or null if not present.
     *
     * @param array<int, array<string, mixed>> $elements
     * @return array<int>|null
     */
    public function pathToId(array $elements, string $elementId): ?array
    {
        $found = $this->findElementById($elements, $elementId);
        return $found['path'] ?? null;
    }

    /* ------------------------------------------------------------------ */
    /* Templates & Library helpers (1.0.4)                                */
    /* ------------------------------------------------------------------ */

    /**
     * The post type Elementor uses for its template library.
     */
    public const TEMPLATE_CPT = 'elementor_library';

    /**
     * Get the Elementor template-library type of a library post
     * (page, section, container, header, footer, popup, etc.) from its
     * elementor_library_type taxonomy term, falling back to the
     * _elementor_template_type post meta.
     */
    public function getTemplateType(int $postId): ?string
    {
        $terms = wp_get_object_terms($postId, 'elementor_library_type', ['fields' => 'slugs']);
        if (!is_wp_error($terms) && !empty($terms)) {
            return (string) $terms[0];
        }
        $meta = get_post_meta($postId, '_elementor_template_type', true);
        return $meta !== '' ? (string) $meta : null;
    }

    /**
     * Set the template-library type for a library post — writes both the
     * taxonomy term and the meta key so Elementor's UI and queries agree.
     */
    public function setTemplateType(int $postId, string $type): void
    {
        wp_set_object_terms($postId, $type, 'elementor_library_type');
        update_post_meta($postId, '_elementor_template_type', $type);
    }

    /**
     * Return the Elementor templates_manager, or throw if unavailable.
     */
    public function templatesManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->templates_manager ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor templates manager is not available.');
        }
        return $mgr;
    }

    /* ------------------------------------------------------------------ */
    /* Global Kit helpers (1.0.4)                                         */
    /* ------------------------------------------------------------------ */

    /**
     * Return the kits_manager, or throw if unavailable.
     */
    public function kitsManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->kits_manager ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor kits manager is not available.');
        }
        return $mgr;
    }

    /**
     * The active kit's post ID (0 if none).
     */
    public function activeKitId(): int
    {
        return (int) $this->kitsManager()->get_active_id();
    }

    /**
     * Read the active kit's settings array (the full _elementor_page_settings
     * meta of the kit post — colors, fonts, typography, layout defaults).
     *
     * @return array<string, mixed>
     */
    public function getKitSettings(?int $kitId = null): array
    {
        $kitId = $kitId ?? $this->activeKitId();
        if ($kitId <= 0) {
            return [];
        }
        $settings = get_post_meta($kitId, '_elementor_page_settings', true);
        return is_array($settings) ? $settings : [];
    }

    /**
     * Write the kit's settings array back to post meta and clear Elementor's
     * CSS cache so the change takes effect on the front end.
     *
     * @param array<string, mixed> $settings
     */
    public function saveKitSettings(array $settings, ?int $kitId = null): bool
    {
        $kitId = $kitId ?? $this->activeKitId();
        if ($kitId <= 0) {
            return false;
        }
        update_post_meta($kitId, '_elementor_page_settings', $settings);
        // Regenerate CSS so the kit change is reflected on the front end.
        if (method_exists($this->plugin()->files_manager, 'clear_cache')) {
            $this->plugin()->files_manager->clear_cache();
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* Revisions helpers (1.0.5)                                          */
    /* ------------------------------------------------------------------ */

    /**
     * Return the Elementor revisions for a document as lightweight rows.
     * Uses WordPress' own revision store; Elementor revisions are just WP
     * post revisions that carry the _elementor_data meta.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getRevisions(int $postId, int $limit = 30): array
    {
        $revisions = wp_get_post_revisions($postId, [
            'posts_per_page' => $limit,
        ]);
        $rows = [];
        foreach ($revisions as $rev) {
            $rows[] = [
                'revision_id' => $rev->ID,
                'author_id'   => (int) $rev->post_author,
                'date_gmt'    => $rev->post_modified_gmt,
                'type'        => (false !== strpos($rev->post_name, 'autosave')) ? 'autosave' : 'revision',
                'has_elementor_data' => (get_metadata('post', $rev->ID, '_elementor_data', true) !== ''),
            ];
        }
        return $rows;
    }

    /**
     * Read the parsed Elementor element tree stored on a specific revision.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getRevisionData(int $revisionId): array
    {
        $raw = get_metadata('post', $revisionId, '_elementor_data', true);
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            return is_array($decoded) ? $decoded : [];
        }
        return is_array($raw) ? $raw : [];
    }

    /* ------------------------------------------------------------------ */
    /* Page settings helpers (1.0.5)                                      */
    /* ------------------------------------------------------------------ */

    /**
     * Read a document's per-page Elementor settings (the _elementor_page_settings
     * meta — page layout, custom CSS for Pro, body background, etc.).
     *
     * @return array<string, mixed>
     */
    public function getPageSettings(int $postId): array
    {
        $settings = get_post_meta($postId, '_elementor_page_settings', true);
        return is_array($settings) ? $settings : [];
    }

    /**
     * Write a document's per-page Elementor settings and clear that
     * document's CSS cache.
     *
     * @param array<string, mixed> $settings
     */
    public function savePageSettings(int $postId, array $settings): bool
    {
        update_post_meta($postId, '_elementor_page_settings', $settings);
        // Clear the per-post CSS so the change is reflected.
        if (method_exists($this->plugin()->files_manager, 'clear_cache')) {
            $this->plugin()->files_manager->clear_cache();
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* Dynamic tags helpers (1.0.5)                                       */
    /* ------------------------------------------------------------------ */

    /**
     * Return the dynamic_tags manager, or throw if unavailable.
     */
    public function dynamicTagsManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->dynamic_tags ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor dynamic tags manager is not available.');
        }
        return $mgr;
    }

    /* ------------------------------------------------------------------ */
    /* Experiments helpers (1.0.6)                                        */
    /* ------------------------------------------------------------------ */

    /**
     * Return the experiments manager, or throw if unavailable.
     */
    public function experimentsManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->experiments ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor experiments manager is not available.');
        }
        return $mgr;
    }

    /**
     * The wp_options key Elementor uses to store an experiment's state.
     */
    public function experimentOptionKey(string $featureName): string
    {
        return 'elementor_experiment-' . $featureName;
    }

    /* ------------------------------------------------------------------ */
    /* Cache helpers (1.0.6)                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Clear Elementor's generated CSS / file cache. Returns true if the
     * files manager exposed a clear_cache method and it was called.
     */
    public function clearCache(): bool
    {
        $fm = $this->plugin()->files_manager ?? null;
        if ($fm !== null && method_exists($fm, 'clear_cache')) {
            $fm->clear_cache();
            return true;
        }
        return false;
    }

    /* ------------------------------------------------------------------ */
    /* Maintenance mode helpers (1.0.6)                                   */
    /* ------------------------------------------------------------------ */

    /**
     * Elementor stores maintenance-mode settings under wp_options keys
     * prefixed with this string (mode, exclude_mode, exclude_roles,
     * template_id).
     */
    public const MAINTENANCE_OPTION_PREFIX = 'elementor_maintenance_mode_';

    /**
     * Read a maintenance-mode option (e.g. 'mode', 'template_id').
     *
     * @return mixed
     */
    public function getMaintenanceOption(string $key, $default = false)
    {
        return get_option(self::MAINTENANCE_OPTION_PREFIX . $key, $default);
    }

    /**
     * Write a maintenance-mode option.
     *
     * @param mixed $value
     */
    public function setMaintenanceOption(string $key, $value): bool
    {
        return update_option(self::MAINTENANCE_OPTION_PREFIX . $key, $value);
    }

    /* ------------------------------------------------------------------ */
    /* Role manager helpers (1.0.7)                                       */
    /* ------------------------------------------------------------------ */

    /**
     * The wp_options key Elementor's Role Manager stores its restrictions in.
     * The value is an array keyed by role slug; a role mapped to
     * ['type' => 'do-not-allow'] cannot use the Elementor editor.
     */
    public const ROLE_MANAGER_OPTION = 'elementor_role-manager';

    /**
     * Read the Elementor Role Manager restrictions array.
     *
     * @return array<string, mixed>
     */
    public function getRoleRestrictions(): array
    {
        $value = get_option(self::ROLE_MANAGER_OPTION, []);
        return is_array($value) ? $value : [];
    }

    /**
     * Write the Elementor Role Manager restrictions array.
     *
     * @param array<string, mixed> $restrictions
     */
    public function saveRoleRestrictions(array $restrictions): bool
    {
        return update_option(self::ROLE_MANAGER_OPTION, $restrictions);
    }

    /* ------------------------------------------------------------------ */
    /* Fonts helpers (1.0.7)                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Return Elementor's font list as [font_name => group] pairs.
     * Uses the static \Elementor\Fonts API.
     *
     * @return array<string, string>
     */
    public function getFonts(): array
    {
        $this->requireElementor();
        if (class_exists('\Elementor\Fonts') && method_exists('\Elementor\Fonts', 'get_fonts')) {
            $fonts = \Elementor\Fonts::get_fonts();
            return is_array($fonts) ? $fonts : [];
        }
        return [];
    }

    /**
     * Return Elementor's font groups as [group_slug => label] pairs.
     *
     * @return array<string, string>
     */
    public function getFontGroups(): array
    {
        $this->requireElementor();
        if (class_exists('\Elementor\Fonts') && method_exists('\Elementor\Fonts', 'get_font_groups')) {
            $groups = \Elementor\Fonts::get_font_groups();
            return is_array($groups) ? $groups : [];
        }
        return [];
    }

    /* ===================================================================
     * Elementor Pro — Theme Builder layer
     *
     * Everything below requires Elementor Pro to be active. Each accessor
     * is guarded: it throws a RuntimeException with a clear message if Pro
     * or the expected Pro internals are missing, rather than fataling. Pro
     * internals have shifted across versions, so every class/method touch
     * is defensive.
     * ================================================================= */

    /**
     * The post meta key Elementor Pro uses to store a theme template's
     * display conditions. Stable across Pro 3.x/4.x.
     */
    public const CONDITIONS_META_KEY = '_elementor_conditions';

    /**
     * Theme Builder document type slugs (as returned by each document's
     * get_type()). Used to identify and filter theme-builder templates.
     *
     * @var string[]
     */
    public const THEME_BUILDER_TYPES = [
        'header',
        'footer',
        'single-post',
        'single-page',
        'single',
        'archive',
        'search-results',
        'error-404',
        'section',
    ];

    /**
     * Assert that Elementor Pro is active. Throw a clear error otherwise.
     *
     * @throws \RuntimeException
     */
    public function requireElementorPro(): void
    {
        $this->requireElementor();
        if (!defined('ELEMENTOR_PRO_VERSION')) {
            throw new \RuntimeException(
                'Elementor Pro is not active. This tool requires Elementor Pro for Theme Builder functionality.'
            );
        }
    }

    /**
     * Whether Elementor Pro is active.
     */
    public function isProActive(): bool
    {
        return defined('ELEMENTOR_PRO_VERSION');
    }

    /**
     * The installed Elementor Pro version string, or null if Pro is inactive.
     */
    public function getProVersion(): ?string
    {
        return defined('ELEMENTOR_PRO_VERSION') ? (string) ELEMENTOR_PRO_VERSION : null;
    }

    /**
     * Get the Elementor Pro plugin instance.
     *
     * @return object \ElementorPro\Plugin
     * @throws \RuntimeException
     */
    public function proPlugin(): object
    {
        $this->requireElementorPro();
        if (!class_exists('\ElementorPro\Plugin')) {
            throw new \RuntimeException('ElementorPro\Plugin class not found — Elementor Pro internals unavailable.');
        }
        return \ElementorPro\Plugin::instance();
    }

    /**
     * Get the Theme Builder module instance.
     *
     * @return object \ElementorPro\Modules\ThemeBuilder\Module
     * @throws \RuntimeException
     */
    public function themeBuilderModule(): object
    {
        $this->requireElementorPro();
        $module = null;

        // Preferred: via the Pro plugin's modules manager.
        $pro = $this->proPlugin();
        if (isset($pro->modules_manager) && is_object($pro->modules_manager)
            && method_exists($pro->modules_manager, 'get_modules')) {
            $module = $pro->modules_manager->get_modules('theme-builder');
        }

        // Fallback: the module's own static instance().
        if (!is_object($module) && class_exists('\ElementorPro\Modules\ThemeBuilder\Module')
            && method_exists('\ElementorPro\Modules\ThemeBuilder\Module', 'instance')) {
            $module = \ElementorPro\Modules\ThemeBuilder\Module::instance();
        }

        if (!is_object($module)) {
            throw new \RuntimeException('Elementor Pro Theme Builder module could not be loaded.');
        }
        return $module;
    }

    /**
     * Get the Theme Builder Conditions_Manager.
     *
     * @return object \ElementorPro\Modules\ThemeBuilder\Classes\Conditions_Manager
     * @throws \RuntimeException
     */
    public function conditionsManager(): object
    {
        $module = $this->themeBuilderModule();
        if (!method_exists($module, 'get_conditions_manager')) {
            throw new \RuntimeException('Theme Builder conditions manager API not available in this Elementor Pro version.');
        }
        $manager = $module->get_conditions_manager();
        if (!is_object($manager)) {
            throw new \RuntimeException('Theme Builder conditions manager could not be loaded.');
        }
        return $manager;
    }

    /**
     * Get the Theme Builder Locations_Manager.
     *
     * @return object \ElementorPro\Modules\ThemeBuilder\Classes\Locations_Manager
     * @throws \RuntimeException
     */
    public function locationsManager(): object
    {
        $module = $this->themeBuilderModule();
        if (!method_exists($module, 'get_locations_manager')) {
            throw new \RuntimeException('Theme Builder locations manager API not available in this Elementor Pro version.');
        }
        $manager = $module->get_locations_manager();
        if (!is_object($manager)) {
            throw new \RuntimeException('Theme Builder locations manager could not be loaded.');
        }
        return $manager;
    }

    /**
     * Determine whether a post is a Theme Builder template, and if so its type.
     *
     * @param int $postId
     * @return string|null The theme-builder type slug, or null if not a TB template.
     */
    public function getThemeBuilderType(int $postId): ?string
    {
        $type = $this->getTemplateType($postId);
        if ($type === null) {
            return null;
        }
        return in_array($type, self::THEME_BUILDER_TYPES, true) ? $type : null;
    }

    /**
     * List all Theme Builder template posts, optionally filtered by type.
     *
     * @param string|null $type One of THEME_BUILDER_TYPES, or null for all.
     * @return array<int, array{id:int,title:string,type:?string,status:string,modified:string}>
     */
    public function listThemeBuilderTemplates(?string $type = null): array
    {
        $this->requireElementorPro();

        $args = [
            'post_type'      => 'elementor_library',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'tax_query'      => [[
                'taxonomy' => 'elementor_library_type',
                'field'    => 'slug',
                'terms'    => $type !== null ? [$type] : self::THEME_BUILDER_TYPES,
            ]],
        ];

        $query = new \WP_Query($args);
        $out = [];
        foreach ($query->posts as $post) {
            $out[] = [
                'id'       => (int) $post->ID,
                'title'    => $post->post_title,
                'type'     => $this->getTemplateType((int) $post->ID),
                'status'   => $post->post_status,
                'modified' => $post->post_modified_gmt,
            ];
        }
        return $out;
    }

    /**
     * Read a theme template's stored display conditions.
     *
     * Conditions are stored as an array of slash-delimited strings, e.g.
     * "include/general", "include/singular/post/in_id/42", "exclude/archive".
     *
     * @param int $postId
     * @return string[]
     */
    public function getTemplateConditions(int $postId): array
    {
        $this->requireElementorPro();
        $raw = get_post_meta($postId, self::CONDITIONS_META_KEY, true);
        if (!is_array($raw)) {
            return [];
        }
        return array_values(array_filter(array_map('strval', $raw)));
    }

    /**
     * Persist a theme template's display conditions, replacing any existing set.
     *
     * Routes through the Conditions_Manager when its save API is available so
     * Pro's condition cache is invalidated; falls back to a direct meta write.
     *
     * @param int      $postId
     * @param string[] $conditions
     * @return bool
     */
    public function saveTemplateConditions(int $postId, array $conditions): bool
    {
        $this->requireElementorPro();
        $clean = array_values(array_filter(array_map('strval', $conditions)));

        // Preferred path: Conditions_Manager::save_conditions() handles cache purge.
        try {
            $manager = $this->conditionsManager();
            if (method_exists($manager, 'save_conditions')) {
                $manager->save_conditions($postId, $clean);
                return true;
            }
        } catch (\Throwable $e) {
            // Fall through to direct meta write below.
        }

        if (empty($clean)) {
            delete_post_meta($postId, self::CONDITIONS_META_KEY);
        } else {
            update_post_meta($postId, self::CONDITIONS_META_KEY, $clean);
        }

        // Best-effort cache clear.
        try {
            $manager = $this->conditionsManager();
            if (method_exists($manager, 'clear_cache')) {
                $manager->clear_cache();
            }
        } catch (\Throwable $e) {
            // Non-fatal.
        }
        return true;
    }

    /**
     * Get the conditions config tree — what condition types exist and how they
     * nest. This is what the Theme Builder UI uses to build its condition picker.
     *
     * @return array<mixed>
     */
    public function getConditionsConfig(): array
    {
        $manager = $this->conditionsManager();
        if (!method_exists($manager, 'get_conditions_config')) {
            return [];
        }
        $config = $manager->get_conditions_config();
        return is_array($config) ? $config : [];
    }

    /**
     * Detect conflicts for a given condition + location: other templates that
     * already claim the same location.
     *
     * @param int    $postId    The template whose condition we're testing.
     * @param string $condition A single condition string.
     * @return array<mixed>
     */
    public function getConditionsConflicts(int $postId, string $condition): array
    {
        $manager = $this->conditionsManager();
        if (!method_exists($manager, 'get_conditions_conflicts')) {
            return [];
        }
        $conflicts = $manager->get_conditions_conflicts($postId, $condition);
        return is_array($conflicts) ? $conflicts : [];
    }

    /**
     * Get the registered Theme Builder locations.
     *
     * @param array<string,mixed> $filterArgs Optional filter args passed through
     *                                        to Locations_Manager::get_locations().
     * @return array<string, mixed>
     */
    public function getLocations(array $filterArgs = []): array
    {
        $manager = $this->locationsManager();
        if (!method_exists($manager, 'get_locations')) {
            return [];
        }
        $locations = $manager->get_locations($filterArgs);
        return is_array($locations) ? $locations : [];
    }

    /**
     * Get the config for a single location.
     *
     * @param string $location
     * @return array<string,mixed>|null
     */
    public function getLocation(string $location): ?array
    {
        $manager = $this->locationsManager();
        if (!method_exists($manager, 'get_location')) {
            return null;
        }
        $config = $manager->get_location($location);
        return is_array($config) ? $config : null;
    }

    /**
     * Get the template post IDs assigned to a location.
     *
     * @param string $location
     * @return int[]
     */
    public function getLocationTemplates(string $location): array
    {
        $manager = $this->conditionsManager();
        if (method_exists($manager, 'get_theme_templates_ids')) {
            $ids = $manager->get_theme_templates_ids($location);
            if (is_array($ids)) {
                return array_values(array_map('intval', $ids));
            }
        }
        // Fallback via locations manager.
        $lm = $this->locationsManager();
        if (method_exists($lm, 'get_documents_for_location')) {
            $docs = $lm->get_documents_for_location($location);
            if (is_array($docs)) {
                return array_values(array_map('intval', array_keys($docs)));
            }
        }
        return [];
    }

    /**
     * Get the location a given theme document is assigned to.
     *
     * @param int $postId
     * @return string|null
     */
    public function getDocumentLocation(int $postId): ?string
    {
        $manager = $this->locationsManager();
        if (!method_exists($manager, 'get_doc_location')) {
            return null;
        }
        $loc = $manager->get_doc_location($postId);
        return is_string($loc) && $loc !== '' ? $loc : null;
    }

    /**
     * Get the Theme Builder document-types config (what TB document types are
     * registered, with their labels/icons).
     *
     * @return array<mixed>
     */
    public function getThemeBuilderTypesConfig(): array
    {
        $module = $this->themeBuilderModule();
        if (method_exists($module, 'get_types_manager')) {
            $tm = $module->get_types_manager();
            if (is_object($tm) && method_exists($tm, 'get_types_config')) {
                $config = $tm->get_types_config();
                return is_array($config) ? $config : [];
            }
        }
        return [];
    }

    /**
     * Create a new Theme Builder template document of the given type.
     *
     * @param string       $type     One of THEME_BUILDER_TYPES.
     * @param string       $title    The template title.
     * @param array<mixed> $elements Optional initial element tree.
     * @param string       $status   Post status (default 'publish').
     * @return int The new template's post ID.
     * @throws \RuntimeException
     */
    public function createThemeBuilderTemplate(
        string $type,
        string $title,
        array $elements = [],
        string $status = 'publish'
    ): int {
        $this->requireElementorPro();

        if (!in_array($type, self::THEME_BUILDER_TYPES, true)) {
            throw new \RuntimeException(
                "Unknown theme builder type '{$type}'. Valid types: " . implode(', ', self::THEME_BUILDER_TYPES)
            );
        }

        $documentsManager = $this->plugin()->documents;
        if (!is_object($documentsManager) || !method_exists($documentsManager, 'create')) {
            throw new \RuntimeException('Elementor documents manager unavailable.');
        }

        $document = $documentsManager->create(
            $type,
            [
                'post_title'  => $title !== '' ? $title : ucfirst($type) . ' Template',
                'post_status' => $status,
            ]
        );

        if (!is_object($document) || !method_exists($document, 'get_main_id')) {
            throw new \RuntimeException("Failed to create {$type} template document.");
        }

        $postId = (int) $document->get_main_id();

        if (!empty($elements)) {
            $this->saveDocumentData($postId, $elements);
        }

        return $postId;
    }

    /* ===================================================================
     * Elementor Pro — Forms layer
     *
     * Forms in Elementor are 'form' widgets embedded in documents. Their
     * fields live in the widget's settings under the 'form_fields' repeater,
     * and their submit actions under 'submit_actions' plus per-action
     * settings keys. Submissions (when the Submissions feature is enabled)
     * are stored in dedicated DB tables, read via Pro's Query singleton.
     * ================================================================= */

    /**
     * The widget type of the Elementor Pro Form widget.
     */
    public const FORM_WIDGET_TYPE = 'form';

    /**
     * The widget type of the Elementor Pro Login widget.
     */
    public const LOGIN_WIDGET_TYPE = 'login';

    /**
     * The 16 form submit actions shipped by Elementor Pro 4.0.4, keyed by the
     * action's registered name with a human-readable label. Used to validate
     * action names and to describe what's available.
     *
     * @var array<string, string>
     */
    public const FORM_ACTIONS = [
        'email'          => 'Email',
        'email2'         => 'Email 2',
        'redirect'       => 'Redirect',
        'webhook'        => 'Webhook',
        'mailchimp'      => 'MailChimp',
        'drip'           => 'Drip',
        'activecampaign' => 'ActiveCampaign',
        'getresponse'    => 'GetResponse',
        'convertkit'     => 'ConvertKit',
        'mailerlite'     => 'MailerLite',
        'mailpoet'       => 'MailPoet',
        'mailpoet3'      => 'MailPoet 3',
        'slack'          => 'Slack',
        'discord'        => 'Discord',
        'cf7db'          => 'Contact Form 7 DB',
        'activity-log'   => 'Activity Log',
    ];

    /**
     * Get Elementor Pro's form submissions Query singleton.
     *
     * @return object \ElementorPro\Modules\Forms\Submissions\Database\Query
     * @throws \RuntimeException
     */
    public function formSubmissionsQuery(): object
    {
        $this->requireElementorPro();
        $class = '\ElementorPro\Modules\Forms\Submissions\Database\Query';
        if (!class_exists($class) || !method_exists($class, 'get_instance')) {
            throw new \RuntimeException(
                'Elementor Pro form submissions API is unavailable. The Submissions feature may be disabled, or this Pro version differs.'
            );
        }
        $query = $class::get_instance();
        if (!is_object($query)) {
            throw new \RuntimeException('Could not obtain the form submissions Query instance.');
        }
        return $query;
    }

    /**
     * Whether the Pro form Submissions feature is enabled on this site.
     */
    public function areSubmissionsEnabled(): bool
    {
        if (!$this->isProActive()) {
            return false;
        }
        // Pro stores the disabled flag as elementor_e_submissions ('1' = disabled).
        return '1' !== get_option('elementor_e_submissions');
    }

    /**
     * Find every Form widget across all Elementor documents.
     *
     * @return array<int, array{document_id:int,document_title:string,element_id:string,form_name:string}>
     */
    public function findAllForms(): array
    {
        $this->requireElementorPro();

        $query = new \WP_Query([
            'post_type'      => ['page', 'post', 'elementor_library'],
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'meta_key'       => '_elementor_edit_mode',
            'meta_value'     => 'builder',
            'fields'         => 'ids',
        ]);

        $forms = [];
        foreach ($query->posts as $postId) {
            $postId = (int) $postId;
            $data = $this->getDocumentData($postId);
            foreach ($this->walkElements($data) as $entry) {
                $el = $entry['element'] ?? null;
                if (!is_array($el)) {
                    continue;
                }
                if (($el['elType'] ?? null) !== 'widget'
                    || ($el['widgetType'] ?? null) !== self::FORM_WIDGET_TYPE) {
                    continue;
                }
                $settings = isset($el['settings']) ? (array) $el['settings'] : [];
                $forms[] = [
                    'document_id'    => $postId,
                    'document_title' => get_the_title($postId),
                    'element_id'     => $el['id'] ?? '',
                    'form_name'      => $settings['form_name'] ?? '',
                ];
            }
        }
        return $forms;
    }

    /* ===================================================================
     * Elementor Pro — Popups layer
     *
     * Popups are 'popup' document types, stored as elementor_library posts
     * whose elementor_library_type term is 'popup'. Their trigger and timing
     * configuration lives in the document's page settings.
     * ================================================================= */

    /**
     * The document/library type slug for Elementor Pro popups.
     */
    public const POPUP_TYPE = 'popup';

    /**
     * List all Popup documents.
     *
     * @return array<int, array{id:int,title:string,status:string,modified:string}>
     */
    public function listPopups(): array
    {
        $this->requireElementorPro();

        $query = new \WP_Query([
            'post_type'      => 'elementor_library',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'tax_query'      => [[
                'taxonomy' => 'elementor_library_type',
                'field'    => 'slug',
                'terms'    => [self::POPUP_TYPE],
            ]],
        ]);

        $out = [];
        foreach ($query->posts as $post) {
            $out[] = [
                'id'       => (int) $post->ID,
                'title'    => $post->post_title,
                'status'   => $post->post_status,
                'modified' => $post->post_modified_gmt,
            ];
        }
        return $out;
    }

    /**
     * Whether a post is a Popup document.
     */
    public function isPopup(int $postId): bool
    {
        return $this->getTemplateType($postId) === self::POPUP_TYPE;
    }

    /**
     * Create a new Popup document.
     *
     * @param string       $title
     * @param array<mixed> $elements
     * @param string       $status
     * @return int New popup post ID.
     * @throws \RuntimeException
     */
    public function createPopup(string $title, array $elements = [], string $status = 'publish'): int
    {
        $this->requireElementorPro();

        $documentsManager = $this->plugin()->documents;
        if (!is_object($documentsManager) || !method_exists($documentsManager, 'create')) {
            throw new \RuntimeException('Elementor documents manager unavailable.');
        }

        $document = $documentsManager->create(
            self::POPUP_TYPE,
            [
                'post_title'  => $title !== '' ? $title : 'Popup',
                'post_status' => $status,
            ]
        );

        if (!is_object($document) || !method_exists($document, 'get_main_id')) {
            throw new \RuntimeException('Failed to create popup document.');
        }

        $postId = (int) $document->get_main_id();
        if (!empty($elements)) {
            $this->saveDocumentData($postId, $elements);
        }
        return $postId;
    }

    /* ===================================================================
     * Elementor Pro — Widget library + Dynamic Tags layer
     *
     * The Pro widget library is the set of Pro widgets that aren't
     * theme-builder, theme-element, WooCommerce or form widgets — carousels,
     * posts/portfolio, pricing, nav/mega menu, slides, and so on. They are
     * inserted and configured through the same document element model as any
     * other widget; this layer just provides the canonical registry and a
     * couple of helpers so the widget tools can validate against real names.
     * ================================================================= */

    /**
     * The Elementor Pro general-library widgets shipped in Pro 4.0.4, keyed by
     * widget type with a human-readable label and a usage group.
     *
     * @var array<string, array{label:string, group:string}>
     */
    public const PRO_WIDGETS = [
        // Content
        'posts'                => ['label' => 'Posts',                'group' => 'content'],
        'portfolio'            => ['label' => 'Portfolio',            'group' => 'content'],
        'gallery'              => ['label' => 'Gallery',              'group' => 'content'],
        'slides'               => ['label' => 'Slides',               'group' => 'content'],
        'media-carousel'       => ['label' => 'Media Carousel',       'group' => 'content'],
        'testimonial-carousel' => ['label' => 'Testimonial Carousel', 'group' => 'content'],
        'reviews'              => ['label' => 'Reviews',              'group' => 'content'],
        'nested-carousel'      => ['label' => 'Carousel',             'group' => 'content'],
        'video-playlist'       => ['label' => 'Video Playlist',       'group' => 'content'],
        'animated-headline'    => ['label' => 'Animated Headline',    'group' => 'content'],
        'blockquote'           => ['label' => 'Blockquote',           'group' => 'content'],
        'table-of-contents'    => ['label' => 'Table of Contents',    'group' => 'content'],
        'code-highlight'       => ['label' => 'Code Highlight',       'group' => 'content'],
        'countdown'            => ['label' => 'Countdown',            'group' => 'content'],
        'lottie'               => ['label' => 'Lottie',               'group' => 'content'],
        'hotspot'              => ['label' => 'Hotspot',              'group' => 'content'],
        // Marketing / conversion
        'call-to-action'       => ['label' => 'Call to Action',       'group' => 'marketing'],
        'flip-box'             => ['label' => 'Flip Box',             'group' => 'marketing'],
        'price-table'          => ['label' => 'Price Table',          'group' => 'marketing'],
        'price-list'           => ['label' => 'Price List',           'group' => 'marketing'],
        'progress-tracker'     => ['label' => 'Progress Tracker',     'group' => 'marketing'],
        'share-buttons'        => ['label' => 'Share Buttons',        'group' => 'marketing'],
        // Navigation / site
        'nav-menu'             => ['label' => 'Nav Menu',             'group' => 'navigation'],
        'mega-menu'            => ['label' => 'Mega Menu',            'group' => 'navigation'],
        'off-canvas'           => ['label' => 'Off-Canvas',           'group' => 'navigation'],
        'search'               => ['label' => 'Search',              'group' => 'navigation'],
        // Link in Bio variants
        'link-in-bio-var-2'    => ['label' => 'Link in Bio',          'group' => 'link-in-bio'],
        'link-in-bio-var-3'    => ['label' => 'Link in Bio',          'group' => 'link-in-bio'],
        'link-in-bio-var-4'    => ['label' => 'Link in Bio',          'group' => 'link-in-bio'],
        'link-in-bio-var-5'    => ['label' => 'Link in Bio',          'group' => 'link-in-bio'],
        'link-in-bio-var-6'    => ['label' => 'Link in Bio',          'group' => 'link-in-bio'],
        'link-in-bio-var-7'    => ['label' => 'Link in Bio',          'group' => 'link-in-bio'],
        // Loop Builder
        'loop-grid'            => ['label' => 'Loop Grid',            'group' => 'loop'],
        'loop-carousel'        => ['label' => 'Loop Carousel',        'group' => 'loop'],
        'taxonomy-filter'      => ['label' => 'Taxonomy Filter',      'group' => 'loop'],
        // Social
        'facebook-button'      => ['label' => 'Facebook Button',      'group' => 'social'],
        'facebook-comments'    => ['label' => 'Facebook Comments',    'group' => 'social'],
        'facebook-embed'       => ['label' => 'Facebook Embed',       'group' => 'social'],
        'facebook-page'        => ['label' => 'Facebook Page',        'group' => 'social'],
    ];

    /**
     * Whether a widget type is a known Pro general-library widget.
     */
    public function isProWidget(string $widgetType): bool
    {
        return isset(self::PRO_WIDGETS[$widgetType]);
    }

    /**
     * Get the controls schema for any registered widget type.
     *
     * @param string $widgetType
     * @return array<string, mixed>|null Null if the widget isn't registered.
     */
    public function getWidgetControls(string $widgetType): ?array
    {
        $this->requireElementor();
        $widgetsManager = $this->plugin()->widgets_manager ?? null;
        if (!is_object($widgetsManager) || !method_exists($widgetsManager, 'get_widget_types')) {
            return null;
        }
        $widget = $widgetsManager->get_widget_types($widgetType);
        if (!is_object($widget) || !method_exists($widget, 'get_controls')) {
            return null;
        }
        $raw = $widget->get_controls();
        if (!is_array($raw)) {
            return null;
        }
        $controls = [];
        foreach ($raw as $key => $control) {
            if (!is_array($control)) {
                continue;
            }
            $controls[$key] = [
                'type'    => $control['type']    ?? null,
                'label'   => $control['label']   ?? null,
                'default' => $control['default'] ?? null,
                'options' => isset($control['options']) && is_array($control['options'])
                    ? $control['options']
                    : null,
            ];
        }
        return $controls;
    }

    /**
     * The Elementor Pro dynamic tags shipped in Pro 4.0.4 (tag names).
     *
     * @var string[]
     */
    public const PRO_DYNAMIC_TAGS = [
        'archive-description', 'archive-meta', 'archive-title', 'archive-url',
        'author-info', 'author-meta', 'author-name', 'author-profile-picture', 'author-url',
        'comments-number', 'comments-url', 'contact-url', 'current-date-time',
        'featured-image-data', 'internal-url', 'lightbox', 'page-title',
        'post-custom-field', 'post-date', 'post-excerpt', 'post-featured-image',
        'post-gallery', 'post-id', 'post-terms', 'post-time', 'post-title', 'post-url',
        'reload-page', 'request-arg', 'shortcode', 'site-logo', 'site-tagline',
        'site-title', 'site-url', 'user-info', 'user-profile-picture',
    ];

    /**
     * Get all registered dynamic tags as [name => group] pairs, reading from
     * Elementor's dynamic tags manager. Returns an empty array if the manager
     * or its tag list is unavailable.
     *
     * @return array<string, string>
     */
    public function getRegisteredDynamicTags(): array
    {
        try {
            $manager = $this->dynamicTagsManager();
        } catch (\Throwable $e) {
            return [];
        }

        $tags = [];

        // get_tags() returns registered tag instances/configs in most Pro versions.
        if (method_exists($manager, 'get_tags')) {
            $raw = $manager->get_tags();
            if (is_array($raw)) {
                foreach ($raw as $name => $tag) {
                    $group = '';
                    if (is_object($tag) && method_exists($tag, 'get_group')) {
                        $g = $tag->get_group();
                        $group = is_array($g) ? implode(',', $g) : (string) $g;
                    }
                    $tags[(string) $name] = $group;
                }
            }
        }
        return $tags;
    }

    /* ===================================================================
     * Elementor Pro — Custom Code, Custom Fonts/Icons, Role Manager
     * ================================================================= */

    /** Custom Code snippet CPT (Elementor Pro). */
    public const CUSTOM_CODE_CPT = 'elementor_snippet';

    /** Custom Fonts CPT (Elementor Pro assets manager). */
    public const CUSTOM_FONT_CPT = 'elementor_font';

    /** Custom Icons CPT (Elementor Pro assets manager). */
    public const CUSTOM_ICONS_CPT = 'elementor_icons';

    /** Valid output locations for a custom-code snippet. */
    public const CUSTOM_CODE_LOCATIONS = ['head', 'body_start', 'body_end'];

    /**
     * List Custom Code snippets.
     *
     * @return array<int, array{id:int,title:string,status:string,location:?string,priority:?int,conditions:array}>
     */
    public function listCustomCodeSnippets(): array
    {
        $this->requireElementorPro();

        $query = new \WP_Query([
            'post_type'      => self::CUSTOM_CODE_CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ]);

        $out = [];
        foreach ($query->posts as $post) {
            $id = (int) $post->ID;
            $location = get_post_meta($id, '_elementor_location', true);
            $priority = get_post_meta($id, '_elementor_priority', true);
            $conditions = get_post_meta($id, '_elementor_conditions', true);
            $out[] = [
                'id'         => $id,
                'title'      => $post->post_title,
                'status'     => $post->post_status,
                'location'   => is_string($location) && $location !== '' ? $location : null,
                'priority'   => $priority !== '' ? (int) $priority : null,
                'conditions' => is_array($conditions)
                    ? array_values(array_filter(array_map('strval', $conditions)))
                    : [],
            ];
        }
        return $out;
    }

    /**
     * Whether a post is a Custom Code snippet.
     */
    public function isCustomCodeSnippet(int $postId): bool
    {
        $post = get_post($postId);
        return $post && $post->post_type === self::CUSTOM_CODE_CPT;
    }

    /**
     * Create a Custom Code snippet.
     *
     * @param string   $title
     * @param string   $code      The snippet body (HTML/JS/CSS as entered in the metabox).
     * @param string   $location  One of CUSTOM_CODE_LOCATIONS.
     * @param int      $priority
     * @param string[] $conditions
     * @param string   $status
     * @return int New snippet post ID.
     * @throws \RuntimeException
     */
    public function createCustomCodeSnippet(
        string $title,
        string $code,
        string $location = 'head',
        int $priority = 10,
        array $conditions = [],
        string $status = 'publish'
    ): int {
        $this->requireElementorPro();

        if (!in_array($location, self::CUSTOM_CODE_LOCATIONS, true)) {
            throw new \RuntimeException(
                "Invalid custom-code location '{$location}'. Valid: " . implode(', ', self::CUSTOM_CODE_LOCATIONS)
            );
        }

        $postId = wp_insert_post([
            'post_type'    => self::CUSTOM_CODE_CPT,
            'post_title'   => $title !== '' ? $title : 'Custom Code',
            'post_content' => $code,
            'post_status'  => $status,
        ], true);

        if (is_wp_error($postId)) {
            throw new \RuntimeException('Failed to create custom code snippet: ' . $postId->get_error_message());
        }
        $postId = (int) $postId;

        update_post_meta($postId, '_elementor_location', $location);
        update_post_meta($postId, '_elementor_priority', $priority);
        if (!empty($conditions)) {
            update_post_meta(
                $postId,
                '_elementor_conditions',
                array_values(array_filter(array_map('strval', $conditions)))
            );
        }
        return $postId;
    }

    /**
     * List custom fonts (the elementor_font CPT). Each entry is id + title
     * (the font family name).
     *
     * @return array<int, array{id:int,font_family:string,status:string}>
     */
    public function listCustomFonts(): array
    {
        $this->requireElementorPro();
        $query = new \WP_Query([
            'post_type'      => self::CUSTOM_FONT_CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ]);
        $out = [];
        foreach ($query->posts as $post) {
            $out[] = [
                'id'          => (int) $post->ID,
                'font_family' => $post->post_title,
                'status'      => $post->post_status,
            ];
        }
        return $out;
    }

    /**
     * List custom icon sets (the elementor_icons CPT).
     *
     * @return array<int, array{id:int,name:string,status:string}>
     */
    public function listCustomIconSets(): array
    {
        $this->requireElementorPro();
        $query = new \WP_Query([
            'post_type'      => self::CUSTOM_ICONS_CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ]);
        $out = [];
        foreach ($query->posts as $post) {
            $out[] = [
                'id'     => (int) $post->ID,
                'name'   => $post->post_title,
                'status' => $post->post_status,
            ];
        }
        return $out;
    }
}
