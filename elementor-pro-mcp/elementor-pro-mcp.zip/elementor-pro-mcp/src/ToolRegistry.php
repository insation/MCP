<?php
/**
 * Tool Registry — ElementorProMCP
 *
 * Central source of truth for tool metadata. Both the runtime registrars
 * (mcp-http.php, register-abilities.php) and the admin Tools toggle UI
 * consume this so they stay in lockstep.
 *
 * Tools are only built when Elementor is active. When Elementor is missing,
 * buildAllTools / buildEnabledTools return an empty array. The admin Tools
 * tab still renders (so users can see what would be available), but
 * tools/list returns nothing to MCP clients until Elementor is loaded.
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Services\ContentPatchingService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ToolRegistry
{
    public const DISABLED_OPTION = 'insationai_eprmcp_disabled_tools';

    /**
     * Build every tool instance.
     *
     * @return AbstractTool[]
     */
    public static function buildAllTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        // ElementorProMCP requires Elementor Pro, not just free Elementor.
        // The Theme Builder, display conditions, locations and Pro widgets all
        // live in Elementor Pro. Without Pro, expose zero tools (the admin Tools
        // tab still renders so users can see what would be available).
        if (!class_exists('\Elementor\Plugin') || !defined('ELEMENTOR_PRO_VERSION')) {
            return [];
        }

        $elementor = new ElementorService();

        return [
            // ── Theme Builder: documents ──────────────────────────────────
            new Tools\ThemeBuilder\ListThemeBuilderTemplates($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\GetThemeBuilderTemplate($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\CreateThemeBuilderTemplate($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\UpdateThemeBuilderTemplate($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\DeleteThemeBuilderTemplate($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\DuplicateThemeBuilderTemplate($wp, $validator, $elementor, $logger),

            // ── Theme Builder: display conditions ─────────────────────────
            new Tools\ThemeBuilder\GetTemplateDisplayConditions($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\SetTemplateDisplayConditions($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\AddTemplateDisplayCondition($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\RemoveTemplateDisplayCondition($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\GetThemeBuilderConditionsConfig($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\GetThemeBuilderConflicts($wp, $validator, $elementor, $logger),

            // ── Theme Builder: locations ──────────────────────────────────
            new Tools\ThemeBuilder\ListThemeBuilderLocations($wp, $validator, $elementor, $logger),
            new Tools\ThemeBuilder\GetLocationTemplates($wp, $validator, $elementor, $logger),

            // ── Theme Builder: widgets ────────────────────────────────────
            new Tools\ThemeWidgets\ListThemeBuilderWidgets($wp, $validator, $elementor, $logger),
            new Tools\ThemeWidgets\GetThemeBuilderWidgetSchema($wp, $validator, $elementor, $logger),
            new Tools\ThemeWidgets\InsertThemeBuilderWidget($wp, $validator, $elementor, $logger),
            new Tools\ThemeWidgets\ConfigureThemeBuilderWidget($wp, $validator, $elementor, $logger),
            new Tools\ThemeWidgets\FindThemeBuilderWidgets($wp, $validator, $elementor, $logger),

            // ── WooCommerce Builder ───────────────────────────────────────
            new Tools\WooCommerce\ListWooCommerceTemplates($wp, $validator, $elementor, $logger),
            new Tools\WooCommerce\CreateWooCommerceTemplate($wp, $validator, $elementor, $logger),
            new Tools\WooCommerce\ListWooCommerceWidgets($wp, $validator, $elementor, $logger),
            new Tools\WooCommerce\InsertWooCommerceWidget($wp, $validator, $elementor, $logger),

            // ── Forms ─────────────────────────────────────────────────────
            new Tools\Forms\ListForms($wp, $validator, $elementor, $logger),
            new Tools\Forms\GetForm($wp, $validator, $elementor, $logger),
            new Tools\Forms\ListFormActions($wp, $validator, $elementor, $logger),
            new Tools\Forms\ManageFormActions($wp, $validator, $elementor, $logger),
            new Tools\Forms\ListFormSubmissions($wp, $validator, $elementor, $logger),
            new Tools\Forms\GetFormSubmission($wp, $validator, $elementor, $logger),
            new Tools\Forms\CountFormSubmissions($wp, $validator, $elementor, $logger),
            new Tools\Forms\ManageFormSubmission($wp, $validator, $elementor, $logger),

            // ── Popups ────────────────────────────────────────────────────
            new Tools\Popups\ListPopups($wp, $validator, $elementor, $logger),
            new Tools\Popups\GetPopup($wp, $validator, $elementor, $logger),
            new Tools\Popups\CreatePopup($wp, $validator, $elementor, $logger),
            new Tools\Popups\UpdatePopupTriggers($wp, $validator, $elementor, $logger),
            new Tools\Popups\DeletePopup($wp, $validator, $elementor, $logger),

            // ── Pro widget library ────────────────────────────────────────
            new Tools\Widgets\ListProWidgets($wp, $validator, $elementor, $logger),
            new Tools\Widgets\GetProWidgetSchema($wp, $validator, $elementor, $logger),
            new Tools\Widgets\InsertProWidget($wp, $validator, $elementor, $logger),
            new Tools\Widgets\ConfigureProWidget($wp, $validator, $elementor, $logger),

            // ── Pro dynamic tags ──────────────────────────────────────────
            new Tools\DynamicTags\ListProDynamicTags($wp, $validator, $elementor, $logger),
            new Tools\DynamicTags\FindDynamicTagUsage($wp, $validator, $elementor, $logger),

            // ── Custom Code ───────────────────────────────────────────────
            new Tools\CustomCode\ListCustomCode($wp, $validator, $elementor, $logger),
            new Tools\CustomCode\GetCustomCode($wp, $validator, $elementor, $logger),
            new Tools\CustomCode\CreateCustomCode($wp, $validator, $elementor, $logger),

            // ── Site Assets (custom fonts & icons) ────────────────────────
            new Tools\SiteAssets\ListSiteAssets($wp, $validator, $elementor, $logger),

            // ── Role Manager ──────────────────────────────────────────────
            new Tools\RoleManager\GetRoleManagerSettings($wp, $validator, $elementor, $logger),
            new Tools\RoleManager\UpdateRoleManagerSettings($wp, $validator, $elementor, $logger),
        ];
    }

    /**
     * Build enabled tools (filters out admin-disabled ones).
     *
     * @return AbstractTool[]
     */
    public static function buildEnabledTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $all = self::buildAllTools($wp, $validator, $logger, $patching);
        $disabled = self::getDisabledToolNames();
        if (empty($disabled) || empty($all)) {
            return $all;
        }
        return array_values(array_filter(
            $all,
            static fn(AbstractTool $t) => !in_array($t->getName(), $disabled, true)
        ));
    }

    /**
     * @return string[]
     */
    public static function getDisabledToolNames(): array
    {
        $stored = get_option(self::DISABLED_OPTION, []);
        return is_array($stored) ? array_values(array_filter(array_map('strval', $stored))) : [];
    }

    /**
     * @param string[] $names
     */
    public static function setDisabledToolNames(array $names): void
    {
        $clean = array_values(array_unique(array_filter(array_map('sanitize_text_field', $names))));
        update_option(self::DISABLED_OPTION, $clean);
    }

    /**
     * Stable category slug for a tool name. Mirrors the grouping used by the
     * admin Tools toggle UI and the Abilities API registrar.
     */
    public static function categoryFor(string $toolName): string
    {
        $documents = [
            'list_theme_builder_templates', 'get_theme_builder_template',
            'create_theme_builder_template', 'update_theme_builder_template',
            'delete_theme_builder_template', 'duplicate_theme_builder_template',
        ];
        if (in_array($toolName, $documents, true)) {
            return 'tb-documents';
        }

        $conditions = [
            'get_template_display_conditions', 'set_template_display_conditions',
            'add_template_display_condition', 'remove_template_display_condition',
            'get_theme_builder_conditions_config', 'get_theme_builder_conflicts',
        ];
        if (in_array($toolName, $conditions, true)) {
            return 'tb-conditions';
        }

        $locations = [
            'list_theme_builder_locations', 'get_location_templates',
        ];
        if (in_array($toolName, $locations, true)) {
            return 'tb-locations';
        }

        $widgets = [
            'list_theme_builder_widgets', 'get_theme_builder_widget_schema',
            'insert_theme_builder_widget', 'configure_theme_builder_widget',
            'find_theme_builder_widgets',
        ];
        if (in_array($toolName, $widgets, true)) {
            return 'tb-widgets';
        }

        $woocommerce = [
            'list_woocommerce_templates', 'create_woocommerce_template',
            'list_woocommerce_widgets', 'insert_woocommerce_widget',
        ];
        if (in_array($toolName, $woocommerce, true)) {
            return 'woocommerce';
        }

        $forms = [
            'list_forms', 'get_form', 'list_form_actions', 'manage_form_actions',
            'list_form_submissions', 'get_form_submission', 'count_form_submissions',
            'manage_form_submission',
        ];
        if (in_array($toolName, $forms, true)) {
            return 'forms';
        }

        $popups = [
            'list_popups', 'get_popup', 'create_popup',
            'update_popup_triggers', 'delete_popup',
        ];
        if (in_array($toolName, $popups, true)) {
            return 'popups';
        }

        $widgets = [
            'list_pro_widgets', 'get_pro_widget_schema',
            'insert_pro_widget', 'configure_pro_widget',
        ];
        if (in_array($toolName, $widgets, true)) {
            return 'pro-widgets';
        }

        $dynamicTags = [
            'list_pro_dynamic_tags', 'find_dynamic_tag_usage',
        ];
        if (in_array($toolName, $dynamicTags, true)) {
            return 'dynamic-tags';
        }

        $customCode = [
            'list_custom_code', 'get_custom_code', 'create_custom_code',
        ];
        if (in_array($toolName, $customCode, true)) {
            return 'custom-code';
        }

        if ($toolName === 'list_site_assets') {
            return 'site-assets';
        }

        $roleManager = [
            'get_role_manager_settings', 'update_role_manager_settings',
        ];
        if (in_array($toolName, $roleManager, true)) {
            return 'role-manager';
        }

        return 'misc';
    }

    /**
     * Human-readable label for a category slug.
     */
    public static function categoryLabel(string $slug): string
    {
        $labels = [
            'tb-documents'  => __('Theme Builder - Templates', 'elementor-pro-mcp'),
            'tb-conditions' => __('Theme Builder - Display Conditions', 'elementor-pro-mcp'),
            'tb-locations'  => __('Theme Builder - Locations', 'elementor-pro-mcp'),
            'tb-widgets'    => __('Theme Builder - Widgets', 'elementor-pro-mcp'),
            'woocommerce'   => __('WooCommerce Builder', 'elementor-pro-mcp'),
            'forms'         => __('Forms & Submissions', 'elementor-pro-mcp'),
            'popups'        => __('Popups', 'elementor-pro-mcp'),
            'pro-widgets'   => __('Pro Widget Library', 'elementor-pro-mcp'),
            'dynamic-tags'  => __('Pro Dynamic Tags', 'elementor-pro-mcp'),
            'custom-code'   => __('Custom Code', 'elementor-pro-mcp'),
            'site-assets'   => __('Custom Fonts & Icons', 'elementor-pro-mcp'),
            'role-manager'  => __('Role Manager', 'elementor-pro-mcp'),
            'misc'          => __('Misc', 'elementor-pro-mcp'),
        ];
        return $labels[$slug] ?? ucfirst(str_replace('-', ' ', $slug));
    }
}
