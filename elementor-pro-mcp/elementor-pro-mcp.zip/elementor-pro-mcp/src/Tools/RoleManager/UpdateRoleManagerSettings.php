<?php
/**
 * Update Role Manager Settings Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.3.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\RoleManager;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class UpdateRoleManagerSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_role_manager_settings';
    }

    public function getDescription(): string
    {
        return 'Update Elementor Pro\'s Role Manager restrictions — the per-role rules controlling Elementor editor access. Supply a JSON object keyed by WordPress role. By default the supplied roles are merged into the existing settings (other roles untouched); pass replace=true to overwrite the entire restrictions map. This changes editor access for users, so use with care.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'restrictions_json' => [
                'required',
                'string',
                'description' => 'JSON object keyed by WordPress role slug, with each role\'s restriction settings as the value.',
            ],
            'replace' => [
                'optional',
                'bool',
                'description' => 'If true, replace the entire restrictions map. If false (default), merge per-role into existing settings.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('updating role manager settings');

        $decoded = json_decode((string) $parameters['restrictions_json'], true);
        if (!is_array($decoded)) {
            return $this->error('restrictions_json is not valid JSON, or did not decode to an object.');
        }

        $replace = !empty($parameters['replace']);
        $current = $this->elementor->getRoleRestrictions();

        $newRestrictions = $replace ? $decoded : array_merge($current, $decoded);

        $saved = $this->elementor->saveRoleRestrictions($newRestrictions);
        if (!$saved && $newRestrictions !== $current) {
            return $this->error('Failed to save role manager settings.');
        }

        return $this->success([
            'mode'          => $replace ? 'replace' : 'merge',
            'roles_updated' => array_keys($decoded),
            'restrictions'  => $newRestrictions,
        ], 'Updated Elementor Pro Role Manager settings (' . ($replace ? 'replaced' : 'merged') . ').');
    }
}
