<?php
/**
 * Get Role Manager Settings Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.3.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\RoleManager;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetRoleManagerSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_role_manager_settings';
    }

    public function getDescription(): string
    {
        return 'Read Elementor Pro\'s Role Manager settings — the per-WordPress-role restrictions that control which roles can use the Elementor editor and which are limited (e.g. content-only access, or no access at all). Returns the raw restrictions map keyed by role.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $restrictions = $this->elementor->getRoleRestrictions();

        return $this->success([
            'role_count'   => count($restrictions),
            'restrictions' => $restrictions,
        ]);
    }
}
