<?php
/**
 * Get Pro Widget Schema Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Widgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetProWidgetSchema extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_pro_widget_schema';
    }

    public function getDescription(): string
    {
        return 'Get the full controls schema for an Elementor Pro general-library widget — every setting the widget exposes, with each control\'s type, default value, and options. Use this to learn the exact settings keys insert_pro_widget and configure_pro_widget accept for a given widget type.';
    }

    public function getSchema(): array
    {
        return [
            'widget_type' => [
                'required',
                'string',
                'description' => 'The Pro widget type, e.g. posts, price-table, nav-menu. See list_pro_widgets.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $widgetType = (string) $parameters['widget_type'];
        if (!$this->elementor->isProWidget($widgetType)) {
            return $this->error(
                "'{$widgetType}' is not a recognized Elementor Pro general-library widget.",
                ['valid_types' => array_keys(ElementorService::PRO_WIDGETS)]
            );
        }

        $controls = $this->elementor->getWidgetControls($widgetType);

        if ($controls === null) {
            return $this->error(
                "Widget '{$widgetType}' is not currently registered, or its controls could not be read. It may require a context to load."
            );
        }

        return $this->success([
            'widget_type'   => $widgetType,
            'label'         => ElementorService::PRO_WIDGETS[$widgetType]['label'],
            'control_count' => count($controls),
            'controls'      => $controls,
        ]);
    }
}
