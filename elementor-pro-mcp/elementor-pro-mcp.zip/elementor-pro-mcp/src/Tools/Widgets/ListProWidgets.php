<?php
/**
 * List Pro Widgets Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Widgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListProWidgets extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_pro_widgets';
    }

    public function getDescription(): string
    {
        return 'List the Elementor Pro general-library widgets — the Pro widgets that are not theme-builder, WooCommerce, or form widgets: Posts, Portfolio, Gallery, Slides, the carousels, Animated Headline, Countdown, Table of Contents, Call to Action, Flip Box, Price Table/List, Nav Menu, Mega Menu, Off-Canvas, Loop Grid/Carousel, and more. For each widget, reports its widget type, label, usage group, and whether it is currently registered on this site.';
    }

    public function getSchema(): array
    {
        return [
            'group' => [
                'optional',
                'string',
                'description' => 'Filter by usage group: content, marketing, navigation, link-in-bio, loop, social.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $registered = [];
        try {
            $widgetsManager = $this->elementor->plugin()->widgets_manager;
            if (is_object($widgetsManager) && method_exists($widgetsManager, 'get_widget_types')) {
                $types = $widgetsManager->get_widget_types();
                if (is_array($types)) {
                    $registered = array_keys($types);
                }
            }
        } catch (\Throwable $e) {
            $registered = [];
        }

        $groupFilter = isset($parameters['group']) && $parameters['group'] !== ''
            ? (string) $parameters['group']
            : null;

        $items = [];
        foreach (ElementorService::PRO_WIDGETS as $type => $info) {
            if ($groupFilter !== null && $info['group'] !== $groupFilter) {
                continue;
            }
            $items[] = [
                'widget_type' => $type,
                'label'       => $info['label'],
                'group'       => $info['group'],
                'registered'  => empty($registered) ? null : in_array($type, $registered, true),
            ];
        }

        return $this->success([
            'count'   => count($items),
            'group'   => $groupFilter,
            'widgets' => $items,
        ]);
    }
}
