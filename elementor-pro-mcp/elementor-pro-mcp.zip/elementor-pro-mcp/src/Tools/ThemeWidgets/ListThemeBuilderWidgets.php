<?php
/**
 * List Theme Builder Widgets Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeWidgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListThemeBuilderWidgets extends AbstractTool
{
    protected ElementorService $elementor;

    /**
     * The theme-builder and theme-element widgets shipped by Elementor Pro.
     * Keyed by widget type (the value of the widget's get_name()), with a
     * human-readable label and the kind of dynamic content it renders.
     *
     * This is the canonical list the other ThemeWidgets tools validate against.
     *
     * @var array<string, array{label:string, group:string}>
     */
    public const THEME_WIDGETS = [
        'theme-site-logo'           => ['label' => 'Site Logo',          'group' => 'site'],
        'theme-site-title'          => ['label' => 'Site Title',         'group' => 'site'],
        'theme-page-title'          => ['label' => 'Page Title',         'group' => 'page'],
        'theme-post-title'          => ['label' => 'Post Title',         'group' => 'post'],
        'theme-post-content'        => ['label' => 'Post Content',       'group' => 'post'],
        'theme-post-excerpt'        => ['label' => 'Post Excerpt',       'group' => 'post'],
        'theme-post-featured-image' => ['label' => 'Featured Image',     'group' => 'post'],
        'archive-posts'             => ['label' => 'Archive Posts',      'group' => 'archive'],
        'theme-archive-title'       => ['label' => 'Archive Title',      'group' => 'archive'],
        'author-box'                => ['label' => 'Author Box',         'group' => 'post'],
        'breadcrumbs'               => ['label' => 'Breadcrumbs',        'group' => 'navigation'],
        'post-comments'             => ['label' => 'Post Comments',      'group' => 'post'],
        'post-info'                 => ['label' => 'Post Info',          'group' => 'post'],
        'post-navigation'           => ['label' => 'Post Navigation',    'group' => 'navigation'],
        'search-form'               => ['label' => 'Search Form',        'group' => 'navigation'],
        'sitemap'                   => ['label' => 'Sitemap',            'group' => 'navigation'],
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_theme_builder_widgets';
    }

    public function getDescription(): string
    {
        return 'List the Elementor Pro theme-builder and theme-element widgets — the dynamic widgets used to build headers, footers, and single/archive templates (site logo, post title, post content, featured image, author box, breadcrumbs, archive posts, etc.). For each widget, reports its widget type, label, content group, and whether it is currently registered and available on this site.';
    }

    public function getSchema(): array
    {
        return [
            'group' => [
                'optional',
                'string',
                'description' => 'Filter by content group: site, page, post, archive, navigation.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        // Find which widget types are actually registered with Elementor right now.
        $registered = [];
        try {
            $widgetsManager = $this->elementor->plugin()->widgets_manager;
            if (is_object($widgetsManager) && method_exists($widgetsManager, 'get_widget_types')) {
                $types = $widgetsManager->get_widget_types();
                if (is_array($types)) {
                    $registered = array_keys($types);
                }
            }
        } catch (\Throwable $e) {
            // Non-fatal: we still return the canonical list, just without the
            // "registered" flag being authoritative.
            $registered = [];
        }

        $groupFilter = isset($parameters['group']) && $parameters['group'] !== ''
            ? (string) $parameters['group']
            : null;

        $items = [];
        foreach (self::THEME_WIDGETS as $type => $info) {
            if ($groupFilter !== null && $info['group'] !== $groupFilter) {
                continue;
            }
            $items[] = [
                'widget_type' => $type,
                'label'       => $info['label'],
                'group'       => $info['group'],
                'registered'  => empty($registered) ? null : in_array($type, $registered, true),
            ];
        }

        return $this->success([
            'count'   => count($items),
            'group'   => $groupFilter,
            'widgets' => $items,
        ]);
    }
}
