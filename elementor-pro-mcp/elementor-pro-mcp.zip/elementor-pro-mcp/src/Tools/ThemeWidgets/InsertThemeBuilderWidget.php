<?php
/**
 * Insert Theme Builder Widget Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeWidgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class InsertThemeBuilderWidget extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'insert_theme_builder_widget';
    }

    public function getDescription(): string
    {
        return 'Insert an Elementor Pro theme-builder widget (site logo, post title, post content, featured image, breadcrumbs, archive posts, etc.) into a document. The widget is inserted either as a child of a target container/section element, or at the document root. A fresh element ID is generated automatically. Provide widget settings as a JSON object — use get_theme_builder_widget_schema to see valid settings keys for the widget type.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document to insert the widget into (typically a theme-builder template).',
            ],
            'widget_type' => [
                'required',
                'string',
                'description' => 'The theme widget type, e.g. theme-post-title, theme-site-logo, breadcrumbs. See list_theme_builder_widgets.',
            ],
            'settings_json' => [
                'optional',
                'string',
                'description' => 'JSON object of widget settings. Omit for widget defaults. See get_theme_builder_widget_schema for valid keys.',
            ],
            'parent_id' => [
                'optional',
                'string',
                'description' => 'Element ID of the container/section to insert into. Omit to insert at the document root.',
            ],
            'position' => [
                'optional',
                'int',
                'description' => 'Zero-based insertion index among the target\'s children. Omit to append at the end.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('inserting a theme builder widget');

        $widgetType = (string) $parameters['widget_type'];
        if (!isset(ListThemeBuilderWidgets::THEME_WIDGETS[$widgetType])) {
            return $this->error(
                "'{$widgetType}' is not a recognized theme-builder widget.",
                ['valid_types' => array_keys(ListThemeBuilderWidgets::THEME_WIDGETS)]
            );
        }

        $docId = (int) $parameters['document_id'];
        $document = $this->elementor->getDocument($docId);
        if ($document === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        // Parse settings.
        $settings = [];
        if (!empty($parameters['settings_json'])) {
            $decoded = json_decode((string) $parameters['settings_json'], true);
            if (!is_array($decoded)) {
                return $this->error('settings_json is not valid JSON, or did not decode to an object.');
            }
            $settings = $decoded;
        }

        // Build the widget element with a fresh ID.
        $element = [
            'id'         => $this->elementor->newElementId(),
            'elType'     => 'widget',
            'widgetType' => $widgetType,
            'settings'   => (object) $settings,
            'elements'   => [],
        ];

        $data = $this->elementor->getDocumentData($docId);

        if (empty($parameters['parent_id'])) {
            // Insert at document root.
            $position = isset($parameters['position'])
                ? max(0, min((int) $parameters['position'], count($data)))
                : count($data);
            array_splice($data, $position, 0, [$element]);
            $newData = array_values($data);
        } else {
            $parentId = (string) $parameters['parent_id'];
            $parentPath = $this->elementor->pathToId($data, $parentId);
            if ($parentPath === null) {
                return $this->error("Parent element '{$parentId}' not found in document {$docId}.");
            }
            // Resolve current child count for position clamping.
            $cursor = ['elements' => $data];
            foreach ($parentPath as $idx) {
                $cursor = $cursor['elements'][$idx];
            }
            $childCount = isset($cursor['elements']) && is_array($cursor['elements'])
                ? count($cursor['elements'])
                : 0;
            $position = isset($parameters['position'])
                ? max(0, min((int) $parameters['position'], $childCount))
                : $childCount;
            $childPath = array_merge($parentPath, [$position]);
            $newData = $this->elementor->insertAtPath($data, $childPath, $element);
        }

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            return $this->error('Failed to save the document after inserting the widget.');
        }

        return $this->success([
            'document_id'         => $docId,
            'widget_type'         => $widgetType,
            'inserted_element_id' => $element['id'],
            'parent_id'           => $parameters['parent_id'] ?? null,
            'position'            => $position,
        ], "Inserted '{$widgetType}' widget into document {$docId} (element ID {$element['id']}).");
    }
}
