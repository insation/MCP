<?php
/**
 * Get Theme Builder Widget Schema Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeWidgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetThemeBuilderWidgetSchema extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_theme_builder_widget_schema';
    }

    public function getDescription(): string
    {
        return 'Get the full controls schema for a theme-builder widget — every setting the widget exposes, with each control\'s type, default value, and options. Use this to learn exactly what settings keys insert_theme_builder_widget and configure_theme_builder_widget accept for a given widget type.';
    }

    public function getSchema(): array
    {
        return [
            'widget_type' => [
                'required',
                'string',
                'description' => 'The theme widget type, e.g. theme-post-title, theme-site-logo, breadcrumbs. See list_theme_builder_widgets for valid values.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $widgetType = (string) $parameters['widget_type'];
        if (!isset(ListThemeBuilderWidgets::THEME_WIDGETS[$widgetType])) {
            return $this->error(
                "'{$widgetType}' is not a recognized theme-builder widget.",
                ['valid_types' => array_keys(ListThemeBuilderWidgets::THEME_WIDGETS)]
            );
        }

        try {
            $widgetsManager = $this->elementor->plugin()->widgets_manager;
            if (!is_object($widgetsManager) || !method_exists($widgetsManager, 'get_widget_types')) {
                return $this->error('Elementor widgets manager is unavailable.');
            }
            $widget = $widgetsManager->get_widget_types($widgetType);
        } catch (\Throwable $e) {
            return $this->error('Could not load widget: ' . $e->getMessage());
        }

        if (!is_object($widget)) {
            return $this->error(
                "Widget '{$widgetType}' is not currently registered. It may require a context (e.g. an active Pro license) to load."
            );
        }

        // Pull the controls. get_controls() is the stable public accessor.
        $controls = [];
        if (method_exists($widget, 'get_controls')) {
            $raw = $widget->get_controls();
            if (is_array($raw)) {
                foreach ($raw as $key => $control) {
                    if (!is_array($control)) {
                        continue;
                    }
                    $controls[$key] = [
                        'type'    => $control['type']    ?? null,
                        'label'   => $control['label']   ?? null,
                        'default' => $control['default'] ?? null,
                        'options' => isset($control['options']) && is_array($control['options'])
                            ? $control['options']
                            : null,
                        'tab'     => $control['tab']     ?? null,
                        'section' => $control['section'] ?? null,
                    ];
                }
            }
        }

        return $this->success([
            'widget_type'   => $widgetType,
            'label'         => ListThemeBuilderWidgets::THEME_WIDGETS[$widgetType]['label'],
            'control_count' => count($controls),
            'controls'      => $controls,
        ]);
    }
}
