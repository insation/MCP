<?php
/**
 * Configure Theme Builder Widget Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeWidgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ConfigureThemeBuilderWidget extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'configure_theme_builder_widget';
    }

    public function getDescription(): string
    {
        return 'Update the settings of an existing theme-builder widget already placed in a document, identified by its element ID. By default the supplied settings are merged into the widget\'s current settings (only the keys you pass change); pass replace=true to overwrite the settings object entirely. Use get_theme_builder_widget_schema to see valid settings keys.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document containing the widget.',
            ],
            'element_id' => [
                'required',
                'string',
                'description' => 'The element ID of the theme widget to configure.',
            ],
            'settings_json' => [
                'required',
                'string',
                'description' => 'JSON object of widget settings to apply.',
            ],
            'replace' => [
                'optional',
                'bool',
                'description' => 'If true, replace the entire settings object. If false (default), merge into existing settings.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('configuring a theme builder widget');

        $docId = (int) $parameters['document_id'];
        if ($this->elementor->getDocument($docId) === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        $elementId = (string) $parameters['element_id'];

        $decoded = json_decode((string) $parameters['settings_json'], true);
        if (!is_array($decoded)) {
            return $this->error('settings_json is not valid JSON, or did not decode to an object.');
        }

        $data  = $this->elementor->getDocumentData($docId);
        $found = $this->elementor->findElementById($data, $elementId);

        if ($found === null) {
            return $this->error("Element '{$elementId}' not found in document {$docId}.");
        }

        // findElementById returns ['path' => [...], 'element' => [...]].
        $element = $found['element'];
        $path    = $found['path'];

        if (($element['elType'] ?? null) !== 'widget') {
            return $this->error("Element '{$elementId}' is not a widget (elType: " . ($element['elType'] ?? 'unknown') . ').');
        }

        $widgetType = $element['widgetType'] ?? null;
        if ($widgetType === null || !isset(ListThemeBuilderWidgets::THEME_WIDGETS[$widgetType])) {
            return $this->error(
                "Element '{$elementId}' is widget type '" . ($widgetType ?? 'unknown') . "', which is not a theme-builder widget. Use the generic element tools for non-theme widgets."
            );
        }

        $replace = !empty($parameters['replace']);

        // Current settings as an array.
        $current = [];
        if (isset($element['settings'])) {
            $current = (array) $element['settings'];
        }

        $newSettings = $replace ? $decoded : array_merge($current, $decoded);

        // Build the replacement element, preserving everything except settings.
        $updatedElement = $element;
        $updatedElement['settings'] = (object) $newSettings;

        $newData = $this->elementor->replaceAtPath($data, $path, $updatedElement);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            return $this->error('Failed to save the document after configuring the widget.');
        }

        return $this->success([
            'document_id'    => $docId,
            'element_id'     => $elementId,
            'widget_type'    => $widgetType,
            'mode'           => $replace ? 'replace' : 'merge',
            'settings_keys'  => array_keys($newSettings),
        ], "Updated settings of '{$widgetType}' widget (element {$elementId}) in document {$docId}.");
    }
}
