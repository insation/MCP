<?php
/**
 * Find Theme Builder Widgets Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeWidgets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class FindThemeBuilderWidgets extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_theme_builder_widgets';
    }

    public function getDescription(): string
    {
        return 'Find every theme-builder widget used inside a document, or just the occurrences of one specific theme widget type. Returns each match\'s element ID, widget type, and current settings — useful for auditing what dynamic widgets a header/footer/single template is built from before editing them.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document to scan.',
            ],
            'widget_type' => [
                'optional',
                'string',
                'description' => 'Restrict the search to one theme widget type, e.g. theme-post-title. Omit to find all theme-builder widgets.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $docId = (int) $parameters['document_id'];
        if ($this->elementor->getDocument($docId) === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        $filterType = isset($parameters['widget_type']) && $parameters['widget_type'] !== ''
            ? (string) $parameters['widget_type']
            : null;

        if ($filterType !== null && !isset(ListThemeBuilderWidgets::THEME_WIDGETS[$filterType])) {
            return $this->error(
                "'{$filterType}' is not a recognized theme-builder widget.",
                ['valid_types' => array_keys(ListThemeBuilderWidgets::THEME_WIDGETS)]
            );
        }

        $data = $this->elementor->getDocumentData($docId);
        $matches = [];

        // walkElements yields ['path' => [...], 'element' => [...]] across the tree.
        foreach ($this->elementor->walkElements($data) as $entry) {
            $element = $entry['element'] ?? null;
            if (!is_array($element)) {
                continue;
            }
            if (($element['elType'] ?? null) !== 'widget') {
                continue;
            }
            $type = $element['widgetType'] ?? null;
            if ($type === null || !isset(ListThemeBuilderWidgets::THEME_WIDGETS[$type])) {
                continue;
            }
            if ($filterType !== null && $type !== $filterType) {
                continue;
            }
            $matches[] = [
                'element_id'  => $element['id'] ?? null,
                'widget_type' => $type,
                'label'       => ListThemeBuilderWidgets::THEME_WIDGETS[$type]['label'],
                'settings'    => isset($element['settings']) ? (array) $element['settings'] : [],
            ];
        }

        return $this->success([
            'document_id' => $docId,
            'widget_type' => $filterType,
            'match_count' => count($matches),
            'widgets'     => $matches,
        ]);
    }
}
