<?php
/**
 * List Form Actions Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListFormActions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_form_actions';
    }

    public function getDescription(): string
    {
        return 'List the form submit actions available in Elementor Pro — Email, Email 2, Redirect, Webhook, MailChimp, Drip, ActiveCampaign, GetResponse, ConvertKit, MailerLite, MailPoet, Slack, Discord, Contact Form 7 DB, and Activity Log. Each entry reports the action\'s registered name (used in add_form_action / form settings) and its human-readable label, and whether it is currently registered on this site.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        // Try to read the actually-registered actions from Pro's registrar.
        $registered = [];
        try {
            $module = null;
            $pro = $this->elementor->proPlugin();
            if (isset($pro->modules_manager) && is_object($pro->modules_manager)
                && method_exists($pro->modules_manager, 'get_modules')) {
                $module = $pro->modules_manager->get_modules('forms');
            }
            if (is_object($module) && method_exists($module, 'get_form_actions')) {
                $actions = $module->get_form_actions();
                if (is_array($actions)) {
                    $registered = array_keys($actions);
                }
            }
        } catch (\Throwable $e) {
            $registered = [];
        }

        $items = [];
        foreach (ElementorService::FORM_ACTIONS as $name => $label) {
            $items[] = [
                'name'       => $name,
                'label'      => $label,
                'registered' => empty($registered) ? null : in_array($name, $registered, true),
            ];
        }

        return $this->success([
            'count'   => count($items),
            'actions' => $items,
        ]);
    }
}
