<?php
/**
 * Manage Form Actions Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ManageFormActions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'manage_form_actions';
    }

    public function getDescription(): string
    {
        return 'Add or remove a submit action on an Elementor Pro form. Updates the form widget\'s submit_actions list. When adding an action you may also pass a JSON object of that action\'s settings keys (e.g. for "email": email_to, email_subject) which is merged into the form settings. Use list_form_actions for valid action names and get_form to inspect current actions.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document containing the form.',
            ],
            'element_id' => [
                'required',
                'string',
                'description' => 'The element ID of the form widget.',
            ],
            'action' => [
                'required',
                'string',
                'description' => 'One of: add, remove.',
            ],
            'action_name' => [
                'required',
                'string',
                'description' => 'The form action name, e.g. email, webhook, redirect, mailchimp, slack. See list_form_actions.',
            ],
            'action_settings_json' => [
                'optional',
                'string',
                'description' => 'For action=add: JSON object of that action\'s settings keys to merge into the form settings.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('managing form actions');

        $op = (string) $parameters['action'];
        if (!in_array($op, ['add', 'remove'], true)) {
            return $this->error("Invalid action '{$op}'. Use 'add' or 'remove'.");
        }

        $actionName = (string) $parameters['action_name'];
        if (!isset(ElementorService::FORM_ACTIONS[$actionName])) {
            return $this->error(
                "'{$actionName}' is not a recognized form action.",
                ['valid_actions' => array_keys(ElementorService::FORM_ACTIONS)]
            );
        }

        $docId = (int) $parameters['document_id'];
        if ($this->elementor->getDocument($docId) === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        $elementId = (string) $parameters['element_id'];
        $data  = $this->elementor->getDocumentData($docId);
        $found = $this->elementor->findElementById($data, $elementId);
        if ($found === null) {
            return $this->error("Element '{$elementId}' not found in document {$docId}.");
        }

        $element = $found['element'];
        $path    = $found['path'];
        if (($element['widgetType'] ?? null) !== ElementorService::FORM_WIDGET_TYPE) {
            return $this->error("Element '{$elementId}' is not a form widget.");
        }

        $settings = isset($element['settings']) ? (array) $element['settings'] : [];
        $actions  = isset($settings['submit_actions']) && is_array($settings['submit_actions'])
            ? array_values(array_map('strval', $settings['submit_actions']))
            : [];

        if ($op === 'add') {
            if (!in_array($actionName, $actions, true)) {
                $actions[] = $actionName;
            }
            // Merge optional action settings.
            if (!empty($parameters['action_settings_json'])) {
                $decoded = json_decode((string) $parameters['action_settings_json'], true);
                if (!is_array($decoded)) {
                    return $this->error('action_settings_json is not valid JSON, or did not decode to an object.');
                }
                $settings = array_merge($settings, $decoded);
            }
        } else { // remove
            $actions = array_values(array_filter($actions, static fn($a) => $a !== $actionName));
        }

        $settings['submit_actions'] = $actions;

        $updatedElement = $element;
        $updatedElement['settings'] = (object) $settings;
        $newData = $this->elementor->replaceAtPath($data, $path, $updatedElement);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            return $this->error('Failed to save the document after updating form actions.');
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $elementId,
            'operation'   => $op,
            'action_name' => $actionName,
            'actions'     => $actions,
        ], ($op === 'add' ? "Added" : "Removed") . " form action '{$actionName}' " .
            ($op === 'add' ? "to" : "from") . " form {$elementId} in document {$docId}.");
    }
}
