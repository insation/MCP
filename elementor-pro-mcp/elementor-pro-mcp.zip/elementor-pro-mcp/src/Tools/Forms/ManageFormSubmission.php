<?php
/**
 * Manage Form Submission Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ManageFormSubmission extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'manage_form_submission';
    }

    public function getDescription(): string
    {
        return 'Move an Elementor Pro form submission to trash, restore it from trash, or permanently delete it. Requires the Pro Submissions feature to be enabled. Permanent deletion cannot be undone and is blocked when safe mode is on.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'submission_id' => [
                'required',
                'int',
                'description' => 'The submission ID.',
            ],
            'action' => [
                'required',
                'string',
                'description' => 'One of: trash, restore, delete. "delete" is permanent.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        if (!$this->elementor->areSubmissionsEnabled()) {
            return $this->error('The Elementor Pro Submissions feature is not enabled on this site.');
        }

        $action = (string) $parameters['action'];
        if (!in_array($action, ['trash', 'restore', 'delete'], true)) {
            return $this->error("Invalid action '{$action}'. Use 'trash', 'restore', or 'delete'.");
        }

        // Permanent delete is the destructive one.
        if ($action === 'delete') {
            $this->checkSafeMode('permanently deleting a form submission');
        }

        try {
            $query = $this->elementor->formSubmissionsQuery();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $submissionId = (int) $parameters['submission_id'];

        try {
            switch ($action) {
                case 'trash':
                    $ok = $query->move_to_trash_submission($submissionId);
                    break;
                case 'restore':
                    $ok = $query->restore($submissionId);
                    break;
                case 'delete':
                default:
                    $ok = $query->delete_submission($submissionId);
                    break;
            }
        } catch (\Throwable $e) {
            return $this->error("Failed to {$action} submission: " . $e->getMessage());
        }

        if (!$ok) {
            // Surface Pro's own last error if available.
            $detail = '';
            try {
                if (method_exists($query, 'get_last_error')) {
                    $err = $query->get_last_error();
                    if (!empty($err)) {
                        $detail = ' (' . (is_string($err) ? $err : json_encode($err)) . ')';
                    }
                }
            } catch (\Throwable $e) {
                // ignore
            }
            return $this->error("Could not {$action} submission ID {$submissionId}{$detail}.");
        }

        $messages = [
            'trash'   => "Moved submission ID {$submissionId} to trash.",
            'restore' => "Restored submission ID {$submissionId} from trash.",
            'delete'  => "Permanently deleted submission ID {$submissionId}.",
        ];

        return $this->success([
            'submission_id' => $submissionId,
            'action'        => $action,
        ], $messages[$action]);
    }
}
