<?php
/**
 * Get Form Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetForm extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_form';
    }

    public function getDescription(): string
    {
        return 'Get the full configuration of a single Elementor Pro form, identified by its document ID and the form widget\'s element ID. Returns the form name, the list of form fields (each field\'s id, type, label, and required flag), the configured submit actions, and the complete raw settings object.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document containing the form.',
            ],
            'element_id' => [
                'required',
                'string',
                'description' => 'The element ID of the form widget. See list_forms.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $docId = (int) $parameters['document_id'];
        if ($this->elementor->getDocument($docId) === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        $elementId = (string) $parameters['element_id'];
        $data  = $this->elementor->getDocumentData($docId);
        $found = $this->elementor->findElementById($data, $elementId);

        if ($found === null) {
            return $this->error("Element '{$elementId}' not found in document {$docId}.");
        }

        $element = $found['element'];
        if (($element['widgetType'] ?? null) !== ElementorService::FORM_WIDGET_TYPE) {
            return $this->error(
                "Element '{$elementId}' is not a form widget (widgetType: " . ($element['widgetType'] ?? 'unknown') . ').'
            );
        }

        $settings = isset($element['settings']) ? (array) $element['settings'] : [];

        // Parse the form_fields repeater into a clean summary.
        $fields = [];
        if (isset($settings['form_fields']) && is_array($settings['form_fields'])) {
            foreach ($settings['form_fields'] as $field) {
                $field = (array) $field;
                $fields[] = [
                    'custom_id'   => $field['custom_id']   ?? null,
                    'field_type'  => $field['field_type']  ?? null,
                    'field_label' => $field['field_label'] ?? null,
                    'required'    => !empty($field['required']),
                    'placeholder' => $field['placeholder'] ?? null,
                ];
            }
        }

        // Configured submit actions.
        $actions = [];
        if (isset($settings['submit_actions']) && is_array($settings['submit_actions'])) {
            $actions = array_values(array_map('strval', $settings['submit_actions']));
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $elementId,
            'form_name'   => $settings['form_name'] ?? '',
            'field_count' => count($fields),
            'fields'      => $fields,
            'actions'     => $actions,
            'raw_settings'=> $settings,
        ]);
    }
}
