<?php
/**
 * List Forms Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListForms extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_forms';
    }

    public function getDescription(): string
    {
        return 'Find every Elementor Pro Form widget across the site. Scans all Elementor-built pages, posts, and library templates and returns each form\'s containing document ID and title, the form widget\'s element ID, and the form name. Use this to locate a form before reading or editing its fields and actions.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $forms = $this->elementor->findAllForms();

        return $this->success([
            'count' => count($forms),
            'forms' => $forms,
        ]);
    }
}
