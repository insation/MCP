<?php
/**
 * Count Form Submissions Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class CountFormSubmissions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'count_form_submissions';
    }

    public function getDescription(): string
    {
        return 'Count Elementor Pro form submissions broken down by status (new vs trash). Requires the Pro Submissions feature to be enabled. A fast way to see submission volume without paging through the full list.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        if (!$this->elementor->areSubmissionsEnabled()) {
            return $this->error('The Elementor Pro Submissions feature is not enabled on this site.');
        }

        try {
            $query = $this->elementor->formSubmissionsQuery();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $counts = $query->count_submissions_by_status();
        } catch (\Throwable $e) {
            return $this->error('Failed to count submissions: ' . $e->getMessage());
        }

        // Normalize to a predictable shape.
        $byStatus = [];
        if (is_array($counts)) {
            foreach ($counts as $status => $count) {
                $byStatus[(string) $status] = (int) $count;
            }
        }

        return $this->success([
            'by_status' => $byStatus,
            'total'     => array_sum($byStatus),
        ]);
    }
}
