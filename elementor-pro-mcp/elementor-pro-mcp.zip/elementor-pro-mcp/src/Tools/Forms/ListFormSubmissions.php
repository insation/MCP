<?php
/**
 * List Form Submissions Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListFormSubmissions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_form_submissions';
    }

    public function getDescription(): string
    {
        return 'List Elementor Pro form submissions from the submissions database, with pagination. Requires the Pro Submissions feature to be enabled. Optionally filter by status (new or trash). Returns each submission\'s id, the form it came from, status, and created date.';
    }

    public function getSchema(): array
    {
        return [
            'page' => [
                'optional',
                'int',
                'description' => 'Page number (1-based). Default 1.',
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100],
                'description' => 'Results per page (1-100). Default 25.',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Filter by status: new or trash.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        if (!$this->elementor->areSubmissionsEnabled()) {
            return $this->error('The Elementor Pro Submissions feature is not enabled on this site, so there are no stored submissions to read.');
        }

        try {
            $query = $this->elementor->formSubmissionsQuery();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $args = [
            'page'     => max(1, (int) ($parameters['page'] ?? 1)),
            'per_page' => max(1, min(100, (int) ($parameters['per_page'] ?? 25))),
        ];

        if (isset($parameters['status']) && $parameters['status'] !== '') {
            $status = (string) $parameters['status'];
            if (!in_array($status, ['new', 'trash'], true)) {
                return $this->error("Invalid status '{$status}'. Use 'new' or 'trash'.");
            }
            $args['filters'] = ['main_meta_status' => $status];
        }

        try {
            $result = $query->get_submissions($args);
        } catch (\Throwable $e) {
            return $this->error('Failed to read submissions: ' . $e->getMessage());
        }

        $rows = is_array($result) && isset($result['data']) && is_array($result['data'])
            ? $result['data']
            : [];

        // Normalize each row to a stable summary shape.
        $submissions = [];
        foreach ($rows as $row) {
            $row = (array) $row;
            $submissions[] = [
                'id'           => isset($row['id']) ? (int) $row['id'] : null,
                'post_id'      => isset($row['post_id']) ? (int) $row['post_id'] : null,
                'element_id'   => $row['element_id'] ?? null,
                'form_name'    => $row['form_name'] ?? null,
                'status'       => $row['status'] ?? null,
                'created_at'   => $row['created_at'] ?? null,
                'main_meta_id' => $row['main_meta_id'] ?? null,
            ];
        }

        $meta = is_array($result) && isset($result['meta']) ? $result['meta'] : [];

        return $this->success([
            'page'        => $args['page'],
            'per_page'    => $args['per_page'],
            'count'       => count($submissions),
            'total'       => $meta['total'] ?? null,
            'submissions' => $submissions,
        ]);
    }
}
