<?php
/**
 * Get Form Submission Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Forms;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetFormSubmission extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_form_submission';
    }

    public function getDescription(): string
    {
        return 'Get the full detail of a single Elementor Pro form submission by its submission ID — the submitted field values, the form and page it came from, status, created date, and the form-actions log (which submit actions ran and whether they succeeded). Requires the Pro Submissions feature to be enabled.';
    }

    public function getSchema(): array
    {
        return [
            'submission_id' => [
                'required',
                'int',
                'description' => 'The submission ID. See list_form_submissions.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        if (!$this->elementor->areSubmissionsEnabled()) {
            return $this->error('The Elementor Pro Submissions feature is not enabled on this site.');
        }

        try {
            $query = $this->elementor->formSubmissionsQuery();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $submissionId = (int) $parameters['submission_id'];

        try {
            $submission = $query->get_submission($submissionId);
        } catch (\Throwable $e) {
            return $this->error('Failed to read submission: ' . $e->getMessage());
        }

        if (empty($submission)) {
            return $this->error("No submission found with ID {$submissionId}.");
        }

        // get_submission returns a structured array; pass it through but ensure
        // it is a plain array for JSON encoding.
        $submission = json_decode(json_encode($submission), true);

        return $this->success([
            'submission_id' => $submissionId,
            'submission'    => $submission,
        ]);
    }
}
