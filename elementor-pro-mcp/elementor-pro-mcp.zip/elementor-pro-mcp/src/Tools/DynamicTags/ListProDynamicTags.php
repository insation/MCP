<?php
/**
 * List Pro Dynamic Tags Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\DynamicTags;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListProDynamicTags extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_pro_dynamic_tags';
    }

    public function getDescription(): string
    {
        return 'List the Elementor Pro dynamic tags — the dynamic data sources usable in widget controls (post title, post date, featured image, author info, archive title, site logo, custom field, shortcode, request arg, and many more). Reports the known Pro dynamic tags and, where readable, the live set registered on this site with their groups.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        // Live registered tags (name => group), if the manager exposes them.
        $registered = $this->elementor->getRegisteredDynamicTags();

        $items = [];
        foreach (ElementorService::PRO_DYNAMIC_TAGS as $name) {
            $items[] = [
                'name'       => $name,
                'registered' => empty($registered) ? null : array_key_exists($name, $registered),
                'group'      => $registered[$name] ?? null,
            ];
        }

        // Also surface any registered tags not in our canonical Pro list
        // (e.g. tags added by ACF/Pods/Toolset bridges or other plugins).
        $extra = [];
        foreach ($registered as $name => $group) {
            if (!in_array($name, ElementorService::PRO_DYNAMIC_TAGS, true)) {
                $extra[] = ['name' => $name, 'group' => $group];
            }
        }

        return $this->success([
            'count'              => count($items),
            'pro_dynamic_tags'   => $items,
            'other_registered'   => $extra,
        ]);
    }
}
