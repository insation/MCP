<?php
/**
 * Find Dynamic Tag Usage Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\DynamicTags;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class FindDynamicTagUsage extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_dynamic_tag_usage';
    }

    public function getDescription(): string
    {
        return 'Scan a single Elementor document for dynamic-tag usage. Elementor stores dynamic values in a control\'s "__dynamic__" settings key; this tool walks the document\'s element tree and reports every element that uses a dynamic tag, which control it is bound to, and the dynamic tag expression. Useful for auditing how a template pulls in dynamic content before editing it.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document to scan.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $docId = (int) $parameters['document_id'];
        if ($this->elementor->getDocument($docId) === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        $data  = $this->elementor->getDocumentData($docId);
        $usages = [];

        foreach ($this->elementor->walkElements($data) as $entry) {
            $element = $entry['element'] ?? null;
            if (!is_array($element)) {
                continue;
            }
            $settings = isset($element['settings']) ? (array) $element['settings'] : [];

            // Dynamic values live under settings['__dynamic__'] => [controlKey => tagExpression].
            if (empty($settings['__dynamic__']) || !is_array($settings['__dynamic__'])) {
                continue;
            }

            foreach ($settings['__dynamic__'] as $controlKey => $tagExpression) {
                // The expression looks like: [elementor-tag id="..." name="post-title" settings="..."]
                $tagName = null;
                if (is_string($tagExpression) && preg_match('/name="([^"]+)"/', $tagExpression, $m)) {
                    $tagName = $m[1];
                }
                $usages[] = [
                    'element_id'   => $element['id'] ?? null,
                    'el_type'      => $element['elType'] ?? null,
                    'widget_type'  => $element['widgetType'] ?? null,
                    'control_key'  => (string) $controlKey,
                    'tag_name'     => $tagName,
                    'expression'   => is_string($tagExpression) ? $tagExpression : null,
                ];
            }
        }

        return $this->success([
            'document_id' => $docId,
            'usage_count' => count($usages),
            'usages'      => $usages,
        ]);
    }
}
