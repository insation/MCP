<?php
/**
 * List Custom Code Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.3.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\CustomCode;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListCustomCode extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_custom_code';
    }

    public function getDescription(): string
    {
        return 'List all Elementor Pro Custom Code snippets. Each entry returns the snippet\'s post ID, title, status, output location (head, body_start, body_end), priority, and any display conditions attached. Custom Code snippets inject HTML/JS/CSS into the site at the chosen location.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $snippets = $this->elementor->listCustomCodeSnippets();

        return $this->success([
            'count'    => count($snippets),
            'snippets' => $snippets,
        ]);
    }
}
