<?php
/**
 * Create Custom Code Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.3.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\CustomCode;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class CreateCustomCode extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'create_custom_code';
    }

    public function getDescription(): string
    {
        return 'Create a new Elementor Pro Custom Code snippet — a block of HTML/JS/CSS injected into the site at a chosen location (head, body_start, or body_end) with a priority and optional display conditions. Returns the new snippet post ID. Note: custom code runs on the site front end, so review the code carefully before publishing.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'description' => 'A name for the snippet.',
            ],
            'code' => [
                'required',
                'string',
                'description' => 'The snippet body — HTML/JS/CSS as it would be entered in the Custom Code editor.',
            ],
            'location' => [
                'optional',
                'string',
                'description' => 'Where to output the code: head, body_start, or body_end. Default head.',
            ],
            'priority' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100],
                'description' => 'Output priority (1-100, lower runs earlier). Default 10.',
            ],
            'conditions' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Display condition strings, e.g. ["include/general"].',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Post status: publish or draft. Default draft (so it does not run until reviewed).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('creating a custom code snippet');

        $title    = (string) $parameters['title'];
        $code     = (string) $parameters['code'];
        $location = $parameters['location'] ?? 'head';
        $priority = isset($parameters['priority']) ? (int) $parameters['priority'] : 10;
        // Default to draft — custom code executes on the front end, so it should
        // not go live until a human has reviewed it.
        $status   = $parameters['status'] ?? 'draft';

        if (!in_array($location, ElementorService::CUSTOM_CODE_LOCATIONS, true)) {
            return $this->error(
                "Invalid location '{$location}'.",
                ['valid_locations' => ElementorService::CUSTOM_CODE_LOCATIONS]
            );
        }
        if (!in_array($status, ['publish', 'draft'], true)) {
            return $this->error("Invalid status '{$status}'. Use 'publish' or 'draft'.");
        }

        $conditions = [];
        if (!empty($parameters['conditions']) && is_array($parameters['conditions'])) {
            $conditions = array_values(array_filter(array_map('strval', $parameters['conditions'])));
        }

        try {
            $snippetId = $this->elementor->createCustomCodeSnippet(
                $title,
                $code,
                $location,
                $priority,
                $conditions,
                $status
            );
        } catch (\RuntimeException $e) {
            return $this->error('Failed to create custom code snippet: ' . $e->getMessage());
        }

        return $this->success([
            'id'         => $snippetId,
            'title'      => $title,
            'location'   => $location,
            'priority'   => $priority,
            'status'     => $status,
            'conditions' => $conditions,
        ], "Created custom code snippet '{$title}' (ID {$snippetId}, status: {$status}).");
    }
}
