<?php
/**
 * Get Custom Code Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.3.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\CustomCode;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetCustomCode extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_custom_code';
    }

    public function getDescription(): string
    {
        return 'Get a single Elementor Pro Custom Code snippet by its post ID — its title, status, output location, priority, display conditions, and the full code body.';
    }

    public function getSchema(): array
    {
        return [
            'snippet_id' => [
                'required',
                'int',
                'description' => 'The post ID of the custom code snippet.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $snippetId = (int) $parameters['snippet_id'];
        if (!$this->elementor->isCustomCodeSnippet($snippetId)) {
            return $this->error("No Elementor custom code snippet found with ID {$snippetId}.");
        }

        $post = get_post($snippetId);
        $location   = get_post_meta($snippetId, '_elementor_location', true);
        $priority   = get_post_meta($snippetId, '_elementor_priority', true);
        $conditions = get_post_meta($snippetId, '_elementor_conditions', true);

        return $this->success([
            'id'         => $snippetId,
            'title'      => $post->post_title,
            'status'     => $post->post_status,
            'location'   => is_string($location) && $location !== '' ? $location : null,
            'priority'   => $priority !== '' ? (int) $priority : null,
            'conditions' => is_array($conditions)
                ? array_values(array_filter(array_map('strval', $conditions)))
                : [],
            'code'       => $post->post_content,
            'modified'   => $post->post_modified_gmt,
        ]);
    }
}
