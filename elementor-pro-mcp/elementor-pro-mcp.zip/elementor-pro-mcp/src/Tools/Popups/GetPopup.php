<?php
/**
 * Get Popup Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Popups;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetPopup extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_popup';
    }

    public function getDescription(): string
    {
        return 'Get a single Elementor Pro popup\'s full configuration: title, status, the open/close triggers (on load, on scroll, on click, on exit intent, after inactivity), the timing rules (frequency, show after X page views/sessions, schedule), and optionally the popup\'s element tree. Trigger and timing settings live in the popup document\'s page settings.';
    }

    public function getSchema(): array
    {
        return [
            'popup_id' => [
                'required',
                'int',
                'description' => 'The post ID of the popup.',
            ],
            'include_elements' => [
                'optional',
                'bool',
                'description' => 'Include the popup\'s full Elementor element tree. Default false.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $popupId = (int) $parameters['popup_id'];
        $post = get_post($popupId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library item found with ID {$popupId}.");
        }
        if (!$this->elementor->isPopup($popupId)) {
            return $this->error(
                "Post {$popupId} is not a popup (type: " . ($this->elementor->getTemplateType($popupId) ?? 'unknown') . ').'
            );
        }

        // Popup triggers/timing live in the document page settings.
        $pageSettings = $this->elementor->getPageSettings($popupId);

        // Pull the popup-specific keys out for a focused view, but also return
        // the full settings object so nothing is hidden.
        $triggers = [];
        $timing   = [];
        foreach ($pageSettings as $key => $value) {
            if (strpos($key, 'triggers_') === 0 || strpos($key, 'timing_') === 0) {
                if (strpos($key, 'triggers_') === 0) {
                    $triggers[$key] = $value;
                } else {
                    $timing[$key] = $value;
                }
            }
        }

        $result = [
            'id'             => $popupId,
            'title'          => $post->post_title,
            'status'         => $post->post_status,
            'modified'       => $post->post_modified_gmt,
            'triggers'       => $triggers,
            'timing'         => $timing,
            'page_settings'  => $pageSettings,
            'edit_url'       => admin_url('post.php?post=' . $popupId . '&action=elementor'),
        ];

        if (!empty($parameters['include_elements'])) {
            $result['elements'] = $this->elementor->getDocumentData($popupId);
        }

        return $this->success($result);
    }
}
