<?php
/**
 * Update Popup Triggers Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Popups;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class UpdatePopupTriggers extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_popup_triggers';
    }

    public function getDescription(): string
    {
        return 'Update an Elementor Pro popup\'s trigger and timing settings — when the popup opens (on page load, on scroll, on click, on exit intent, after inactivity) and how often it shows (frequency, after N page views or sessions, schedule). Supplied settings are merged into the popup\'s page settings; pass replace=true to overwrite the page settings entirely. Use get_popup first to see the current trigger/timing keys.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'popup_id' => [
                'required',
                'int',
                'description' => 'The post ID of the popup.',
            ],
            'settings_json' => [
                'required',
                'string',
                'description' => 'JSON object of trigger/timing settings keys to apply, e.g. {"triggers_on_load":"yes","triggers_on_load_delay":3,"timing_times":1}.',
            ],
            'replace' => [
                'optional',
                'bool',
                'description' => 'If true, replace the entire page-settings object. If false (default), merge into existing page settings.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('updating popup triggers');

        $popupId = (int) $parameters['popup_id'];
        $post = get_post($popupId);
        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library item found with ID {$popupId}.");
        }
        if (!$this->elementor->isPopup($popupId)) {
            return $this->error("Post {$popupId} is not a popup.");
        }

        $decoded = json_decode((string) $parameters['settings_json'], true);
        if (!is_array($decoded)) {
            return $this->error('settings_json is not valid JSON, or did not decode to an object.');
        }

        $replace = !empty($parameters['replace']);
        $current = $this->elementor->getPageSettings($popupId);

        $newSettings = $replace ? $decoded : array_merge($current, $decoded);

        $saved = $this->elementor->savePageSettings($popupId, $newSettings);
        if (!$saved) {
            return $this->error('Failed to save the popup page settings.');
        }

        return $this->success([
            'popup_id'      => $popupId,
            'mode'          => $replace ? 'replace' : 'merge',
            'applied_keys'  => array_keys($decoded),
            'page_settings' => $newSettings,
        ], "Updated trigger/timing settings for popup ID {$popupId}.");
    }
}
