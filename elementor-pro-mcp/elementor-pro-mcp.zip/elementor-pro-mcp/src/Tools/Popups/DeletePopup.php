<?php
/**
 * Delete Popup Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Popups;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class DeletePopup extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_popup';
    }

    public function getDescription(): string
    {
        return 'Delete an Elementor Pro popup. By default the popup is moved to trash (recoverable); pass force=true to permanently delete it.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'popup_id' => [
                'required',
                'int',
                'description' => 'The post ID of the popup to delete.',
            ],
            'force' => [
                'optional',
                'bool',
                'description' => 'Permanently delete instead of moving to trash. Default false.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('deleting a popup');

        $popupId = (int) $parameters['popup_id'];
        $post = get_post($popupId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library item found with ID {$popupId}.");
        }
        if (!$this->elementor->isPopup($popupId)) {
            return $this->error("Post {$popupId} is not a popup.");
        }

        $force = !empty($parameters['force']);
        $title = $post->post_title;

        $result = wp_delete_post($popupId, $force);
        if (!$result) {
            return $this->error("Failed to delete popup ID {$popupId}.");
        }

        return $this->success([
            'id'          => $popupId,
            'title'       => $title,
            'permanently' => $force,
        ], $force
            ? "Permanently deleted popup '{$title}' (ID {$popupId})."
            : "Moved popup '{$title}' (ID {$popupId}) to trash.");
    }
}
