<?php
/**
 * Create Popup Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\Popups;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class CreatePopup extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'create_popup';
    }

    public function getDescription(): string
    {
        return 'Create a new Elementor Pro popup. Optionally provide an initial element tree for the popup content. Triggers and timing rules can be set afterward with update_popup_triggers. Returns the new popup post ID and its Elementor edit URL.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'title' => [
                'required',
                'string',
                'description' => 'Title for the new popup.',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Post status: publish or draft. Default publish.',
            ],
            'elements_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded Elementor element tree for the popup content. If omitted, the popup is created empty.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('creating a popup');

        $title  = (string) $parameters['title'];
        $status = $parameters['status'] ?? 'publish';
        if (!in_array($status, ['publish', 'draft'], true)) {
            return $this->error("Invalid status '{$status}'. Use 'publish' or 'draft'.");
        }

        $elements = [];
        if (!empty($parameters['elements_json'])) {
            $decoded = json_decode((string) $parameters['elements_json'], true);
            if (!is_array($decoded)) {
                return $this->error('elements_json is not valid JSON, or did not decode to an array.');
            }
            $elements = $decoded;
        }

        try {
            $popupId = $this->elementor->createPopup($title, $elements, $status);
        } catch (\RuntimeException $e) {
            return $this->error('Failed to create popup: ' . $e->getMessage());
        }

        return $this->success([
            'id'       => $popupId,
            'title'    => $title,
            'status'   => $status,
            'edit_url' => admin_url('post.php?post=' . $popupId . '&action=elementor'),
        ], "Created popup '{$title}' (ID {$popupId}).");
    }
}
