<?php
/**
 * Insert WooCommerce Widget Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\WooCommerce;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class InsertWooCommerceWidget extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'insert_woocommerce_widget';
    }

    public function getDescription(): string
    {
        return 'Insert an Elementor Pro WooCommerce Builder widget (product title, price, images, add-to-cart, related products, cart, checkout, etc.) into a document — typically a WooCommerce product or product-archive template. The widget is inserted as a child of a target element or at the document root, with a fresh element ID. Requires Elementor Pro and WooCommerce. Provide settings as a JSON object.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => [
                'required',
                'int',
                'description' => 'The post ID of the document to insert the widget into.',
            ],
            'widget_type' => [
                'required',
                'string',
                'description' => 'The WooCommerce widget type, e.g. woocommerce-product-title, woocommerce-cart. See list_woocommerce_widgets.',
            ],
            'settings_json' => [
                'optional',
                'string',
                'description' => 'JSON object of widget settings. Omit for widget defaults.',
            ],
            'parent_id' => [
                'optional',
                'string',
                'description' => 'Element ID of the container/section to insert into. Omit to insert at the document root.',
            ],
            'position' => [
                'optional',
                'int',
                'description' => 'Zero-based insertion index among the target\'s children. Omit to append.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('inserting a WooCommerce widget');

        if (!class_exists('\WooCommerce') && !function_exists('WC')) {
            return $this->error('WooCommerce is not active. WooCommerce widgets require the WooCommerce plugin.');
        }

        $widgetType = (string) $parameters['widget_type'];
        if (!isset(ListWooCommerceWidgets::WOO_WIDGETS[$widgetType])) {
            return $this->error(
                "'{$widgetType}' is not a recognized WooCommerce widget.",
                ['valid_types' => array_keys(ListWooCommerceWidgets::WOO_WIDGETS)]
            );
        }

        $docId = (int) $parameters['document_id'];
        if ($this->elementor->getDocument($docId) === null) {
            return $this->error("No Elementor document found with ID {$docId}.");
        }

        $settings = [];
        if (!empty($parameters['settings_json'])) {
            $decoded = json_decode((string) $parameters['settings_json'], true);
            if (!is_array($decoded)) {
                return $this->error('settings_json is not valid JSON, or did not decode to an object.');
            }
            $settings = $decoded;
        }

        $element = [
            'id'         => $this->elementor->newElementId(),
            'elType'     => 'widget',
            'widgetType' => $widgetType,
            'settings'   => (object) $settings,
            'elements'   => [],
        ];

        $data = $this->elementor->getDocumentData($docId);

        if (empty($parameters['parent_id'])) {
            $position = isset($parameters['position'])
                ? max(0, min((int) $parameters['position'], count($data)))
                : count($data);
            array_splice($data, $position, 0, [$element]);
            $newData = array_values($data);
        } else {
            $parentId = (string) $parameters['parent_id'];
            $parentPath = $this->elementor->pathToId($data, $parentId);
            if ($parentPath === null) {
                return $this->error("Parent element '{$parentId}' not found in document {$docId}.");
            }
            $cursor = ['elements' => $data];
            foreach ($parentPath as $idx) {
                $cursor = $cursor['elements'][$idx];
            }
            $childCount = isset($cursor['elements']) && is_array($cursor['elements'])
                ? count($cursor['elements'])
                : 0;
            $position = isset($parameters['position'])
                ? max(0, min((int) $parameters['position'], $childCount))
                : $childCount;
            $childPath = array_merge($parentPath, [$position]);
            $newData = $this->elementor->insertAtPath($data, $childPath, $element);
        }

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            return $this->error('Failed to save the document after inserting the widget.');
        }

        return $this->success([
            'document_id'         => $docId,
            'widget_type'         => $widgetType,
            'inserted_element_id' => $element['id'],
            'parent_id'           => $parameters['parent_id'] ?? null,
            'position'            => $position,
        ], "Inserted '{$widgetType}' widget into document {$docId} (element ID {$element['id']}).");
    }
}
