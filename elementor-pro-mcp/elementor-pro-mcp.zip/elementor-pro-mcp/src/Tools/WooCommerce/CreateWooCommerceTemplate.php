<?php
/**
 * Create WooCommerce Template Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\WooCommerce;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class CreateWooCommerceTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'create_woocommerce_template';
    }

    public function getDescription(): string
    {
        return 'Create a new Elementor Pro WooCommerce Builder template — a single product template (type "product") or a product archive/shop template (type "product-archive"). Requires Elementor Pro and WooCommerce. Optionally provide an initial element tree and display conditions. Returns the new template post ID and edit URL.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'type' => [
                'required',
                'string',
                'description' => 'WooCommerce template type: product (single product) or product-archive (shop/category archive).',
            ],
            'title' => [
                'required',
                'string',
                'description' => 'Title for the new template.',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Post status: publish or draft. Default publish.',
            ],
            'elements_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded Elementor element tree for the template content. If omitted, the template is created empty.',
            ],
            'conditions' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Display condition strings to attach immediately, e.g. ["include/product_archive"] or ["include/singular/product"].',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('creating a WooCommerce template');

        if (!class_exists('\WooCommerce') && !function_exists('WC')) {
            return $this->error('WooCommerce is not active. WooCommerce Builder templates require the WooCommerce plugin.');
        }

        $type = (string) $parameters['type'];
        // Only the user-facing creatable types — product-post is an internal variant.
        $creatable = ['product', 'product-archive'];
        if (!in_array($type, $creatable, true)) {
            return $this->error(
                "Invalid WooCommerce template type '{$type}'.",
                ['valid_types' => $creatable]
            );
        }

        $title  = (string) $parameters['title'];
        $status = $parameters['status'] ?? 'publish';
        if (!in_array($status, ['publish', 'draft'], true)) {
            return $this->error("Invalid status '{$status}'. Use 'publish' or 'draft'.");
        }

        $elements = [];
        if (!empty($parameters['elements_json'])) {
            $decoded = json_decode((string) $parameters['elements_json'], true);
            if (!is_array($decoded)) {
                return $this->error('elements_json is not valid JSON, or did not decode to an array.');
            }
            $elements = $decoded;
        }

        // The Elementor documents manager creates the document; WooCommerce
        // document types register under these same slugs.
        try {
            $documentsManager = $this->elementor->plugin()->documents;
            if (!is_object($documentsManager) || !method_exists($documentsManager, 'create')) {
                return $this->error('Elementor documents manager unavailable.');
            }
            $document = $documentsManager->create(
                $type,
                [
                    'post_title'  => $title !== '' ? $title : ucfirst(str_replace('-', ' ', $type)) . ' Template',
                    'post_status' => $status,
                ]
            );
            if (!is_object($document) || !method_exists($document, 'get_main_id')) {
                return $this->error("Failed to create {$type} template document.");
            }
            $templateId = (int) $document->get_main_id();
        } catch (\Throwable $e) {
            return $this->error('Failed to create WooCommerce template: ' . $e->getMessage());
        }

        if (!empty($elements)) {
            $this->elementor->saveDocumentData($templateId, $elements);
        }

        $conditionsApplied = [];
        if (!empty($parameters['conditions']) && is_array($parameters['conditions'])) {
            $conditions = array_values(array_filter(array_map('strval', $parameters['conditions'])));
            if (!empty($conditions)) {
                $this->elementor->saveTemplateConditions($templateId, $conditions);
                $conditionsApplied = $conditions;
            }
        }

        return $this->success([
            'id'         => $templateId,
            'type'       => $type,
            'title'      => $title,
            'status'     => $status,
            'conditions' => $conditionsApplied,
            'edit_url'   => admin_url('post.php?post=' . $templateId . '&action=elementor'),
        ], "Created WooCommerce {$type} template '{$title}' (ID {$templateId}).");
    }
}
