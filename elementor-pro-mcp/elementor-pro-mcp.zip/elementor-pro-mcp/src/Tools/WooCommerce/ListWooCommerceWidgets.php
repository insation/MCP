<?php
/**
 * List WooCommerce Widgets Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\WooCommerce;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListWooCommerceWidgets extends AbstractTool
{
    protected ElementorService $elementor;

    /**
     * The WooCommerce widgets shipped by Elementor Pro, keyed by widget type
     * (the value of each widget's get_name()), with a human-readable label and
     * a usage group. This is the canonical list the other WooCommerce widget
     * tools validate against.
     *
     * @var array<string, array{label:string, group:string}>
     */
    public const WOO_WIDGETS = [
        // Single product building blocks
        'woocommerce-product-title'                  => ['label' => 'Product Title',            'group' => 'single-product'],
        'woocommerce-product-images'                 => ['label' => 'Product Images',           'group' => 'single-product'],
        'woocommerce-product-price'                  => ['label' => 'Product Price',            'group' => 'single-product'],
        'woocommerce-product-add-to-cart'            => ['label' => 'Product Add To Cart',      'group' => 'single-product'],
        'woocommerce-product-rating'                 => ['label' => 'Product Rating',           'group' => 'single-product'],
        'woocommerce-product-stock'                  => ['label' => 'Product Stock',            'group' => 'single-product'],
        'woocommerce-product-meta'                   => ['label' => 'Product Meta',             'group' => 'single-product'],
        'woocommerce-product-content'                => ['label' => 'Product Content',          'group' => 'single-product'],
        'woocommerce-product-short-description'      => ['label' => 'Product Short Description', 'group' => 'single-product'],
        'woocommerce-product-data-tabs'              => ['label' => 'Product Data Tabs',        'group' => 'single-product'],
        'woocommerce-product-additional-information' => ['label' => 'Additional Information',   'group' => 'single-product'],
        'woocommerce-product-related'                => ['label' => 'Related Products',         'group' => 'single-product'],
        'woocommerce-product-upsell'                 => ['label' => 'Upsells',                  'group' => 'single-product'],
        'wc-single-elements'                         => ['label' => 'Single Product (Elements)', 'group' => 'single-product'],
        'wc-add-to-cart'                             => ['label' => 'Custom Add To Cart',       'group' => 'single-product'],
        // Archive / shop
        'wc-archive-products'                        => ['label' => 'Archive Products',         'group' => 'archive'],
        'woocommerce-products'                       => ['label' => 'Products',                 'group' => 'archive'],
        'woocommerce-archive-description'            => ['label' => 'Archive Description',      'group' => 'archive'],
        'wc-categories'                              => ['label' => 'Product Categories',       'group' => 'archive'],
        'woocommerce-category-image'                 => ['label' => 'Category Image',           'group' => 'archive'],
        'wc-elements'                                => ['label' => 'WooCommerce Elements',     'group' => 'archive'],
        'woocommerce-breadcrumb'                     => ['label' => 'WooCommerce Breadcrumb',   'group' => 'archive'],
        // Cart / checkout / account
        'woocommerce-cart'                           => ['label' => 'Cart',                    'group' => 'shop-pages'],
        'woocommerce-checkout-page'                  => ['label' => 'Checkout',                'group' => 'shop-pages'],
        'woocommerce-my-account'                     => ['label' => 'My Account',              'group' => 'shop-pages'],
        'woocommerce-purchase-summary'               => ['label' => 'Purchase Summary',        'group' => 'shop-pages'],
        'woocommerce-menu-cart'                      => ['label' => 'Menu Cart',               'group' => 'shop-pages'],
        'woocommerce-notices'                        => ['label' => 'WooCommerce Notices',     'group' => 'shop-pages'],
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_woocommerce_widgets';
    }

    public function getDescription(): string
    {
        return 'List the Elementor Pro WooCommerce Builder widgets — product title, price, images, add-to-cart, related products, cart, checkout, my-account, archive products, and more. Requires Elementor Pro and WooCommerce. For each widget, reports its widget type, label, usage group, and whether it is currently registered on this site.';
    }

    public function getSchema(): array
    {
        return [
            'group' => [
                'optional',
                'string',
                'description' => 'Filter by usage group: single-product, archive, shop-pages.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        if (!class_exists('\WooCommerce') && !function_exists('WC')) {
            return $this->error('WooCommerce is not active. WooCommerce widgets require the WooCommerce plugin.');
        }

        $registered = [];
        try {
            $widgetsManager = $this->elementor->plugin()->widgets_manager;
            if (is_object($widgetsManager) && method_exists($widgetsManager, 'get_widget_types')) {
                $types = $widgetsManager->get_widget_types();
                if (is_array($types)) {
                    $registered = array_keys($types);
                }
            }
        } catch (\Throwable $e) {
            $registered = [];
        }

        $groupFilter = isset($parameters['group']) && $parameters['group'] !== ''
            ? (string) $parameters['group']
            : null;

        $items = [];
        foreach (self::WOO_WIDGETS as $type => $info) {
            if ($groupFilter !== null && $info['group'] !== $groupFilter) {
                continue;
            }
            $items[] = [
                'widget_type' => $type,
                'label'       => $info['label'],
                'group'       => $info['group'],
                'registered'  => empty($registered) ? null : in_array($type, $registered, true),
            ];
        }

        return $this->success([
            'count'   => count($items),
            'group'   => $groupFilter,
            'widgets' => $items,
        ]);
    }
}
