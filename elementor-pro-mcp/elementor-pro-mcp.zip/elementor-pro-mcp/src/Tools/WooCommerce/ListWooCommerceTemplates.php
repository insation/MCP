<?php
/**
 * List WooCommerce Templates Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\WooCommerce;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListWooCommerceTemplates extends AbstractTool
{
    protected ElementorService $elementor;

    /**
     * WooCommerce Builder document type slugs. These are theme-builder
     * documents that render WooCommerce pages — the single product page and
     * the product archive (shop / category) page.
     *
     * @var string[]
     */
    public const WOO_TEMPLATE_TYPES = [
        'product',          // single product
        'product-post',     // single product (post context variant)
        'product-archive',  // shop / product archive
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_woocommerce_templates';
    }

    public function getDescription(): string
    {
        return 'List Elementor Pro WooCommerce Builder templates — single product templates and product archive (shop) templates. Requires both Elementor Pro and WooCommerce to be active. Each entry returns id, title, WooCommerce template type, status, modified date, and display-condition count.';
    }

    public function getSchema(): array
    {
        return [
            'type' => [
                'optional',
                'string',
                'description' => 'Filter by WooCommerce template type: product, product-post, product-archive.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        if (!class_exists('\WooCommerce') && !function_exists('WC')) {
            return $this->error('WooCommerce is not active. WooCommerce Builder templates require the WooCommerce plugin.');
        }

        $type = isset($parameters['type']) && $parameters['type'] !== ''
            ? (string) $parameters['type']
            : null;

        if ($type !== null && !in_array($type, self::WOO_TEMPLATE_TYPES, true)) {
            return $this->error(
                "Unknown WooCommerce template type '{$type}'.",
                ['valid_types' => self::WOO_TEMPLATE_TYPES]
            );
        }

        $args = [
            'post_type'      => 'elementor_library',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'tax_query'      => [[
                'taxonomy' => 'elementor_library_type',
                'field'    => 'slug',
                'terms'    => $type !== null ? [$type] : self::WOO_TEMPLATE_TYPES,
            ]],
        ];

        $query = new \WP_Query($args);
        $items = [];
        foreach ($query->posts as $post) {
            $id = (int) $post->ID;
            $items[] = [
                'id'              => $id,
                'title'           => $post->post_title,
                'type'            => $this->elementor->getTemplateType($id),
                'status'          => $post->post_status,
                'modified'        => $post->post_modified_gmt,
                'condition_count' => count($this->elementor->getTemplateConditions($id)),
            ];
        }

        return $this->success([
            'count'     => count($items),
            'type'      => $type,
            'templates' => $items,
        ]);
    }
}
