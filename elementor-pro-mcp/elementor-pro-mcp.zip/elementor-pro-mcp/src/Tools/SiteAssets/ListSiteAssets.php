<?php
/**
 * List Site Assets Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.3.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\SiteAssets;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListSiteAssets extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_site_assets';
    }

    public function getDescription(): string
    {
        return 'List the custom site assets managed by Elementor Pro\'s assets manager — custom fonts (each font family uploaded to the site) and custom icon sets. Returns each asset\'s post ID, name, and status. Use this to see what custom typography and iconography is available for use in widget settings.';
    }

    public function getSchema(): array
    {
        return [
            'asset_type' => [
                'optional',
                'string',
                'description' => 'Limit to one type: fonts or icons. Omit to return both.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $assetType = isset($parameters['asset_type']) && $parameters['asset_type'] !== ''
            ? (string) $parameters['asset_type']
            : null;

        if ($assetType !== null && !in_array($assetType, ['fonts', 'icons'], true)) {
            return $this->error("Invalid asset_type '{$assetType}'. Use 'fonts' or 'icons'.");
        }

        $result = [];

        if ($assetType === null || $assetType === 'fonts') {
            $fonts = $this->elementor->listCustomFonts();
            $result['fonts'] = [
                'count' => count($fonts),
                'items' => $fonts,
            ];
        }

        if ($assetType === null || $assetType === 'icons') {
            $icons = $this->elementor->listCustomIconSets();
            $result['icons'] = [
                'count' => count($icons),
                'items' => $icons,
            ];
        }

        return $this->success($result);
    }
}
