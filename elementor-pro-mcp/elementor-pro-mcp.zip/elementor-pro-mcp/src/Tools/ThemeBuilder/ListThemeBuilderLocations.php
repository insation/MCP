<?php
/**
 * List Theme Builder Locations Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListThemeBuilderLocations extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_theme_builder_locations';
    }

    public function getDescription(): string
    {
        return 'List the registered Theme Builder locations — the slots in the page where theme templates render, such as header, footer, single, and archive. Core locations come from Elementor Pro; themes and plugins can register additional ones. Each entry includes the location slug, label, whether it is a core location, and how many templates are currently assigned to it.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $locations = $this->elementor->getLocations();
        $items = [];

        foreach ($locations as $slug => $config) {
            $templateIds = $this->elementor->getLocationTemplates((string) $slug);
            $items[] = [
                'slug'           => (string) $slug,
                'label'          => is_array($config) ? ($config['label'] ?? (string) $slug) : (string) $slug,
                'is_core'        => is_array($config) ? (bool) ($config['is_core'] ?? false) : false,
                'multiple'       => is_array($config) ? (bool) ($config['multiple'] ?? false) : false,
                'edit_in_content'=> is_array($config) ? (bool) ($config['edit_in_content'] ?? true) : true,
                'template_count' => count($templateIds),
                'template_ids'   => $templateIds,
            ];
        }

        return $this->success([
            'count'     => count($items),
            'locations' => $items,
        ]);
    }
}
