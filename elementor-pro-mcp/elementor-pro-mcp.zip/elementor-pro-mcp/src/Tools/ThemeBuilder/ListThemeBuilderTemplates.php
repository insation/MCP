<?php
/**
 * List Theme Builder Templates Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class ListThemeBuilderTemplates extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_theme_builder_templates';
    }

    public function getDescription(): string
    {
        return 'List all Elementor Pro Theme Builder templates — headers, footers, single (post/page) templates, archive templates, the 404 template, and the search-results template. Each entry returns id, title, theme-builder type, post status, modified date, and the count of display conditions attached. Optionally filter by theme-builder type.';
    }

    public function getSchema(): array
    {
        return [
            'type' => [
                'optional',
                'string',
                'description' => 'Filter by theme-builder type: header, footer, single-post, single-page, single, archive, search-results, error-404, section.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $type = isset($parameters['type']) && $parameters['type'] !== ''
            ? (string) $parameters['type']
            : null;

        if ($type !== null && !in_array($type, ElementorService::THEME_BUILDER_TYPES, true)) {
            return $this->error(
                "Unknown theme-builder type '{$type}'.",
                ['valid_types' => ElementorService::THEME_BUILDER_TYPES]
            );
        }

        $templates = $this->elementor->listThemeBuilderTemplates($type);

        // Enrich each with its display-condition count and current location.
        foreach ($templates as &$tpl) {
            $conditions = $this->elementor->getTemplateConditions((int) $tpl['id']);
            $tpl['condition_count'] = count($conditions);
            $tpl['location']        = $this->elementor->getDocumentLocation((int) $tpl['id']);
        }
        unset($tpl);

        return $this->success([
            'count'     => count($templates),
            'type'      => $type,
            'templates' => $templates,
        ]);
    }
}
