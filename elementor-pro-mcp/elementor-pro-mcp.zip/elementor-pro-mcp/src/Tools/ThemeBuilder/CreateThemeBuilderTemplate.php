<?php
/**
 * Create Theme Builder Template Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class CreateThemeBuilderTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'create_theme_builder_template';
    }

    public function getDescription(): string
    {
        return 'Create a new Elementor Pro Theme Builder template — a header, footer, single (post/page), archive, 404, or search-results template. Optionally provide an initial Elementor element tree and display conditions. Returns the new template post ID and its Elementor edit URL.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'type' => [
                'required',
                'string',
                'description' => 'Theme-builder type: header, footer, single-post, single-page, single, archive, search-results, error-404, section.',
            ],
            'title' => [
                'required',
                'string',
                'description' => 'Title for the new template.',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Post status: publish or draft. Default publish.',
            ],
            'elements_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded Elementor element tree to set as the template content. If omitted, the template is created empty.',
            ],
            'conditions' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Display condition strings to attach immediately, e.g. ["include/general"] or ["include/singular/post"].',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('creating a theme builder template');

        $type = (string) $parameters['type'];
        if (!in_array($type, ElementorService::THEME_BUILDER_TYPES, true)) {
            return $this->error(
                "Unknown theme-builder type '{$type}'.",
                ['valid_types' => ElementorService::THEME_BUILDER_TYPES]
            );
        }

        $title  = (string) $parameters['title'];
        $status = $parameters['status'] ?? 'publish';
        if (!in_array($status, ['publish', 'draft'], true)) {
            return $this->error("Invalid status '{$status}'. Use 'publish' or 'draft'.");
        }

        // Parse optional element tree.
        $elements = [];
        if (!empty($parameters['elements_json'])) {
            $decoded = json_decode((string) $parameters['elements_json'], true);
            if (!is_array($decoded)) {
                return $this->error('elements_json is not valid JSON, or did not decode to an array.');
            }
            $elements = $decoded;
        }

        try {
            $templateId = $this->elementor->createThemeBuilderTemplate($type, $title, $elements, $status);
        } catch (\RuntimeException $e) {
            return $this->error('Failed to create theme builder template: ' . $e->getMessage());
        }

        // Attach conditions if supplied.
        $conditionsApplied = [];
        if (!empty($parameters['conditions']) && is_array($parameters['conditions'])) {
            $conditions = array_values(array_filter(array_map('strval', $parameters['conditions'])));
            if (!empty($conditions)) {
                $this->elementor->saveTemplateConditions($templateId, $conditions);
                $conditionsApplied = $conditions;
            }
        }

        return $this->success([
            'id'         => $templateId,
            'type'       => $type,
            'title'      => $title,
            'status'     => $status,
            'conditions' => $conditionsApplied,
            'edit_url'   => admin_url('post.php?post=' . $templateId . '&action=elementor'),
        ], "Created {$type} template '{$title}' (ID {$templateId}).");
    }
}
