<?php
/**
 * Get Template Display Conditions Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetTemplateDisplayConditions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_template_display_conditions';
    }

    public function getDescription(): string
    {
        return 'Read the display conditions attached to a Theme Builder template. Conditions are slash-delimited strings such as "include/general", "include/singular/post", or "exclude/singular/page/in_id/42" — they decide where on the site the template renders. Returns the raw condition list plus a parsed, human-readable breakdown of each.';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        if ($this->elementor->getThemeBuilderType($templateId) === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $conditions = $this->elementor->getTemplateConditions($templateId);

        // Parse each condition string into a structured breakdown.
        $parsed = [];
        foreach ($conditions as $condition) {
            $segments = explode('/', $condition);
            $type = $segments[0] ?? 'include'; // include | exclude
            $parsed[] = [
                'raw'      => $condition,
                'type'     => $type,
                'name'     => $segments[1] ?? null,       // general | singular | archive ...
                'sub_name' => $segments[2] ?? null,       // post | page | <taxonomy> ...
                'operator' => $segments[3] ?? null,       // in_id | in_parent | in_term ...
                'value'    => $segments[4] ?? null,       // the target ID/term
            ];
        }

        return $this->success([
            'template_id'     => $templateId,
            'condition_count' => count($conditions),
            'conditions'      => $conditions,
            'parsed'          => $parsed,
        ]);
    }
}
