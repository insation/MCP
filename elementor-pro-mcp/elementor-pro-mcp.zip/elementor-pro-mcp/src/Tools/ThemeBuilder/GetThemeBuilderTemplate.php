<?php
/**
 * Get Theme Builder Template Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetThemeBuilderTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_theme_builder_template';
    }

    public function getDescription(): string
    {
        return 'Get full information about a single Theme Builder template by post ID: title, theme-builder type, status, modified date, the assigned location, its display conditions, and (optionally) the full Elementor element tree of the template.';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template.',
            ],
            'include_elements' => [
                'optional',
                'bool',
                'description' => 'Include the full Elementor element tree of the template. Default false (metadata only).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }

        $tbType = $this->elementor->getThemeBuilderType($templateId);
        if ($tbType === null) {
            return $this->error(
                "Post {$templateId} is an Elementor library item but not a Theme Builder template.",
                ['template_type' => $this->elementor->getTemplateType($templateId)]
            );
        }

        $result = [
            'id'              => $templateId,
            'title'           => $post->post_title,
            'type'            => $tbType,
            'status'          => $post->post_status,
            'modified'        => $post->post_modified_gmt,
            'author_id'       => (int) $post->post_author,
            'location'        => $this->elementor->getDocumentLocation($templateId),
            'conditions'      => $this->elementor->getTemplateConditions($templateId),
            'edit_url'        => admin_url('post.php?post=' . $templateId . '&action=elementor'),
        ];

        if (!empty($parameters['include_elements'])) {
            $result['elements'] = $this->elementor->getDocumentData($templateId);
        }

        return $this->success($result);
    }
}
