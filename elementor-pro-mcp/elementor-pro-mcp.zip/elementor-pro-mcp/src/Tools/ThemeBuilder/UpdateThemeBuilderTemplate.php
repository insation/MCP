<?php
/**
 * Update Theme Builder Template Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class UpdateThemeBuilderTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_theme_builder_template';
    }

    public function getDescription(): string
    {
        return 'Update an existing Theme Builder template — change its title, post status, and/or replace its full Elementor element tree. Only the fields you supply are changed. To edit individual elements rather than replacing the whole tree, use the element-level tools instead.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template to update.',
            ],
            'title' => [
                'optional',
                'string',
                'description' => 'New title for the template.',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'New post status: publish or draft.',
            ],
            'elements_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded Elementor element tree to REPLACE the template content with. Omit to leave content unchanged.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('updating a theme builder template');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        if ($this->elementor->getThemeBuilderType($templateId) === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $changed = [];

        // Title / status via wp_update_post.
        $postUpdate = ['ID' => $templateId];
        if (isset($parameters['title']) && $parameters['title'] !== '') {
            $postUpdate['post_title'] = (string) $parameters['title'];
            $changed[] = 'title';
        }
        if (isset($parameters['status']) && $parameters['status'] !== '') {
            $status = (string) $parameters['status'];
            if (!in_array($status, ['publish', 'draft'], true)) {
                return $this->error("Invalid status '{$status}'. Use 'publish' or 'draft'.");
            }
            $postUpdate['post_status'] = $status;
            $changed[] = 'status';
        }
        if (count($postUpdate) > 1) {
            $res = wp_update_post($postUpdate, true);
            if (is_wp_error($res)) {
                return $this->error('Failed to update template post: ' . $res->get_error_message());
            }
        }

        // Element tree replacement.
        if (!empty($parameters['elements_json'])) {
            $decoded = json_decode((string) $parameters['elements_json'], true);
            if (!is_array($decoded)) {
                return $this->error('elements_json is not valid JSON, or did not decode to an array.');
            }
            $saved = $this->elementor->saveDocumentData($templateId, $decoded);
            if (!$saved) {
                return $this->error('Failed to save the new element tree to the template.');
            }
            $changed[] = 'elements';
        }

        if (empty($changed)) {
            return $this->error('Nothing to update — supply at least one of: title, status, elements_json.');
        }

        return $this->success([
            'id'      => $templateId,
            'changed' => $changed,
        ], 'Updated theme builder template ID ' . $templateId . ' (' . implode(', ', $changed) . ').');
    }
}
