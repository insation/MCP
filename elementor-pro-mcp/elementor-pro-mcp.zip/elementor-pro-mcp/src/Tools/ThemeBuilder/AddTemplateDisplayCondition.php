<?php
/**
 * Add Template Display Condition Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class AddTemplateDisplayCondition extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'add_template_display_condition';
    }

    public function getDescription(): string
    {
        return 'Add a single display condition to a Theme Builder template, leaving its existing conditions intact. The condition is a slash-delimited string such as "include/general", "include/singular/post", or "exclude/singular/page/in_id/42". If the exact condition is already present, the call is a no-op.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template.',
            ],
            'condition' => [
                'required',
                'string',
                'description' => 'The condition string to add, e.g. "include/general" or "exclude/singular/post/in_id/42". Must start with include/ or exclude/.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('adding a template display condition');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        if ($this->elementor->getThemeBuilderType($templateId) === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $condition = trim((string) $parameters['condition']);
        if (!preg_match('#^(include|exclude)(/|$)#', $condition)) {
            return $this->error(
                "Condition '{$condition}' must start with 'include/' or 'exclude/'.",
                ['example' => 'include/general']
            );
        }

        $existing = $this->elementor->getTemplateConditions($templateId);

        if (in_array($condition, $existing, true)) {
            return $this->success([
                'template_id' => $templateId,
                'condition'   => $condition,
                'added'       => false,
                'conditions'  => $existing,
            ], "Condition '{$condition}' was already present — no change.");
        }

        $updated = $existing;
        $updated[] = $condition;
        $this->elementor->saveTemplateConditions($templateId, $updated);

        return $this->success([
            'template_id' => $templateId,
            'condition'   => $condition,
            'added'       => true,
            'conditions'  => $updated,
        ], "Added condition '{$condition}' to template ID {$templateId}.");
    }
}
