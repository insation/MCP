<?php
/**
 * Remove Template Display Condition Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class RemoveTemplateDisplayCondition extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'remove_template_display_condition';
    }

    public function getDescription(): string
    {
        return 'Remove a single display condition from a Theme Builder template, leaving the rest intact. The condition must match exactly. If the condition is not present, the call reports that no change was made.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template.',
            ],
            'condition' => [
                'required',
                'string',
                'description' => 'The exact condition string to remove, e.g. "include/general".',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('removing a template display condition');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        if ($this->elementor->getThemeBuilderType($templateId) === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $condition = trim((string) $parameters['condition']);
        $existing  = $this->elementor->getTemplateConditions($templateId);

        if (!in_array($condition, $existing, true)) {
            return $this->success([
                'template_id' => $templateId,
                'condition'   => $condition,
                'removed'     => false,
                'conditions'  => $existing,
            ], "Condition '{$condition}' was not present — no change.");
        }

        $updated = array_values(array_filter(
            $existing,
            static fn($c) => $c !== $condition
        ));
        $this->elementor->saveTemplateConditions($templateId, $updated);

        return $this->success([
            'template_id' => $templateId,
            'condition'   => $condition,
            'removed'     => true,
            'conditions'  => $updated,
        ], "Removed condition '{$condition}' from template ID {$templateId}.");
    }
}
