<?php
/**
 * Get Theme Builder Conditions Config Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetThemeBuilderConditionsConfig extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_theme_builder_conditions_config';
    }

    public function getDescription(): string
    {
        return 'Get the Theme Builder conditions configuration tree — the full set of condition types available on this site and how they nest (general, archive, singular, and their sub-conditions for each registered post type and taxonomy). This is the reference an AI agent needs to construct valid condition strings for set_template_display_conditions and add_template_display_condition.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $config = $this->elementor->getConditionsConfig();

        if (empty($config)) {
            return $this->success([
                'available'  => false,
                'config'     => [],
            ], 'The conditions config could not be read from this Elementor Pro version. Condition strings can still be set directly.');
        }

        return $this->success([
            'available' => true,
            'config'    => $config,
        ]);
    }
}
