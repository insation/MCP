<?php
/**
 * Get Theme Builder Conflicts Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetThemeBuilderConflicts extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_theme_builder_conflicts';
    }

    public function getDescription(): string
    {
        return 'Scan Theme Builder templates for display-condition conflicts — the common "wrong header/footer is showing" problem, where two or more templates of the same type both claim the same location via overlapping conditions. Returns, per location, the groups of templates that compete, so you can decide which to adjust.';
    }

    public function getSchema(): array
    {
        return [
            'type' => [
                'optional',
                'string',
                'description' => 'Limit the scan to one theme-builder type (e.g. header, footer). Default: scan all types.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $type = isset($parameters['type']) && $parameters['type'] !== ''
            ? (string) $parameters['type']
            : null;

        if ($type !== null && !in_array($type, ElementorService::THEME_BUILDER_TYPES, true)) {
            return $this->error(
                "Unknown theme-builder type '{$type}'.",
                ['valid_types' => ElementorService::THEME_BUILDER_TYPES]
            );
        }

        // Gather published templates grouped by their assigned location.
        $templates = $this->elementor->listThemeBuilderTemplates($type);
        $byLocation = [];

        foreach ($templates as $tpl) {
            if ($tpl['status'] !== 'publish') {
                continue; // only published templates actually render
            }
            $id = (int) $tpl['id'];
            $location = $this->elementor->getDocumentLocation($id);
            if ($location === null) {
                // Fall back to the type as a pseudo-location bucket.
                $location = (string) ($tpl['type'] ?? 'unknown');
            }
            $conditions = $this->elementor->getTemplateConditions($id);
            // Only templates that actually have conditions can conflict.
            if (empty($conditions)) {
                continue;
            }
            $byLocation[$location][] = [
                'id'         => $id,
                'title'      => $tpl['title'],
                'type'       => $tpl['type'],
                'conditions' => $conditions,
            ];
        }

        // A location with 2+ condition-bearing templates is a potential conflict.
        $conflicts = [];
        foreach ($byLocation as $location => $group) {
            if (count($group) >= 2) {
                $conflicts[] = [
                    'location'           => $location,
                    'competing_count'    => count($group),
                    'competing_templates'=> $group,
                ];
            }
        }

        return $this->success([
            'scanned_type'   => $type,
            'conflict_count' => count($conflicts),
            'conflicts'      => $conflicts,
            'note'           => empty($conflicts)
                ? 'No locations have multiple published, condition-bearing templates competing.'
                : 'Each listed location has multiple published templates with display conditions. Review their conditions and narrow or remove overlaps so a single template wins.',
        ]);
    }
}
