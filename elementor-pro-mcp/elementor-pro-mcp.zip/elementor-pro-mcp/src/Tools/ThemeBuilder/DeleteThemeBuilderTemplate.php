<?php
/**
 * Delete Theme Builder Template Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class DeleteThemeBuilderTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_theme_builder_template';
    }

    public function getDescription(): string
    {
        return 'Delete a Theme Builder template. By default the template is moved to trash (recoverable); pass force=true to permanently delete it. Deleting a template also removes its display conditions.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template to delete.',
            ],
            'force' => [
                'optional',
                'bool',
                'description' => 'Permanently delete instead of moving to trash. Default false.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('deleting a theme builder template');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        $tbType = $this->elementor->getThemeBuilderType($templateId);
        if ($tbType === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $force = !empty($parameters['force']);
        $title = $post->post_title;

        $result = wp_delete_post($templateId, $force);
        if (!$result) {
            return $this->error("Failed to delete theme builder template ID {$templateId}.");
        }

        return $this->success([
            'id'          => $templateId,
            'title'       => $title,
            'type'        => $tbType,
            'permanently' => $force,
        ], $force
            ? "Permanently deleted theme builder template '{$title}' (ID {$templateId})."
            : "Moved theme builder template '{$title}' (ID {$templateId}) to trash.");
    }
}
