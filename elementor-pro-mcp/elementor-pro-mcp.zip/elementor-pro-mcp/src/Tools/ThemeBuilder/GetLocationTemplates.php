<?php
/**
 * Get Location Templates Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class GetLocationTemplates extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_location_templates';
    }

    public function getDescription(): string
    {
        return 'List the Theme Builder templates assigned to a specific location (e.g. "header", "footer", "single", "archive"). Returns each template\'s id, title, type, status, and display conditions — useful for understanding which template will render in a given slot, and for spotting multiple templates competing for the same location.';
    }

    public function getSchema(): array
    {
        return [
            'location' => [
                'required',
                'string',
                'description' => 'The location slug, e.g. header, footer, single, archive. Use list_theme_builder_locations to see available slugs.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();

        $location = trim((string) $parameters['location']);
        if ($location === '') {
            return $this->error('location must not be empty.');
        }

        // Confirm the location is registered.
        $locationConfig = $this->elementor->getLocation($location);
        if ($locationConfig === null) {
            $known = array_keys($this->elementor->getLocations());
            return $this->error(
                "Location '{$location}' is not registered.",
                ['known_locations' => $known]
            );
        }

        $templateIds = $this->elementor->getLocationTemplates($location);
        $templates = [];
        foreach ($templateIds as $id) {
            $post = get_post($id);
            if (!$post) {
                continue;
            }
            $templates[] = [
                'id'         => (int) $id,
                'title'      => $post->post_title,
                'type'       => $this->elementor->getTemplateType((int) $id),
                'status'     => $post->post_status,
                'conditions' => $this->elementor->getTemplateConditions((int) $id),
            ];
        }

        return $this->success([
            'location'       => $location,
            'label'          => $locationConfig['label'] ?? $location,
            'template_count' => count($templates),
            'templates'      => $templates,
        ]);
    }
}
