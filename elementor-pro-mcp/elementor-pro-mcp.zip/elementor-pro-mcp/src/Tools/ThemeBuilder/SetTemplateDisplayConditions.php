<?php
/**
 * Set Template Display Conditions Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class SetTemplateDisplayConditions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'set_template_display_conditions';
    }

    public function getDescription(): string
    {
        return 'Replace ALL display conditions on a Theme Builder template with a new set. This overwrites the existing conditions entirely — to add or remove individual conditions without disturbing the rest, use add_template_display_condition / remove_template_display_condition. Pass an empty array to clear all conditions.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template.',
            ],
            'conditions' => [
                'required',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'The complete new list of condition strings, e.g. ["include/general"] or ["include/singular/post","exclude/singular/post/in_id/42"]. Empty array clears all conditions.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('setting template display conditions');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        if ($this->elementor->getThemeBuilderType($templateId) === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $conditions = is_array($parameters['conditions']) ? $parameters['conditions'] : [];
        $conditions = array_values(array_filter(array_map('strval', $conditions)));

        // Light structural validation: each condition should start with include/ or exclude/.
        foreach ($conditions as $condition) {
            if (!preg_match('#^(include|exclude)(/|$)#', $condition)) {
                return $this->error(
                    "Condition '{$condition}' must start with 'include/' or 'exclude/'.",
                    ['example' => 'include/general']
                );
            }
        }

        $before = $this->elementor->getTemplateConditions($templateId);
        $this->elementor->saveTemplateConditions($templateId, $conditions);

        return $this->success([
            'template_id'      => $templateId,
            'conditions_before' => $before,
            'conditions_after'  => $conditions,
        ], 'Replaced display conditions on template ID ' . $templateId . ' (' . count($conditions) . ' condition(s)).');
    }
}
