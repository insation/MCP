<?php
/**
 * Duplicate Theme Builder Template Tool
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorProMCP\Tools\ThemeBuilder;

use InsationAI\ElementorProMCP\Services\ElementorService;
use InsationAI\ElementorProMCP\Services\ValidationService;
use InsationAI\ElementorProMCP\Services\WordPressService;
use InsationAI\ElementorProMCP\Logger\WordPressLogger;
use InsationAI\ElementorProMCP\Tools\AbstractTool;

class DuplicateThemeBuilderTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'duplicate_theme_builder_template';
    }

    public function getDescription(): string
    {
        return 'Duplicate a Theme Builder template. The copy has the same type and element tree as the original, a fresh set of element IDs, and is created as a draft with NO display conditions (so it cannot accidentally override the original). Returns the new template ID.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => [
                'required',
                'int',
                'description' => 'The post ID of the theme-builder template to duplicate.',
            ],
            'new_title' => [
                'optional',
                'string',
                'description' => 'Title for the copy. Defaults to the original title with " (copy)" appended.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementorPro();
        $this->checkSafeMode('duplicating a theme builder template');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);

        if (!$post || $post->post_type !== 'elementor_library') {
            return $this->error("No Elementor library template found with ID {$templateId}.");
        }
        $tbType = $this->elementor->getThemeBuilderType($templateId);
        if ($tbType === null) {
            return $this->error("Post {$templateId} is not a Theme Builder template.");
        }

        $newTitle = isset($parameters['new_title']) && $parameters['new_title'] !== ''
            ? (string) $parameters['new_title']
            : $post->post_title . ' (copy)';

        // Copy the element tree and regenerate every element ID so the copy is
        // structurally independent of the original.
        $elements = $this->elementor->getDocumentData($templateId);
        $freshElements = [];
        foreach ($elements as $element) {
            if (is_array($element)) {
                $freshElements[] = $this->elementor->regenerateIds($element);
            }
        }

        try {
            // Created as draft with no conditions — deliberate, see description.
            $newId = $this->elementor->createThemeBuilderTemplate(
                $tbType,
                $newTitle,
                $freshElements,
                'draft'
            );
        } catch (\RuntimeException $e) {
            return $this->error('Failed to duplicate theme builder template: ' . $e->getMessage());
        }

        return $this->success([
            'source_id'  => $templateId,
            'new_id'     => $newId,
            'type'       => $tbType,
            'new_title'  => $newTitle,
            'status'     => 'draft',
            'conditions' => [],
            'edit_url'   => admin_url('post.php?post=' . $newId . '&action=elementor'),
        ], "Duplicated theme builder template ID {$templateId} → new draft ID {$newId}.");
    }
}
