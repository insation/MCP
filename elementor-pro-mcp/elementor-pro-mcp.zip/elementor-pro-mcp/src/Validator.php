<?php

namespace InsationAI\ElementorProMCP;

/**
 * Site Validator
 *
 * Stub validator kept for code-path compatibility. Always returns true —
 * ElementorProMCP is site-agnostic and does not gate functionality behind a
 * hosting platform check.
 *
 * @package InsationAI\ElementorProMCP
 * @since 1.0.0
 */
class Validator
{
    /**
     * Check if current site is authorized to use the plugin.
     *
     * @return bool Always true in ElementorProMCP.
     */
    public static function isAuthorized(): bool
    {
        return true;
    }

    /**
     * Get generic error message for unauthorized sites.
     *
     * @return string Error message.
     */
    public static function getErrorMessage(): string
    {
        return __('This plugin cannot be activated on this site.', 'elementor-pro-mcp');
    }

    /**
     * Get admin notice message for unauthorized sites.
     *
     * @return string Admin notice message.
     */
    public static function getAdminNotice(): string
    {
        return __('ElementorProMCP plugin is not activated properly. Please contact support.', 'elementor-pro-mcp');
    }

    /**
     * Log unauthorized access attempt.
     *
     * @param string $context Context of the attempt (activation, runtime, endpoint).
     */
    public static function logUnauthorizedAttempt(string $context): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                '[ElementorProMCP] Unauthorized access attempt - Context: %s, Site: %s, IP: %s',
                $context,
                home_url(),
                $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ));
        }
    }
}
