# Connecting MCP Clients to ElementorProMCP

ElementorProMCP exposes a standard Streamable HTTP MCP transport at:

```
https://your-site.com/elementor-pro-mcp?t=YOUR_64_CHAR_TOKEN
```

…or with a header:

```
URL:    https://your-site.com/elementor-pro-mcp
Header: Authorization: Bearer YOUR_64_CHAR_TOKEN
```

Get the token from **WordPress Admin → Settings → ElementorProMCP → API Tokens**.

This document shows how to wire up the most common MCP clients. If your client
isn't listed, the rule of thumb is: any client that supports a remote
**Streamable HTTP** MCP server with a Bearer header will work. For clients that
only support stdio, use [`mcp-remote`](https://www.npmjs.com/package/mcp-remote)
as a bridge — examples below.

> Throughout these snippets, replace `your-site.com` and `YOUR_TOKEN` with
> your real values.

---

## Quick reference

| Client                    | Transport                                          | Snippet                  |
|---------------------------|----------------------------------------------------|--------------------------|
| Claude Desktop            | stdio via `mcp-remote`                             | [link](#claude-desktop)  |
| Claude Code (CLI)         | native HTTP                                        | [link](#claude-code-cli) |
| Claude.ai (web)           | Connector UI, native HTTP                          | [link](#claudeai-web)    |
| Cursor                    | native HTTP                                        | [link](#cursor)          |
| Windsurf                  | stdio via `mcp-remote` *(or native, see below)*    | [link](#windsurf)        |
| Cline (VS Code)           | native HTTP                                        | [link](#cline-vs-code)   |
| Roo Code (VS Code)        | native HTTP                                        | [link](#roo-code-vs-code)|
| GitHub Copilot (VS Code)  | native HTTP                                        | [link](#github-copilot-vs-code) |
| Zed                       | stdio via `mcp-remote`                             | [link](#zed)             |
| Gemini CLI                | native HTTP                                        | [link](#gemini-cli)      |
| OpenAI Codex CLI          | native HTTP                                        | [link](#openai-codex-cli)|
| ChatGPT (web/desktop)     | Connector UI, native HTTP                          | [link](#chatgpt-webdesktop) |
| Continue.dev              | native HTTP                                        | [link](#continuedev)     |

---

## Claude Desktop

Claude Desktop currently speaks stdio. Use `mcp-remote` as a transport bridge.

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`
(macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "wordpress": {
      "command": "npx",
      "args": [
        "-y",
        "mcp-remote",
        "https://your-site.com/elementor-pro-mcp?t=YOUR_TOKEN"
      ]
    }
  }
}
```

Restart Claude Desktop. The 26 ElementorProMCP tools should appear in the connector
list.

## Claude Code (CLI)

```bash
claude mcp add --transport http wordpress \
  "https://your-site.com/elementor-pro-mcp" \
  --header "Authorization: Bearer YOUR_TOKEN"
```

Or with the query-string flavor (no header needed):

```bash
claude mcp add --transport http wordpress \
  "https://your-site.com/elementor-pro-mcp?t=YOUR_TOKEN"
```

List with `claude mcp list`, remove with `claude mcp remove wordpress`.

## Claude.ai (web)

1. Open **Settings → Connectors → Add custom connector**.
2. Name: `WordPress (My Site)`.
3. URL: `https://your-site.com/elementor-pro-mcp?t=YOUR_TOKEN`.
4. Save. The connector should switch from "Connect" to "Configure" once auth
   succeeds.

> **Troubleshooting:** if the connector stays on "Connect", the most common
> cause is Bunny CDN caching an early unauthenticated 401 response. See
> `docs/TROUBLESHOOTING.md` for the cache-bypass rule fix.

## Cursor

Edit `~/.cursor/mcp.json` (or use **Settings → Cursor Settings → MCP**):

```json
{
  "mcpServers": {
    "wordpress": {
      "url": "https://your-site.com/elementor-pro-mcp",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN"
      }
    }
  }
}
```

Reload Cursor. Tools appear in the agent panel.

## Windsurf

Windsurf supports remote MCP via stdio bridging. In
`~/.codeium/windsurf/mcp_config.json`:

```json
{
  "mcpServers": {
    "wordpress": {
      "command": "npx",
      "args": [
        "-y",
        "mcp-remote",
        "https://your-site.com/elementor-pro-mcp?t=YOUR_TOKEN"
      ]
    }
  }
}
```

## Cline (VS Code)

Open the Cline panel → **MCP Servers** → **Configure MCP Servers**, then add:

```json
{
  "mcpServers": {
    "wordpress": {
      "type": "streamableHttp",
      "url": "https://your-site.com/elementor-pro-mcp",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN"
      }
    }
  }
}
```

## Roo Code (VS Code)

Same JSON shape as Cline. Open the Roo Code panel → **MCP** → edit
`mcp_settings.json`:

```json
{
  "mcpServers": {
    "wordpress": {
      "type": "streamableHttp",
      "url": "https://your-site.com/elementor-pro-mcp",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN"
      }
    }
  }
}
```

## GitHub Copilot (VS Code)

GitHub Copilot in VS Code supports remote MCP servers via the
`github.copilot.advanced.mcp.servers` setting.

In `settings.json`:

```json
{
  "github.copilot.advanced.mcp.servers": {
    "wordpress": {
      "url": "https://your-site.com/elementor-pro-mcp",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN"
      }
    }
  }
}
```

Reload window. Use `@workspace` chat with `/mcp` commands to invoke tools.

## Zed

Zed connects via stdio. Add to `~/.config/zed/settings.json`:

```json
{
  "context_servers": {
    "wordpress": {
      "command": {
        "path": "npx",
        "args": [
          "-y",
          "mcp-remote",
          "https://your-site.com/elementor-pro-mcp?t=YOUR_TOKEN"
        ]
      }
    }
  }
}
```

## Gemini CLI

```bash
gemini mcp add wordpress \
  --transport http \
  --url "https://your-site.com/elementor-pro-mcp" \
  --header "Authorization: Bearer YOUR_TOKEN"
```

Or edit `~/.gemini/settings.json` directly:

```json
{
  "mcpServers": {
    "wordpress": {
      "httpUrl": "https://your-site.com/elementor-pro-mcp",
      "headers": {
        "Authorization": "Bearer YOUR_TOKEN"
      }
    }
  }
}
```

## OpenAI Codex CLI

In `~/.codex/config.toml`:

```toml
[mcp_servers.wordpress]
url = "https://your-site.com/elementor-pro-mcp"

[mcp_servers.wordpress.headers]
Authorization = "Bearer YOUR_TOKEN"
```

## ChatGPT (web/desktop)

ChatGPT exposes MCP via custom Connectors (Pro/Team/Enterprise tiers).

1. **Settings → Connectors → Create**.
2. Type: **Remote MCP server**.
3. URL: `https://your-site.com/elementor-pro-mcp`.
4. Auth: **Bearer**, token = `YOUR_TOKEN`.
5. Save and toggle the connector on for the conversation.

## Continue.dev

In `~/.continue/config.yaml`:

```yaml
mcpServers:
  - name: wordpress
    type: streamable-http
    url: https://your-site.com/elementor-pro-mcp
    headers:
      Authorization: Bearer YOUR_TOKEN
```

---

## Verifying the connection

The MCP HTTP transport accepts an `initialize` request — you can hit it with
`curl` to confirm the server is reachable before plumbing it into a client:

```bash
curl -sS -X POST "https://your-site.com/elementor-pro-mcp" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "initialize",
    "params": {
      "protocolVersion": "2024-11-05",
      "clientInfo": {"name": "curl", "version": "1.0"},
      "capabilities": {}
    }
  }'
```

A successful response includes `serverInfo.name = "ElementorProMCP"` and a session
cookie. A `401` means the token is wrong or missing.

## Common gotchas

- **CDN caching `/elementor-pro-mcp`.** Bunny / Cloudflare can pin a 401 response and
  serve it back for authenticated requests. Add a cache-bypass rule for the
  endpoint path.
- **PHP 8.0 vs 8.2 mismatch.** ElementorProMCP requires PHP 8.2+. CLI PHP and web PHP
  versions can diverge — verify with `php -v` (CLI) and a `phpinfo()` page (web).
