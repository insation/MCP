<?php
/**
 * Admin Settings Page
 *
 * @package WordpressMCP
 * @since 1.0.0
 *
 * Security Note: This file uses phpcs:disable for WordPress.Security.EscapeOutput
 * because it is an admin-only settings page that requires the 'manage_options'
 * capability. All user input is properly sanitized before storage, and all output
 * is from trusted sources (WordPress translation functions and admin-controlled data).
 *
 * phpcs:disable WordPress.Security.EscapeOutput -- Admin-only page with proper input sanitization
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Check user permissions
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'insationai-wordpress-mcp'));
}

// Check site authorization
if (!class_exists('\InsationAI\WordpressMCP\Validator')) {
    require_once INSATIONAI_WPMCP_PLUGIN_DIR . 'src/Validator.php';
}

if (!\InsationAI\WordpressMCP\Validator::isAuthorized()) {
    ?>
    <div class="wrap insationai-mcp-skin">
        <h1><?php _e('WordpressMCP', 'insationai-wordpress-mcp'); ?></h1>
        <div class="notice notice-error">
            <p><strong><?php echo esc_html(\InsationAI\WordpressMCP\Validator::getAdminNotice()); ?></strong></p>
            <p>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('plugins.php?action=deactivate&plugin=' . urlencode(plugin_basename(INSATIONAI_WPMCP_PLUGIN_FILE))), 'deactivate-plugin_' . plugin_basename(INSATIONAI_WPMCP_PLUGIN_FILE))); ?>" class="button">
                    <?php _e('Deactivate Plugin', 'insationai-wordpress-mcp'); ?>
                </a>
            </p>
        </div>
    </div>
    <?php
    return;
}

// Load TokenRepository
require_once INSATIONAI_WPMCP_PLUGIN_DIR . 'src/Auth/TokenRepository.php';
$tokenRepo = new \InsationAI\WordpressMCP\Auth\TokenRepository();

// Display activation errors if any
$activation_errors = get_transient('insationai_wpmcp_activation_errors');
if ($activation_errors && is_array($activation_errors)) {
    echo '<div class="notice notice-error is-dismissible">';
    echo '<p><strong>' . __('WordpressMCP Database Setup Errors:', 'insationai-wordpress-mcp') . '</strong></p>';
    echo '<ul style="list-style: disc; margin-left: 20px;">';
    foreach ($activation_errors as $error) {
        echo '<li>' . esc_html($error) . '</li>';
    }
    echo '</ul>';
    echo '<p>' . __('The plugin may not function correctly. Please check your database permissions and try deactivating and reactivating the plugin.', 'insationai-wordpress-mcp') . '</p>';
    echo '</div>';
    // Don't delete the transient yet - keep it visible until dismissed
}

// Tracks which settings tab the page should display after a POST round-trip.
// Without this, every form submit reloads the page and the JS defaults to the
// General tab — losing the user's place. Each handler below sets this to the
// tab it belongs to. Read by the page-init JS near the bottom of this file.
$active_tab_override = null;

// One-shot flag: only true on the request immediately after a successful
// license activation/check. Drives the one-time "License active" confirmation.
$wpmcp_license_just_activated = false;

// --- License: activate / clear -------------------------------------------
// Handled before everything else so the gate below reflects the new state
// immediately on the same request.
if (
    isset($_POST['insationai_wpmcp_license_activate'])
    && check_admin_referer('insationai_wpmcp_license')
    && class_exists('InsationAI_WPMCP_License_Service')
) {
    $submitted_key = isset($_POST['insationai_wpmcp_license_key'])
        ? sanitize_text_field(wp_unslash($_POST['insationai_wpmcp_license_key']))
        : '';
    // A blank field means "re-check the license already stored" (the masked
    // key is never re-rendered into the input, so blank is the normal state
    // for a Check-now). Passing null makes refresh() use the stored key.
    // Only a non-empty submission is treated as a new/replacement key.
    $key_arg = ('' === trim($submitted_key)) ? null : $submitted_key;
    InsationAI_WPMCP_License_Service::refresh($key_arg, true);
    $active_tab_override = 'license';
    // One-shot: show the green "License active" confirmation ONLY on this
    // request (right after activating/checking). It is suppressed on every
    // later visit to the License tab. True only if the result is licensed.
    $wpmcp_license_just_activated = InsationAI_WPMCP_License_Service::is_licensed();
}
if (
    isset($_POST['insationai_wpmcp_license_clear'])
    && check_admin_referer('insationai_wpmcp_license')
    && class_exists('InsationAI_WPMCP_License_Service')
) {
    InsationAI_WPMCP_License_Service::deactivate();
    $active_tab_override = 'license';
}

// Single source of truth for the UI gate (computed once, used below).
$wpmcp_is_licensed = class_exists('InsationAI_WPMCP_License_Service')
    ? InsationAI_WPMCP_License_Service::is_licensed()
    : true; // fail-safe: if the service somehow isn't loaded, don't lock the admin out
$wpmcp_license_state = class_exists('InsationAI_WPMCP_License_Service')
    ? InsationAI_WPMCP_License_Service::get_state()
    : array('reason_message' => '', 'reason_code' => 'ok', 'key' => '',
            'tier' => '', 'expires' => '', 'last_success' => 0, 'last_check' => 0);

// Handle token creation
if (isset($_POST['insationai_wpmcp_create_token']) && check_admin_referer('insationai_wpmcp_create_token')) {
    $label = sanitize_text_field($_POST['token_label']);
    $user_id = isset($_POST['token_user_id']) ? (int)$_POST['token_user_id'] : get_current_user_id();
    $expires_days = isset($_POST['token_expires_days']) && $_POST['token_expires_days'] !== ''
        ? (int)$_POST['token_expires_days']
        : null;

    // Verify the user exists
    if (!get_userdata($user_id)) {
        echo '<div class="notice notice-error"><p>' . __('Invalid user selected.', 'insationai-wordpress-mcp') . '</p></div>';
    } else {
        $expires_at = null;
        if ($expires_days !== null && $expires_days > 0) {
            $expires_at = gmdate('Y-m-d H:i:s', strtotime("+{$expires_days} days"));
        }

        $result = $tokenRepo->createToken($user_id, $label, $expires_at);

        if ($result['success']) {
            // Store token temporarily for display
            set_transient('insationai_wpmcp_new_token_' . get_current_user_id(), $result['token'], 300);
            echo '<div class="notice notice-success"><p>' . __('Token created successfully! Copy it now - it won\'t be shown again.', 'insationai-wordpress-mcp') . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . esc_html($result['error']) . '</p></div>';
        }
    }

    // Stay on the API Tokens tab so the new token (and its one-time display) is visible.
    $active_tab_override = 'tokens';
}

// Handle token revocation — supports single, bulk-selected, and revoke-all.
// After any revoke action we set $active_tab_override so the page reload
// lands back on the API Tokens tab instead of defaulting to General.
if (
    (isset($_POST['insationai_wpmcp_revoke_token'])
        || isset($_POST['insationai_wpmcp_revoke_selected'])
        || isset($_POST['insationai_wpmcp_revoke_all']))
    && check_admin_referer('insationai_wpmcp_revoke_token')
) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'insationai_wpmcp_user_tokens';

    // Build the list of token IDs to revoke depending on which button was used.
    $token_ids = [];

    if (isset($_POST['insationai_wpmcp_revoke_all'])) {
        // Revoke every token in the table.
        $token_ids = array_map('intval', (array) $wpdb->get_col("SELECT id FROM `{$table_name}`"));
    } elseif (isset($_POST['insationai_wpmcp_revoke_selected'])) {
        // Revoke the checked tokens.
        $raw = isset($_POST['token_ids']) && is_array($_POST['token_ids']) ? $_POST['token_ids'] : [];
        $token_ids = array_values(array_filter(array_map('intval', $raw)));
    } else {
        // Single token revoke (the per-row button).
        $token_ids = [(int) $_POST['token_id']];
    }

    if (empty($token_ids)) {
        echo '<div class="notice notice-warning"><p>' . __('No tokens selected to revoke.', 'insationai-wordpress-mcp') . '</p></div>';
    } else {
        $revoked = 0;
        $failed  = 0;
        foreach ($token_ids as $token_id) {
            if ($token_id <= 0) {
                continue;
            }
            // Admin can revoke any token, so we look up the owning user first.
            $token_user_id = $wpdb->get_var($wpdb->prepare(
                "SELECT user_id FROM `{$table_name}` WHERE id = %d",
                $token_id
            ));
            if ($token_user_id && $tokenRepo->revokeToken($token_id, (int) $token_user_id)) {
                $revoked++;
            } else {
                $failed++;
            }
        }

        if ($revoked > 0 && $failed === 0) {
            echo '<div class="notice notice-success"><p>' . sprintf(
                /* translators: %d: number of tokens revoked */
                _n('%d token revoked successfully!', '%d tokens revoked successfully!', $revoked, 'insationai-wordpress-mcp'),
                $revoked
            ) . '</p></div>';
        } elseif ($revoked > 0 && $failed > 0) {
            echo '<div class="notice notice-warning"><p>' . sprintf(
                /* translators: 1: number revoked, 2: number failed */
                __('%1$d token(s) revoked, %2$d failed.', 'insationai-wordpress-mcp'),
                $revoked,
                $failed
            ) . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . __('Failed to revoke token(s).', 'insationai-wordpress-mcp') . '</p></div>';
        }
    }

    // Whatever the outcome, keep the admin on the API Tokens tab.
    $active_tab_override = 'tokens';
}

// Handle form submission. Each tab posts its own form with `insationai_wpmcp_section`
// indicating which set of fields is in $_POST — without this, an OAuth-tab
// save would clobber General-tab fields (and vice-versa) because the missing
// fields default to empty/zero.
if (isset($_POST['insationai_wpmcp_save_settings']) && check_admin_referer('insationai_wpmcp_settings')) {
    $section = isset($_POST['insationai_wpmcp_section']) ? sanitize_key($_POST['insationai_wpmcp_section']) : 'general';

    if ($section === 'general') {
        update_option('insationai_wpmcp_endpoint_slug', sanitize_text_field($_POST['endpoint_slug']));
        update_option('insationai_wpmcp_safe_mode', isset($_POST['safe_mode']) ? 1 : 0);
        update_option('insationai_wpmcp_execute_php_enabled', isset($_POST['execute_php_enabled']) ? 1 : 0);

        // Flush rewrite rules in case the slug changed.
        flush_rewrite_rules();
    } elseif ($section === 'oauth') {
        update_option('insationai_wpmcp_oauth_enabled', isset($_POST['oauth_enabled']) ? 1 : 0);
        update_option('insationai_wpmcp_oauth_issuer', esc_url_raw($_POST['oauth_issuer']));
        update_option('insationai_wpmcp_oauth_resource_identifier', esc_url_raw($_POST['oauth_resource_identifier']));
        update_option('insationai_wpmcp_oauth_private_key_path', sanitize_text_field($_POST['oauth_private_key_path']));
        update_option('insationai_wpmcp_oauth_public_key_path', sanitize_text_field($_POST['oauth_public_key_path']));
    }

    echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', 'insationai-wordpress-mcp') . '</p></div>';

    // Return to the tab the save came from instead of defaulting to General.
    // ($active_tab_override may already be set by the revoke handler above;
    //  a save and a revoke can't happen in the same request, so this is safe.)
    if ($section === 'oauth') {
        $active_tab_override = 'oauth';
    } else {
        $active_tab_override = 'general';
    }
}

// Get current settings
$endpoint_slug = get_option('insationai_wpmcp_endpoint_slug', 'insationai-wordpress-mcp');
$safe_mode = get_option('insationai_wpmcp_safe_mode', true);
$execute_php_enabled = get_option('insationai_wpmcp_execute_php_enabled', false);
$oauth_enabled = get_option('insationai_wpmcp_oauth_enabled', false);
$oauth_issuer = get_option('insationai_wpmcp_oauth_issuer', home_url('/insationai-wordpress-mcp'));
$oauth_resource_identifier = get_option('insationai_wpmcp_oauth_resource_identifier', home_url('/insationai-wordpress-mcp'));
$oauth_private_key_path = get_option('insationai_wpmcp_oauth_private_key_path', '');
$oauth_public_key_path = get_option('insationai_wpmcp_oauth_public_key_path', '');

?>

<div class="wrap insationai-mcp-skin">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <h2 class="nav-tab-wrapper">
        <?php if ($wpmcp_is_licensed): ?>
        <a href="#general" class="nav-tab nav-tab-active"><?php _e('General', 'insationai-wordpress-mcp'); ?></a>
        <a href="#tokens" class="nav-tab"><?php _e('API Tokens', 'insationai-wordpress-mcp'); ?></a>
        <?php if (INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED): ?>
            <a href="#oauth" class="nav-tab"><?php _e('OAuth', 'insationai-wordpress-mcp'); ?></a>
        <?php endif; ?>
        <a href="#endpoints" class="nav-tab"><?php _e('Endpoints', 'insationai-wordpress-mcp'); ?></a>
        <a href="#tools" class="nav-tab"><?php _e('Tools', 'insationai-wordpress-mcp'); ?></a>
        <a href="#revisions" class="nav-tab"><?php _e('Revisions', 'insationai-wordpress-mcp'); ?></a>
        <a href="#updates" class="nav-tab"><?php _e('Updates', 'insationai-wordpress-mcp'); ?></a>
        <a href="#support" class="nav-tab"><?php _e('Support', 'insationai-wordpress-mcp'); ?></a>
        <a href="#license" class="nav-tab"><?php _e('License', 'insationai-wordpress-mcp'); ?></a>
        <?php else: ?>
        <a href="#license" class="nav-tab nav-tab-active"><?php _e('License', 'insationai-wordpress-mcp'); ?></a>
        <?php endif; ?>
    </h2>

        <!-- License (always available; tab appears last when licensed) -->
        <div id="license-settings" class="tab-content"<?php echo $wpmcp_is_licensed ? ' style="display:none;"' : ''; ?>>
            <?php
            $ls = $wpmcp_license_state;
            $ok = $wpmcp_is_licensed;
            $has_key = isset($ls['key']) && $ls['key'] !== '';
            $masked  = ($has_key && class_exists('InsationAI_WPMCP_License_Service'))
                ? InsationAI_WPMCP_License_Service::mask_key($ls['key'])
                : '';
            // Expiry display: lifetime keys report the literal 'never'.
            $exp_raw = isset($ls['expires']) ? (string) $ls['expires'] : '';
            $exp_disp = ($exp_raw === '' || strtolower($exp_raw) === 'never')
                ? esc_html__('Never expires (lifetime)', 'insationai-wordpress-mcp')
                : esc_html($exp_raw);
            $reason_code = isset($ls['reason_code']) ? $ls['reason_code'] : '';
            $last_ok = !empty($ls['last_success'])
                ? sprintf(
                    /* translators: %s = human time diff */
                    esc_html__('%s ago', 'insationai-wordpress-mcp'),
                    human_time_diff($ls['last_success'])
                  )
                : esc_html__('never', 'insationai-wordpress-mcp');
            ?>
            <?php
            // Show the status notice when: (a) unlicensed — the warning is
            // essential, always shown; or (b) the license was JUST activated
            // this request — the green "License active" confirmation appears
            // exactly once and is suppressed on every later visit.
            if (!$ok || $wpmcp_license_just_activated):
            ?>
            <div class="notice <?php echo $ok ? 'notice-success' : 'notice-warning'; ?>" style="margin:14px 0;padding:14px 16px;">
                <p style="margin:0 0 6px;font-size:14px;">
                    <strong><?php echo $ok
                        ? esc_html__('License active', 'insationai-wordpress-mcp')
                        : esc_html__('This installation is not licensed', 'insationai-wordpress-mcp'); ?></strong>
                </p>
                <p style="margin:0;">
                    <?php echo esc_html(isset($ls['reason_message']) ? $ls['reason_message'] : ''); ?>
                </p>
                <?php if (!$ok): ?>
                <p style="margin:8px 0 0;color:#64748B;">
                    <?php esc_html_e('The MCP endpoint is disabled and the other settings tabs are hidden until a valid license key is activated on this site.', 'insationai-wordpress-mcp'); ?>
                </p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($has_key): ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php _e('License key', 'insationai-wordpress-mcp'); ?></th>
                    <td><code style="font-size:13px;"><?php echo esc_html($masked); ?></code></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Tier', 'insationai-wordpress-mcp'); ?></th>
                    <td><?php echo esc_html(($ls['tier'] !== '') ? $ls['tier'] : '—'); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Activations', 'insationai-wordpress-mcp'); ?></th>
                    <td>
                        <?php
                        $lim = isset($ls['activation_limit']) ? (int) $ls['activation_limit'] : 0;
                        $cnt = isset($ls['activation_count']) ? (int) $ls['activation_count'] : 0;
                        $rem = isset($ls['activation_remaining']) ? (string) $ls['activation_remaining'] : '';
                        if ($lim === 0) {
                            echo esc_html(sprintf(
                                /* translators: %d = used count */
                                __('%d used · Unlimited activations', 'insationai-wordpress-mcp'),
                                $cnt
                            ));
                        } else {
                            echo esc_html(sprintf(
                                /* translators: 1: used, 2: limit, 3: remaining */
                                __('%1$d of %2$d used · %3$s remaining', 'insationai-wordpress-mcp'),
                                $cnt, $lim,
                                ($rem === '' ? (string) max(0, $lim - $cnt) : $rem)
                            ));
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Expires', 'insationai-wordpress-mcp'); ?></th>
                    <td><?php echo $exp_disp; ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('License server', 'insationai-wordpress-mcp'); ?></th>
                    <td>
                        <?php
                        // Static (cron-based) status — no live ping on page load.
                        if ($ok) {
                            echo '<span style="color:#15803D;">&#9679; </span>';
                            echo esc_html__('Connected', 'insationai-wordpress-mcp');
                        } elseif ($reason_code === 'server_unreachable' || $reason_code === 'server_error') {
                            echo '<span style="color:#B45309;">&#9679; </span>';
                            echo esc_html__('Unreachable (will retry automatically)', 'insationai-wordpress-mcp');
                        } else {
                            echo '<span style="color:#B91C1C;">&#9679; </span>';
                            echo esc_html__('Not verified', 'insationai-wordpress-mcp');
                        }
                        echo ' &middot; ';
                        echo esc_html(sprintf(
                            /* translators: %s = relative time */
                            __('last verified: %s', 'insationai-wordpress-mcp'),
                            $last_ok
                        ));
                        ?>
                    </td>
                </tr>
            </table>
            <?php endif; ?>

            <form method="post" action="">
                <?php wp_nonce_field('insationai_wpmcp_license'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="insationai_wpmcp_license_key"><?php echo $has_key ? esc_html__('Replace license key', 'insationai-wordpress-mcp') : esc_html__('License Key', 'insationai-wordpress-mcp'); ?></label></th>
                        <td>
                            <input type="text" id="insationai_wpmcp_license_key"
                                   name="insationai_wpmcp_license_key"
                                   value=""
                                   class="regular-text" style="font-family:Consolas,Monaco,monospace;"
                                   placeholder="<?php echo $has_key ? esc_attr($masked) : 'WPMCP-1-XXXX-XXXX-XXXX'; ?>" autocomplete="off" />
                            <p class="description">
                                <?php echo $has_key
                                    ? esc_html__('Leave blank and click "Check now" to re-verify the current license, or enter a new key to replace it.', 'insationai-wordpress-mcp')
                                    : esc_html__('Enter the license key from your purchase confirmation email, then activate it for this site.', 'insationai-wordpress-mcp'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" name="insationai_wpmcp_license_activate" class="button button-primary">
                        <?php echo $has_key ? esc_html__('Check now', 'insationai-wordpress-mcp') : esc_html__('Activate license', 'insationai-wordpress-mcp'); ?>
                    </button>
                    <?php if ($has_key): ?>
                    <button type="submit" name="insationai_wpmcp_license_clear" class="button"
                            onclick="return confirm('<?php echo esc_js(__('Remove this license from this site? The MCP endpoint will stop working until a license is re-activated.', 'insationai-wordpress-mcp')); ?>');">
                        <?php _e('Remove license', 'insationai-wordpress-mcp'); ?>
                    </button>
                    <?php endif; ?>
                </p>
            </form>
        </div>

<?php if ($wpmcp_is_licensed): ?>
        <!-- General Settings -->
        <div id="general-settings" class="tab-content">
            <form method="post" action="">
                <?php wp_nonce_field('insationai_wpmcp_settings'); ?>
                <input type="hidden" name="insationai_wpmcp_section" value="general" />
                <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">
                        <label for="endpoint_slug"><?php _e('Endpoint Slug', 'insationai-wordpress-mcp'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="endpoint_slug" name="endpoint_slug"
                               value="<?php echo esc_attr($endpoint_slug); ?>" class="regular-text" />
                        <p class="description">
                            <?php
                            /* translators: %s: The current MCP endpoint URL */
                            printf(__('The URL slug for the MCP endpoint. Current: %s', 'insationai-wordpress-mcp'),
                                '<code>' . home_url('/' . $endpoint_slug) . '</code>'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Safe Mode', 'insationai-wordpress-mcp'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="safe_mode" value="1" <?php checked($safe_mode, 1); ?> />
                            <?php _e('Enable safe mode (prevents delete operations)', 'insationai-wordpress-mcp'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Execute PHP', 'insationai-wordpress-mcp'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="execute_php_enabled" value="1" <?php checked($execute_php_enabled, 1); ?> />
                            <?php _e('Enable the execute_php tool (lets the AI run arbitrary PHP)', 'insationai-wordpress-mcp'); ?>
                        </label>
                        <p class="description" style="color:#b32d2e;">
                            <strong><?php _e('Warning:', 'insationai-wordpress-mcp'); ?></strong>
                            <?php _e('This grants the AI agent root-equivalent control over WordPress: it can read/write any file your web user can touch, run any DB query, and call any plugin API. Use only on staging/development sites or when you fully trust the connecting client. Restricted to the mcp:admin scope and the manage_options capability. Hard 30-second time limit per call.', 'insationai-wordpress-mcp'); ?>
                        </p>
                    </td>
                </tr>
                </table>
                <?php submit_button(__('Save Settings', 'insationai-wordpress-mcp'), 'primary', 'insationai_wpmcp_save_settings'); ?>
            </form>
        </div>

        <!-- API Tokens -->
        <div id="tokens-settings" class="tab-content" style="display:none;">
            <?php
            // Display newly created token if available
            $new_token = get_transient('insationai_wpmcp_new_token_' . get_current_user_id());
            if ($new_token) {
                delete_transient('insationai_wpmcp_new_token_' . get_current_user_id());
                ?>
                <?php
                $usage_url    = home_url('/' . $endpoint_slug . '?t=' . $new_token);
                $bearer_value = 'Authorization: Bearer ' . $new_token;
                ?>
                <div class="notice notice-info">
                    <p><strong><?php _e('Your new token:', 'insationai-wordpress-mcp'); ?></strong></p>
                    <p>
                        <code id="new-token-display" style="font-size: 14px; padding: 10px; background: #f5f5f5; display: inline-block; word-break: break-all;">
                            <?php echo esc_html($new_token); ?>
                        </code>
                        <button type="button" class="button" onclick="copyToken('<?php echo esc_js($new_token); ?>')">
                            <?php _e('Copy', 'insationai-wordpress-mcp'); ?>
                        </button>
                    </p>
                    <p class="description" style="margin-bottom: 6px;">
                        <strong><?php _e('Save this token now! It will not be shown again.', 'insationai-wordpress-mcp'); ?></strong>
                    </p>
                    <p style="margin: 6px 0;">
                        <label style="display:block; font-weight:600; margin-bottom:4px;"><?php _e('Usage URL', 'insationai-wordpress-mcp'); ?></label>
                        <code style="font-size: 13px; padding: 8px 10px; background: #f5f5f5; display: inline-block; word-break: break-all; vertical-align: middle; max-width: 70%;">
                            <?php echo esc_html($usage_url); ?>
                        </code>
                        <button type="button" class="button" style="vertical-align: middle;" onclick="copyToken('<?php echo esc_js($usage_url); ?>')">
                            <?php _e('Copy', 'insationai-wordpress-mcp'); ?>
                        </button>
                    </p>
                    <p style="margin: 6px 0;">
                        <label style="display:block; font-weight:600; margin-bottom:4px;"><?php _e('Authorization Header', 'insationai-wordpress-mcp'); ?></label>
                        <code style="font-size: 13px; padding: 8px 10px; background: #f5f5f5; display: inline-block; word-break: break-all; vertical-align: middle; max-width: 70%;">
                            <?php echo esc_html($bearer_value); ?>
                        </code>
                        <button type="button" class="button" style="vertical-align: middle;" onclick="copyToken('<?php echo esc_js($bearer_value); ?>')">
                            <?php _e('Copy', 'insationai-wordpress-mcp'); ?>
                        </button>
                    </p>
                </div>
                <?php
            }
            ?>

            <h3><?php _e('Create New Token', 'insationai-wordpress-mcp'); ?></h3>
            <form method="post" action="" style="margin-bottom: 30px;">
                <?php wp_nonce_field('insationai_wpmcp_create_token'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="token_user_id"><?php _e('User', 'insationai-wordpress-mcp'); ?></label>
                        </th>
                        <td>
                            <?php
                            wp_dropdown_users([
                                'name' => 'token_user_id',
                                'id' => 'token_user_id',
                                'selected' => get_current_user_id(),
                                'show_option_none' => __('Select User', 'insationai-wordpress-mcp'),
                                'option_none_value' => '',
                            ]);
                            ?>
                            <p class="description"><?php _e('Which user this token belongs to', 'insationai-wordpress-mcp'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="token_label"><?php _e('Token Label', 'insationai-wordpress-mcp'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="token_label" name="token_label" class="regular-text" required />
                            <p class="description"><?php _e('A friendly name to identify this token', 'insationai-wordpress-mcp'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="token_expires_days"><?php _e('Expires In (days)', 'insationai-wordpress-mcp'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="token_expires_days" name="token_expires_days" class="small-text" min="1" />
                            <p class="description"><?php _e('Leave empty for no expiration', 'insationai-wordpress-mcp'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Create Token', 'insationai-wordpress-mcp'), 'secondary', 'insationai_wpmcp_create_token'); ?>
            </form>

            <h3><?php _e('All Tokens', 'insationai-wordpress-mcp'); ?></h3>
            <?php
            // Get all tokens (admin can see all)
            global $wpdb;
            $table_name = $wpdb->prefix . 'insationai_wpmcp_user_tokens';
            $tokens = $wpdb->get_results(
                "SELECT * FROM `{$table_name}` ORDER BY created_at DESC",
                ARRAY_A
            );
            ?>
            <form method="post" action="" id="insationai-wpmcp-tokens-form">
                <?php wp_nonce_field('insationai_wpmcp_revoke_token'); ?>
                <?php if (!empty($tokens)): ?>
                <div class="tablenav top" style="margin-bottom: 8px;">
                    <div class="alignleft actions">
                        <button type="submit" name="insationai_wpmcp_revoke_selected" class="button"
                                id="insationai-wpmcp-revoke-selected" disabled
                                onclick="return insationaiWpmcpConfirmRevokeSelected();">
                            <?php _e('Revoke Selected', 'insationai-wordpress-mcp'); ?>
                        </button>
                        <button type="submit" name="insationai_wpmcp_revoke_all" class="button button-link-delete"
                                onclick="return insationaiWpmcpConfirmRevokeAll();">
                            <?php _e('Revoke All Tokens', 'insationai-wordpress-mcp'); ?>
                        </button>
                        <span id="insationai-wpmcp-selected-count" style="margin-left: 8px; color: #50575e;"></span>
                    </div>
                    <br class="clear" />
                </div>
                <?php endif; ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <td class="manage-column column-cb check-column">
                                <input type="checkbox" id="insationai-wpmcp-select-all-tokens"
                                       title="<?php esc_attr_e('Select all', 'insationai-wordpress-mcp'); ?>" />
                            </td>
                            <th><?php _e('User', 'insationai-wordpress-mcp'); ?></th>
                            <th><?php _e('Label', 'insationai-wordpress-mcp'); ?></th>
                            <th><?php _e('Created', 'insationai-wordpress-mcp'); ?></th>
                            <th><?php _e('Expires', 'insationai-wordpress-mcp'); ?></th>
                            <th><?php _e('Last Used', 'insationai-wordpress-mcp'); ?></th>
                            <th><?php _e('Actions', 'insationai-wordpress-mcp'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (empty($tokens)) {
                            echo '<tr><td colspan="7">' . __('No tokens found.', 'insationai-wordpress-mcp') . '</td></tr>';
                        } else {
                            foreach ($tokens as $token) {
                                $is_expired = $token['expires_at'] && strtotime($token['expires_at']) < time();
                                $user = get_userdata($token['user_id']);
                                ?>
                                <tr<?php if ($is_expired) echo ' style="opacity: 0.6;"'; ?>>
                                    <th scope="row" class="check-column">
                                        <input type="checkbox" class="insationai-wpmcp-token-cb"
                                               name="token_ids[]" value="<?php echo esc_attr($token['id']); ?>" />
                                    </th>
                                    <td>
                                        <?php
                                        if ($user) {
                                            echo esc_html($user->user_login);
                                            echo ' <span style="color: #666;">(' . esc_html($user->display_name) . ')</span>';
                                        } else {
                                            echo '<span style="color: #dc3232;">' . __('User deleted', 'insationai-wordpress-mcp') . '</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo esc_html($token['label']); ?>
                                        <?php if ($is_expired) echo '<span style="color: #dc3232;"> (Expired)</span>'; ?>
                                    </td>
                                    <td><?php echo esc_html(gmdate('Y-m-d H:i', strtotime($token['created_at']))); ?></td>
                                    <td>
                                        <?php
                                        if ($token['expires_at']) {
                                            echo esc_html(gmdate('Y-m-d H:i', strtotime($token['expires_at'])));
                                        } else {
                                            echo __('Never', 'insationai-wordpress-mcp');
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($token['last_used_at']) {
                                            echo esc_html(gmdate('Y-m-d H:i', strtotime($token['last_used_at'])));
                                        } else {
                                            echo __('Never', 'insationai-wordpress-mcp');
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <button type="button" class="button button-small" onclick="showTokenUsage('<?php echo esc_js($endpoint_slug); ?>')">
                                            <?php _e('Usage', 'insationai-wordpress-mcp'); ?>
                                        </button>
                                        <button type="submit" name="insationai_wpmcp_revoke_token" value="<?php echo esc_attr($token['id']); ?>"
                                                class="button button-small" style="margin-left: 5px;"
                                                onclick="document.getElementById('insationai-wpmcp-single-token-id').value='<?php echo esc_js($token['id']); ?>'; return confirm('<?php esc_attr_e('Are you sure you want to revoke this token?', 'insationai-wordpress-mcp'); ?>');">
                                            <?php _e('Revoke', 'insationai-wordpress-mcp'); ?>
                                        </button>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <?php // Carries the single-row revoke target; set by the per-row button's onclick. ?>
                <input type="hidden" name="token_id" id="insationai-wpmcp-single-token-id" value="" />
            </form>
        </div>

        <!-- OAuth Settings -->
        <?php if (INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED): ?>
        <div id="oauth-settings" class="tab-content" style="display:none;">
            <form method="post" action="">
                <?php wp_nonce_field('insationai_wpmcp_settings'); ?>
                <input type="hidden" name="insationai_wpmcp_section" value="oauth" />
                <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php _e('Enable OAuth', 'insationai-wordpress-mcp'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="oauth_enabled" value="1" <?php checked($oauth_enabled, 1); ?> />
                            <?php _e('Enable OAuth 2.1 authentication', 'insationai-wordpress-mcp'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="oauth_issuer"><?php _e('OAuth Issuer', 'insationai-wordpress-mcp'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="oauth_issuer" name="oauth_issuer"
                               value="<?php echo esc_url($oauth_issuer); ?>" class="regular-text" />
                        <p class="description">
                            <?php _e('The OAuth issuer URL (must match where .well-known is accessible)', 'insationai-wordpress-mcp'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="oauth_resource_identifier"><?php _e('Resource Identifier', 'insationai-wordpress-mcp'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="oauth_resource_identifier" name="oauth_resource_identifier"
                               value="<?php echo esc_url($oauth_resource_identifier); ?>" class="regular-text" />
                        <p class="description">
                            <?php _e('The resource identifier URL (typically same as issuer)', 'insationai-wordpress-mcp'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="oauth_private_key_path"><?php _e('Private Key Path', 'insationai-wordpress-mcp'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="oauth_private_key_path" name="oauth_private_key_path"
                               value="<?php echo esc_attr($oauth_private_key_path); ?>" class="regular-text" />
                        <p class="description">
                            <?php _e('Absolute path to RSA private key file', 'insationai-wordpress-mcp'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="oauth_public_key_path"><?php _e('Public Key Path', 'insationai-wordpress-mcp'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="oauth_public_key_path" name="oauth_public_key_path"
                               value="<?php echo esc_attr($oauth_public_key_path); ?>" class="regular-text" />
                        <p class="description">
                            <?php _e('Absolute path to RSA public key file', 'insationai-wordpress-mcp'); ?>
                        </p>
                    </td>
                </tr>
                </table>
                <?php submit_button(__('Save Settings', 'insationai-wordpress-mcp'), 'primary', 'insationai_wpmcp_save_settings'); ?>
            </form>
        </div>
        <?php endif; ?>

        <!-- Endpoints Info -->
        <div id="endpoints-info" class="tab-content" style="display:none;">
            <h2><?php _e('Getting Started', 'insationai-wordpress-mcp'); ?></h2>
            <p><?php _e('To use WordpressMCP, you need an API token. Go to the', 'insationai-wordpress-mcp'); ?> <a href="#tokens" class="insationai-wpmcp-tab-link"><?php _e('API Tokens tab', 'insationai-wordpress-mcp'); ?></a> <?php _e('to create or view your tokens.', 'insationai-wordpress-mcp'); ?></p>

            <h3><?php _e('Main MCP Endpoint', 'insationai-wordpress-mcp'); ?></h3>
            <p><?php _e('This is the primary endpoint for all MCP requests:', 'insationai-wordpress-mcp'); ?></p>
            <div class="endpoint-box">
                <code id="mcp-endpoint-url"><?php echo home_url('/' . $endpoint_slug); ?></code>
                <button class="button button-small" onclick="copyEndpointUrl('mcp-endpoint-url')" style="margin-left: 10px;">
                    <?php _e('Copy URL', 'insationai-wordpress-mcp'); ?>
                </button>
            </div>

            <h3><?php _e('Token Authentication Examples', 'insationai-wordpress-mcp'); ?></h3>

            <h4><?php _e('Method 1: Query Parameter (All HTTP methods)', 'insationai-wordpress-mcp'); ?></h4>
            <p><?php _e('Append your token to the URL as a query parameter:', 'insationai-wordpress-mcp'); ?></p>
            <div class="endpoint-box">
                <code id="query-param-example"><?php echo home_url('/' . $endpoint_slug . '?t=YOUR_TOKEN_HERE'); ?></code>
                <button class="button button-small" onclick="copyEndpointUrl('query-param-example')" style="margin-left: 10px;">
                    <?php _e('Copy Example', 'insationai-wordpress-mcp'); ?>
                </button>
            </div>
            <p class="description">
                <strong><?php _e('Pros:', 'insationai-wordpress-mcp'); ?></strong> <?php _e('Simple to use, works with all HTTP methods, perfect for tools like Claude Desktop', 'insationai-wordpress-mcp'); ?><br>
                <strong><?php _e('Cons:', 'insationai-wordpress-mcp'); ?></strong> <?php _e('Token visible in URL logs', 'insationai-wordpress-mcp'); ?>
            </p>

            <h4><?php _e('Method 2: Authorization Header (All HTTP methods)', 'insationai-wordpress-mcp'); ?></h4>
            <p><?php _e('Include token in the Authorization header:', 'insationai-wordpress-mcp'); ?></p>
            <div class="endpoint-box">
                <code>curl -H "Authorization: Bearer YOUR_TOKEN_HERE" <?php echo home_url('/' . $endpoint_slug); ?></code>
            </div>
            <p class="description">
                <strong><?php _e('Pros:', 'insationai-wordpress-mcp'); ?></strong> <?php _e('Works with all HTTP methods, more secure (not in URL)', 'insationai-wordpress-mcp'); ?><br>
                <strong><?php _e('Cons:', 'insationai-wordpress-mcp'); ?></strong> <?php _e('Requires setting custom headers', 'insationai-wordpress-mcp'); ?>
            </p>

            <h3><?php _e('Using with Claude Desktop', 'insationai-wordpress-mcp'); ?></h3>
            <p><?php _e('Add this to your Claude Desktop configuration file:', 'insationai-wordpress-mcp'); ?></p>
            <div class="endpoint-box">
                <pre id="claude-config" style="background: #f5f5f5; padding: 15px; overflow-x: auto;">{
  "mcpServers": {
    "wordpress": {
      "command": "npx",
      "args": [
        "mcp-remote",
        "<?php echo home_url('/' . $endpoint_slug . '?t=YOUR_TOKEN_HERE'); ?>"
      ]
    }
  }
}</pre>
                <button class="button button-small" onclick="copyEndpointUrl('claude-config')" style="margin-top: 10px;">
                    <?php _e('Copy Config', 'insationai-wordpress-mcp'); ?>
                </button>
            </div>
            <p class="description">
                <strong><?php _e('Location:', 'insationai-wordpress-mcp'); ?></strong>
                <br><?php _e('macOS:', 'insationai-wordpress-mcp'); ?> <code>~/Library/Application Support/Claude/claude_desktop_config.json</code>
                <br><?php _e('Windows:', 'insationai-wordpress-mcp'); ?> <code>%APPDATA%\Claude\claude_desktop_config.json</code>
            </p>

            <?php if (INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED && $oauth_enabled): ?>
            <hr style="margin: 30px 0;">
            <h2><?php _e('OAuth 2.1 Endpoints (Advanced)', 'insationai-wordpress-mcp'); ?></h2>
            <p><?php _e('For third-party integrations and advanced use cases. Most users should use API tokens instead.', 'insationai-wordpress-mcp'); ?></p>

            <h3><?php _e('OAuth Discovery (RFC 8414/9728)', 'insationai-wordpress-mcp'); ?></h3>
            <table class="widefat" style="margin-top: 15px;">
                <thead>
                    <tr>
                        <th><?php _e('Type', 'insationai-wordpress-mcp'); ?></th>
                        <th><?php _e('URL', 'insationai-wordpress-mcp'); ?></th>
                        <th><?php _e('Action', 'insationai-wordpress-mcp'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php _e('Authorization Server Metadata', 'insationai-wordpress-mcp'); ?></td>
                        <td><code id="oauth-as-url"><?php echo home_url('/.well-known/oauth-authorization-server/' . $endpoint_slug); ?></code></td>
                        <td><button class="button button-small" onclick="copyEndpointUrl('oauth-as-url')"><?php _e('Copy', 'insationai-wordpress-mcp'); ?></button></td>
                    </tr>
                    <tr>
                        <td><?php _e('Protected Resource Metadata', 'insationai-wordpress-mcp'); ?></td>
                        <td><code id="oauth-pr-url"><?php echo home_url('/.well-known/oauth-protected-resource/' . $endpoint_slug); ?></code></td>
                        <td><button class="button button-small" onclick="copyEndpointUrl('oauth-pr-url')"><?php _e('Copy', 'insationai-wordpress-mcp'); ?></button></td>
                    </tr>
                    <tr>
                        <td><?php _e('JWKS (Public Keys)', 'insationai-wordpress-mcp'); ?></td>
                        <td><code id="oauth-jwks-url"><?php echo home_url('/.well-known/jwks.json/' . $endpoint_slug); ?></code></td>
                        <td><button class="button button-small" onclick="copyEndpointUrl('oauth-jwks-url')"><?php _e('Copy', 'insationai-wordpress-mcp'); ?></button></td>
                    </tr>
                </tbody>
            </table>

            <h3><?php _e('OAuth Flow Endpoints', 'insationai-wordpress-mcp'); ?></h3>
            <table class="widefat" style="margin-top: 15px;">
                <thead>
                    <tr>
                        <th><?php _e('Endpoint', 'insationai-wordpress-mcp'); ?></th>
                        <th><?php _e('URL', 'insationai-wordpress-mcp'); ?></th>
                        <th><?php _e('Action', 'insationai-wordpress-mcp'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php _e('Authorization', 'insationai-wordpress-mcp'); ?></td>
                        <td><code id="oauth-auth-url"><?php echo home_url('/' . $endpoint_slug . '/oauth/authorize'); ?></code></td>
                        <td><button class="button button-small" onclick="copyEndpointUrl('oauth-auth-url')"><?php _e('Copy', 'insationai-wordpress-mcp'); ?></button></td>
                    </tr>
                    <tr>
                        <td><?php _e('Token', 'insationai-wordpress-mcp'); ?></td>
                        <td><code id="oauth-token-url"><?php echo home_url('/' . $endpoint_slug . '/oauth/token'); ?></code></td>
                        <td><button class="button button-small" onclick="copyEndpointUrl('oauth-token-url')"><?php _e('Copy', 'insationai-wordpress-mcp'); ?></button></td>
                    </tr>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- Tools toggle -->
        <div id="tools-info" class="tab-content" style="display:none;">
            <?php
            // Build the canonical tool list using the registry so this view
            // is always consistent with what's actually registered.
            $registryTools = \InsationAI\WordpressMCP\ToolRegistry::buildAllTools(
                new \InsationAI\WordpressMCP\Services\WordPressService(),
                new \InsationAI\WordpressMCP\Services\ValidationService(),
                new \InsationAI\WordpressMCP\Logger\WordPressLogger()
            );

            // Group tools by category
            $grouped = [];
            foreach ($registryTools as $t) {
                $name = $t->getName();
                $cat = \InsationAI\WordpressMCP\ToolRegistry::categoryFor($name);
                $grouped[$cat][] = [
                    'name'        => $name,
                    'description' => $t->getDescription(),
                    'scope'       => $t->getRequiredScope(),
                ];
            }
            // Sort categories alphabetically by label; tools within each by name
            uksort($grouped, function ($a, $b) {
                return strcmp(
                    \InsationAI\WordpressMCP\ToolRegistry::categoryLabel($a),
                    \InsationAI\WordpressMCP\ToolRegistry::categoryLabel($b)
                );
            });
            foreach ($grouped as &$bucket) {
                usort($bucket, fn($a, $b) => strcmp($a['name'], $b['name']));
            }
            unset($bucket);

            $disabled = \InsationAI\WordpressMCP\ToolRegistry::getDisabledToolNames();
            $totalCount = count($registryTools);
            $enabledCount = $totalCount - count(array_intersect($disabled, array_map(fn($t) => $t->getName(), $registryTools)));
            ?>

            <h2><?php _e('Tools', 'insationai-wordpress-mcp'); ?></h2>
            <p class="description">
                <?php _e('Enable or disable individual MCP tools, or toggle whole categories at once. Disabled tools are not registered with MCP clients or the WordPress Abilities API — they effectively don\'t exist until re-enabled.', 'insationai-wordpress-mcp'); ?>
            </p>

            <div id="insationai-wpmcp-tools-toolbar">
                <div class="insationai-wpmcp-tools-status">
                    <strong><span id="insationai-wpmcp-tools-enabled-count"><?php echo (int) $enabledCount; ?></span></strong>
                    <span> / <?php echo (int) $totalCount; ?> <?php _e('tools enabled', 'insationai-wordpress-mcp'); ?></span>
                </div>
                <div class="insationai-wpmcp-tools-actions">
                    <button type="button" class="button" id="insationai-wpmcp-enable-all"><?php _e('Enable All', 'insationai-wordpress-mcp'); ?></button>
                    <button type="button" class="button" id="insationai-wpmcp-disable-all"><?php _e('Disable All', 'insationai-wordpress-mcp'); ?></button>
                    <button type="button" class="button button-primary" id="insationai-wpmcp-save-tools"><?php _e('Save Changes', 'insationai-wordpress-mcp'); ?></button>
                    <span class="insationai-wpmcp-save-status" id="insationai-wpmcp-save-status"></span>
                </div>
            </div>

            <div id="insationai-wpmcp-tools-grid">
                <?php foreach ($grouped as $cat => $tools): ?>
                    <?php
                    $catLabel = \InsationAI\WordpressMCP\ToolRegistry::categoryLabel($cat);
                    $catTotal = count($tools);
                    $catDisabled = 0;
                    foreach ($tools as $tool) {
                        if (in_array($tool['name'], $disabled, true)) {
                            $catDisabled++;
                        }
                    }
                    $catEnabled = $catTotal - $catDisabled;
                    ?>
                    <div class="insationai-wpmcp-tool-category" data-category="<?php echo esc_attr($cat); ?>">
                        <div class="insationai-wpmcp-cat-header">
                            <label class="insationai-wpmcp-cat-toggle">
                                <input type="checkbox"
                                       class="insationai-wpmcp-cat-checkbox"
                                       data-category="<?php echo esc_attr($cat); ?>"
                                       <?php checked($catEnabled === $catTotal); ?>
                                       <?php if ($catEnabled > 0 && $catEnabled < $catTotal): ?>data-indeterminate="1"<?php endif; ?> />
                                <span class="insationai-wpmcp-cat-name"><?php echo esc_html($catLabel); ?></span>
                                <span class="insationai-wpmcp-cat-count">
                                    <span class="insationai-wpmcp-cat-enabled"><?php echo (int) $catEnabled; ?></span>
                                    <span> / <?php echo (int) $catTotal; ?></span>
                                </span>
                            </label>
                        </div>
                        <ul class="insationai-wpmcp-tool-list">
                            <?php foreach ($tools as $tool): ?>
                                <?php $isEnabled = !in_array($tool['name'], $disabled, true); ?>
                                <li class="insationai-wpmcp-tool-row">
                                    <label class="insationai-wpmcp-tool-toggle">
                                        <input type="checkbox"
                                               class="insationai-wpmcp-tool-checkbox"
                                               data-tool="<?php echo esc_attr($tool['name']); ?>"
                                               data-category="<?php echo esc_attr($cat); ?>"
                                               <?php checked($isEnabled); ?> />
                                        <code class="insationai-wpmcp-tool-name"><?php echo esc_html($tool['name']); ?></code>
                                        <span class="insationai-wpmcp-tool-scope insationai-wpmcp-tool-scope-<?php echo esc_attr(str_replace(':', '-', $tool['scope'])); ?>">
                                            <?php echo esc_html($tool['scope']); ?>
                                        </span>
                                    </label>
                                    <p class="insationai-wpmcp-tool-description"><?php echo esc_html($tool['description']); ?></p>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>

            <script>
            (function() {
                var nonce = <?php echo wp_json_encode(wp_create_nonce('insationai_wpmcp_tools_toggle')); ?>;
                var ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;

                jQuery(document).ready(function($) {
                    // Initialize indeterminate state on category checkboxes
                    $('.insationai-wpmcp-cat-checkbox[data-indeterminate="1"]').each(function() {
                        this.indeterminate = true;
                    });

                    function refreshCounters() {
                        var totalEnabled = 0;
                        var totalTools  = 0;
                        $('.insationai-wpmcp-tool-category').each(function() {
                            var $cat = $(this);
                            var $boxes = $cat.find('.insationai-wpmcp-tool-checkbox');
                            var enabled = $boxes.filter(':checked').length;
                            var count = $boxes.length;
                            $cat.find('.insationai-wpmcp-cat-enabled').text(enabled);

                            var $catBox = $cat.find('.insationai-wpmcp-cat-checkbox');
                            if (enabled === 0) {
                                $catBox.prop('checked', false).prop('indeterminate', false);
                            } else if (enabled === count) {
                                $catBox.prop('checked', true).prop('indeterminate', false);
                            } else {
                                $catBox.prop('checked', false).prop('indeterminate', true);
                            }

                            totalEnabled += enabled;
                            totalTools  += count;
                        });
                        $('#insationai-wpmcp-tools-enabled-count').text(totalEnabled);
                    }

                    // Category checkbox toggles every tool in the category
                    $('.insationai-wpmcp-cat-checkbox').on('change', function() {
                        var cat = $(this).data('category');
                        var checked = this.checked;
                        $('.insationai-wpmcp-tool-checkbox[data-category="' + cat + '"]').prop('checked', checked);
                        refreshCounters();
                    });

                    // Tool checkbox updates its category state
                    $('.insationai-wpmcp-tool-checkbox').on('change', refreshCounters);

                    // Enable / Disable all
                    $('#insationai-wpmcp-enable-all').on('click', function() {
                        $('.insationai-wpmcp-tool-checkbox').prop('checked', true);
                        refreshCounters();
                    });
                    $('#insationai-wpmcp-disable-all').on('click', function() {
                        $('.insationai-wpmcp-tool-checkbox').prop('checked', false);
                        refreshCounters();
                    });

                    // Save via AJAX
                    $('#insationai-wpmcp-save-tools').on('click', function() {
                        var disabled = [];
                        $('.insationai-wpmcp-tool-checkbox').each(function() {
                            if (!this.checked) {
                                disabled.push($(this).data('tool'));
                            }
                        });

                        var $btn = $(this);
                        var $status = $('#insationai-wpmcp-save-status');
                        $btn.prop('disabled', true);
                        $status.text(<?php echo wp_json_encode(__('Saving…', 'insationai-wordpress-mcp')); ?>).removeClass('error success');

                        $.post(ajaxUrl, {
                            action: 'insationai_wpmcp_save_tools',
                            _ajax_nonce: nonce,
                            disabled: disabled
                        }).done(function(resp) {
                            if (resp && resp.success) {
                                $status.text(<?php echo wp_json_encode(__('Saved.', 'insationai-wordpress-mcp')); ?>).addClass('success');
                            } else {
                                $status.text(<?php echo wp_json_encode(__('Save failed.', 'insationai-wordpress-mcp')); ?>).addClass('error');
                            }
                        }).fail(function() {
                            $status.text(<?php echo wp_json_encode(__('Network error.', 'insationai-wordpress-mcp')); ?>).addClass('error');
                        }).always(function() {
                            $btn.prop('disabled', false);
                            setTimeout(function() {
                                $status.fadeOut(400, function() { $(this).text('').show().removeClass('error success'); });
                            }, 2500);
                        });
                    });
                });
            })();
            </script>
        </div>

        <!-- Revisions / Changelog -->
        <div id="revisions-info" class="tab-content" style="display:none;">
            <h2><?php _e('Revisions & Changelog', 'insationai-wordpress-mcp'); ?></h2>
            <p class="description">
                <?php _e('A running history of every change shipped in WordpressMCP. Sourced from <code>revisions.json</code> in the plugin root.', 'insationai-wordpress-mcp'); ?>
            </p>

            <?php
            $revisions_file = INSATIONAI_WPMCP_PLUGIN_DIR . 'revisions.json';
            $revisions      = [];
            $revisions_err  = null;

            if (file_exists($revisions_file)) {
                $raw = file_get_contents($revisions_file);
                $decoded = json_decode($raw, true);
                if (json_last_error() === JSON_ERROR_NONE && isset($decoded['releases']) && is_array($decoded['releases'])) {
                    $revisions = $decoded['releases'];
                } else {
                    $revisions_err = json_last_error_msg();
                }
            } else {
                $revisions_err = __('revisions.json not found.', 'insationai-wordpress-mcp');
            }
            ?>

            <?php if ($revisions_err): ?>
                <div class="notice notice-warning inline">
                    <p><?php echo esc_html($revisions_err); ?></p>
                </div>
            <?php endif; ?>

            <div class="insationai-wpmcp-revisions">
                <?php foreach ($revisions as $release): ?>
                    <div class="insationai-wpmcp-revision-card">
                        <div class="insationai-wpmcp-revision-header">
                            <span class="insationai-wpmcp-revision-version">v<?php echo esc_html($release['version'] ?? '?'); ?></span>
                            <?php if (!empty($release['date'])): ?>
                                <span class="insationai-wpmcp-revision-date"><?php echo esc_html($release['date']); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($release['type'])): ?>
                                <span class="insationai-wpmcp-revision-type insationai-wpmcp-revision-type-<?php echo esc_attr($release['type']); ?>">
                                    <?php echo esc_html(ucfirst($release['type'])); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($release['summary'])): ?>
                            <p class="insationai-wpmcp-revision-summary"><?php echo esc_html($release['summary']); ?></p>
                        <?php endif; ?>

                        <?php foreach (['added', 'changed', 'fixed', 'removed', 'security'] as $section): ?>
                            <?php if (!empty($release[$section]) && is_array($release[$section])): ?>
                                <div class="insationai-wpmcp-revision-section insationai-wpmcp-revision-section-<?php echo esc_attr($section); ?>">
                                    <h4><?php echo esc_html(ucfirst($section)); ?></h4>
                                    <ul>
                                        <?php foreach ($release[$section] as $entry): ?>
                                            <li><?php echo esc_html($entry); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>

                <?php if (empty($revisions) && !$revisions_err): ?>
                    <p><?php _e('No revisions recorded yet.', 'insationai-wordpress-mcp'); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Updates -->
        <div id="updates-info" class="tab-content" style="display:none;">
            <h2><?php _e('Updates', 'insationai-wordpress-mcp'); ?></h2>
            <?php
            $upd_current = defined('INSATIONAI_WPMCP_VERSION') ? INSATIONAI_WPMCP_VERSION : '?';
            $upd_file    = 'insationai-wordpress-mcp/insationai-wordpress-mcp.php';
            // Read WP's own update transient (populated by UpdateChecker on its
            // 6-hour cycle / on a manual check) — no blocking HTTP call here.
            $upd_trans   = function_exists('get_site_transient') ? get_site_transient('update_plugins') : false;
            $upd_available = '';
            $upd_has = false;
            if (is_object($upd_trans)) {
                if (!empty($upd_trans->response[$upd_file]->new_version)) {
                    $upd_available = (string) $upd_trans->response[$upd_file]->new_version;
                    $upd_has = version_compare($upd_available, $upd_current, '>');
                } elseif (!empty($upd_trans->no_update[$upd_file]->new_version)) {
                    $upd_available = (string) $upd_trans->no_update[$upd_file]->new_version;
                }
            }
            ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php _e('Installed version', 'insationai-wordpress-mcp'); ?></th>
                    <td><code style="font-size:13px;"><?php echo esc_html($upd_current); ?></code></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Latest available', 'insationai-wordpress-mcp'); ?></th>
                    <td>
                        <?php if ($upd_available !== ''): ?>
                            <code style="font-size:13px;"><?php echo esc_html($upd_available); ?></code>
                            <?php if ($upd_has): ?>
                                <span style="color:#B45309;font-weight:600;margin-left:8px;">&#9679; <?php esc_html_e('Update available', 'insationai-wordpress-mcp'); ?></span>
                            <?php else: ?>
                                <span style="color:#15803D;margin-left:8px;">&#9679; <?php esc_html_e('Up to date', 'insationai-wordpress-mcp'); ?></span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span style="color:#64748B;"><?php esc_html_e('Not checked yet — use “Check for updates” below.', 'insationai-wordpress-mcp'); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <?php if ($upd_has): ?>
            <p>
                <a class="button button-primary" href="<?php echo esc_url(self_admin_url('plugins.php')); ?>">
                    <?php esc_html_e('Go to Plugins to install the update', 'insationai-wordpress-mcp'); ?>
                </a>
            </p>
            <?php endif; ?>

            <p>
                <a class="button" href="<?php echo esc_url(
                    wp_nonce_url(
                        add_query_arg(array('insationai_wpmcp_check_update' => '1'), self_admin_url('plugins.php')),
                        'insationai_wpmcp_check_update'
                    )
                ); ?>">
                    <?php esc_html_e('Check for updates now', 'insationai-wordpress-mcp'); ?>
                </a>
            </p>

            <p class="description" style="margin-top:14px;color:#64748B;">
                <?php esc_html_e('This installation automatically checks insation.ai for new versions about every 6 hours while licensed, and you can check manually above. Updates are delivered only to a licensed, active install.', 'insationai-wordpress-mcp'); ?>
            </p>
        </div>

        <!-- Support -->
        <div id="support-info" class="tab-content" style="display:none;">
            <h2><?php _e('Support', 'insationai-wordpress-mcp'); ?></h2>
            <p class="description">
                <?php _e('Need help? Compose a request below. A diagnostic summary is included to speed up troubleshooting — you can review exactly what it contains before sending. The license key is shown masked; your full key is never included.', 'insationai-wordpress-mcp'); ?>
            </p>

            <?php
            // --- Curated, non-sensitive diagnostic bundle ---------------------
            // Deliberately excludes the raw license key and any auth tokens.
            // mask_key() yields prefix + last group only (e.g. WPMCP-1-****-****-GMCR).
            $sup_ls = $wpmcp_license_state;
            $sup_mask = (!empty($sup_ls['key']) && class_exists('InsationAI_WPMCP_License_Service'))
                ? InsationAI_WPMCP_License_Service::mask_key($sup_ls['key'])
                : '(none)';
            $sup_exp = isset($sup_ls['expires']) ? (string) $sup_ls['expires'] : '';
            $sup_exp = ($sup_exp === '' || strtolower($sup_exp) === 'never')
                ? 'never (lifetime)' : $sup_exp;
            global $wp_version;
            $sup_data = array(
                'Plugin'             => 'WordpressMCP ' . (defined('INSATIONAI_WPMCP_VERSION') ? INSATIONAI_WPMCP_VERSION : '?'),
                'WordPress'          => isset($wp_version) ? $wp_version : get_bloginfo('version'),
                'PHP'                => PHP_VERSION,
                'Site URL'           => home_url('/'),
                'License status'     => isset($sup_ls['status']) ? $sup_ls['status'] : 'unknown',
                'License reason'     => isset($sup_ls['reason_code']) ? $sup_ls['reason_code'] : '',
                'License key'        => $sup_mask,
                'Tier'               => (!empty($sup_ls['tier']) ? $sup_ls['tier'] : '—'),
                'Activations'        => (isset($sup_ls['activation_count']) ? (int) $sup_ls['activation_count'] : 0)
                                        . ' / ' . (isset($sup_ls['activation_limit']) && (int) $sup_ls['activation_limit'] > 0
                                            ? (int) $sup_ls['activation_limit'] : 'unlimited'),
                'Expires'            => $sup_exp,
                'Last verified'      => (!empty($sup_ls['last_success'])
                                        ? human_time_diff($sup_ls['last_success']) . ' ago' : 'never'),
            );
            $sup_report_lines = array();
            foreach ($sup_data as $k => $v) {
                $sup_report_lines[] = $k . ': ' . $v;
            }
            $sup_report = implode("\n", $sup_report_lines);
            ?>

            <form method="post" action="" id="insationai-wpmcp-support-form" onsubmit="return false;">
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="insationai-wpmcp-support-cat"><?php _e('Category', 'insationai-wordpress-mcp'); ?></label></th>
                        <td>
                            <select id="insationai-wpmcp-support-cat" class="regular-text">
                                <option value="Technical support"><?php _e('Technical support', 'insationai-wordpress-mcp'); ?></option>
                                <option value="Billing"><?php _e('Billing', 'insationai-wordpress-mcp'); ?></option>
                                <option value="Feature request"><?php _e('Feature request', 'insationai-wordpress-mcp'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="insationai-wpmcp-support-subject"><?php _e('Subject', 'insationai-wordpress-mcp'); ?></label></th>
                        <td><input type="text" id="insationai-wpmcp-support-subject" class="regular-text" placeholder="<?php esc_attr_e('Brief summary of the issue', 'insationai-wordpress-mcp'); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="insationai-wpmcp-support-msg"><?php _e('Message', 'insationai-wordpress-mcp'); ?></label></th>
                        <td><textarea id="insationai-wpmcp-support-msg" rows="7" class="large-text" placeholder="<?php esc_attr_e('Describe what you expected, what happened, and any steps to reproduce.', 'insationai-wordpress-mcp'); ?>"></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Diagnostic summary', 'insationai-wordpress-mcp'); ?></th>
                        <td>
                            <p class="description" style="margin-top:0;"><?php _e('Included with your request. No secrets — the license key is masked.', 'insationai-wordpress-mcp'); ?></p>
                            <textarea id="insationai-wpmcp-support-diag" rows="9" class="large-text" readonly style="font-family:Consolas,Monaco,monospace;font-size:12px;background:#F8FAFC;"><?php echo esc_textarea($sup_report); ?></textarea>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="button" class="button button-primary" id="insationai-wpmcp-support-send"><?php _e('Open in email', 'insationai-wordpress-mcp'); ?></button>
                    <button type="button" class="button" id="insationai-wpmcp-support-copy"><?php _e('Copy report', 'insationai-wordpress-mcp'); ?></button>
                    <span id="insationai-wpmcp-support-copied" style="display:none;color:#15803D;margin-left:8px;"><?php _e('Copied to clipboard!', 'insationai-wordpress-mcp'); ?></span>
                </p>
                <p class="description">
                    <?php _e('“Open in email” starts a message to support@insation.ai in your mail app. If nothing opens, use “Copy report” and paste it into an email to support@insation.ai manually.', 'insationai-wordpress-mcp'); ?>
                </p>
            </form>

            <script>
            (function(){
                var supEmail = 'support@insation.ai';
                function buildBody(){
                    var cat = document.getElementById('insationai-wpmcp-support-cat').value;
                    var msg = document.getElementById('insationai-wpmcp-support-msg').value;
                    var diag = document.getElementById('insationai-wpmcp-support-diag').value;
                    return 'Category: ' + cat + '\n\n' + (msg || '') +
                           '\n\n---- Diagnostic summary ----\n' + diag + '\n';
                }
                var sendBtn = document.getElementById('insationai-wpmcp-support-send');
                if (sendBtn) sendBtn.addEventListener('click', function(){
                    var cat = document.getElementById('insationai-wpmcp-support-cat').value;
                    var subj = document.getElementById('insationai-wpmcp-support-subject').value || cat;
                    var href = 'mailto:' + supEmail +
                        '?subject=' + encodeURIComponent('[WordpressMCP] ' + subj) +
                        '&body=' + encodeURIComponent(buildBody());
                    window.location.href = href;
                });
                var copyBtn = document.getElementById('insationai-wpmcp-support-copy');
                if (copyBtn) copyBtn.addEventListener('click', function(){
                    var txt = buildBody();
                    var done = function(){
                        var c = document.getElementById('insationai-wpmcp-support-copied');
                        if (c){ c.style.display='inline'; setTimeout(function(){ c.style.display='none'; }, 2500); }
                    };
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(txt).then(done).catch(function(){
                            var ta=document.getElementById('insationai-wpmcp-support-diag');
                            ta.focus(); ta.select(); try{document.execCommand('copy');}catch(e){} done();
                        });
                    } else {
                        var ta=document.getElementById('insationai-wpmcp-support-diag');
                        ta.focus(); ta.select(); try{document.execCommand('copy');}catch(e){} done();
                    }
                });
            })();
            </script>
        </div>
<?php endif; /* $wpmcp_is_licensed — end of licensed-only tab content */ ?>

    </div>

<script>
// Confirm dialogs for bulk token actions — defined outside jQuery ready so the
// inline onclick handlers can reach them.
function insationaiWpmcpConfirmRevokeSelected() {
    var checked = document.querySelectorAll('.insationai-wpmcp-token-cb:checked').length;
    if (checked === 0) {
        return false;
    }
    return confirm(
        checked === 1
            ? '<?php echo esc_js(__('Revoke the selected token?', 'insationai-wordpress-mcp')); ?>'
            : '<?php echo esc_js(__('Revoke the', 'insationai-wordpress-mcp')); ?>' + ' ' + checked + ' '
              + '<?php echo esc_js(__('selected tokens?', 'insationai-wordpress-mcp')); ?>'
    );
}
function insationaiWpmcpConfirmRevokeAll() {
    return confirm('<?php echo esc_js(__('Revoke ALL tokens? This cannot be undone and will immediately disconnect every MCP client using this site.', 'insationai-wordpress-mcp')); ?>');
}

jQuery(document).ready(function($) {
    /**
     * Show a tab by its slug ('general', 'tokens', etc.) and persist it in the
     * URL hash so a page reload (e.g. after a form POST) returns to it.
     */
    function insationaiWpmcpShowTab(target, updateHash) {
        // The safe fallback tab depends on license state: when unlicensed,
        // only #license exists, so falling back to 'general' would blank the page.
        var fallbackTab = <?php echo $wpmcp_is_licensed ? "'general'" : "'license'"; ?>;
        var $targetTab = $('.nav-tab[href="#' + target + '"]');
        if (!$targetTab.length) {
            target = fallbackTab;
            $targetTab = $('.nav-tab[href="#' + fallbackTab + '"]');
        }
        $('.nav-tab').removeClass('nav-tab-active');
        $targetTab.addClass('nav-tab-active');
        $('.tab-content').hide();
        $('#' + target + '-settings, #' + target + '-info').show();
        if (updateHash) {
            // Use replaceState so we don't spam the browser history on every tab click.
            if (window.history && window.history.replaceState) {
                window.history.replaceState(null, '', '#' + target);
            } else {
                window.location.hash = target;
            }
        }
    }

    // Tab switching (nav clicks)
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();
        insationaiWpmcpShowTab($(this).attr('href').substring(1), true);
    });

    // Inline tab links (e.g., "API Tokens tab" link inside body copy)
    $('.insationai-wpmcp-tab-link').on('click', function(e) {
        e.preventDefault();
        insationaiWpmcpShowTab($(this).attr('href').substring(1), true);
    });

    /**
     * On page load, decide which tab to show. Priority:
     *   1. A server-side override (set after a token revoke POST so we land
     *      back on the API Tokens tab instead of General).
     *   2. The URL hash (so a manual reload or shared link keeps the tab).
     *   3. Default: General.
     */
    var serverTabOverride = <?php echo wp_json_encode($active_tab_override); ?>;
    // When unlicensed, only the License tab/content exists, so it must be the
    // default — otherwise showTab() hides everything looking for #general.
    var licensedDefaultTab = <?php echo $wpmcp_is_licensed ? "'general'" : "'license'"; ?>;
    var initialTab = serverTabOverride
        || (window.location.hash ? window.location.hash.substring(1) : '')
        || licensedDefaultTab;
    // Safety: if not licensed, force the License tab regardless of a stale hash
    // (e.g. user previously had #tokens in the URL before the license lapsed).
    <?php if (!$wpmcp_is_licensed): ?>
    initialTab = 'license';
    <?php endif; ?>
    insationaiWpmcpShowTab(initialTab, true);

    /* ---- API Tokens: checkbox + bulk action wiring ---- */

    function insationaiWpmcpRefreshTokenSelection() {
        var $boxes = $('.insationai-wpmcp-token-cb');
        var $checked = $boxes.filter(':checked');
        var count = $checked.length;

        // Enable/disable the "Revoke Selected" button
        $('#insationai-wpmcp-revoke-selected').prop('disabled', count === 0);

        // Update the count label
        var label = '';
        if (count === 1) {
            label = '1 <?php echo esc_js(__('token selected', 'insationai-wordpress-mcp')); ?>';
        } else if (count > 1) {
            label = count + ' <?php echo esc_js(__('tokens selected', 'insationai-wordpress-mcp')); ?>';
        }
        $('#insationai-wpmcp-selected-count').text(label);

        // Sync the "select all" header checkbox state
        var $all = $('#insationai-wpmcp-select-all-tokens');
        if (count === 0) {
            $all.prop('checked', false).prop('indeterminate', false);
        } else if (count === $boxes.length) {
            $all.prop('checked', true).prop('indeterminate', false);
        } else {
            $all.prop('checked', false).prop('indeterminate', true);
        }
    }

    // "Select all" header checkbox toggles every row
    $('#insationai-wpmcp-select-all-tokens').on('change', function() {
        $('.insationai-wpmcp-token-cb').prop('checked', this.checked);
        insationaiWpmcpRefreshTokenSelection();
    });

    // Individual row checkbox updates the toolbar state
    $('.insationai-wpmcp-token-cb').on('change', insationaiWpmcpRefreshTokenSelection);

    // Initialize toolbar state on load
    insationaiWpmcpRefreshTokenSelection();

    // Handle dismissible activation error notice
    $(document).on('click', '.notice-error.is-dismissible .notice-dismiss', function() {
        // Send AJAX request to delete the transient
        $.post(ajaxurl, {
            action: 'insationai_wpmcp_dismiss_activation_error'
        });
    });
});

// Copy token to clipboard
function copyToken(token) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(token).then(function() {
            alert('Copied to clipboard!');
        }).catch(function(err) {
            fallbackCopyToken(token);
        });
    } else {
        fallbackCopyToken(token);
    }
}

function fallbackCopyToken(token) {
    var textArea = document.createElement('textarea');
    textArea.value = token;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.select();
    try {
        document.execCommand('copy');
        alert('Copied to clipboard!');
    } catch (err) {
        alert('Failed to copy. Please copy it manually.');
    }
    document.body.removeChild(textArea);
}

// Show token usage modal
function showTokenUsage(endpointSlug) {
    var baseUrl = '<?php echo esc_js(home_url('/')); ?>';
    var modalHtml = '<div id="token-usage-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 100000; display: flex; align-items: center; justify-content: center;">' +
        '<div style="background: white; padding: 30px; border-radius: 5px; max-width: 600px; max-height: 80%; overflow-y: auto;">' +
        '<h2 style="margin-top: 0;">Token Usage Instructions</h2>' +
        '<p><strong>Note:</strong> For security reasons, tokens are only displayed once when created. If you need the token value, create a new token.</p>' +
        '<h3>Method 1: Query Parameter (GET requests only)</h3>' +
        '<p>Append your token to the URL:</p>' +
        '<code style="display: block; background: #f5f5f5; padding: 10px; margin: 10px 0; word-break: break-all;">' + baseUrl + endpointSlug + '?t=YOUR_TOKEN</code>' +
        '<h3>Method 2: Authorization Header (All HTTP methods)</h3>' +
        '<p>Include token in the Authorization header:</p>' +
        '<code style="display: block; background: #f5f5f5; padding: 10px; margin: 10px 0;">Authorization: Bearer YOUR_TOKEN</code>' +
        '<h3>Example with curl:</h3>' +
        '<code style="display: block; background: #f5f5f5; padding: 10px; margin: 10px 0; word-break: break-all;"># Query parameter<br>curl "' + baseUrl + endpointSlug + '?t=YOUR_TOKEN"<br><br># Header<br>curl -H "Authorization: Bearer YOUR_TOKEN" ' + baseUrl + endpointSlug + '</code>' +
        '<div style="text-align: right; margin-top: 20px;">' +
        '<button onclick="closeTokenUsageModal()" class="button button-primary">Close</button>' +
        '</div>' +
        '</div>' +
        '</div>';

    jQuery('body').append(modalHtml);
}

function closeTokenUsageModal() {
    jQuery('#token-usage-modal').remove();
}

// Close modal on click outside
jQuery(document).on('click', '#token-usage-modal', function(e) {
    if (e.target.id === 'token-usage-modal') {
        closeTokenUsageModal();
    }
});

// Copy endpoint URL to clipboard
function copyEndpointUrl(elementId) {
    var element = document.getElementById(elementId);
    var text = element.textContent || element.innerText;

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function() {
            alert('Copied to clipboard!');
        }).catch(function(err) {
            fallbackCopy(text);
        });
    } else {
        fallbackCopy(text);
    }
}

function fallbackCopy(text) {
    var textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.select();
    try {
        document.execCommand('copy');
        alert('Copied to clipboard!');
    } catch (err) {
        alert('Failed to copy. Please copy it manually.');
    }
    document.body.removeChild(textArea);
}
</script>

<style>
.tab-content {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-top: none;
    padding: 20px;
    margin-bottom: 20px;
}

.endpoint-box {
    background: #f5f5f5;
    padding: 15px;
    margin: 15px 0;
    border-left: 4px solid #2271b1;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
}

.endpoint-box code {
    flex: 1;
    word-break: break-all;
    font-size: 13px;
    background: transparent;
    padding: 0;
}

.endpoint-box pre {
    margin: 0;
    flex: 1 1 100%;
}

.insationai-wpmcp-tab-link {
    color: #2271b1;
    text-decoration: none;
    font-weight: 600;
}

.insationai-wpmcp-tab-link:hover {
    color: #135e96;
    text-decoration: underline;
}

#endpoints-info h2 {
    margin-top: 0;
    padding-top: 0;
    color: #1d2327;
}

#endpoints-info h3 {
    margin-top: 25px;
    color: #1d2327;
    font-size: 16px;
}

#endpoints-info h4 {
    margin-top: 20px;
    margin-bottom: 10px;
    color: #2c3338;
    font-size: 14px;
}

#endpoints-info .widefat code {
    font-size: 12px;
}

/* Revisions tab */
.insationai-wpmcp-revisions {
    margin-top: 20px;
    max-width: 880px;
}
.insationai-wpmcp-revision-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-left: 4px solid #2271b1;
    border-radius: 4px;
    padding: 18px 22px;
    margin-bottom: 16px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}
.insationai-wpmcp-revision-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
    flex-wrap: wrap;
}
.insationai-wpmcp-revision-version {
    font-size: 18px;
    font-weight: 600;
    color: #1d2327;
    font-family: Consolas, Monaco, monospace;
}
.insationai-wpmcp-revision-date {
    color: #646970;
    font-size: 13px;
}
.insationai-wpmcp-revision-type {
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.insationai-wpmcp-revision-type-major   { background: #fde8e8; color: #b32d2e; }
.insationai-wpmcp-revision-type-minor   { background: #fff3cd; color: #856404; }
.insationai-wpmcp-revision-type-patch   { background: #e6f4ea; color: #1e6e3a; }
.insationai-wpmcp-revision-type-initial { background: #e8f0fe; color: #1a56db; }
.insationai-wpmcp-revision-summary {
    font-size: 14px;
    color: #50575e;
    margin: 6px 0 14px;
}
.insationai-wpmcp-revision-section {
    margin: 12px 0;
}
.insationai-wpmcp-revision-section h4 {
    margin: 0 0 6px;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #50575e;
}
.insationai-wpmcp-revision-section ul {
    margin: 0 0 0 18px;
    list-style: disc;
}
.insationai-wpmcp-revision-section li {
    margin: 3px 0;
    color: #1d2327;
    font-size: 13px;
}
.insationai-wpmcp-revision-section-added   h4 { color: #1e6e3a; }
.insationai-wpmcp-revision-section-changed h4 { color: #856404; }
.insationai-wpmcp-revision-section-fixed   h4 { color: #1a56db; }
.insationai-wpmcp-revision-section-removed h4 { color: #b32d2e; }
.insationai-wpmcp-revision-section-security h4 { color: #6f42c1; }

/* Tools tab */
#insationai-wpmcp-tools-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 20px 0 16px;
    padding: 14px 18px;
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    position: sticky;
    top: 32px;
    z-index: 10;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}
.insationai-wpmcp-tools-status {
    font-size: 14px;
    color: #1d2327;
}
.insationai-wpmcp-tools-status strong {
    font-size: 18px;
    color: #2271b1;
}
.insationai-wpmcp-tools-actions {
    display: flex;
    align-items: center;
    gap: 8px;
}
.insationai-wpmcp-save-status {
    margin-left: 8px;
    font-size: 13px;
}
.insationai-wpmcp-save-status.success { color: #1e6e3a; }
.insationai-wpmcp-save-status.error   { color: #b32d2e; }

#insationai-wpmcp-tools-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 14px;
    max-width: 1100px;
}
.insationai-wpmcp-tool-category {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    overflow: hidden;
}
.insationai-wpmcp-cat-header {
    background: #f6f7f7;
    border-bottom: 1px solid #c3c4c7;
    padding: 10px 16px;
}
.insationai-wpmcp-cat-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    user-select: none;
}
.insationai-wpmcp-cat-name {
    font-weight: 600;
    font-size: 14px;
    color: #1d2327;
    flex: 1;
}
.insationai-wpmcp-cat-count {
    font-size: 12px;
    color: #50575e;
    font-variant-numeric: tabular-nums;
}
.insationai-wpmcp-cat-enabled {
    font-weight: 600;
    color: #2271b1;
}
.insationai-wpmcp-tool-list {
    list-style: none;
    margin: 0;
    padding: 0;
}
.insationai-wpmcp-tool-row {
    padding: 10px 16px;
    border-bottom: 1px solid #f0f0f1;
}
.insationai-wpmcp-tool-row:last-child {
    border-bottom: none;
}
.insationai-wpmcp-tool-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
}
.insationai-wpmcp-tool-name {
    font-family: Consolas, Monaco, monospace;
    font-size: 13px;
    color: #1d2327;
    background: #f6f7f7;
    padding: 2px 8px;
    border-radius: 3px;
    flex: 1;
}
.insationai-wpmcp-tool-scope {
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 10px;
    font-weight: 600;
    letter-spacing: 0.3px;
}
.insationai-wpmcp-tool-scope-mcp-read   { background: #e8f0fe; color: #1a56db; }
.insationai-wpmcp-tool-scope-mcp-write  { background: #fff3cd; color: #856404; }
.insationai-wpmcp-tool-scope-mcp-delete { background: #fde8e8; color: #b32d2e; }
.insationai-wpmcp-tool-scope-mcp-admin  { background: #e6f4ea; color: #1e6e3a; }
.insationai-wpmcp-tool-description {
    margin: 4px 0 0 28px;
    font-size: 12px;
    color: #50575e;
    line-height: 1.5;
}


/* ===================================================================
 * InsationAI admin brand skin — light working surface, navy brand.
 * Geometry/spacing/accent extracted from the live insation.ai home
 * page (Elementor doc 21): 1240px content width, 10px button radius,
 * 600-weight type, #2563EB accent, soft borders, generous spacing.
 * Per the design decision: a readable near-slate canvas for dense
 * admin, with the InsationAI brand expressed through deep-navy panels,
 * the blue accent, and the site's geometry — NOT the dark marketing
 * look. Scoped to .insationai-mcp-skin so nothing leaks into the rest
 * of wp-admin; defensive overrides keep injected core elements on-theme.
 * ================================================================= */
.insationai-mcp-skin {
    --ia-navy: #0A1A3F;
    --ia-navy-soft: #142554;
    --ia-canvas: #F1F5F9;
    --ia-panel: #FFFFFF;
    --ia-ink: #0F1E3D;
    --ia-text: #334155;
    --ia-muted: #64748B;
    --ia-accent: #2563EB;
    --ia-accent-hover: #1D4ED8;
    --ia-accent-soft: #EFF4FF;
    --ia-link: #2563EB;
    --ia-link-hover: #1D4ED8;
    --ia-border: #E2E8F0;
    --ia-border-strong: #CBD5E1;
    --ia-radius: 12px;
    --ia-radius-sm: 8px;

    background: var(--ia-canvas);
    color: var(--ia-text);
    margin: 10px 20px 0 2px;
    padding: 0 0 40px;
    border-radius: 16px;
    overflow: hidden;
    min-height: calc(100vh - 100px);
}

/* Brand identity band (navy header, the one place the dark brand shows) */
.insationai-mcp-skin > h1:first-of-type {
    display: flex; align-items: center; gap: 14px;
    background: linear-gradient(135deg, var(--ia-navy) 0%, var(--ia-navy-soft) 100%);
    color: #FFFFFF;
    font-size: 22px; font-weight: 700;
    margin: 0 0 24px; padding: 26px 32px;
}
.insationai-mcp-skin > h1:first-of-type::before {
    content: ""; width: 32px; height: 32px; border-radius: 9px;
    background: linear-gradient(135deg, var(--ia-accent), #60A5FA);
    box-shadow: 0 4px 14px rgba(37,99,235,0.45);
    display: inline-block; flex: 0 0 auto;
}

/* Body content gets breathing room (site uses generous padding) */
.insationai-mcp-skin > *:not(h1:first-of-type) { margin-left: 32px; margin-right: 32px; }
.insationai-mcp-skin .nav-tab-wrapper { margin-left: 32px; margin-right: 32px; }

.insationai-mcp-skin h2,
.insationai-mcp-skin h3,
.insationai-mcp-skin h4 { color: var(--ia-ink); }
.insationai-mcp-skin p,
.insationai-mcp-skin li,
.insationai-mcp-skin td,
.insationai-mcp-skin label { color: var(--ia-text); }
.insationai-mcp-skin a { color: var(--ia-link); }
.insationai-mcp-skin a:hover { color: var(--ia-link-hover); }
.insationai-mcp-skin .description,
.insationai-mcp-skin .howto { color: var(--ia-muted) !important; }

/* Tabs */
.insationai-mcp-skin .nav-tab-wrapper { border-bottom: 1px solid var(--ia-border); }
.insationai-mcp-skin .nav-tab {
    background: transparent; border: 1px solid transparent; border-bottom: none;
    color: var(--ia-muted); font-weight: 600; border-radius: 8px 8px 0 0;
    margin-bottom: -1px;
}
.insationai-mcp-skin .nav-tab:hover { color: var(--ia-ink); background: #FFFFFF; }
.insationai-mcp-skin .nav-tab-active,
.insationai-mcp-skin .nav-tab-active:focus,
.insationai-mcp-skin .nav-tab-active:hover {
    background: #FFFFFF; color: var(--ia-accent);
    border-color: var(--ia-border); border-bottom-color: #FFFFFF;
}

/* Panels / cards — white with soft border + subtle elevation */
.insationai-mcp-skin .tab-content,
.insationai-mcp-skin .endpoint-box,
.insationai-mcp-skin .insationai-wpmcp-revision-card,
.insationai-mcp-skin .card,
.insationai-mcp-skin .postbox {
    background: var(--ia-panel) !important;
    border: 1px solid var(--ia-border) !important;
    border-radius: var(--ia-radius) !important;
    color: var(--ia-text) !important;
    box-shadow: 0 1px 3px rgba(15,30,61,0.06), 0 1px 2px rgba(15,30,61,0.04) !important;
}
.insationai-mcp-skin .endpoint-box { border-left: 4px solid var(--ia-accent) !important; }
.insationai-mcp-skin .insationai-wpmcp-revision-card { border-left: 4px solid var(--ia-accent) !important; }
.insationai-mcp-skin .insationai-wpmcp-revision-version,
.insationai-mcp-skin #endpoints-info h2,
.insationai-mcp-skin #endpoints-info h3,
.insationai-mcp-skin #endpoints-info h4 { color: var(--ia-ink) !important; }

/* Code blocks — light navy-tinted, readable */
.insationai-mcp-skin code,
.insationai-mcp-skin pre {
    background: var(--ia-accent-soft) !important;
    color: #1E3A8A !important;
    border: 1px solid #DBE6FF !important;
    border-radius: 6px;
}

/* Defensive: core notices injected by WP */
.insationai-mcp-skin .notice,
.insationai-mcp-skin .updated,
.insationai-mcp-skin .error,
.insationai-mcp-skin .notice-info,
.insationai-mcp-skin .notice-success,
.insationai-mcp-skin .notice-warning {
    background: #FFFFFF !important;
    color: var(--ia-text) !important;
    border: 1px solid var(--ia-border) !important;
    border-left: 4px solid var(--ia-accent) !important;
    border-radius: var(--ia-radius-sm) !important;
    box-shadow: 0 1px 2px rgba(15,30,61,0.05) !important;
}
.insationai-mcp-skin .notice-success { border-left-color: #22C55E !important; }
.insationai-mcp-skin .notice-warning { border-left-color: #F59E0B !important; }
.insationai-mcp-skin .notice-error,
.insationai-mcp-skin .error { border-left-color: #EF4444 !important; }
.insationai-mcp-skin .notice p,
.insationai-mcp-skin .notice a { color: var(--ia-text) !important; }

/* Buttons — brand accent primary, clean secondary */
.insationai-mcp-skin .button,
.insationai-mcp-skin .button-secondary {
    background: #FFFFFF !important;
    color: var(--ia-text) !important;
    border: 1px solid var(--ia-border-strong) !important;
    border-radius: var(--ia-radius-sm) !important;
    text-shadow: none !important; box-shadow: none !important;
    font-weight: 600 !important;
}
.insationai-mcp-skin .button:hover { background: #F8FAFC !important; color: var(--ia-ink) !important; border-color: var(--ia-muted) !important; }
.insationai-mcp-skin .button-primary {
    background: var(--ia-accent) !important;
    border: 1px solid var(--ia-accent) !important;
    color: #FFFFFF !important;
    border-radius: var(--ia-radius-sm) !important;
    padding: 2px 16px !important;
}
.insationai-mcp-skin .button-primary:hover { background: var(--ia-accent-hover) !important; border-color: var(--ia-accent-hover) !important; }

/* Inputs */
.insationai-mcp-skin input[type="text"],
.insationai-mcp-skin input[type="email"],
.insationai-mcp-skin input[type="password"],
.insationai-mcp-skin input[type="url"],
.insationai-mcp-skin input[type="search"],
.insationai-mcp-skin input[type="number"],
.insationai-mcp-skin textarea,
.insationai-mcp-skin select {
    background: #FFFFFF !important;
    color: var(--ia-ink) !important;
    border: 1px solid var(--ia-border-strong) !important;
    border-radius: var(--ia-radius-sm) !important;
}
.insationai-mcp-skin input::placeholder,
.insationai-mcp-skin textarea::placeholder { color: #94A3B8 !important; }
.insationai-mcp-skin input:focus,
.insationai-mcp-skin textarea:focus,
.insationai-mcp-skin select:focus {
    border-color: var(--ia-accent) !important;
    outline: none !important;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.15) !important;
}

/* Tables */
.insationai-mcp-skin table.widefat,
.insationai-mcp-skin .form-table,
.insationai-mcp-skin table.shop_table {
    background: #FFFFFF !important;
    color: var(--ia-text) !important;
    border: 1px solid var(--ia-border) !important;
    border-radius: var(--ia-radius) !important;
    overflow: hidden;
}
.insationai-mcp-skin table.widefat th,
.insationai-mcp-skin .form-table th,
.insationai-mcp-skin table.widefat thead td {
    background: #F8FAFC !important;
    color: var(--ia-ink) !important;
}
.insationai-mcp-skin table.widefat td,
.insationai-mcp-skin .form-table td {
    border-top: 1px solid var(--ia-border) !important;
    color: var(--ia-text) !important;
}
.insationai-mcp-skin table.widefat tr:hover td { background: #F8FAFC !important; }
.insationai-mcp-skin hr { border-color: var(--ia-border) !important; }

</style>
