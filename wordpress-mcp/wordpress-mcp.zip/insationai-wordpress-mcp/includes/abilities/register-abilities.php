<?php
/**
 * WordPress Abilities API registration.
 *
 * Dual-registers every WordpressMCP tool as a WordPress Ability via wp_register_ability()
 * (introduced in WP 6.9). The tools also continue to be served via the custom
 * /insationai-wordpress-mcp HTTP endpoint — this file does not replace that endpoint, it
 * mirrors the same tools onto the WP-native Abilities API so that:
 *
 *   - Other WP plugins / first-party WP MCP clients that consume the Abilities
 *     API see WordpressMCP's tools without needing the custom endpoint.
 *   - Sites can keep the WordpressMCP HTTP endpoint disabled (custom-slug or
 *     firewalled) and still expose tools through the official WP MCP Adapter.
 *
 * The WP HTTP endpoint at /insationai-wordpress-mcp remains the canonical transport for
 * cloud-hosted clients (Claude Desktop, Cursor, etc.) using the bearer-token
 * flow this plugin provisions.
 *
 * @package WordpressMCP
 * @since 1.1.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

use InsationAI\WordpressMCP\Services\ContentPatchingService;
use InsationAI\WordpressMCP\Services\ValidationService;
use InsationAI\WordpressMCP\Services\WordPressService;
use InsationAI\WordpressMCP\Logger\WordPressLogger;
use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Tools\Code\ExecutePhp;
use InsationAI\WordpressMCP\Tools\Content\CreateContent;
use InsationAI\WordpressMCP\Tools\Content\DeleteContent;
use InsationAI\WordpressMCP\Tools\Content\DiscoverContentTypes;
use InsationAI\WordpressMCP\Tools\Content\FindContentByUrl;
use InsationAI\WordpressMCP\Tools\Content\GetContent;
use InsationAI\WordpressMCP\Tools\Content\GetContentBySlug;
use InsationAI\WordpressMCP\Tools\Content\ListContent;
use InsationAI\WordpressMCP\Tools\Content\PatchContent;
use InsationAI\WordpressMCP\Tools\Content\UpdateContent;
use InsationAI\WordpressMCP\Tools\Media\MediaAttach;
use InsationAI\WordpressMCP\Tools\Media\MediaMetadata;
use InsationAI\WordpressMCP\Tools\Media\MediaUpload;
use InsationAI\WordpressMCP\Tools\Plugin\PluginFiles;
use InsationAI\WordpressMCP\Tools\Plugin\PluginInfo;
use InsationAI\WordpressMCP\Tools\Plugin\PluginOperations;
use InsationAI\WordpressMCP\Tools\Taxonomy\AssignTermsToContent;
use InsationAI\WordpressMCP\Tools\Taxonomy\CreateTerm;
use InsationAI\WordpressMCP\Tools\Taxonomy\DeleteTerm;
use InsationAI\WordpressMCP\Tools\Taxonomy\DiscoverTaxonomies;
use InsationAI\WordpressMCP\Tools\Taxonomy\GetContentTerms;
use InsationAI\WordpressMCP\Tools\Taxonomy\GetTaxonomy;
use InsationAI\WordpressMCP\Tools\Taxonomy\GetTerm;
use InsationAI\WordpressMCP\Tools\Taxonomy\ListTerms;
use InsationAI\WordpressMCP\Tools\Taxonomy\UpdateTerm;
use InsationAI\WordpressMCP\Tools\Theme\ThemeFiles;
use InsationAI\WordpressMCP\Tools\Theme\ThemeInfo;
use InsationAI\WordpressMCP\Tools\Theme\ThemeOperations;
use InsationAI\WordpressMCP\Tools\User\ListUsers;
use InsationAI\WordpressMCP\Tools\User\GetUser;
use InsationAI\WordpressMCP\Tools\User\CreateUser;
use InsationAI\WordpressMCP\Tools\User\UpdateUser;
use InsationAI\WordpressMCP\Tools\User\DeleteUser;
use InsationAI\WordpressMCP\Tools\User\ListRoles;
use InsationAI\WordpressMCP\Tools\User\ManageUserRoles;
use InsationAI\WordpressMCP\Tools\User\ManageCapabilities;
use InsationAI\WordpressMCP\Tools\Comment\ListComments;
use InsationAI\WordpressMCP\Tools\Comment\GetComment;
use InsationAI\WordpressMCP\Tools\Comment\CreateComment;
use InsationAI\WordpressMCP\Tools\Comment\UpdateComment;
use InsationAI\WordpressMCP\Tools\Comment\DeleteComment;
use InsationAI\WordpressMCP\Tools\Comment\ModerateComment;
use InsationAI\WordpressMCP\Tools\Option\GetOption;
use InsationAI\WordpressMCP\Tools\Option\UpdateOption;
use InsationAI\WordpressMCP\Tools\Option\DeleteOption;
use InsationAI\WordpressMCP\Tools\Option\ListOptions;
use InsationAI\WordpressMCP\Tools\Option\GetTransient;
use InsationAI\WordpressMCP\Tools\Option\SetTransient;
use InsationAI\WordpressMCP\Tools\Option\DeleteTransient;
use InsationAI\WordpressMCP\Tools\Option\ManageThemeMods;
use InsationAI\WordpressMCP\Tools\Menu\ListMenus;
use InsationAI\WordpressMCP\Tools\Menu\GetMenu;
use InsationAI\WordpressMCP\Tools\Menu\ManageMenu;
use InsationAI\WordpressMCP\Tools\Menu\ManageMenuItems;
use InsationAI\WordpressMCP\Tools\Menu\AssignMenuLocation;
use InsationAI\WordpressMCP\Tools\Widget\ListSidebars;
use InsationAI\WordpressMCP\Tools\Widget\ListWidgets;
use InsationAI\WordpressMCP\Tools\Widget\ManageWidget;
use InsationAI\WordpressMCP\Tools\Widget\ManageBlockWidgets;
use InsationAI\WordpressMCP\Tools\Pattern\ListPatterns;
use InsationAI\WordpressMCP\Tools\Pattern\ManagePattern;
use InsationAI\WordpressMCP\Tools\Pattern\ListReusableBlocks;
use InsationAI\WordpressMCP\Tools\Customizer\GetCustomizerSettings;
use InsationAI\WordpressMCP\Tools\Customizer\UpdateCustomizerSetting;
use InsationAI\WordpressMCP\Tools\Customizer\ExportCustomizer;
use InsationAI\WordpressMCP\Tools\Cron\ListScheduledEvents;
use InsationAI\WordpressMCP\Tools\Cron\ScheduleEvent;
use InsationAI\WordpressMCP\Tools\Cron\UnscheduleEvent;
use InsationAI\WordpressMCP\Tools\Cron\RunEventNow;
use InsationAI\WordpressMCP\Tools\Rewrite\ListRewriteRules;
use InsationAI\WordpressMCP\Tools\Rewrite\FlushRewriteRules;
use InsationAI\WordpressMCP\Tools\Rewrite\AddRewriteRule;
use InsationAI\WordpressMCP\Tools\Database\DbQuery;
use InsationAI\WordpressMCP\Tools\Database\DbTableInfo;
use InsationAI\WordpressMCP\Tools\Database\OptimizeTables;
use InsationAI\WordpressMCP\Tools\Database\RepairTables;
use InsationAI\WordpressMCP\Tools\Database\CleanupRevisions;
use InsationAI\WordpressMCP\Tools\Database\CleanupSpamComments;
use InsationAI\WordpressMCP\Tools\Database\CleanupTransients;
use InsationAI\WordpressMCP\Tools\Database\SearchReplace;
use InsationAI\WordpressMCP\Tools\Diagnostics\SystemInfo;
use InsationAI\WordpressMCP\Tools\Diagnostics\SiteHealthCheck;
use InsationAI\WordpressMCP\Tools\Diagnostics\DebugLogRead;
use InsationAI\WordpressMCP\Tools\Diagnostics\DebugLogClear;
use InsationAI\WordpressMCP\Tools\Diagnostics\ListHooksOnAction;
use InsationAI\WordpressMCP\Tools\Multisite\ListSites;
use InsationAI\WordpressMCP\Tools\Multisite\GetSite;
use InsationAI\WordpressMCP\Tools\Multisite\ManageSite;
use InsationAI\WordpressMCP\Tools\Multisite\ManageNetworkUsers;
use InsationAI\WordpressMCP\Tools\Multisite\NetworkActivatePlugin;

/**
 * Map of OAuth scope → minimum WordPress capability used by the Abilities
 * permission_callback. Mirrors what the OAuth scope check enforces inside
 * AbstractTool::checkScopeAuthorization().
 */
const INSATIONAI_WPMCP_SCOPE_CAPABILITY_MAP = [
    'mcp:read'   => 'read',
    'mcp:write'  => 'edit_posts',
    'mcp:delete' => 'delete_posts',
    'mcp:admin'  => 'manage_options',
];

/**
 * Tool category for the Abilities API — used for grouping in admin UIs that
 * surface registered abilities.
 */
function insationai_wpmcp_ability_category_for(string $toolName): string
{
    if (str_starts_with($toolName, 'plugin_')) {
        return 'wordpress-plugins';
    }
    if (str_starts_with($toolName, 'theme_')) {
        return 'wordpress-themes';
    }
    if (str_starts_with($toolName, 'media_')) {
        return 'wordpress-media';
    }
    if (str_starts_with($toolName, 'execute_')) {
        return 'code-execution';
    }
    if (
        str_starts_with($toolName, 'list_users') ||
        str_starts_with($toolName, 'get_user') ||
        str_starts_with($toolName, 'create_user') ||
        str_starts_with($toolName, 'update_user') ||
        str_starts_with($toolName, 'delete_user') ||
        str_starts_with($toolName, 'list_roles') ||
        str_starts_with($toolName, 'manage_user_roles') ||
        str_starts_with($toolName, 'manage_capabilities')
    ) {
        return 'wordpress-users';
    }
    if (
        $toolName === 'list_comments' ||
        $toolName === 'get_comment' ||
        $toolName === 'create_comment' ||
        $toolName === 'update_comment' ||
        $toolName === 'delete_comment' ||
        $toolName === 'moderate_comment'
    ) {
        return 'wordpress-comments';
    }
    if (
        str_ends_with($toolName, '_option') ||
        $toolName === 'list_options' ||
        str_ends_with($toolName, '_transient') ||
        $toolName === 'manage_theme_mods'
    ) {
        return 'wordpress-options';
    }
    if (
        $toolName === 'list_menus' ||
        $toolName === 'get_menu' ||
        $toolName === 'manage_menu' ||
        $toolName === 'manage_menu_items' ||
        $toolName === 'assign_menu_location'
    ) {
        return 'wordpress-menus';
    }
    if (
        $toolName === 'list_sidebars' ||
        $toolName === 'list_widgets' ||
        $toolName === 'manage_widget' ||
        $toolName === 'manage_block_widgets'
    ) {
        return 'wordpress-widgets';
    }
    if (
        $toolName === 'list_patterns' ||
        $toolName === 'manage_pattern' ||
        $toolName === 'list_reusable_blocks'
    ) {
        return 'wordpress-patterns';
    }
    if (
        $toolName === 'get_customizer_settings' ||
        $toolName === 'update_customizer_setting' ||
        $toolName === 'export_customizer'
    ) {
        return 'wordpress-customizer';
    }
    if (
        $toolName === 'list_scheduled_events' ||
        $toolName === 'schedule_event' ||
        $toolName === 'unschedule_event' ||
        $toolName === 'run_event_now'
    ) {
        return 'wordpress-cron';
    }
    if (
        $toolName === 'list_rewrite_rules' ||
        $toolName === 'flush_rewrite_rules' ||
        $toolName === 'add_rewrite_rule'
    ) {
        return 'wordpress-rewrites';
    }
    if (
        $toolName === 'db_query' ||
        $toolName === 'db_table_info' ||
        $toolName === 'optimize_tables' ||
        $toolName === 'repair_tables' ||
        str_starts_with($toolName, 'cleanup_') ||
        $toolName === 'search_replace'
    ) {
        return 'wordpress-database';
    }
    if (
        $toolName === 'system_info' ||
        $toolName === 'site_health_check' ||
        str_starts_with($toolName, 'debug_log_') ||
        $toolName === 'list_hooks_on_action'
    ) {
        return 'wordpress-diagnostics';
    }
    if (
        $toolName === 'list_sites' ||
        $toolName === 'get_site' ||
        $toolName === 'manage_site' ||
        $toolName === 'manage_network_users' ||
        $toolName === 'network_activate_plugin'
    ) {
        return 'wordpress-multisite';
    }
    if (
        str_contains($toolName, 'term') ||
        str_contains($toolName, 'tax') ||
        str_starts_with($toolName, 'discover_taxonomies')
    ) {
        return 'wordpress-taxonomy';
    }
    return 'wordpress-content';
}

/**
 * Register all WordpressMCP tools as WordPress Abilities (WP 6.9+).
 *
 * No-op on WP < 6.9 (when wp_register_ability is undefined). The /insationai-wordpress-mcp
 * HTTP endpoint continues to work in either case.
 */
function insationai_wpmcp_register_abilities(): void
{
    if (!function_exists('wp_register_ability')) {
        return;
    }

    // Sanity: don't register on a site that hasn't authorized WordpressMCP yet.
    if (class_exists('\InsationAI\WordpressMCP\Validator') && !\InsationAI\WordpressMCP\Validator::isAuthorized()) {
        return;
    }

    $wpService = new WordPressService();
    $validationService = new ValidationService();
    $logger = new WordPressLogger();
    $patchingService = new ContentPatchingService($wpService, $logger);

    $tools = \InsationAI\WordpressMCP\ToolRegistry::buildEnabledTools(
        $wpService,
        $validationService,
        $logger,
        $patchingService
    );


    foreach ($tools as $tool) {
        insationai_wpmcp_register_one_ability($tool);
    }
}

function insationai_wpmcp_register_one_ability(AbstractTool $tool): void
{
    $name = $tool->getName();
    $scope = $tool->getRequiredScope();
    $capability = INSATIONAI_WPMCP_SCOPE_CAPABILITY_MAP[$scope] ?? 'manage_options';
    $isDestructive = in_array($scope, ['mcp:write', 'mcp:delete', 'mcp:admin'], true);
    $isReadonly = $scope === 'mcp:read';

    wp_register_ability("insationai-wpmcp/{$name}", [
        'label'              => $name,
        'description'        => $tool->getDescription(),
        'category'           => insationai_wpmcp_ability_category_for($name),
        'input_schema'       => $tool->getInputSchema(),
        'output_schema'      => [
            'type' => 'object',
            'description' => 'Tool execution result. Shape varies per tool — see description.',
            'additionalProperties' => true,
        ],
        'execute_callback'   => static function ($input) use ($tool) {
            // The Abilities API runs in standard WP request context. The user
            // is whoever WP says — wp_get_current_user(). Build a minimal user
            // context so AbstractTool's scope check has something to look at.
            $current = wp_get_current_user();
            if ($current && $current->ID) {
                $tool->setUserContext([
                    'id' => (int) $current->ID,
                    'login' => (string) $current->user_login,
                    'username' => (string) $current->user_login,
                    'roles' => (array) $current->roles,
                    // Map: an authenticated WP user gets all scopes their
                    // capabilities cover. The capability check inside
                    // permission_callback already gated the call.
                    'scopes' => insationai_wpmcp_scopes_for_user($current),
                ]);
            }

            try {
                return $tool->execute(is_array($input) ? $input : []);
            } catch (\Throwable $e) {
                return new \WP_Error(
                    'insationai_wpmcp_tool_error',
                    $e->getMessage(),
                    ['status' => 400]
                );
            }
        },
        'permission_callback' => static function () use ($capability) {
            return current_user_can($capability);
        },
        'meta' => [
            'show_in_rest' => true,
            'mcp' => ['public' => true],
            'annotations' => [
                'readonly'    => $isReadonly,
                'destructive' => $isDestructive,
                'idempotent'  => false,
                'instructions' => 'Tool source: WordpressMCP. See ' . home_url('/wp-admin/admin.php?page=insationai-tools') . ' for token management.',
            ],
        ],
    ]);
}

function insationai_wpmcp_scopes_for_user(\WP_User $user): array
{
    $scopes = [];
    if (user_can($user, 'read')) {
        $scopes[] = 'mcp:read';
    }
    if (user_can($user, 'edit_posts')) {
        $scopes[] = 'mcp:write';
    }
    if (user_can($user, 'delete_posts')) {
        $scopes[] = 'mcp:delete';
    }
    if (user_can($user, 'manage_options')) {
        $scopes[] = 'mcp:admin';
    }
    return $scopes;
}

// WP 6.9+ requires abilities to be registered on the `wp_abilities_api_init`
// hook — registering earlier (e.g. on `init`) is rejected by core with a
// _doing_it_wrong() notice and the ability is NOT registered. We hook there
// when the Abilities API exists, and fall back to `init` priority 20 on older
// WordPress that predates it (where the function_exists('wp_register_ability')
// guard inside the function makes it a harmless no-op anyway). did_action()
// guards the rare case where this file loads after the hook already fired.
if (function_exists('wp_register_ability')) {
    if (did_action('wp_abilities_api_init')) {
        insationai_wpmcp_register_abilities();
    } else {
        add_action('wp_abilities_api_init', 'insationai_wpmcp_register_abilities', 20);
    }
} else {
    add_action('init', 'insationai_wpmcp_register_abilities', 20);
}
