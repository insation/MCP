<?php
/**
 * Tool Registry
 *
 * Central source of truth for tool metadata. Both the runtime registrars
 * (mcp-http.php, register-abilities.php) and the admin Tools toggle UI
 * consume this so they stay in lockstep — there is no place to add a tool
 * to one side without the other.
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP;

use InsationAI\WordpressMCP\Services\ValidationService;
use InsationAI\WordpressMCP\Services\WordPressService;
use InsationAI\WordpressMCP\Services\ContentPatchingService;
use InsationAI\WordpressMCP\Logger\WordPressLogger;
use InsationAI\WordpressMCP\Tools\AbstractTool;

class ToolRegistry
{
    public const DISABLED_OPTION = 'insationai_wpmcp_disabled_tools';

    /**
     * Build every tool instance. The optional patching service is required
     * by PatchContent and instantiated only when not supplied (e.g. from
     * Abilities API context that doesn't already have one constructed).
     *
     * @return AbstractTool[]
     */
    public static function buildAllTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        if ($patching === null) {
            $patching = new ContentPatchingService($wp, $logger);
        }

        $tools = [
            // Content
            new Tools\Content\ListContent($wp, $validator, $logger),
            new Tools\Content\GetContent($wp, $validator, $logger),
            new Tools\Content\CreateContent($wp, $validator, $logger),
            new Tools\Content\UpdateContent($wp, $validator, $logger),
            new Tools\Content\PatchContent($wp, $validator, $patching, $logger),
            new Tools\Content\DeleteContent($wp, $validator, $logger),
            new Tools\Content\DiscoverContentTypes($wp, $validator, $logger),
            new Tools\Content\GetContentBySlug($wp, $validator, $logger),
            new Tools\Content\FindContentByUrl($wp, $validator, $logger),

            // Taxonomy
            new Tools\Taxonomy\DiscoverTaxonomies($wp, $validator, $logger),
            new Tools\Taxonomy\GetTaxonomy($wp, $validator, $logger),
            new Tools\Taxonomy\ListTerms($wp, $validator, $logger),
            new Tools\Taxonomy\GetTerm($wp, $validator, $logger),
            new Tools\Taxonomy\CreateTerm($wp, $validator, $logger),
            new Tools\Taxonomy\UpdateTerm($wp, $validator, $logger),
            new Tools\Taxonomy\DeleteTerm($wp, $validator, $logger),
            new Tools\Taxonomy\AssignTermsToContent($wp, $validator, $logger),
            new Tools\Taxonomy\GetContentTerms($wp, $validator, $logger),

            // Plugin
            new Tools\Plugin\PluginInfo($wp, $validator, $logger),
            new Tools\Plugin\PluginOperations($wp, $validator, $logger),
            new Tools\Plugin\PluginFiles($wp, $validator, $logger),

            // Theme
            new Tools\Theme\ThemeInfo($wp, $validator, $logger),
            new Tools\Theme\ThemeOperations($wp, $validator, $logger),
            new Tools\Theme\ThemeFiles($wp, $validator, $logger),

            // Media
            new Tools\Media\MediaUpload($wp, $validator, $logger),
            new Tools\Media\MediaAttach($wp, $validator, $logger),
            new Tools\Media\MediaMetadata($wp, $validator, $logger),

            // User
            new Tools\User\ListUsers($wp, $validator, $logger),
            new Tools\User\GetUser($wp, $validator, $logger),
            new Tools\User\CreateUser($wp, $validator, $logger),
            new Tools\User\UpdateUser($wp, $validator, $logger),
            new Tools\User\DeleteUser($wp, $validator, $logger),
            new Tools\User\ListRoles($wp, $validator, $logger),
            new Tools\User\ManageUserRoles($wp, $validator, $logger),
            new Tools\User\ManageCapabilities($wp, $validator, $logger),

            // Comment
            new Tools\Comment\ListComments($wp, $validator, $logger),
            new Tools\Comment\GetComment($wp, $validator, $logger),
            new Tools\Comment\CreateComment($wp, $validator, $logger),
            new Tools\Comment\UpdateComment($wp, $validator, $logger),
            new Tools\Comment\DeleteComment($wp, $validator, $logger),
            new Tools\Comment\ModerateComment($wp, $validator, $logger),

            // Option / settings
            new Tools\Option\GetOption($wp, $validator, $logger),
            new Tools\Option\UpdateOption($wp, $validator, $logger),
            new Tools\Option\DeleteOption($wp, $validator, $logger),
            new Tools\Option\ListOptions($wp, $validator, $logger),
            new Tools\Option\GetTransient($wp, $validator, $logger),
            new Tools\Option\SetTransient($wp, $validator, $logger),
            new Tools\Option\DeleteTransient($wp, $validator, $logger),
            new Tools\Option\ManageThemeMods($wp, $validator, $logger),

            // Menu
            new Tools\Menu\ListMenus($wp, $validator, $logger),
            new Tools\Menu\GetMenu($wp, $validator, $logger),
            new Tools\Menu\ManageMenu($wp, $validator, $logger),
            new Tools\Menu\ManageMenuItems($wp, $validator, $logger),
            new Tools\Menu\AssignMenuLocation($wp, $validator, $logger),

            // Widget
            new Tools\Widget\ListSidebars($wp, $validator, $logger),
            new Tools\Widget\ListWidgets($wp, $validator, $logger),
            new Tools\Widget\ManageWidget($wp, $validator, $logger),
            new Tools\Widget\ManageBlockWidgets($wp, $validator, $logger),

            // Pattern
            new Tools\Pattern\ListPatterns($wp, $validator, $logger),
            new Tools\Pattern\ManagePattern($wp, $validator, $logger),
            new Tools\Pattern\ListReusableBlocks($wp, $validator, $logger),

            // Customizer
            new Tools\Customizer\GetCustomizerSettings($wp, $validator, $logger),
            new Tools\Customizer\UpdateCustomizerSetting($wp, $validator, $logger),
            new Tools\Customizer\ExportCustomizer($wp, $validator, $logger),

            // Cron
            new Tools\Cron\ListScheduledEvents($wp, $validator, $logger),
            new Tools\Cron\ScheduleEvent($wp, $validator, $logger),
            new Tools\Cron\UnscheduleEvent($wp, $validator, $logger),
            new Tools\Cron\RunEventNow($wp, $validator, $logger),

            // Rewrite
            new Tools\Rewrite\ListRewriteRules($wp, $validator, $logger),
            new Tools\Rewrite\FlushRewriteRules($wp, $validator, $logger),
            new Tools\Rewrite\AddRewriteRule($wp, $validator, $logger),

            // Database
            new Tools\Database\DbQuery($wp, $validator, $logger),
            new Tools\Database\DbTableInfo($wp, $validator, $logger),
            new Tools\Database\OptimizeTables($wp, $validator, $logger),
            new Tools\Database\RepairTables($wp, $validator, $logger),
            new Tools\Database\CleanupRevisions($wp, $validator, $logger),
            new Tools\Database\CleanupSpamComments($wp, $validator, $logger),
            new Tools\Database\CleanupTransients($wp, $validator, $logger),
            new Tools\Database\SearchReplace($wp, $validator, $logger),

            // Diagnostics
            new Tools\Diagnostics\SystemInfo($wp, $validator, $logger),
            new Tools\Diagnostics\SiteHealthCheck($wp, $validator, $logger),
            new Tools\Diagnostics\DebugLogRead($wp, $validator, $logger),
            new Tools\Diagnostics\DebugLogClear($wp, $validator, $logger),
            new Tools\Diagnostics\ListHooksOnAction($wp, $validator, $logger),

            // SEO & Redirects (1.0.4)
            new Tools\Seo\ManageRobotsTxt($wp, $validator, $logger),
            new Tools\Seo\ManageSitemap($wp, $validator, $logger),
            new Tools\Seo\ManageRedirects($wp, $validator, $logger),

            // Export / Import (1.0.4)
            new Tools\ExportImport\ExportContent($wp, $validator, $logger),
            new Tools\ExportImport\ImportContent($wp, $validator, $logger),
            new Tools\ExportImport\BackupDatabase($wp, $validator, $logger),

            // Audit log (1.0.7)
            new Tools\Audit\ListRecentToolCalls($wp, $validator, $logger),
            new Tools\Audit\ClearAuditLog($wp, $validator, $logger),
        ];

        // Multisite tools — only when on a multisite network
        if (is_multisite()) {
            $tools[] = new Tools\Multisite\ListSites($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\GetSite($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\ManageSite($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\ManageNetworkUsers($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\NetworkActivatePlugin($wp, $validator, $logger);
        }

        // Opt-in tool gated by its own constant
        if (Tools\Code\ExecutePhp::isEnabled()) {
            $tools[] = new Tools\Code\ExecutePhp($wp, $validator, $logger);
        }

        return $tools;
    }

    /**
     * Build the list of tools, with disabled ones filtered out.
     *
     * @return AbstractTool[]
     */
    public static function buildEnabledTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $all = self::buildAllTools($wp, $validator, $logger, $patching);
        $disabled = self::getDisabledToolNames();
        if (empty($disabled)) {
            return $all;
        }
        return array_values(array_filter(
            $all,
            static fn(AbstractTool $t) => !in_array($t->getName(), $disabled, true)
        ));
    }

    /**
     * Read the option that stores disabled tool names.
     *
     * @return string[]
     */
    public static function getDisabledToolNames(): array
    {
        $stored = get_option(self::DISABLED_OPTION, []);
        return is_array($stored) ? array_values(array_filter(array_map('strval', $stored))) : [];
    }

    /**
     * Persist the disabled tool names array.
     *
     * @param string[] $names
     */
    public static function setDisabledToolNames(array $names): void
    {
        $clean = array_values(array_unique(array_filter(array_map('sanitize_text_field', $names))));
        update_option(self::DISABLED_OPTION, $clean);
    }

    /**
     * Stable category slug for a tool name. Mirrors the category logic in
     * register-abilities.php so the admin UI and the abilities API agree.
     */
    public static function categoryFor(string $toolName): string
    {
        if (str_starts_with($toolName, 'plugin_')) {
            return 'plugins';
        }
        if (str_starts_with($toolName, 'theme_')) {
            return 'themes';
        }
        if (str_starts_with($toolName, 'media_')) {
            return 'media';
        }
        if (str_starts_with($toolName, 'execute_')) {
            return 'code';
        }
        if (
            $toolName === 'list_users' || $toolName === 'get_user' ||
            $toolName === 'create_user' || $toolName === 'update_user' ||
            $toolName === 'delete_user' || $toolName === 'list_roles' ||
            $toolName === 'manage_user_roles' || $toolName === 'manage_capabilities'
        ) {
            return 'users';
        }
        if (
            $toolName === 'list_comments' || $toolName === 'get_comment' ||
            $toolName === 'create_comment' || $toolName === 'update_comment' ||
            $toolName === 'delete_comment' || $toolName === 'moderate_comment'
        ) {
            return 'comments';
        }
        if (
            str_ends_with($toolName, '_option') || $toolName === 'list_options' ||
            str_ends_with($toolName, '_transient') || $toolName === 'manage_theme_mods'
        ) {
            return 'options';
        }
        if (
            $toolName === 'list_menus' || $toolName === 'get_menu' ||
            $toolName === 'manage_menu' || $toolName === 'manage_menu_items' ||
            $toolName === 'assign_menu_location'
        ) {
            return 'menus';
        }
        if (
            $toolName === 'list_sidebars' || $toolName === 'list_widgets' ||
            $toolName === 'manage_widget' || $toolName === 'manage_block_widgets'
        ) {
            return 'widgets';
        }
        if (
            $toolName === 'list_patterns' || $toolName === 'manage_pattern' ||
            $toolName === 'list_reusable_blocks'
        ) {
            return 'patterns';
        }
        if (
            $toolName === 'get_customizer_settings' ||
            $toolName === 'update_customizer_setting' ||
            $toolName === 'export_customizer'
        ) {
            return 'customizer';
        }
        if (
            $toolName === 'list_scheduled_events' || $toolName === 'schedule_event' ||
            $toolName === 'unschedule_event' || $toolName === 'run_event_now'
        ) {
            return 'cron';
        }
        if (
            $toolName === 'list_rewrite_rules' || $toolName === 'flush_rewrite_rules' ||
            $toolName === 'add_rewrite_rule'
        ) {
            return 'rewrites';
        }
        if (
            $toolName === 'db_query' || $toolName === 'db_table_info' ||
            $toolName === 'optimize_tables' || $toolName === 'repair_tables' ||
            str_starts_with($toolName, 'cleanup_') || $toolName === 'search_replace'
        ) {
            return 'database';
        }
        if (
            $toolName === 'system_info' || $toolName === 'site_health_check' ||
            str_starts_with($toolName, 'debug_log_') || $toolName === 'list_hooks_on_action'
        ) {
            return 'diagnostics';
        }
        if (
            $toolName === 'list_sites' || $toolName === 'get_site' ||
            $toolName === 'manage_site' || $toolName === 'manage_network_users' ||
            $toolName === 'network_activate_plugin'
        ) {
            return 'multisite';
        }
        if (
            $toolName === 'manage_robots_txt' || $toolName === 'manage_sitemap' ||
            $toolName === 'manage_redirects'
        ) {
            return 'seo';
        }
        if (
            $toolName === 'export_content' || $toolName === 'import_content' ||
            $toolName === 'backup_database'
        ) {
            return 'export-import';
        }
        if (
            $toolName === 'list_recent_tool_calls' || $toolName === 'clear_audit_log'
        ) {
            return 'audit';
        }
        if (
            str_contains($toolName, 'term') || str_contains($toolName, 'tax') ||
            str_starts_with($toolName, 'discover_taxonomies')
        ) {
            return 'taxonomy';
        }
        return 'content';
    }

    /**
     * Human-readable label for a category slug.
     */
    public static function categoryLabel(string $slug): string
    {
        $labels = [
            'content'       => __('Content', 'insationai-wordpress-mcp'),
            'taxonomy'      => __('Taxonomy', 'insationai-wordpress-mcp'),
            'media'         => __('Media', 'insationai-wordpress-mcp'),
            'plugins'       => __('Plugins', 'insationai-wordpress-mcp'),
            'themes'        => __('Themes', 'insationai-wordpress-mcp'),
            'code'          => __('Code Execution', 'insationai-wordpress-mcp'),
            'users'         => __('Users & Roles', 'insationai-wordpress-mcp'),
            'comments'      => __('Comments', 'insationai-wordpress-mcp'),
            'options'       => __('Options & Settings', 'insationai-wordpress-mcp'),
            'menus'         => __('Menus', 'insationai-wordpress-mcp'),
            'widgets'       => __('Widgets', 'insationai-wordpress-mcp'),
            'patterns'      => __('Block Patterns', 'insationai-wordpress-mcp'),
            'customizer'    => __('Customizer', 'insationai-wordpress-mcp'),
            'cron'          => __('Cron', 'insationai-wordpress-mcp'),
            'rewrites'      => __('Rewrites', 'insationai-wordpress-mcp'),
            'database'      => __('Database', 'insationai-wordpress-mcp'),
            'diagnostics'   => __('Diagnostics', 'insationai-wordpress-mcp'),
            'multisite'     => __('Multisite', 'insationai-wordpress-mcp'),
            'seo'           => __('SEO & Redirects', 'insationai-wordpress-mcp'),
            'export-import' => __('Export & Import', 'insationai-wordpress-mcp'),
            'audit'         => __('Audit Log', 'insationai-wordpress-mcp'),
        ];
        return $labels[$slug] ?? ucfirst(str_replace('-', ' ', $slug));
    }
}
