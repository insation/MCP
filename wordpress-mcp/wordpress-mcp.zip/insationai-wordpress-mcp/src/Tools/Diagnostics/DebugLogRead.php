<?php
/**
 * Debug Log Read Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Diagnostics;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class DebugLogRead extends AbstractTool
{
    public function getName(): string
    {
        return 'debug_log_read';
    }

    public function getDescription(): string
    {
        return 'Read the tail of wp-content/debug.log (or a custom WP_DEBUG_LOG path). Returns the last N kilobytes to avoid pulling massive logs. If WP_DEBUG_LOG is not enabled, this tool reports that and returns no content.';
    }

    public function getSchema(): array
    {
        return [
            'max_kb' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 1024],
                'description' => 'How many KB of trailing log to return. Default 64. Max 1024.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $path = $this->resolveLogPath();
        if (!$path) {
            return $this->success([
                'available' => false,
                'reason'    => 'WP_DEBUG_LOG is disabled or the log path cannot be determined.',
            ]);
        }
        if (!file_exists($path)) {
            return $this->success([
                'available' => false,
                'path'      => $path,
                'reason'    => 'Log file does not exist yet (nothing has been logged).',
            ]);
        }
        if (!is_readable($path)) {
            throw ToolException::wordpressError("Debug log exists but is not readable: {$path}");
        }

        $maxBytes = ((int) ($parameters['max_kb'] ?? 64)) * 1024;
        $size     = filesize($path);
        $offset   = max(0, $size - $maxBytes);

        $fh = fopen($path, 'rb');
        if (!$fh) {
            throw ToolException::wordpressError("Failed to open debug log: {$path}");
        }
        fseek($fh, $offset);
        $content = fread($fh, $maxBytes) ?: '';
        fclose($fh);

        // If we trimmed mid-line, drop the partial first line
        if ($offset > 0) {
            $nl = strpos($content, "\n");
            if ($nl !== false) {
                $content = substr($content, $nl + 1);
            }
        }

        return $this->success([
            'available'   => true,
            'path'        => $path,
            'size_bytes'  => $size,
            'returned_bytes' => strlen($content),
            'truncated'   => $offset > 0,
            'content'     => $content,
        ]);
    }

    private function resolveLogPath(): ?string
    {
        if (!defined('WP_DEBUG_LOG') || WP_DEBUG_LOG === false) {
            return null;
        }
        if (is_string(WP_DEBUG_LOG) && WP_DEBUG_LOG !== '') {
            return WP_DEBUG_LOG;
        }
        // Default: wp-content/debug.log
        return WP_CONTENT_DIR . '/debug.log';
    }
}
