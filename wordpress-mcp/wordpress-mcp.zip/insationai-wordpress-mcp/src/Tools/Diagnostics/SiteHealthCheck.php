<?php
/**
 * Site Health Check Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Diagnostics;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class SiteHealthCheck extends AbstractTool
{
    public function getName(): string
    {
        return 'site_health_check';
    }

    public function getDescription(): string
    {
        return 'Run WordPress core Site Health checks and return results: WordPress version freshness, PHP version, HTTPS status, file permissions, scheduled events, debug mode, etc.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        if (!class_exists('WP_Site_Health')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-site-health.php';
        }
        if (!class_exists('WP_Site_Health')) {
            return $this->success(['available' => false], 'Site Health API not available on this WP version.');
        }

        $health = \WP_Site_Health::get_instance();

        $checks = [
            'php_version'        => $health->get_test_php_version(),
            'sql_server'         => $health->get_test_sql_server(),
            'utf8mb4_support'    => $health->get_test_utf8mb4_support(),
            'https_status'       => $health->get_test_https_status(),
            'ssl_support'        => $health->get_test_ssl_support(),
            'scheduled_events'   => $health->get_test_scheduled_events(),
            'background_updates' => $health->get_test_background_updates(),
            'plugin_version'     => $health->get_test_plugin_version(),
            'theme_version'      => $health->get_test_theme_version(),
            'wordpress_version'  => $health->get_test_wordpress_version(),
            'debug_enabled'      => $health->get_test_is_in_debug_mode(),
            'rest_availability'  => method_exists($health, 'get_test_rest_availability') ? $health->get_test_rest_availability() : null,
            'http_requests'      => method_exists($health, 'get_test_http_requests') ? $health->get_test_http_requests() : null,
        ];

        $counts = ['good' => 0, 'recommended' => 0, 'critical' => 0];
        foreach ($checks as $check) {
            if (is_array($check) && isset($check['status'])) {
                if (isset($counts[$check['status']])) {
                    $counts[$check['status']]++;
                }
            }
        }

        return $this->success([
            'counts' => $counts,
            'checks' => $checks,
        ]);
    }
}
