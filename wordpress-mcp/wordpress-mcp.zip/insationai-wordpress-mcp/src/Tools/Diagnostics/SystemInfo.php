<?php
/**
 * System Info Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Diagnostics;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class SystemInfo extends AbstractTool
{
    public function getName(): string
    {
        return 'system_info';
    }

    public function getDescription(): string
    {
        return 'Return a comprehensive system snapshot: WordPress version, PHP version and limits, server software, database server, active theme and plugins, multisite status, debug flags.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        global $wp_version, $wpdb;

        $active_plugins = (array) get_option('active_plugins', []);
        if (is_multisite()) {
            $network_active = array_keys((array) get_site_option('active_sitewide_plugins', []));
            $active_plugins = array_unique(array_merge($active_plugins, $network_active));
        }

        $theme = wp_get_theme();

        return $this->success([
            'wordpress' => [
                'version'         => $wp_version,
                'siteurl'         => get_option('siteurl'),
                'home'            => get_option('home'),
                'locale'          => get_locale(),
                'multisite'       => is_multisite(),
                'environment'     => function_exists('wp_get_environment_type') ? wp_get_environment_type() : null,
                'debug'           => defined('WP_DEBUG') && WP_DEBUG,
                'debug_log'       => defined('WP_DEBUG_LOG') && WP_DEBUG_LOG,
                'debug_display'   => defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY,
                'wp_cache'        => defined('WP_CACHE') && WP_CACHE,
                'permalinks'      => get_option('permalink_structure') ?: 'plain',
            ],
            'php' => [
                'version'             => PHP_VERSION,
                'sapi'                => PHP_SAPI,
                'memory_limit'        => ini_get('memory_limit'),
                'max_execution_time'  => ini_get('max_execution_time'),
                'upload_max_filesize' => ini_get('upload_max_filesize'),
                'post_max_size'       => ini_get('post_max_size'),
                'max_input_vars'      => ini_get('max_input_vars'),
                'extensions'          => array_values(array_filter(get_loaded_extensions(), static fn($e) => in_array($e, [
                    'curl', 'json', 'mbstring', 'mysqli', 'pdo_mysql', 'gd', 'imagick',
                    'openssl', 'sodium', 'xml', 'zip', 'intl', 'exif', 'bcmath', 'redis', 'memcached',
                ], true))),
            ],
            'server' => [
                'software' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
                'os'       => PHP_OS_FAMILY,
            ],
            'database' => [
                'server_version' => $wpdb->db_version(),
                'name'           => DB_NAME,
                'host'           => DB_HOST,
                'charset'        => $wpdb->charset,
                'collate'        => $wpdb->collate,
                'prefix'         => $wpdb->prefix,
            ],
            'theme' => [
                'name'        => $theme->get('Name'),
                'version'     => $theme->get('Version'),
                'stylesheet'  => get_stylesheet(),
                'template'    => get_template(),
                'is_child'    => is_child_theme(),
            ],
            'plugins' => [
                'active_count' => count($active_plugins),
                'active'       => array_values($active_plugins),
            ],
            'mcp' => [
                'plugin_version' => INSATIONAI_WPMCP_VERSION,
                'oauth_enabled'  => defined('INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED') && INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED,
            ],
        ]);
    }
}
