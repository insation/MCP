<?php
/**
 * Update Customizer Setting Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Customizer;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class UpdateCustomizerSetting extends AbstractTool
{
    /**
     * Allow-list of customizer settings this tool will write, mapped to how
     * they are stored. Custom-CSS is special-cased via wp_update_custom_css_post.
     */
    private const SUPPORTED = [
        'blogname'         => ['source' => 'option'],
        'blogdescription'  => ['source' => 'option'],
        'site_icon'        => ['source' => 'option'],
        'show_on_front'    => ['source' => 'option', 'in' => ['posts', 'page']],
        'page_on_front'    => ['source' => 'option'],
        'page_for_posts'   => ['source' => 'option'],
        'background_color' => ['source' => 'theme_mod'],
        'background_image' => ['source' => 'theme_mod'],
        'header_image'     => ['source' => 'theme_mod'],
        'header_textcolor' => ['source' => 'theme_mod'],
        'custom_logo'      => ['source' => 'theme_mod'],
        'custom_css'       => ['source' => 'custom_css'],
    ];

    public function getName(): string
    {
        return 'update_customizer_setting';
    }

    public function getDescription(): string
    {
        return 'Update a Customizer setting on the active theme. Supports core settings (blogname, blogdescription, site_icon, show_on_front, page_on_front, page_for_posts, background_color, background_image, header_image, header_textcolor, custom_logo, custom_css).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'name' => [
                'required',
                'string',
                ['in' => [
                    'blogname', 'blogdescription', 'site_icon',
                    'show_on_front', 'page_on_front', 'page_for_posts',
                    'background_color', 'background_image', 'header_image',
                    'header_textcolor', 'custom_logo', 'custom_css',
                ]],
            ],
            'value' => [
                'optional',
                'string',
                'description' => 'New scalar value. For settings that hold attachment IDs (site_icon, custom_logo, background_image, header_image), pass the numeric ID as a string.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $name = $parameters['name'];
        if (!isset(self::SUPPORTED[$name])) {
            throw ToolException::wordpressError("Setting '{$name}' is not supported.");
        }
        if (!isset($parameters['value'])) {
            throw ToolException::wordpressError("'value' is required.");
        }
        $value = $parameters['value'];
        $config = self::SUPPORTED[$name];

        // Enum validation if configured
        if (isset($config['in']) && !in_array($value, $config['in'], true)) {
            throw ToolException::wordpressError(
                "Invalid value for {$name}: must be one of " . implode(', ', $config['in'])
            );
        }

        switch ($config['source']) {
            case 'option':
                $coerced = $this->coerceValue($name, $value);
                update_option($name, $coerced);
                break;

            case 'theme_mod':
                $coerced = $this->coerceValue($name, $value);
                set_theme_mod($name, $coerced);
                break;

            case 'custom_css':
                $result = wp_update_custom_css_post($value);
                if (is_wp_error($result)) {
                    throw ToolException::wordpressError('Failed to update custom CSS: ' . $result->get_error_message());
                }
                break;
        }

        return $this->success([
            'name'  => $name,
            'value' => $value,
        ], 'Customizer setting updated.');
    }

    private function coerceValue(string $name, string $value)
    {
        // Settings that store attachment/post IDs should be integers
        $intSettings = ['site_icon', 'custom_logo', 'page_on_front', 'page_for_posts', 'background_image', 'header_image'];
        if (in_array($name, $intSettings, true) && ctype_digit($value)) {
            return (int) $value;
        }
        return $value;
    }
}
