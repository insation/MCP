<?php
/**
 * Export Customizer Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Customizer;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ExportCustomizer extends AbstractTool
{
    public function getName(): string
    {
        return 'export_customizer';
    }

    public function getDescription(): string
    {
        return 'Export the Customizer state for the active theme as a portable JSON snapshot. Useful for backing up theme appearance before changes or migrating to another site. action=import restores from a snapshot.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:read';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['export', 'import']],
            ],
            'snapshot_json' => [
                'optional',
                'string',
                'description' => 'For action=import: JSON snapshot returned by a previous export.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];

        if ($action === 'export') {
            $snapshot = [
                'plugin'    => 'WordpressMCP',
                'version'   => 1,
                'theme'     => get_stylesheet(),
                'generated' => current_time('c'),
                'theme_mods'=> get_theme_mods() ?: [],
                'options'   => [
                    'blogname'        => get_option('blogname'),
                    'blogdescription' => get_option('blogdescription'),
                    'site_icon'       => (int) get_option('site_icon'),
                    'show_on_front'   => get_option('show_on_front'),
                    'page_on_front'   => (int) get_option('page_on_front'),
                    'page_for_posts'  => (int) get_option('page_for_posts'),
                ],
                'custom_css' => function_exists('wp_get_custom_css') ? wp_get_custom_css() : '',
            ];
            return $this->success([
                'snapshot' => $snapshot,
            ]);
        }

        // action=import — needs write scope
        $scopes = $this->userContext['scopes'] ?? [];
        $hasWrite = in_array('mcp:write', $scopes, true) || in_array('mcp:admin', $scopes, true);
        if ($this->userContext !== null && !$hasWrite) {
            throw ToolException::insufficientPermissions(
                "action=import requires mcp:write or mcp:admin scope."
            );
        }

        if (empty($parameters['snapshot_json'])) {
            throw ToolException::wordpressError("'snapshot_json' is required for action=import");
        }

        $snapshot = json_decode($parameters['snapshot_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in snapshot_json: ' . json_last_error_msg());
        }
        if (!isset($snapshot['theme_mods'])) {
            throw ToolException::wordpressError('Snapshot does not contain theme_mods.');
        }

        if ($snapshot['theme'] !== get_stylesheet()) {
            throw ToolException::wordpressError(
                "Snapshot is for theme '{$snapshot['theme']}', but active theme is '" . get_stylesheet() . "'."
            );
        }

        // Replace theme mods
        update_option('theme_mods_' . get_stylesheet(), $snapshot['theme_mods']);

        // Replace eligible options
        foreach (($snapshot['options'] ?? []) as $key => $val) {
            if (in_array($key, ['blogname', 'blogdescription', 'site_icon', 'show_on_front', 'page_on_front', 'page_for_posts'], true)) {
                update_option($key, $val);
            }
        }

        if (isset($snapshot['custom_css']) && function_exists('wp_update_custom_css_post')) {
            wp_update_custom_css_post($snapshot['custom_css']);
        }

        return $this->success([
            'theme' => get_stylesheet(),
        ], 'Customizer snapshot imported.');
    }
}
