<?php
/**
 * Get Option Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Option;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class GetOption extends AbstractTool
{
    /**
     * Option names whose values are sensitive and must never be returned by this tool.
     */
    private const BLOCKED = [
        'secret',
        'auth_key',
        'auth_salt',
        'logged_in_key',
        'logged_in_salt',
        'nonce_key',
        'nonce_salt',
        'secure_auth_key',
        'secure_auth_salt',
    ];

    public function getName(): string
    {
        return 'get_option';
    }

    public function getDescription(): string
    {
        return 'Read a single option from wp_options by name. Returns the option value (auto-deserialized by WordPress). Sensitive auth keys/salts are blocked.';
    }

    public function getSchema(): array
    {
        return [
            'name' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Option name (key in wp_options).'
            ],
            'default' => [
                'optional',
                'string',
                'description' => 'Value to return when the option does not exist.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $name = $parameters['name'];

        foreach (self::BLOCKED as $blocked) {
            if (stripos($name, $blocked) !== false) {
                throw ToolException::insufficientPermissions(
                    "Option '{$name}' is blocked: contains sensitive auth material."
                );
            }
        }

        $default = $parameters['default'] ?? null;
        $value = get_option($name, $default);

        return $this->success([
            'name'   => $name,
            'value'  => $value,
            'exists' => $value !== $default || get_option($name) !== false,
        ]);
    }
}
