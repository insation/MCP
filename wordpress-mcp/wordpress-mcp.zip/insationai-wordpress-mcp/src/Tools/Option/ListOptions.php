<?php
/**
 * List Options Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Option;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ListOptions extends AbstractTool
{
    public function getName(): string
    {
        return 'list_options';
    }

    public function getDescription(): string
    {
        return 'List options from wp_options. Optionally filter by name prefix or substring. Returns option names and sizes (values omitted to keep responses small — use get_option for individual values).';
    }

    public function getSchema(): array
    {
        return [
            'prefix' => [
                'optional',
                'string',
                'description' => 'Return only options whose name starts with this prefix.'
            ],
            'search' => [
                'optional',
                'string',
                'description' => 'Return only options whose name contains this substring.'
            ],
            'autoload_only' => [
                'optional',
                'bool',
                'description' => 'When true, only return options with autoload=yes.'
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 500]
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1]
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $perPage = $parameters['per_page'] ?? 100;
        $page    = $parameters['page'] ?? 1;
        $offset  = ($page - 1) * $perPage;

        $where = [];
        $args  = [];

        if (!empty($parameters['prefix'])) {
            $where[] = 'option_name LIKE %s';
            $args[]  = $wpdb->esc_like($parameters['prefix']) . '%';
        }
        if (!empty($parameters['search'])) {
            $where[] = 'option_name LIKE %s';
            $args[]  = '%' . $wpdb->esc_like($parameters['search']) . '%';
        }
        if (!empty($parameters['autoload_only'])) {
            $where[] = "autoload = 'yes'";
        }

        $whereClause = empty($where) ? '' : ('WHERE ' . implode(' AND ', $where));

        // Count
        $countSql = "SELECT COUNT(*) FROM {$wpdb->options} {$whereClause}";
        $total = empty($args)
            ? (int) $wpdb->get_var($countSql)
            : (int) $wpdb->get_var($wpdb->prepare($countSql, $args));

        // Page
        $sql = "SELECT option_name, autoload, LENGTH(option_value) AS value_length
                FROM {$wpdb->options} {$whereClause}
                ORDER BY option_name ASC
                LIMIT %d OFFSET %d";
        $pageArgs = array_merge($args, [$perPage, $offset]);
        $rows = $wpdb->get_results($wpdb->prepare($sql, $pageArgs), ARRAY_A);

        return $this->success([
            'count'    => count($rows),
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'items'    => array_map(static function ($r) {
                return [
                    'name'         => $r['option_name'],
                    'autoload'     => $r['autoload'] === 'yes',
                    'value_length' => (int) $r['value_length'],
                ];
            }, $rows),
        ]);
    }
}
