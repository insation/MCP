<?php
/**
 * Delete Option Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Option;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class DeleteOption extends AbstractTool
{
    private const PROTECTED_OPTIONS = [
        'siteurl', 'home', 'blogname', 'admin_email', 'template', 'stylesheet',
        'active_plugins', 'db_version', 'wp_user_roles', 'cron',
    ];

    private const BLOCKED = [
        'secret', 'auth_key', 'auth_salt',
        'logged_in_key', 'logged_in_salt',
        'nonce_key', 'nonce_salt',
        'secure_auth_key', 'secure_auth_salt',
    ];

    public function getName(): string
    {
        return 'delete_option';
    }

    public function getDescription(): string
    {
        return 'Delete an option from wp_options. A short list of core options (siteurl, home, active_plugins, etc.) is protected from deletion. Subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'name' => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->checkSafeMode('deleting options');

        $name = $parameters['name'];

        if (in_array($name, self::PROTECTED_OPTIONS, true)) {
            throw ToolException::wordpressError("Refusing to delete protected core option: '{$name}'");
        }
        foreach (self::BLOCKED as $blocked) {
            if (stripos($name, $blocked) !== false) {
                throw ToolException::insufficientPermissions(
                    "Option '{$name}' is blocked: contains sensitive auth material."
                );
            }
        }

        $existed = get_option($name, '__INSATIONAI_WPMCP_MISSING__') !== '__INSATIONAI_WPMCP_MISSING__';
        if (!$existed) {
            return $this->success(['name' => $name, 'deleted' => false], "Option '{$name}' does not exist.");
        }

        $result = delete_option($name);
        if (!$result) {
            throw ToolException::wordpressError("Failed to delete option '{$name}'.");
        }

        return $this->success(['name' => $name, 'deleted' => true], 'Option deleted.');
    }
}
