<?php
/**
 * Delete Transient Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Option;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class DeleteTransient extends AbstractTool
{
    public function getName(): string
    {
        return 'delete_transient';
    }

    public function getDescription(): string
    {
        return 'Delete a transient. Useful for forcing cache invalidation.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'name' => ['required', 'string', ['notEmpty' => true]],
            'site' => [
                'optional',
                'bool',
                'description' => 'Delete a site (network) transient.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $name = $parameters['name'];
        $isSite = !empty($parameters['site']);

        $deleted = $isSite ? delete_site_transient($name) : delete_transient($name);

        return $this->success([
            'name'    => $name,
            'site'    => $isSite,
            'deleted' => (bool) $deleted,
        ], $deleted ? 'Transient deleted.' : 'Transient not found (no-op).');
    }
}
