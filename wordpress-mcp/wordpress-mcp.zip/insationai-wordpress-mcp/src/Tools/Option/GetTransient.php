<?php
/**
 * Get Transient Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Option;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class GetTransient extends AbstractTool
{
    public function getName(): string
    {
        return 'get_transient';
    }

    public function getDescription(): string
    {
        return 'Read a WordPress transient by name. Optionally site-wide (network transients) via `site=true`.';
    }

    public function getSchema(): array
    {
        return [
            'name' => ['required', 'string', ['notEmpty' => true]],
            'site' => [
                'optional',
                'bool',
                'description' => 'Use site (network) transient. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $name = $parameters['name'];
        $isSite = !empty($parameters['site']);
        $value = $isSite ? get_site_transient($name) : get_transient($name);

        return $this->success([
            'name'   => $name,
            'site'   => $isSite,
            'value'  => $value,
            'exists' => $value !== false,
        ]);
    }
}
