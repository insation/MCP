<?php
/**
 * Manage Menu Items Tool — add, update, delete, or reorder items within a menu.
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Menu;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageMenuItems extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_menu_items';
    }

    public function getDescription(): string
    {
        return 'Add, update, delete, or reorder navigation menu items. For action=add, provide either a custom URL+title or an object_type+object_id (e.g. post/page reference).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'menu' => [
                'required',
                'string',
                'description' => 'Menu ID, slug, or name.'
            ],
            'action' => [
                'required',
                'string',
                ['in' => ['add', 'update', 'delete', 'reorder']],
            ],
            'item_id' => [
                'optional',
                'int',
                'description' => 'For update/delete: the menu item ID.'
            ],
            'title' => ['optional', 'string'],
            'url' => [
                'optional',
                'string',
                'description' => 'For custom links: the URL.'
            ],
            'object_type' => [
                'optional',
                'string',
                ['in' => ['post_type', 'taxonomy', 'custom']],
                'description' => 'Type of menu item. Default: custom (URL link).'
            ],
            'object' => [
                'optional',
                'string',
                'description' => 'For post_type: the post type slug (e.g. page, post). For taxonomy: the taxonomy slug.'
            ],
            'object_id' => [
                'optional',
                'int',
                'description' => 'For post_type/taxonomy: the post or term ID.'
            ],
            'parent_id' => [
                'optional',
                'int',
                'description' => 'Parent menu item ID for nesting. 0 = top level.'
            ],
            'target' => [
                'optional',
                'string',
                ['in' => ['', '_blank']],
            ],
            'classes' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
            ],
            'order' => [
                'optional',
                'array',
                'items' => ['type' => 'integer'],
                'description' => 'For action=reorder: ordered list of menu item IDs in the desired sequence (top-level only).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $menu = wp_get_nav_menu_object($parameters['menu']);
        if (!$menu) {
            throw ToolException::wordpressError("Menu not found: '{$parameters['menu']}'");
        }

        $action = $parameters['action'];

        switch ($action) {
            case 'add':
            case 'update':
                $item_id = $action === 'update' ? (int) ($parameters['item_id'] ?? 0) : 0;
                if ($action === 'update' && !$item_id) {
                    throw ToolException::wordpressError("'item_id' is required for action=update");
                }

                $object_type = $parameters['object_type'] ?? 'custom';
                $data = [
                    'menu-item-title'       => $parameters['title'] ?? '',
                    'menu-item-status'      => 'publish',
                    'menu-item-type'        => $object_type,
                    'menu-item-parent-id'   => (int) ($parameters['parent_id'] ?? 0),
                    'menu-item-target'      => $parameters['target'] ?? '',
                    'menu-item-classes'     => isset($parameters['classes']) ? implode(' ', $parameters['classes']) : '',
                ];

                if ($object_type === 'custom') {
                    if (empty($parameters['url']) && $action === 'add') {
                        throw ToolException::wordpressError("'url' is required when adding a custom menu item.");
                    }
                    if (isset($parameters['url'])) {
                        $data['menu-item-url'] = esc_url_raw($parameters['url']);
                    }
                } else {
                    if ($action === 'add' && (empty($parameters['object']) || empty($parameters['object_id']))) {
                        throw ToolException::wordpressError("'object' and 'object_id' are required for object_type={$object_type}");
                    }
                    if (isset($parameters['object'])) {
                        $data['menu-item-object'] = $parameters['object'];
                    }
                    if (isset($parameters['object_id'])) {
                        $data['menu-item-object-id'] = (int) $parameters['object_id'];
                    }
                }

                $new_id = wp_update_nav_menu_item($menu->term_id, $item_id, $data);
                if (is_wp_error($new_id)) {
                    throw ToolException::wordpressError('Failed: ' . $new_id->get_error_message());
                }

                return $this->success([
                    'menu_id' => $menu->term_id,
                    'item_id' => (int) $new_id,
                    'action'  => $action,
                ], $action === 'add' ? 'Menu item added.' : 'Menu item updated.');

            case 'delete':
                $this->checkSafeMode('deleting menu items');
                $item_id = (int) ($parameters['item_id'] ?? 0);
                if (!$item_id) {
                    throw ToolException::wordpressError("'item_id' is required for action=delete");
                }
                $result = wp_delete_post($item_id, true);
                if (!$result) {
                    throw ToolException::wordpressError("Failed to delete menu item {$item_id}.");
                }
                return $this->success(['item_id' => $item_id], 'Menu item deleted.');

            case 'reorder':
                if (empty($parameters['order']) || !is_array($parameters['order'])) {
                    throw ToolException::wordpressError("'order' array is required for action=reorder");
                }
                $pos = 0;
                foreach ($parameters['order'] as $iid) {
                    $pos++;
                    wp_update_post([
                        'ID'         => (int) $iid,
                        'menu_order' => $pos,
                    ]);
                }
                return $this->success([
                    'menu_id' => $menu->term_id,
                    'reordered_count' => count($parameters['order']),
                ], 'Menu items reordered.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
