<?php
/**
 * Get Menu Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Menu;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class GetMenu extends AbstractTool
{
    public function getName(): string
    {
        return 'get_menu';
    }

    public function getDescription(): string
    {
        return 'Get a single navigation menu with all its items, including their hierarchy, URLs, types, and ordering.';
    }

    public function getSchema(): array
    {
        return [
            'menu' => [
                'required',
                'string',
                'description' => 'Menu ID (numeric), slug, or name.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $menu = wp_get_nav_menu_object($parameters['menu']);
        if (!$menu) {
            throw ToolException::wordpressError("Menu not found: '{$parameters['menu']}'");
        }

        $items = wp_get_nav_menu_items($menu->term_id, ['update_post_term_cache' => false]) ?: [];

        $formatted = array_map(function ($item) {
            return [
                'id'         => (int) $item->ID,
                'parent_id'  => (int) $item->menu_item_parent,
                'order'      => (int) $item->menu_order,
                'title'      => $item->title,
                'url'        => $item->url,
                'type'       => $item->type,           // post_type | taxonomy | custom
                'object'     => $item->object,         // page | category | etc.
                'object_id'  => (int) $item->object_id,
                'target'     => $item->target,
                'classes'    => array_values(array_filter((array) $item->classes)),
                'attr_title' => $item->attr_title,
                'description'=> $item->description,
                'xfn'        => $item->xfn,
            ];
        }, $items);

        return $this->success([
            'id'         => $menu->term_id,
            'name'       => $menu->name,
            'slug'       => $menu->slug,
            'item_count' => count($formatted),
            'items'      => $formatted,
        ]);
    }
}
