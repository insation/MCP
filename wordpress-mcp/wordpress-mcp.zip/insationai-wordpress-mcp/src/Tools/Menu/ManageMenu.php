<?php
/**
 * Manage Menu Tool — create, rename, or delete navigation menus.
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Menu;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageMenu extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_menu';
    }

    public function getDescription(): string
    {
        return 'Create a new navigation menu, rename an existing menu, or delete a menu. Use manage_menu_items to add items.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['create', 'rename', 'delete']],
            ],
            'name' => [
                'optional',
                'string',
                'description' => 'For create: new menu name (required). For rename: new name.'
            ],
            'menu' => [
                'optional',
                'string',
                'description' => 'For rename/delete: existing menu ID, slug, or name.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];

        switch ($action) {
            case 'create':
                if (empty($parameters['name'])) {
                    throw ToolException::wordpressError("'name' is required for action=create");
                }
                $id = wp_create_nav_menu($parameters['name']);
                if (is_wp_error($id)) {
                    throw ToolException::wordpressError('Failed to create menu: ' . $id->get_error_message());
                }
                return $this->success([
                    'id'   => (int) $id,
                    'name' => $parameters['name'],
                ], 'Menu created.');

            case 'rename':
                if (empty($parameters['menu']) || empty($parameters['name'])) {
                    throw ToolException::wordpressError("'menu' and 'name' are required for action=rename");
                }
                $menu = wp_get_nav_menu_object($parameters['menu']);
                if (!$menu) {
                    throw ToolException::wordpressError("Menu not found: '{$parameters['menu']}'");
                }
                $result = wp_update_nav_menu_object($menu->term_id, ['menu-name' => $parameters['name']]);
                if (is_wp_error($result)) {
                    throw ToolException::wordpressError('Failed to rename menu: ' . $result->get_error_message());
                }
                return $this->success([
                    'id'   => $menu->term_id,
                    'name' => $parameters['name'],
                ], 'Menu renamed.');

            case 'delete':
                $this->checkSafeMode('deleting menus');
                if (empty($parameters['menu'])) {
                    throw ToolException::wordpressError("'menu' is required for action=delete");
                }
                $menu = wp_get_nav_menu_object($parameters['menu']);
                if (!$menu) {
                    throw ToolException::wordpressError("Menu not found: '{$parameters['menu']}'");
                }
                $result = wp_delete_nav_menu($menu->term_id);
                if (is_wp_error($result) || $result === false) {
                    $msg = is_wp_error($result) ? $result->get_error_message() : 'unknown error';
                    throw ToolException::wordpressError("Failed to delete menu: {$msg}");
                }
                return $this->success(['id' => $menu->term_id], 'Menu deleted.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
