<?php
/**
 * Assign Menu Location Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Menu;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class AssignMenuLocation extends AbstractTool
{
    public function getName(): string
    {
        return 'assign_menu_location';
    }

    public function getDescription(): string
    {
        return 'Assign a menu to a registered theme location (e.g. primary, footer). Pass menu=null to unassign a location. Use list_menus to see registered_locations.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'location' => [
                'required',
                'string',
                'description' => 'Registered theme location slug (e.g. primary, footer-menu).'
            ],
            'menu' => [
                'optional',
                'string',
                'description' => 'Menu ID, slug, or name. Omit or pass empty to unassign.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $location = $parameters['location'];
        $registered = get_registered_nav_menus();

        if (!array_key_exists($location, $registered)) {
            throw ToolException::wordpressError(
                "Location '{$location}' is not registered. Available: " . implode(', ', array_keys($registered))
            );
        }

        $locations = get_nav_menu_locations();

        if (empty($parameters['menu'])) {
            unset($locations[$location]);
            set_theme_mod('nav_menu_locations', $locations);
            return $this->success([
                'location' => $location,
                'menu_id'  => null,
            ], 'Menu location unassigned.');
        }

        $menu = wp_get_nav_menu_object($parameters['menu']);
        if (!$menu) {
            throw ToolException::wordpressError("Menu not found: '{$parameters['menu']}'");
        }

        $locations[$location] = $menu->term_id;
        set_theme_mod('nav_menu_locations', $locations);

        return $this->success([
            'location' => $location,
            'menu_id'  => $menu->term_id,
            'menu_name'=> $menu->name,
        ], "Menu '{$menu->name}' assigned to location '{$location}'.");
    }
}
