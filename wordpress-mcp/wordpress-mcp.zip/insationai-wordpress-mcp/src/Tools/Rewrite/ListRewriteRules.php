<?php
/**
 * List Rewrite Rules Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Rewrite;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class ListRewriteRules extends AbstractTool
{
    public function getName(): string
    {
        return 'list_rewrite_rules';
    }

    public function getDescription(): string
    {
        return 'List all WordPress rewrite rules (the regex → query mapping table). Optionally filter by pattern substring.';
    }

    public function getSchema(): array
    {
        return [
            'search' => [
                'optional',
                'string',
                'description' => 'Substring filter — matched against both the pattern and the target query.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $rules = get_option('rewrite_rules');
        if (!is_array($rules)) {
            // WP keeps rules in $wp_rewrite when not flushed to options
            global $wp_rewrite;
            $rules = is_object($wp_rewrite) ? (array) $wp_rewrite->wp_rewrite_rules() : [];
        }

        $search = $parameters['search'] ?? null;

        $items = [];
        foreach ($rules as $pattern => $query) {
            if ($search !== null) {
                if (stripos($pattern, $search) === false && stripos((string) $query, $search) === false) {
                    continue;
                }
            }
            $items[] = [
                'pattern' => $pattern,
                'query'   => $query,
            ];
        }

        return $this->success([
            'count'             => count($items),
            'total_in_database' => count($rules),
            'items'             => $items,
            'permalink_structure' => get_option('permalink_structure'),
        ]);
    }
}
