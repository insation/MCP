<?php
/**
 * Network Activate Plugin Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Multisite;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class NetworkActivatePlugin extends AbstractTool
{
    public function getName(): string
    {
        return 'network_activate_plugin';
    }

    public function getDescription(): string
    {
        return 'Activate or deactivate a plugin across an entire WordPress multisite network. The plugin file must already be present in /wp-content/plugins/. Multisite only.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'plugin' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Plugin slug (e.g. "akismet/akismet.php" or the folder name).'
            ],
            'action' => [
                'required',
                'string',
                ['in' => ['activate', 'deactivate']],
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!is_multisite()) {
            throw ToolException::wordpressError('This site is not a multisite network.');
        }

        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugin = $parameters['plugin'];
        // Allow callers to pass just the folder name — resolve to full plugin file
        if (!str_contains($plugin, '/') && !str_ends_with($plugin, '.php')) {
            $candidates = glob(WP_PLUGIN_DIR . '/' . $plugin . '/*.php') ?: [];
            foreach ($candidates as $candidate) {
                $data = get_plugin_data($candidate, false, false);
                if (!empty($data['Name'])) {
                    $plugin = $plugin . '/' . basename($candidate);
                    break;
                }
            }
        }

        $plugin_file = WP_PLUGIN_DIR . '/' . $plugin;
        if (!file_exists($plugin_file)) {
            throw ToolException::wordpressError("Plugin file not found: {$plugin}");
        }

        $action = $parameters['action'];

        if ($action === 'activate') {
            $result = activate_plugin($plugin, '', true /* network-wide */);
            if (is_wp_error($result)) {
                throw ToolException::wordpressError('Failed to network-activate: ' . $result->get_error_message());
            }
            return $this->success([
                'plugin'   => $plugin,
                'network'  => true,
            ], 'Plugin network-activated.');
        }

        // deactivate
        $this->checkSafeMode('deactivating network plugins');
        deactivate_plugins([$plugin], false, true /* network-wide */);
        return $this->success([
            'plugin'  => $plugin,
            'network' => true,
        ], 'Plugin network-deactivated.');
    }
}
