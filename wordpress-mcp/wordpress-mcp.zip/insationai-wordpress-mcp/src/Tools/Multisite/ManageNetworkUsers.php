<?php
/**
 * Manage Network Users Tool — add/remove users on network sites.
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Multisite;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageNetworkUsers extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_network_users';
    }

    public function getDescription(): string
    {
        return 'Add an existing user to a network site with a specified role, remove a user from a network site, or grant/revoke super admin status. Multisite only.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['add_to_site', 'remove_from_site', 'grant_super_admin', 'revoke_super_admin']],
            ],
            'user_id' => ['required', 'int'],
            'blog_id' => [
                'optional',
                'int',
                'description' => 'Required for add_to_site / remove_from_site.'
            ],
            'role' => [
                'optional',
                'string',
                'description' => 'Role slug for add_to_site. Default: subscriber.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!is_multisite()) {
            throw ToolException::wordpressError('This site is not a multisite network.');
        }

        $action = $parameters['action'];
        $user_id = (int) $parameters['user_id'];

        if (!get_userdata($user_id)) {
            throw ToolException::wordpressError("User not found: ID {$user_id}");
        }

        switch ($action) {
            case 'add_to_site':
                if (empty($parameters['blog_id'])) {
                    throw ToolException::wordpressError("'blog_id' is required for action=add_to_site");
                }
                $role = $parameters['role'] ?? 'subscriber';
                $result = add_user_to_blog((int) $parameters['blog_id'], $user_id, $role);
                if (is_wp_error($result)) {
                    throw ToolException::wordpressError('Failed: ' . $result->get_error_message());
                }
                return $this->success([
                    'user_id' => $user_id,
                    'blog_id' => (int) $parameters['blog_id'],
                    'role'    => $role,
                ], 'User added to site.');

            case 'remove_from_site':
                if (empty($parameters['blog_id'])) {
                    throw ToolException::wordpressError("'blog_id' is required for action=remove_from_site");
                }
                if (!function_exists('remove_user_from_blog')) {
                    require_once ABSPATH . 'wp-admin/includes/ms.php';
                }
                $result = remove_user_from_blog($user_id, (int) $parameters['blog_id']);
                if (is_wp_error($result)) {
                    throw ToolException::wordpressError('Failed: ' . $result->get_error_message());
                }
                return $this->success([
                    'user_id' => $user_id,
                    'blog_id' => (int) $parameters['blog_id'],
                ], 'User removed from site.');

            case 'grant_super_admin':
                if (!function_exists('grant_super_admin')) {
                    require_once ABSPATH . 'wp-admin/includes/ms.php';
                }
                $result = grant_super_admin($user_id);
                if (!$result) {
                    throw ToolException::wordpressError('Failed to grant super admin (user may already be super admin, or it is the only admin).');
                }
                return $this->success(['user_id' => $user_id], 'Super admin granted.');

            case 'revoke_super_admin':
                $this->checkSafeMode('revoking super admin');
                if (!function_exists('revoke_super_admin')) {
                    require_once ABSPATH . 'wp-admin/includes/ms.php';
                }
                $result = revoke_super_admin($user_id);
                if (!$result) {
                    throw ToolException::wordpressError('Failed to revoke super admin (user may not be super admin, or this would leave network with no super admins).');
                }
                return $this->success(['user_id' => $user_id], 'Super admin revoked.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
