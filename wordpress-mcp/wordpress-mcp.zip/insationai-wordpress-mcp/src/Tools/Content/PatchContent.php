<?php

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Content;

use InsationAI\WordpressMCP\Exceptions\ToolException;
use InsationAI\WordpressMCP\Services\ContentPatchingService;
use InsationAI\WordpressMCP\Services\ValidationService;
use InsationAI\WordpressMCP\Services\WordPressService;
use InsationAI\WordpressMCP\Tools\AbstractTool;

/**
 * Tool for patching WordPress content using sed-style search-replace operations.
 *
 * Enables efficient editing of long posts by sending only the changes (search-replace operations)
 * instead of the entire content. Supports literal string replacement and regex patterns.
 *
 * Features:
 * - Search-replace with configurable count (1, all, or specific number)
 * - Regex pattern support
 * - Dry-run mode for previewing changes
 * - Automatic content backups
 * - Diff preview showing before/after changes
 *
 * Example usage:
 * {
 *   "content_id": 123,
 *   "operations": [
 *     {"search": "old text", "replace": "new text", "count": 1},
 *     {"search": "/pattern/", "replace": "replacement", "count": "all", "regex": true}
 *   ],
 *   "dry_run": false,
 *   "create_backup": true
 * }
 */
class PatchContent extends AbstractTool
{
    private ContentPatchingService $patchingService;

    public function __construct(
        WordPressService $wpService,
        ValidationService $validationService,
        ContentPatchingService $patchingService,
        $logger = null
    ) {
        parent::__construct($wpService, $validationService, $logger);
        $this->patchingService = $patchingService;
    }

    public function getName(): string
    {
        return 'patch_content';
    }

    public function getDescription(): string
    {
        return 'Patch WordPress content using sed-style search-replace operations. ' .
               'Efficiently edit long posts by sending only the changes instead of entire content. ' .
               'Supports literal string replacement and regex patterns with configurable replacement counts.';
    }

    public function getSchema(): array
    {
        return [
            'content_id' => [
                'required',
                'intType',
                'positive',
                'description' => 'Post/page/CPT ID to patch',
            ],
            'operations' => [
                'required',
                'arrayType',
                'notEmpty',
                'description' => 'Array of search-replace operations. Each operation must have: ' .
                                 'search (string), replace (string), count (int|"all"), optional regex (bool)',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'search' => ['type' => 'string', 'description' => 'Text or regex pattern to find'],
                        'replace' => ['type' => 'string', 'description' => 'Replacement text'],
                        'count' => ['type' => 'string', 'description' => 'Number of replacements: integer or "all"'],
                        'regex' => ['type' => 'boolean', 'description' => 'Treat search as regex pattern']
                    ],
                    'required' => ['search', 'replace', 'count']
                ]
            ],
            'dry_run' => [
                'optional',
                'boolType',
                'description' => 'If true, preview changes without saving. Returns diff preview and statistics.',
            ],
            'create_backup' => [
                'optional',
                'boolType',
                'description' => 'If true, create backup of original content before patching. Default: true.',
            ],
        ];
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    protected function doExecute(array $parameters): array
    {
        $contentId = $parameters['content_id'];
        $operations = $parameters['operations'];
        $dryRun = $parameters['dry_run'] ?? false;
        $createBackup = $parameters['create_backup'] ?? true;

        // Get current post
        $post = $this->wp->getPost($contentId);
        if (!$post) {
            throw ToolException::notFound('post', $contentId);
        }

        // Check user can edit this post
        if (!current_user_can('edit_post', $contentId)) {
            throw ToolException::forbidden("You don't have permission to edit this content");
        }

        $originalContent = $post->post_content;

        $this->logger->info("Patching content ID {$contentId} with " . count($operations) . " operations");

        // Apply search-replace operations
        try {
            $result = $this->patchingService->applySearchReplace($originalContent, $operations);
        } catch (ToolException $e) {
            throw $e;
        } catch (\Exception $e) {
            throw ToolException::executionFailed("Failed to apply patches: " . $e->getMessage());
        }

        $patchedContent = $result['patched_content'];
        $statistics = $result['statistics'];
        $changesDetail = $result['changes_detail'];

        // Generate diff preview
        $preview = $this->patchingService->generateDiffPreview($originalContent, $patchedContent);

        $response = [
            'id' => $contentId,
            'type' => $post->post_type,
            'title' => $post->post_title,
            'operations_applied' => $statistics['operations_applied'],
            'statistics' => $statistics,
            'changes_detail' => $changesDetail,
            'preview' => $preview,
            'dry_run' => $dryRun,
        ];

        // If dry run, don't save
        if ($dryRun) {
            $this->logger->info("Dry run completed for post {$contentId} - not saving changes");
            $response['saved'] = false;
            $response['message'] = 'Dry run completed. Changes not saved. Review preview and statistics.';
            return $this->success($response);
        }

        // Create backup if requested
        $backupKey = null;
        if ($createBackup) {
            try {
                $backupKey = $this->patchingService->createBackup($contentId, $originalContent);
                $this->logger->info("Created backup: {$backupKey}");
            } catch (\Exception $e) {
                $this->logger->warning("Failed to create backup: " . $e->getMessage());
                // Continue with save even if backup fails
            }
        }

        // Update the post
        $updateResult = $this->wp->updatePost([
            'ID' => $contentId,
            'post_content' => $patchedContent,
        ]);

        if ($this->wp->isError($updateResult)) {
            throw ToolException::wordpressError(
                "Failed to update content: " . $updateResult->get_error_message()
            );
        }

        $this->logger->info("Successfully patched post {$contentId}");

        $response['saved'] = true;
        $response['backup_key'] = $backupKey;
        $response['message'] = 'Content patched successfully. ' .
                              $statistics['total_replacements'] . ' replacement(s) made.';

        // Add updated post info
        $updatedPost = $this->wp->getPost($contentId);
        $response['url'] = get_permalink($updatedPost);
        $response['modified'] = $updatedPost->post_modified;

        return $this->success($response);
    }
}
