<?php
/**
 * Delete User Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\User;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class DeleteUser extends AbstractTool
{
    public function getName(): string
    {
        return 'delete_user';
    }

    public function getDescription(): string
    {
        return 'Delete a WordPress user. Optionally reassign their posts to another user (recommended). Without reassignment, all their posts and links are also deleted. Subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                'description' => 'User ID to delete.'
            ],
            'reassign_to' => [
                'optional',
                'int',
                'description' => 'User ID to reassign posts/links to. If omitted, content is deleted.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->checkSafeMode('deleting users');

        $user_id = (int) $parameters['id'];
        if (!get_userdata($user_id)) {
            throw ToolException::wordpressError("User not found: ID {$user_id}");
        }

        // Prevent deleting yourself or the only admin.
        if (function_exists('get_current_user_id') && get_current_user_id() === $user_id) {
            throw ToolException::wordpressError('Cannot delete the currently authenticated user.');
        }

        // Ensure file is loaded outside admin context.
        if (!function_exists('wp_delete_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        $reassign = isset($parameters['reassign_to']) ? (int) $parameters['reassign_to'] : null;
        if ($reassign !== null && !get_userdata($reassign)) {
            throw ToolException::wordpressError("Reassign target user not found: ID {$reassign}");
        }

        $result = wp_delete_user($user_id, $reassign);
        if (!$result) {
            throw ToolException::wordpressError('Failed to delete user.');
        }

        return $this->success([
            'deleted_id'  => $user_id,
            'reassigned_to' => $reassign,
        ], 'User deleted successfully.');
    }
}
