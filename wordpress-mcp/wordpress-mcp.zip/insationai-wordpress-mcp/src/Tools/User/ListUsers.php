<?php
/**
 * List Users Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\User;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ListUsers extends AbstractTool
{
    public function getName(): string
    {
        return 'list_users';
    }

    public function getDescription(): string
    {
        return 'List WordPress users with filtering, sorting, and pagination. Supports filtering by role, search query, and registration date.';
    }

    public function getSchema(): array
    {
        return [
            'role' => [
                'optional',
                'string',
                'description' => 'Filter by role slug (e.g., administrator, editor, author, subscriber, customer).'
            ],
            'search' => [
                'optional',
                'string',
                'description' => 'Search term — matches user login, email, display name, or URL.'
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100]
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1]
            ],
            'orderby' => [
                'optional',
                'string',
                ['in' => ['ID', 'login', 'nicename', 'email', 'registered', 'display_name']]
            ],
            'order' => [
                'optional',
                'string',
                ['in' => ['ASC', 'DESC']]
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $args = [
            'number'  => $parameters['per_page'] ?? 10,
            'paged'   => $parameters['page'] ?? 1,
            'orderby' => $parameters['orderby'] ?? 'ID',
            'order'   => $parameters['order'] ?? 'ASC',
        ];

        if (!empty($parameters['role'])) {
            $args['role'] = $parameters['role'];
        }
        if (!empty($parameters['search'])) {
            $args['search'] = '*' . $parameters['search'] . '*';
        }

        $query = new \WP_User_Query($args);
        $users = $query->get_results();
        $total = (int) $query->get_total();

        $formatted = array_map(fn(\WP_User $u) => $this->formatUser($u), $users);

        return $this->success([
            'count'    => count($formatted),
            'total'    => $total,
            'page'     => $args['paged'],
            'per_page' => $args['number'],
            'items'    => $formatted,
        ]);
    }

    private function formatUser(\WP_User $user): array
    {
        return [
            'id'           => $user->ID,
            'login'        => $user->user_login,
            'email'        => $user->user_email,
            'display_name' => $user->display_name,
            'first_name'   => $user->first_name,
            'last_name'    => $user->last_name,
            'roles'        => $user->roles,
            'registered'   => $user->user_registered,
            'url'          => $user->user_url,
        ];
    }
}
