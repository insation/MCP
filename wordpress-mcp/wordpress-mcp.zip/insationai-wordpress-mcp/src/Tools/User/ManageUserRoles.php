<?php
/**
 * Manage User Roles Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\User;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageUserRoles extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_user_roles';
    }

    public function getDescription(): string
    {
        return 'Assign, add, or remove roles on a user. Use action=set to replace all current roles, action=add to add one, action=remove to remove one.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'user_id' => [
                'required',
                'int',
                'description' => 'Target user ID.'
            ],
            'action' => [
                'required',
                'string',
                ['in' => ['set', 'add', 'remove']],
                'description' => 'set: replace all roles with `role` or `roles`. add: add `role`. remove: remove `role`.'
            ],
            'role' => [
                'optional',
                'string',
                'description' => 'Single role slug (used for add/remove, or set when only one).'
            ],
            'roles' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'For action=set, a list of role slugs to assign.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $user_id = (int) $parameters['user_id'];
        $user = get_userdata($user_id);
        if (!$user) {
            throw ToolException::wordpressError("User not found: ID {$user_id}");
        }

        $action = $parameters['action'];
        $wp_roles = wp_roles();

        $validate = function (string $slug) use ($wp_roles): void {
            if (!isset($wp_roles->roles[$slug])) {
                throw ToolException::wordpressError("Unknown role: '{$slug}'");
            }
        };

        switch ($action) {
            case 'set':
                $roles = $parameters['roles']
                    ?? (isset($parameters['role']) ? [$parameters['role']] : null);
                if (!$roles) {
                    throw ToolException::wordpressError("'role' or 'roles' is required for action=set");
                }
                foreach ($roles as $r) {
                    $validate($r);
                }
                $user->set_role(array_shift($roles));
                foreach ($roles as $r) {
                    $user->add_role($r);
                }
                break;

            case 'add':
                if (empty($parameters['role'])) {
                    throw ToolException::wordpressError("'role' is required for action=add");
                }
                $validate($parameters['role']);
                $user->add_role($parameters['role']);
                break;

            case 'remove':
                if (empty($parameters['role'])) {
                    throw ToolException::wordpressError("'role' is required for action=remove");
                }
                $user->remove_role($parameters['role']);
                break;
        }

        // Refresh
        $user = get_userdata($user_id);

        return $this->success([
            'user_id' => $user_id,
            'action'  => $action,
            'roles'   => $user->roles,
        ], "Roles updated.");
    }
}
