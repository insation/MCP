<?php
/**
 * Manage Capabilities Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\User;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageCapabilities extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_capabilities';
    }

    public function getDescription(): string
    {
        return 'Create custom roles or add/remove capabilities on existing roles. Persists across requests (writes to wp_options). Requires admin scope.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['create_role', 'delete_role', 'add_cap', 'remove_cap']],
                'description' => 'create_role | delete_role | add_cap | remove_cap'
            ],
            'role' => [
                'required',
                'string',
                'description' => 'Role slug.'
            ],
            'display_name' => [
                'optional',
                'string',
                'description' => 'Required for action=create_role. Human-readable role name.'
            ],
            'capabilities' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'For create_role: array of capability slugs to grant. For add_cap/remove_cap: capabilities to modify.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $roleSlug = $parameters['role'];
        $wp_roles = wp_roles();

        switch ($action) {
            case 'create_role':
                if (empty($parameters['display_name'])) {
                    throw ToolException::wordpressError("'display_name' is required for create_role");
                }
                if (isset($wp_roles->roles[$roleSlug])) {
                    throw ToolException::wordpressError("Role already exists: '{$roleSlug}'");
                }
                $caps = [];
                foreach (($parameters['capabilities'] ?? []) as $c) {
                    $caps[$c] = true;
                }
                $new = add_role($roleSlug, $parameters['display_name'], $caps);
                if ($new === null) {
                    throw ToolException::wordpressError("Failed to create role: '{$roleSlug}'");
                }
                return $this->success([
                    'role' => $roleSlug,
                    'capabilities' => array_keys($caps),
                ], 'Role created.');

            case 'delete_role':
                $this->checkSafeMode('deleting roles');
                if (!isset($wp_roles->roles[$roleSlug])) {
                    throw ToolException::wordpressError("Role not found: '{$roleSlug}'");
                }
                if (in_array($roleSlug, ['administrator', 'editor', 'author', 'contributor', 'subscriber'], true)) {
                    throw ToolException::wordpressError("Cannot delete built-in role: '{$roleSlug}'");
                }
                remove_role($roleSlug);
                return $this->success(['role' => $roleSlug], 'Role deleted.');

            case 'add_cap':
            case 'remove_cap':
                if (!isset($wp_roles->roles[$roleSlug])) {
                    throw ToolException::wordpressError("Role not found: '{$roleSlug}'");
                }
                if (empty($parameters['capabilities'])) {
                    throw ToolException::wordpressError("'capabilities' is required for {$action}");
                }
                $role = get_role($roleSlug);
                foreach ($parameters['capabilities'] as $cap) {
                    if ($action === 'add_cap') {
                        $role->add_cap($cap);
                    } else {
                        $role->remove_cap($cap);
                    }
                }
                return $this->success([
                    'role' => $roleSlug,
                    'capabilities' => $parameters['capabilities'],
                    'action' => $action,
                ], 'Capabilities updated.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
