<?php
/**
 * Backup Database Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\ExportImport;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class BackupDatabase extends AbstractTool
{
    public function getName(): string
    {
        return 'backup_database';
    }

    public function getDescription(): string
    {
        return 'Generate a SQL dump of WP-prefix tables and write it to the uploads directory. Best-effort dump using SHOW CREATE TABLE + row export — for production backups, prefer a managed solution (host snapshots, WP-CLI db export, or a dedicated backup plugin). Subject to safe mode for actions that delete old backups.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'tables' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Specific table names to dump. Omit for all WP-prefix tables.'
            ],
            'list_backups' => [
                'optional',
                'bool',
                'description' => 'When true, do not dump — instead list existing backups in the uploads dir.'
            ],
            'delete_backup' => [
                'optional',
                'string',
                'description' => 'When set, delete this specific backup filename (no dump performed).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $upload = wp_upload_dir();
        $dir = trailingslashit($upload['basedir']) . 'insationai-wpmcp-backups';
        $url_base = trailingslashit($upload['baseurl']) . 'insationai-wpmcp-backups';

        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }

        if (!empty($parameters['list_backups'])) {
            $files = glob($dir . '/*.sql') ?: [];
            $items = array_map(static function ($f) use ($url_base) {
                return [
                    'filename' => basename($f),
                    'size'     => filesize($f),
                    'modified' => gmdate('Y-m-d H:i:s', filemtime($f)) . ' UTC',
                    'url'      => $url_base . '/' . basename($f),
                ];
            }, $files);
            return $this->success([
                'count'  => count($items),
                'items'  => $items,
                'directory' => $dir,
            ]);
        }

        if (!empty($parameters['delete_backup'])) {
            $this->checkSafeMode('deleting backup files');
            $name = basename($parameters['delete_backup']);  // strip path
            $path = $dir . '/' . $name;
            if (!file_exists($path)) {
                throw ToolException::wordpressError("Backup not found: {$name}");
            }
            if (!unlink($path)) {
                throw ToolException::wordpressError("Failed to delete: {$path}");
            }
            return $this->success(['filename' => $name], 'Backup deleted.');
        }

        // Determine tables
        $tables = $parameters['tables'] ?? null;
        if (empty($tables)) {
            $tables = $wpdb->get_col($wpdb->prepare(
                "SELECT TABLE_NAME FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s",
                DB_NAME,
                $wpdb->esc_like($wpdb->prefix) . '%'
            ));
        }

        // Sanity-check
        foreach ($tables as $t) {
            if (!preg_match('/^[A-Za-z0-9_]+$/', $t)) {
                throw ToolException::wordpressError("Invalid table name: '{$t}'");
            }
        }

        $filename = 'db-backup-' . gmdate('Ymd-His') . '-' . wp_generate_password(8, false) . '.sql';
        $path = $dir . '/' . $filename;

        $fh = fopen($path, 'wb');
        if (!$fh) {
            throw ToolException::wordpressError("Failed to open backup file for writing: {$path}");
        }

        fwrite($fh, "-- WordpressMCP Database Backup\n");
        fwrite($fh, "-- Generated: " . gmdate('Y-m-d H:i:s') . " UTC\n");
        fwrite($fh, "-- Database: " . DB_NAME . "\n");
        fwrite($fh, "-- Tables: " . count($tables) . "\n\n");
        fwrite($fh, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($fh, "SET NAMES utf8mb4;\n\n");

        $rowsTotal = 0;

        foreach ($tables as $table) {
            // CREATE TABLE
            $create = $wpdb->get_row("SHOW CREATE TABLE `{$table}`", ARRAY_N);
            if (!$create || !isset($create[1])) {
                continue;
            }
            fwrite($fh, "--\n-- Table: {$table}\n--\n");
            fwrite($fh, "DROP TABLE IF EXISTS `{$table}`;\n");
            fwrite($fh, $create[1] . ";\n\n");

            // Data — batched to manage memory
            $offset = 0;
            $batch = 500;
            while (true) {
                $rows = $wpdb->get_results("SELECT * FROM `{$table}` LIMIT {$offset}, {$batch}", ARRAY_A);
                if (empty($rows)) {
                    break;
                }
                foreach ($rows as $r) {
                    $cols = array_map(static fn($c) => "`{$c}`", array_keys($r));
                    $vals = array_map(static function ($v) use ($wpdb) {
                        if ($v === null) {
                            return 'NULL';
                        }
                        return "'" . esc_sql((string) $v) . "'";
                    }, array_values($r));
                    fwrite($fh, "INSERT INTO `{$table}` (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ");\n");
                    $rowsTotal++;
                }
                $offset += $batch;
            }
            fwrite($fh, "\n");
        }

        fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fh);

        return $this->success([
            'filename' => $filename,
            'path'     => $path,
            'url'      => $url_base . '/' . $filename,
            'size'     => filesize($path),
            'tables'   => count($tables),
            'rows'     => $rowsTotal,
        ], 'Database backup written.');
    }
}
