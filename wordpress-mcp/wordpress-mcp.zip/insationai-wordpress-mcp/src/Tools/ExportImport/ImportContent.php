<?php
/**
 * Import Content Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\ExportImport;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ImportContent extends AbstractTool
{
    public function getName(): string
    {
        return 'import_content';
    }

    public function getDescription(): string
    {
        return 'Import a WXR file. Requires the official "WordPress Importer" plugin to be installed and active (provides the WP_Import class). Pass a path to a local WXR file, or inline XML content. Always run with dry_run=true first to scan the file.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'path' => [
                'optional',
                'string',
                'description' => 'Server-side path to a WXR file. Either path or content is required.'
            ],
            'content' => [
                'optional',
                'string',
                'description' => 'Inline WXR XML content. Stored to a temp file before import.'
            ],
            'fetch_attachments' => [
                'optional',
                'bool',
                'description' => 'Download remote attachment files referenced in the WXR. Default false.'
            ],
            'author_remap_json' => [
                'optional',
                'string',
                'description' => 'JSON mapping of old author logins → new user IDs.'
            ],
            'dry_run' => [
                'optional',
                'bool',
                'description' => 'When true, only scan the file and report what would be imported. Default true.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $dryRun = $parameters['dry_run'] ?? true;

        $path = $parameters['path'] ?? null;
        if (!$path && !empty($parameters['content'])) {
            // Write inline to a temp file
            $upload = wp_upload_dir();
            $dir = trailingslashit($upload['basedir']) . 'insationai-wpmcp-imports';
            if (!file_exists($dir)) {
                wp_mkdir_p($dir);
            }
            $path = $dir . '/' . 'import-' . gmdate('Ymd-His') . '-' . wp_generate_password(8, false) . '.xml';
            if (file_put_contents($path, $parameters['content']) === false) {
                throw ToolException::wordpressError("Failed to write temp file: {$path}");
            }
        }

        if (!$path) {
            throw ToolException::wordpressError("Must supply either 'path' or 'content'.");
        }
        if (!file_exists($path)) {
            throw ToolException::wordpressError("File not found: {$path}");
        }
        if (!is_readable($path)) {
            throw ToolException::wordpressError("File not readable: {$path}");
        }

        // Scan the WXR to count items
        if (!class_exists('WXR_Parser')) {
            $parser_path = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
            if (file_exists($parser_path)) {
                require_once $parser_path;
            }
        }

        // Best-effort scan even without the official importer plugin
        $scan = $this->scanWxr($path);

        if ($dryRun) {
            return $this->success([
                'dry_run' => true,
                'path'    => $path,
                'scan'    => $scan,
                'note'    => 'Run with dry_run=false to actually import. Requires the official "wordpress-importer" plugin to be active.',
            ]);
        }

        $this->checkSafeMode('importing content');

        // Real import requires the official importer plugin
        if (!class_exists('WP_Import')) {
            $importer = WP_PLUGIN_DIR . '/wordpress-importer/wordpress-importer.php';
            if (file_exists($importer)) {
                require_once $importer;
            }
        }
        if (!class_exists('WP_Import')) {
            throw ToolException::wordpressError(
                'The "wordpress-importer" plugin is not installed or active. Install it (Plugins → Add New → search "WordPress Importer") and try again.'
            );
        }

        $remap = [];
        if (!empty($parameters['author_remap_json'])) {
            $decoded = json_decode($parameters['author_remap_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in author_remap_json: ' . json_last_error_msg());
            }
            $remap = is_array($decoded) ? $decoded : [];
        }

        $importer = new \WP_Import();
        $importer->fetch_attachments = !empty($parameters['fetch_attachments']);

        // The official importer reads $_POST['user_map'] / $_POST['imported_authors'] for
        // its UI flow; for headless use we set the property directly.
        if (!empty($remap)) {
            $importer->author_mapping = $remap;
        }

        ob_start();
        try {
            $importer->import($path);
        } catch (\Throwable $e) {
            ob_end_clean();
            throw ToolException::wordpressError('Import threw exception: ' . $e->getMessage());
        }
        $log = ob_get_clean();

        return $this->success([
            'dry_run' => false,
            'path'    => $path,
            'scan'    => $scan,
            'log_excerpt' => substr((string) $log, 0, 4000),
        ], 'Import complete.');
    }

    /**
     * Cheap structural scan of a WXR file — counts items by type.
     *
     * @return array<string,int>
     */
    private function scanWxr(string $path): array
    {
        $counts = ['posts' => 0, 'pages' => 0, 'attachments' => 0, 'comments' => 0, 'terms' => 0, 'other' => 0];
        $fh = fopen($path, 'rb');
        if (!$fh) {
            return $counts;
        }
        // Parse XML in streaming chunks
        $parser = xml_parser_create();
        $depth = 0;
        $postType = null;
        xml_set_element_handler(
            $parser,
            function ($parser, $name, $attrs) use (&$counts, &$depth, &$postType) {
                $depth++;
                if ($name === 'ITEM') {
                    $postType = null;
                } elseif ($name === 'WP:POST_TYPE') {
                    // post_type comes through as CDATA below — flag we expect it
                    $postType = '';
                } elseif ($name === 'WP:CATEGORY' || $name === 'WP:TAG' || $name === 'WP:TERM') {
                    $counts['terms']++;
                } elseif ($name === 'WP:COMMENT') {
                    $counts['comments']++;
                }
            },
            function ($parser, $name) use (&$counts, &$depth, &$postType) {
                if ($name === 'ITEM') {
                    if ($postType === 'post') {
                        $counts['posts']++;
                    } elseif ($postType === 'page') {
                        $counts['pages']++;
                    } elseif ($postType === 'attachment') {
                        $counts['attachments']++;
                    } else {
                        $counts['other']++;
                    }
                }
                $depth--;
            }
        );
        xml_set_character_data_handler($parser, function ($parser, $data) use (&$postType) {
            if ($postType === '' && is_string($data) && trim($data) !== '') {
                $postType = trim($data);
            }
        });

        while (!feof($fh)) {
            $chunk = fread($fh, 8192);
            if ($chunk === false || $chunk === '') {
                break;
            }
            xml_parse($parser, $chunk, feof($fh));
        }
        xml_parser_free($parser);
        fclose($fh);
        return $counts;
    }
}
