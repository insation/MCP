<?php
/**
 * List Reusable Blocks Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Pattern;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class ListReusableBlocks extends AbstractTool
{
    public function getName(): string
    {
        return 'list_reusable_blocks';
    }

    public function getDescription(): string
    {
        return 'List reusable blocks (the wp_block post type — the "Synced Patterns" library in the editor). Returns ID, title, status, and optionally full content.';
    }

    public function getSchema(): array
    {
        return [
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100],
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1],
            ],
            'search' => ['optional', 'string'],
            'include_content' => [
                'optional',
                'bool',
                'description' => 'When true, include the full block markup.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $args = [
            'post_type'      => 'wp_block',
            'posts_per_page' => $parameters['per_page'] ?? 20,
            'paged'          => $parameters['page'] ?? 1,
            'post_status'    => 'publish',
            'orderby'        => 'title',
            'order'          => 'ASC',
        ];
        if (!empty($parameters['search'])) {
            $args['s'] = $parameters['search'];
        }

        $query = new \WP_Query($args);
        $includeContent = !empty($parameters['include_content']);

        $items = array_map(function (\WP_Post $p) use ($includeContent) {
            $entry = [
                'id'       => $p->ID,
                'title'    => $p->post_title,
                'slug'     => $p->post_name,
                'status'   => $p->post_status,
                'modified' => $p->post_modified,
            ];
            if ($includeContent) {
                $entry['content'] = $p->post_content;
            }
            return $entry;
        }, $query->posts);

        return $this->success([
            'count'    => count($items),
            'total'    => (int) $query->found_posts,
            'page'     => $args['paged'],
            'per_page' => $args['posts_per_page'],
            'items'    => $items,
        ]);
    }
}
