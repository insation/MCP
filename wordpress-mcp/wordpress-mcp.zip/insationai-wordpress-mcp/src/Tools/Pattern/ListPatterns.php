<?php
/**
 * List Patterns Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Pattern;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class ListPatterns extends AbstractTool
{
    public function getName(): string
    {
        return 'list_patterns';
    }

    public function getDescription(): string
    {
        return 'List all registered block patterns and their categories. Includes patterns registered via PHP (theme/plugin code) and theme.json/patterns directory.';
    }

    public function getSchema(): array
    {
        return [
            'category' => [
                'optional',
                'string',
                'description' => 'Filter patterns by category slug.'
            ],
            'include_content' => [
                'optional',
                'bool',
                'description' => 'When true, include full block markup. Default false (just metadata).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $registry = \WP_Block_Patterns_Registry::get_instance();
        $patterns = $registry->get_all_registered();

        $cat_registry = \WP_Block_Pattern_Categories_Registry::get_instance();
        $categories = $cat_registry->get_all_registered();

        $filter = $parameters['category'] ?? null;
        $includeContent = !empty($parameters['include_content']);

        $items = [];
        foreach ($patterns as $p) {
            if ($filter && (!isset($p['categories']) || !in_array($filter, $p['categories'], true))) {
                continue;
            }
            $entry = [
                'name'        => $p['name'] ?? null,
                'title'       => $p['title'] ?? null,
                'description' => $p['description'] ?? '',
                'categories'  => $p['categories'] ?? [],
                'keywords'    => $p['keywords'] ?? [],
                'block_types' => $p['blockTypes'] ?? [],
                'source'      => $p['source'] ?? 'plugin',
            ];
            if ($includeContent) {
                $entry['content'] = $p['content'] ?? '';
            }
            $items[] = $entry;
        }

        return $this->success([
            'count'      => count($items),
            'items'      => $items,
            'categories' => array_map(static fn($c) => [
                'name' => $c['name'] ?? null,
                'label'=> $c['label'] ?? null,
            ], $categories),
        ]);
    }
}
