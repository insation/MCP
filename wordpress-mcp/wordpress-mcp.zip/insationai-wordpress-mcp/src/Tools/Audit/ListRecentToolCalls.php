<?php
/**
 * List Recent Tool Calls Tool
 *
 * @package WordpressMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Audit;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class ListRecentToolCalls extends AbstractTool
{
    public function getName(): string
    {
        return 'list_recent_tool_calls';
    }

    public function getDescription(): string
    {
        return 'Read the WordpressMCP audit log — a ring buffer of the last 1000 tool invocations. Each entry includes the tool name, calling user, OAuth scope used, parameter key names (values are NOT logged for security), outcome, duration, and remote IP. Filter by tool, user, or outcome. Use this to answer "what did this token do recently?".';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'tool' => [
                'optional',
                'string',
                'description' => 'Filter to entries for a specific tool name.'
            ],
            'user_id' => [
                'optional',
                'int',
                'description' => 'Filter to entries by a specific user ID.'
            ],
            'outcome' => [
                'optional',
                'string',
                ['in' => ['success', 'tool_error', 'fatal']],
            ],
            'since_seconds_ago' => [
                'optional',
                'int',
                ['min' => 1],
                'description' => 'Return only entries newer than this many seconds.'
            ],
            'limit' => [
                'optional',
                'int',
                ['min' => 1], ['max' => 1000],
                'description' => 'Max entries to return. Default 100.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $log = get_option('insationai_wpmcp_audit_log', []);
        if (!is_array($log)) {
            $log = [];
        }

        $tool       = $parameters['tool']             ?? null;
        $userIdF    = isset($parameters['user_id']) ? (int) $parameters['user_id'] : null;
        $outcome    = $parameters['outcome']           ?? null;
        $sinceCut   = isset($parameters['since_seconds_ago']) ? time() - (int) $parameters['since_seconds_ago'] : null;
        $limit      = (int) ($parameters['limit'] ?? 100);

        $filtered = [];
        foreach ($log as $entry) {
            if (!is_array($entry)) continue;
            if ($tool !== null && ($entry['tool'] ?? '') !== $tool) continue;
            if ($userIdF !== null && ((int) ($entry['user_id'] ?? 0)) !== $userIdF) continue;
            if ($outcome !== null && ($entry['outcome'] ?? '') !== $outcome) continue;
            if ($sinceCut !== null && ((int) ($entry['t'] ?? 0)) < $sinceCut) continue;
            $filtered[] = $entry;
        }

        // Newest first
        $filtered = array_reverse($filtered);
        if (count($filtered) > $limit) {
            $filtered = array_slice($filtered, 0, $limit);
        }

        // Normalize timestamps
        $items = array_map(static function ($e) {
            $t = (int) ($e['t'] ?? 0);
            $e['when_utc'] = $t > 0 ? gmdate('Y-m-d H:i:s', $t) . ' UTC' : null;
            return $e;
        }, $filtered);

        return $this->success([
            'count'        => count($items),
            'total_in_log' => count($log),
            'capacity'     => 1000,
            'items'        => $items,
        ]);
    }
}
