<?php
/**
 * Get Comment Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Comment;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class GetComment extends AbstractTool
{
    public function getName(): string
    {
        return 'get_comment';
    }

    public function getDescription(): string
    {
        return 'Get a single comment by ID, including meta and parent/post linkage.';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                'description' => 'Comment ID.'
            ],
            'include_meta' => [
                'optional',
                'bool',
                'description' => 'Include comment meta. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $id = (int) $parameters['id'];
        $comment = get_comment($id);
        if (!$comment) {
            throw ToolException::wordpressError("Comment not found: ID {$id}");
        }

        $data = [
            'id'         => (int) $comment->comment_ID,
            'post_id'    => (int) $comment->comment_post_ID,
            'parent_id'  => (int) $comment->comment_parent,
            'user_id'    => (int) $comment->user_id,
            'author'     => $comment->comment_author,
            'email'      => $comment->comment_author_email,
            'url'        => $comment->comment_author_url,
            'ip'         => $comment->comment_author_IP,
            'agent'      => $comment->comment_agent,
            'date'       => $comment->comment_date,
            'date_gmt'   => $comment->comment_date_gmt,
            'content'    => $comment->comment_content,
            'approved'   => $comment->comment_approved,
            'type'       => $comment->comment_type ?: 'comment',
        ];

        $post = get_post($comment->comment_post_ID);
        if ($post) {
            $data['post'] = [
                'id'    => $post->ID,
                'title' => $post->post_title,
                'type'  => $post->post_type,
                'url'   => get_permalink($post->ID),
            ];
        }

        if (!empty($parameters['include_meta'])) {
            $data['meta'] = get_comment_meta($id);
        }

        return $this->success($data);
    }
}
