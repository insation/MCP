<?php
/**
 * Update Comment Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Comment;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class UpdateComment extends AbstractTool
{
    public function getName(): string
    {
        return 'update_comment';
    }

    public function getDescription(): string
    {
        return 'Edit a comment\'s content or author fields. To change approval status, use moderate_comment.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'content' => ['optional', 'string'],
            'author_name' => ['optional', 'string'],
            'author_email' => ['optional', 'string'],
            'author_url' => ['optional', 'string'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $id = (int) $parameters['id'];
        if (!get_comment($id)) {
            throw ToolException::wordpressError("Comment not found: ID {$id}");
        }

        $update = ['comment_ID' => $id];
        if (isset($parameters['content'])) {
            $update['comment_content'] = $parameters['content'];
        }
        if (isset($parameters['author_name'])) {
            $update['comment_author'] = $parameters['author_name'];
        }
        if (isset($parameters['author_email'])) {
            $update['comment_author_email'] = sanitize_email($parameters['author_email']);
        }
        if (isset($parameters['author_url'])) {
            $update['comment_author_url'] = esc_url_raw($parameters['author_url']);
        }

        if (count($update) === 1) {
            throw ToolException::wordpressError('No updatable fields supplied.');
        }

        $result = wp_update_comment(wp_slash($update));
        if ($result === false || is_wp_error($result)) {
            $msg = is_wp_error($result) ? $result->get_error_message() : 'unknown error';
            throw ToolException::wordpressError("Failed to update comment: {$msg}");
        }

        return $this->success(['id' => $id], 'Comment updated.');
    }
}
