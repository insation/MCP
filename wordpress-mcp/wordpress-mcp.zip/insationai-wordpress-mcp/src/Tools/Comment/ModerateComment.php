<?php
/**
 * Moderate Comment Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Comment;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ModerateComment extends AbstractTool
{
    public function getName(): string
    {
        return 'moderate_comment';
    }

    public function getDescription(): string
    {
        return 'Change a comment\'s moderation state: approve, hold, spam, trash, or untrash.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'action' => [
                'required',
                'string',
                ['in' => ['approve', 'hold', 'spam', 'unspam', 'trash', 'untrash']],
                'description' => 'approve | hold | spam | unspam | trash | untrash'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $id = (int) $parameters['id'];
        if (!get_comment($id)) {
            throw ToolException::wordpressError("Comment not found: ID {$id}");
        }

        $action = $parameters['action'];
        $ok = false;

        switch ($action) {
            case 'approve':
                $ok = wp_set_comment_status($id, 'approve');
                break;
            case 'hold':
                $ok = wp_set_comment_status($id, 'hold');
                break;
            case 'spam':
                $ok = (bool) wp_spam_comment($id);
                break;
            case 'unspam':
                $ok = (bool) wp_unspam_comment($id);
                break;
            case 'trash':
                $ok = (bool) wp_trash_comment($id);
                break;
            case 'untrash':
                $ok = (bool) wp_untrash_comment($id);
                break;
        }

        if (!$ok) {
            throw ToolException::wordpressError("Failed to {$action} comment ID {$id}");
        }

        $comment = get_comment($id);
        return $this->success([
            'id'       => $id,
            'action'   => $action,
            'approved' => $comment->comment_approved,
        ], "Comment {$action} successful.");
    }
}
