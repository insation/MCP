<?php
/**
 * Media Attach Tool
 *
 * @package WordpressMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- This tool returns JSON API responses, not HTML output
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Media;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

/**
 * Tool to attach media to posts and manage featured images
 *
 * Handles attaching/detaching media to posts and setting/removing featured images
 */
class MediaAttach extends AbstractTool
{
    /**
     * {@inheritdoc}
     */
    public function getName(): string
    {
        return 'media_attach';
    }

    /**
     * {@inheritdoc}
     */
    public function getDescription(): string
    {
        return 'Attach media to posts, detach media, set featured images, and remove featured images. '
            . 'Manages relationships between media and content.';
    }

    /**
     * {@inheritdoc}
     */
    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['attach_to_post', 'detach_from_post', 'set_featured_image', 'remove_featured_image']]
            ],
            'attachment_id' => [
                'required',
                'int',
                ['min' => 1]
            ],
            'post_id' => [
                'required',
                'int',
                ['min' => 1]
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $attachmentId = $parameters['attachment_id'];
        $postId = $parameters['post_id'];

        // Verify attachment exists
        $attachment = $this->wp->getPost($attachmentId);
        if ($attachment === null || $attachment->post_type !== 'attachment') {
            throw ToolException::wordpressError(
                "Attachment with ID {$attachmentId} not found"
            );
        }

        // Verify post exists
        $post = $this->wp->getPost($postId);
        if ($post === null) {
            throw ToolException::wordpressError(
                "Post with ID {$postId} not found"
            );
        }

        switch ($action) {
            case 'attach_to_post':
                return $this->attachToPost($attachmentId, $postId, $attachment, $post);

            case 'detach_from_post':
                return $this->detachFromPost($attachmentId, $attachment);

            case 'set_featured_image':
                return $this->setFeaturedImage($attachmentId, $postId, $attachment, $post);

            case 'remove_featured_image':
                return $this->removeFeaturedImage($postId, $post);

            default:
                throw ToolException::validationError("Invalid action: {$action}");
        }
    }

    /**
     * Attach media to a post
     *
     * @param int $attachmentId Attachment ID
     * @param int $postId Post ID
     * @param \WP_Post $attachment Attachment post object
     * @param \WP_Post $post Post object
     * @return array<string, mixed>
     */
    private function attachToPost(int $attachmentId, int $postId, \WP_Post $attachment, \WP_Post $post): array
    {
        $this->logger->info('Attaching media to post', [
            'attachment_id' => $attachmentId,
            'post_id' => $postId
        ]);

        $result = $this->wp->updateAttachmentParent($attachmentId, $postId);

        if ($this->wp->isError($result)) {
            throw ToolException::wordpressError(
                "Failed to attach media to post: " . $result->get_error_message()
            );
        }

        return $this->success([
            'attachment_id' => $attachmentId,
            'attachment_title' => $attachment->post_title,
            'post_id' => $postId,
            'post_title' => $post->post_title,
            'attached' => true,
        ], "Media attached to post successfully");
    }

    /**
     * Detach media from post
     *
     * @param int $attachmentId Attachment ID
     * @param \WP_Post $attachment Attachment post object
     * @return array<string, mixed>
     */
    private function detachFromPost(int $attachmentId, \WP_Post $attachment): array
    {
        $this->logger->info('Detaching media from post', ['attachment_id' => $attachmentId]);

        $result = $this->wp->updateAttachmentParent($attachmentId, 0);

        if ($this->wp->isError($result)) {
            throw ToolException::wordpressError(
                "Failed to detach media from post: " . $result->get_error_message()
            );
        }

        return $this->success([
            'attachment_id' => $attachmentId,
            'attachment_title' => $attachment->post_title,
            'detached' => true,
        ], "Media detached from post successfully");
    }

    /**
     * Set featured image for post
     *
     * @param int $attachmentId Attachment ID
     * @param int $postId Post ID
     * @param \WP_Post $attachment Attachment post object
     * @param \WP_Post $post Post object
     * @return array<string, mixed>
     */
    private function setFeaturedImage(int $attachmentId, int $postId, \WP_Post $attachment, \WP_Post $post): array
    {
        $this->logger->info('Setting featured image', [
            'attachment_id' => $attachmentId,
            'post_id' => $postId
        ]);

        $result = $this->wp->setPostThumbnail($postId, $attachmentId);

        if ($this->wp->isError($result)) {
            throw ToolException::wordpressError(
                "Failed to set featured image: " . $result->get_error_message()
            );
        }

        $thumbnailUrl = $this->wp->getAttachmentUrl($attachmentId, 'full');

        return $this->success([
            'attachment_id' => $attachmentId,
            'attachment_title' => $attachment->post_title,
            'attachment_url' => $thumbnailUrl,
            'post_id' => $postId,
            'post_title' => $post->post_title,
            'featured_image_set' => true,
        ], "Featured image set successfully");
    }

    /**
     * Remove featured image from post
     *
     * @param int $postId Post ID
     * @param \WP_Post $post Post object
     * @return array<string, mixed>
     */
    private function removeFeaturedImage(int $postId, \WP_Post $post): array
    {
        $this->logger->info('Removing featured image', ['post_id' => $postId]);

        // Check if post has featured image
        if (!$this->wp->hasPostThumbnail($postId)) {
            throw ToolException::wordpressError("Post does not have a featured image");
        }

        $result = $this->wp->deletePostThumbnail($postId);

        if (!$result) {
            throw ToolException::wordpressError("Failed to remove featured image");
        }

        return $this->success([
            'post_id' => $postId,
            'post_title' => $post->post_title,
            'featured_image_removed' => true,
        ], "Featured image removed successfully");
    }

    /**
     * {@inheritdoc}
     */
    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }
}
