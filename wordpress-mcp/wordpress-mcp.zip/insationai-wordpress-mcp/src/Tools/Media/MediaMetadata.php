<?php
/**
 * Media Metadata Tool
 *
 * @package WordpressMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- This tool returns JSON API responses, not HTML output
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Media;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

/**
 * Tool to get and update media metadata
 *
 * Manages alt text, captions, descriptions, and other attachment metadata
 */
class MediaMetadata extends AbstractTool
{
    /**
     * {@inheritdoc}
     */
    public function getName(): string
    {
        return 'media_metadata';
    }

    /**
     * {@inheritdoc}
     */
    public function getDescription(): string
    {
        return 'Get or update media metadata including alt text, caption, description, title. '
            . 'Returns full attachment information with file sizes, dimensions, and available image sizes.';
    }

    /**
     * {@inheritdoc}
     */
    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['get', 'update']]
            ],
            'attachment_id' => [
                'required',
                'int',
                ['min' => 1]
            ],
            'title' => [
                'optional',
                'string'
            ],
            'alt_text' => [
                'optional',
                'string'
            ],
            'caption' => [
                'optional',
                'string'
            ],
            'description' => [
                'optional',
                'string'
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $attachmentId = $parameters['attachment_id'];

        // Verify attachment exists
        $attachment = $this->wp->getPost($attachmentId);
        if ($attachment === null || $attachment->post_type !== 'attachment') {
            throw ToolException::wordpressError(
                "Attachment with ID {$attachmentId} not found"
            );
        }

        switch ($action) {
            case 'get':
                return $this->getMetadata($attachmentId, $attachment);

            case 'update':
                return $this->updateMetadata($attachmentId, $attachment, $parameters);

            default:
                throw ToolException::validationError("Invalid action: {$action}");
        }
    }

    /**
     * Get attachment metadata
     *
     * @param int $attachmentId Attachment ID
     * @param \WP_Post $attachment Attachment post object
     * @return array<string, mixed>
     */
    private function getMetadata(int $attachmentId, \WP_Post $attachment): array
    {
        $this->logger->info('Getting media metadata', ['attachment_id' => $attachmentId]);

        $metadata = $this->wp->getAttachmentMetadata($attachmentId);
        $altText = $this->wp->getPostMeta($attachmentId, '_wp_attachment_image_alt', true);
        $fullUrl = $this->wp->getAttachmentUrl($attachmentId, 'full');

        $response = [
            'id' => $attachmentId,
            'title' => $attachment->post_title,
            'file_name' => basename($attachment->guid),
            'mime_type' => $attachment->post_mime_type,
            'url' => $fullUrl,
            'caption' => $attachment->post_excerpt,
            'description' => $attachment->post_content,
            'alt_text' => $altText ?: '',
            'uploaded' => $attachment->post_date,
            'modified' => $attachment->post_modified,
            'author_id' => $attachment->post_author,
            'parent_id' => $attachment->post_parent,
        ];

        // Add parent post info if attached
        if ($attachment->post_parent > 0) {
            $parent = $this->wp->getPost($attachment->post_parent);
            if ($parent) {
                $response['parent'] = [
                    'id' => $parent->ID,
                    'title' => $parent->post_title,
                    'type' => $parent->post_type,
                    'url' => $this->wp->getPermalink($parent->ID),
                ];
            }
        }

        // Add image-specific metadata
        if ($metadata && is_array($metadata)) {
            if (isset($metadata['width'])) {
                $response['width'] = $metadata['width'];
            }
            if (isset($metadata['height'])) {
                $response['height'] = $metadata['height'];
            }
            if (isset($metadata['file'])) {
                $response['file_path'] = $metadata['file'];
            }
            if (isset($metadata['filesize'])) {
                $response['file_size'] = $metadata['filesize'];
            }

            // Add available sizes
            if (isset($metadata['sizes']) && is_array($metadata['sizes'])) {
                $response['sizes'] = [];
                foreach ($metadata['sizes'] as $size => $sizeData) {
                    $sizeUrl = $this->wp->getAttachmentUrl($attachmentId, $size);
                    $response['sizes'][$size] = [
                        'url' => $sizeUrl,
                        'width' => $sizeData['width'] ?? null,
                        'height' => $sizeData['height'] ?? null,
                        'file' => $sizeData['file'] ?? null,
                        'filesize' => $sizeData['filesize'] ?? null,
                        'mime_type' => $sizeData['mime-type'] ?? null,
                    ];
                }
            }

            // Add image meta if available
            if (isset($metadata['image_meta']) && is_array($metadata['image_meta'])) {
                $response['image_meta'] = array_filter($metadata['image_meta'], function ($value) {
                    return !empty($value) || $value === 0;
                });
            }
        }

        return $this->success($response, 'Media metadata retrieved successfully');
    }

    /**
     * Update attachment metadata
     *
     * @param int $attachmentId Attachment ID
     * @param \WP_Post $attachment Attachment post object
     * @param array<string, mixed> $parameters Tool parameters
     * @return array<string, mixed>
     */
    private function updateMetadata(int $attachmentId, \WP_Post $attachment, array $parameters): array
    {
        $this->logger->info('Updating media metadata', ['attachment_id' => $attachmentId]);

        $updated = [];

        // Update title
        if (isset($parameters['title'])) {
            $result = $this->wp->updatePost([
                'ID' => $attachmentId,
                'post_title' => $parameters['title'],
            ]);
            if (!$this->wp->isError($result)) {
                $updated[] = 'title';
            }
        }

        // Update caption (post_excerpt)
        if (isset($parameters['caption'])) {
            $result = $this->wp->updatePost([
                'ID' => $attachmentId,
                'post_excerpt' => $parameters['caption'],
            ]);
            if (!$this->wp->isError($result)) {
                $updated[] = 'caption';
            }
        }

        // Update description (post_content)
        if (isset($parameters['description'])) {
            $result = $this->wp->updatePost([
                'ID' => $attachmentId,
                'post_content' => $parameters['description'],
            ]);
            if (!$this->wp->isError($result)) {
                $updated[] = 'description';
            }
        }

        // Update alt text (post meta)
        if (isset($parameters['alt_text'])) {
            $result = $this->wp->updatePostMeta($attachmentId, '_wp_attachment_image_alt', $parameters['alt_text']);
            if (!$this->wp->isError($result)) {
                $updated[] = 'alt_text';
            }
        }

        if (empty($updated)) {
            throw ToolException::validationError('No metadata fields provided to update');
        }

        // Get updated attachment
        $updatedAttachment = $this->wp->getPost($attachmentId);
        $metadata = $this->wp->getAttachmentMetadata($attachmentId);
        $altText = $this->wp->getPostMeta($attachmentId, '_wp_attachment_image_alt', true);
        $fullUrl = $this->wp->getAttachmentUrl($attachmentId, 'full');

        return $this->success([
            'id' => $attachmentId,
            'title' => $updatedAttachment->post_title,
            'url' => $fullUrl,
            'caption' => $updatedAttachment->post_excerpt,
            'description' => $updatedAttachment->post_content,
            'alt_text' => $altText ?: '',
            'updated_fields' => $updated,
            'modified' => $updatedAttachment->post_modified,
        ], 'Media metadata updated successfully');
    }

    /**
     * {@inheritdoc}
     */
    public function getRequiredScope(): string
    {
        // Default to write scope since most operations update metadata
        return 'mcp:write';
    }
}
