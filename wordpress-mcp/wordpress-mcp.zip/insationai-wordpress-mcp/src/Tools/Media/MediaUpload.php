<?php
/**
 * Media Upload Tool
 *
 * @package WordpressMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- This tool returns JSON API responses, not HTML output
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Media;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

/**
 * Tool to upload media files from URL or base64
 *
 * Supports uploading images, videos, documents from external URLs or base64-encoded data
 */
class MediaUpload extends AbstractTool
{
    /**
     * {@inheritdoc}
     */
    public function getName(): string
    {
        return 'media_upload';
    }

    /**
     * {@inheritdoc}
     */
    public function getDescription(): string
    {
        return 'Upload media files from URL or base64-encoded data. '
            . 'Supports images, videos, and documents. Returns attachment ID and URLs.';
    }

    /**
     * {@inheritdoc}
     */
    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['upload_from_url', 'upload_from_base64']]
            ],
            'url' => [
                'optional',
                'string',
                ['notEmpty' => true]
            ],
            'base64_content' => [
                'optional',
                'string',
                ['notEmpty' => true]
            ],
            'file_name' => [
                'optional',
                'string'
            ],
            'title' => [
                'optional',
                'string'
            ],
            'alt_text' => [
                'optional',
                'string'
            ],
            'caption' => [
                'optional',
                'string'
            ],
            'description' => [
                'optional',
                'string'
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    protected function doExecute(array $parameters): array
    {
        $this->checkSafeMode('Media upload operation');

        $action = $parameters['action'];

        switch ($action) {
            case 'upload_from_url':
                return $this->uploadFromUrl($parameters);

            case 'upload_from_base64':
                return $this->uploadFromBase64($parameters);

            default:
                throw ToolException::validationError("Invalid action: {$action}");
        }
    }

    /**
     * Upload media from URL
     *
     * @param array<string, mixed> $parameters Tool parameters
     * @return array<string, mixed>
     */
    private function uploadFromUrl(array $parameters): array
    {
        if (empty($parameters['url'])) {
            throw ToolException::validationError('URL is required for upload_from_url action');
        }

        $url = $parameters['url'];

        // Validate URL
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw ToolException::validationError('Invalid URL provided');
        }

        // Prepare attachment data
        $attachmentData = [];
        if (isset($parameters['title'])) {
            $attachmentData['post_title'] = $parameters['title'];
        }
        if (isset($parameters['caption'])) {
            $attachmentData['post_excerpt'] = $parameters['caption'];
        }
        if (isset($parameters['description'])) {
            $attachmentData['post_content'] = $parameters['description'];
        }

        // Upload file
        $this->logger->info('Uploading media from URL', ['url' => $url]);

        $attachmentId = $this->wp->uploadMediaFromUrl($url, $attachmentData);

        if ($this->wp->isError($attachmentId)) {
            throw ToolException::wordpressError(
                "Failed to upload media from URL: " . $attachmentId->get_error_message()
            );
        }

        // Set alt text if provided
        if (isset($parameters['alt_text'])) {
            $this->wp->updatePostMeta($attachmentId, '_wp_attachment_image_alt', $parameters['alt_text']);
        }

        // Get attachment details
        $attachment = $this->wp->getPost($attachmentId);
        $metadata = $this->wp->getAttachmentMetadata($attachmentId);

        return $this->success($this->formatAttachment($attachment, $metadata), 'Media uploaded successfully from URL');
    }

    /**
     * Upload media from base64
     *
     * @param array<string, mixed> $parameters Tool parameters
     * @return array<string, mixed>
     */
    private function uploadFromBase64(array $parameters): array
    {
        if (empty($parameters['base64_content'])) {
            throw ToolException::validationError('base64_content is required for upload_from_base64 action');
        }

        if (empty($parameters['file_name'])) {
            throw ToolException::validationError('file_name is required for upload_from_base64 action');
        }

        $base64Content = $parameters['base64_content'];
        $fileName = $parameters['file_name'];

        // Prepare attachment data
        $attachmentData = [];
        if (isset($parameters['title'])) {
            $attachmentData['post_title'] = $parameters['title'];
        }
        if (isset($parameters['caption'])) {
            $attachmentData['post_excerpt'] = $parameters['caption'];
        }
        if (isset($parameters['description'])) {
            $attachmentData['post_content'] = $parameters['description'];
        }

        // Upload file
        $this->logger->info('Uploading media from base64', ['file_name' => $fileName]);

        $attachmentId = $this->wp->uploadMediaFromBase64($base64Content, $fileName, $attachmentData);

        if ($this->wp->isError($attachmentId)) {
            throw ToolException::wordpressError(
                "Failed to upload media from base64: " . $attachmentId->get_error_message()
            );
        }

        // Set alt text if provided
        if (isset($parameters['alt_text'])) {
            $this->wp->updatePostMeta($attachmentId, '_wp_attachment_image_alt', $parameters['alt_text']);
        }

        // Get attachment details
        $attachment = $this->wp->getPost($attachmentId);
        $metadata = $this->wp->getAttachmentMetadata($attachmentId);

        return $this->success($this->formatAttachment($attachment, $metadata), 'Media uploaded successfully from base64');
    }

    /**
     * Format attachment data for response
     *
     * @param \WP_Post $attachment Attachment post
     * @param array<string, mixed>|false $metadata Attachment metadata
     * @return array<string, mixed>
     */
    private function formatAttachment(\WP_Post $attachment, array|false $metadata): array
    {
        $fullUrl = $this->wp->getAttachmentUrl($attachment->ID, 'full');
        $altText = $this->wp->getPostMeta($attachment->ID, '_wp_attachment_image_alt', true);

        $response = [
            'id' => $attachment->ID,
            'title' => $attachment->post_title,
            'file_name' => basename($attachment->guid),
            'mime_type' => $attachment->post_mime_type,
            'url' => $fullUrl,
            'caption' => $attachment->post_excerpt,
            'description' => $attachment->post_content,
            'alt_text' => $altText ?: '',
            'uploaded' => $attachment->post_date,
        ];

        // Add image-specific metadata
        if ($metadata && is_array($metadata)) {
            if (isset($metadata['width'])) {
                $response['width'] = $metadata['width'];
            }
            if (isset($metadata['height'])) {
                $response['height'] = $metadata['height'];
            }
            if (isset($metadata['file'])) {
                $response['file_path'] = $metadata['file'];
            }
            if (isset($metadata['filesize'])) {
                $response['file_size'] = $metadata['filesize'];
            }

            // Add available sizes
            if (isset($metadata['sizes']) && is_array($metadata['sizes'])) {
                $response['sizes'] = [];
                foreach ($metadata['sizes'] as $size => $sizeData) {
                    $sizeUrl = $this->wp->getAttachmentUrl($attachment->ID, $size);
                    $response['sizes'][$size] = [
                        'url' => $sizeUrl,
                        'width' => $sizeData['width'] ?? null,
                        'height' => $sizeData['height'] ?? null,
                        'file' => $sizeData['file'] ?? null,
                    ];
                }
            }
        }

        return $response;
    }

    /**
     * {@inheritdoc}
     */
    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }
}
