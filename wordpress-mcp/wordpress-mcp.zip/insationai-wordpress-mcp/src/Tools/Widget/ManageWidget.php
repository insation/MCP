<?php
/**
 * Manage Widget Tool — add, update, or remove classic widgets in a sidebar.
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Widget;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageWidget extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_widget';
    }

    public function getDescription(): string
    {
        return 'Add, update, or remove a classic widget instance. For action=add, supply base_id (e.g. text, calendar) and settings_json. For update/remove, supply widget_id (e.g. text-3).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['add', 'update', 'remove']],
            ],
            'sidebar_id' => [
                'optional',
                'string',
                'description' => 'Target sidebar (required for add). Use wp_inactive_widgets to store without rendering.'
            ],
            'base_id' => [
                'optional',
                'string',
                'description' => 'Widget base ID (e.g. text, calendar, recent-posts). Required for action=add.'
            ],
            'widget_id' => [
                'optional',
                'string',
                'description' => 'Full widget instance ID (e.g. text-3). Required for update/remove.'
            ],
            'settings_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded settings object for the widget instance.'
            ],
            'position' => [
                'optional',
                'int',
                'description' => 'For action=add, zero-based insertion position. Default: append to end.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $sidebars_widgets = wp_get_sidebars_widgets();

        switch ($action) {
            case 'add':
                if (empty($parameters['sidebar_id']) || empty($parameters['base_id'])) {
                    throw ToolException::wordpressError("'sidebar_id' and 'base_id' are required for action=add");
                }
                $base = $parameters['base_id'];
                $settings = $this->decodeSettings($parameters['settings_json'] ?? null);

                // Determine next instance number
                $existing = get_option("widget_{$base}", []);
                if (!is_array($existing)) {
                    $existing = [];
                }
                $next = 1;
                while (isset($existing[$next])) {
                    $next++;
                }
                $existing[$next] = $settings;
                if (!isset($existing['_multiwidget'])) {
                    $existing['_multiwidget'] = 1;
                }
                update_option("widget_{$base}", $existing);

                $widget_id = "{$base}-{$next}";

                if (!isset($sidebars_widgets[$parameters['sidebar_id']]) || !is_array($sidebars_widgets[$parameters['sidebar_id']])) {
                    $sidebars_widgets[$parameters['sidebar_id']] = [];
                }
                if (isset($parameters['position'])) {
                    array_splice($sidebars_widgets[$parameters['sidebar_id']], (int) $parameters['position'], 0, [$widget_id]);
                } else {
                    $sidebars_widgets[$parameters['sidebar_id']][] = $widget_id;
                }
                wp_set_sidebars_widgets($sidebars_widgets);

                return $this->success([
                    'widget_id'  => $widget_id,
                    'sidebar_id' => $parameters['sidebar_id'],
                    'settings'   => $settings,
                ], 'Widget added.');

            case 'update':
                if (empty($parameters['widget_id'])) {
                    throw ToolException::wordpressError("'widget_id' is required for action=update");
                }
                $parts = explode('-', $parameters['widget_id']);
                $number = (int) array_pop($parts);
                $base   = implode('-', $parts);
                $settings = $this->decodeSettings($parameters['settings_json'] ?? null);

                $existing = get_option("widget_{$base}", []);
                if (!isset($existing[$number])) {
                    throw ToolException::wordpressError("Widget not found: {$parameters['widget_id']}");
                }
                $existing[$number] = $settings;
                update_option("widget_{$base}", $existing);

                return $this->success([
                    'widget_id' => $parameters['widget_id'],
                    'settings'  => $settings,
                ], 'Widget updated.');

            case 'remove':
                $this->checkSafeMode('removing widgets');
                if (empty($parameters['widget_id'])) {
                    throw ToolException::wordpressError("'widget_id' is required for action=remove");
                }
                $widget_id = $parameters['widget_id'];

                $found_in = null;
                foreach ($sidebars_widgets as $sid => &$ids) {
                    if (!is_array($ids)) {
                        continue;
                    }
                    $pos = array_search($widget_id, $ids, true);
                    if ($pos !== false) {
                        array_splice($ids, $pos, 1);
                        $found_in = $sid;
                        break;
                    }
                }
                unset($ids);

                if ($found_in === null) {
                    throw ToolException::wordpressError("Widget {$widget_id} not found in any sidebar.");
                }
                wp_set_sidebars_widgets($sidebars_widgets);

                // Also drop the settings entry
                $parts = explode('-', $widget_id);
                $number = (int) array_pop($parts);
                $base   = implode('-', $parts);
                $existing = get_option("widget_{$base}", []);
                unset($existing[$number]);
                update_option("widget_{$base}", $existing);

                return $this->success([
                    'widget_id'         => $widget_id,
                    'removed_from'      => $found_in,
                ], 'Widget removed.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }

    private function decodeSettings(?string $json): array
    {
        if ($json === null || $json === '') {
            return [];
        }
        $decoded = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in settings_json: ' . json_last_error_msg());
        }
        return is_array($decoded) ? $decoded : [];
    }
}
