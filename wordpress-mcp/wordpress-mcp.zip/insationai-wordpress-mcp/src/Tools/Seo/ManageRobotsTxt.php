<?php
/**
 * Manage Robots.txt Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Seo;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageRobotsTxt extends AbstractTool
{
    /**
     * Option key used to store a custom robots.txt body.
     */
    private const OPTION = 'insationai_wpmcp_robots_txt';

    public function getName(): string
    {
        return 'manage_robots_txt';
    }

    public function getDescription(): string
    {
        return 'Read, set, clear, or preview the site\'s robots.txt. WordPress generates a virtual robots.txt by default; this tool stores a custom body in an option and serves it via the robots_txt filter when one is set.';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['get', 'preview', 'set', 'clear']],
            ],
            'content' => [
                'optional',
                'string',
                'description' => 'For action=set: the raw robots.txt body.'
            ],
        ];
    }

    public function getRequiredScope(): string
    {
        return 'mcp:read';
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];

        if (in_array($action, ['set', 'clear'], true)) {
            $scopes = $this->userContext['scopes'] ?? [];
            if ($this->userContext !== null && !in_array('mcp:admin', $scopes, true)) {
                throw ToolException::insufficientPermissions("action={$action} requires mcp:admin scope.");
            }
        }

        switch ($action) {
            case 'get':
                $custom = get_option(self::OPTION, '');
                return $this->success([
                    'has_custom' => $custom !== '',
                    'custom'     => $custom,
                ]);

            case 'preview':
                // Render the actual robots.txt body WP would emit right now.
                // Bypass the filter we install in the plugin to get core's view first.
                $public = (int) get_option('blog_public');
                if ($public === 0) {
                    $body = "User-agent: *\nDisallow: /\n";
                } else {
                    $site_url = wp_parse_url(site_url());
                    $path = (!empty($site_url['path'])) ? $site_url['path'] : '';
                    $body  = "User-agent: *\n";
                    $body .= "Disallow: {$path}/wp-admin/\n";
                    $body .= "Allow: {$path}/wp-admin/admin-ajax.php\n";
                    if (function_exists('wp_sitemaps_get_server')) {
                        $body .= "\nSitemap: " . esc_url(home_url('/wp-sitemap.xml')) . "\n";
                    }
                }
                $body = apply_filters('robots_txt', $body, $public);
                return $this->success([
                    'body' => $body,
                ]);

            case 'set':
                if (!isset($parameters['content'])) {
                    throw ToolException::wordpressError("'content' is required for action=set");
                }
                update_option(self::OPTION, (string) $parameters['content']);
                return $this->success([
                    'bytes' => strlen((string) $parameters['content']),
                ], 'Custom robots.txt stored. Will be served via the robots_txt filter on next render.');

            case 'clear':
                $this->checkSafeMode('clearing custom robots.txt');
                delete_option(self::OPTION);
                return $this->success([], 'Custom robots.txt cleared. WordPress will resume serving the default.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
