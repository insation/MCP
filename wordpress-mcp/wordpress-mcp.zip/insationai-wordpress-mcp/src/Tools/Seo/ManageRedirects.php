<?php
/**
 * Manage Redirects Tool
 *
 * Maintains a list of source → destination redirect rules stored in a single
 * option. A companion template_redirect hook applies them at request time.
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Seo;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ManageRedirects extends AbstractTool
{
    public const OPTION = 'insationai_wpmcp_redirects';

    public function getName(): string
    {
        return 'manage_redirects';
    }

    public function getDescription(): string
    {
        return 'Maintain a simple list of URL redirects. Stored as a single option and applied at template_redirect time by the plugin. Supports exact-match source paths and 301/302/307/308 status codes.';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['list', 'add', 'remove', 'clear']],
            ],
            'source' => [
                'optional',
                'string',
                'description' => 'For add/remove: source path (e.g. "/old-page"). Leading slash recommended.'
            ],
            'target' => [
                'optional',
                'string',
                'description' => 'For add: destination URL or path.'
            ],
            'status' => [
                'optional',
                'int',
                ['in' => [301, 302, 307, 308]],
                'description' => 'HTTP status code. Default 301.'
            ],
        ];
    }

    public function getRequiredScope(): string
    {
        return 'mcp:read';
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];

        if (in_array($action, ['add', 'remove', 'clear'], true)) {
            $scopes = $this->userContext['scopes'] ?? [];
            $hasWrite = in_array('mcp:write', $scopes, true) || in_array('mcp:admin', $scopes, true);
            if ($this->userContext !== null && !$hasWrite) {
                throw ToolException::insufficientPermissions("action={$action} requires mcp:write or mcp:admin scope.");
            }
        }

        $redirects = get_option(self::OPTION, []);
        if (!is_array($redirects)) {
            $redirects = [];
        }

        switch ($action) {
            case 'list':
                return $this->success([
                    'count' => count($redirects),
                    'items' => array_values($redirects),
                ]);

            case 'add':
                if (empty($parameters['source']) || empty($parameters['target'])) {
                    throw ToolException::wordpressError("'source' and 'target' are required for action=add");
                }
                $source = '/' . ltrim($parameters['source'], '/');
                $entry = [
                    'source' => $source,
                    'target' => esc_url_raw($parameters['target']),
                    'status' => (int) ($parameters['status'] ?? 301),
                ];
                // Replace any existing rule with same source
                $redirects = array_values(array_filter(
                    $redirects,
                    static fn($r) => is_array($r) && ($r['source'] ?? null) !== $source
                ));
                $redirects[] = $entry;
                update_option(self::OPTION, $redirects);
                return $this->success([
                    'count' => count($redirects),
                    'added' => $entry,
                ], 'Redirect added.');

            case 'remove':
                $this->checkSafeMode('removing redirects');
                if (empty($parameters['source'])) {
                    throw ToolException::wordpressError("'source' is required for action=remove");
                }
                $source = '/' . ltrim($parameters['source'], '/');
                $before = count($redirects);
                $redirects = array_values(array_filter(
                    $redirects,
                    static fn($r) => is_array($r) && ($r['source'] ?? null) !== $source
                ));
                update_option(self::OPTION, $redirects);
                return $this->success([
                    'count'   => count($redirects),
                    'removed' => $before - count($redirects),
                ], 'Redirect removed.');

            case 'clear':
                $this->checkSafeMode('clearing all redirects');
                update_option(self::OPTION, []);
                return $this->success([
                    'cleared' => count($redirects),
                ], 'All redirects cleared.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
