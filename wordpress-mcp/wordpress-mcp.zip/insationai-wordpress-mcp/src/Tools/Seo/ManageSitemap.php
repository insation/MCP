<?php
/**
 * Manage Sitemap Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Seo;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class ManageSitemap extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_sitemap';
    }

    public function getDescription(): string
    {
        return 'Inspect WordPress\'s core XML sitemap or return URLs of all sub-sitemaps. WP 5.5+ ships with a built-in sitemap at /wp-sitemap.xml organized by post type and taxonomy. This tool does not currently write sitemap config — most sites use a plugin like Yoast or Rank Math for that, and replacing the core sitemap is a theme/plugin-level concern.';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['get', 'list_subsitemaps']],
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];

        if (!function_exists('wp_sitemaps_get_server')) {
            return $this->success([
                'available' => false,
                'reason'    => 'Core WordPress sitemaps API is not available on this WP version (requires 5.5+).',
            ]);
        }

        $server = wp_sitemaps_get_server();
        if (!$server) {
            return $this->success([
                'available' => false,
                'reason'    => 'Sitemap server could not be initialized (possibly disabled by a filter).',
            ]);
        }

        if ($action === 'get') {
            return $this->success([
                'available' => true,
                'index_url' => esc_url_raw(home_url('/wp-sitemap.xml')),
                'enabled'   => (bool) apply_filters('wp_sitemaps_enabled', true),
                'max_urls_per_sitemap' => (int) apply_filters('wp_sitemaps_max_urls', 2000),
            ]);
        }

        // list_subsitemaps — enumerate provider/sub-type permutations
        $registry = $server->registry;
        $providers = $registry->get_providers();

        $items = [];
        foreach ($providers as $provider_name => $provider) {
            $object_subtypes = method_exists($provider, 'get_object_subtypes') ? $provider->get_object_subtypes() : [];
            if (empty($object_subtypes)) {
                $items[] = [
                    'provider' => $provider_name,
                    'subtype'  => null,
                    'url'      => esc_url_raw($provider->get_sitemap_url(null, 1) ?: ''),
                ];
                continue;
            }
            foreach (array_keys($object_subtypes) as $subtype) {
                $items[] = [
                    'provider' => $provider_name,
                    'subtype'  => $subtype,
                    'url'      => esc_url_raw($provider->get_sitemap_url($subtype, 1) ?: ''),
                ];
            }
        }

        return $this->success([
            'available' => true,
            'index_url' => esc_url_raw(home_url('/wp-sitemap.xml')),
            'count'     => count($items),
            'items'     => $items,
        ]);
    }
}
