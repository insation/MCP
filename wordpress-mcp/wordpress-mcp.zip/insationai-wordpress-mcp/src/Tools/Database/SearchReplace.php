<?php
/**
 * Search Replace Tool
 *
 * Safe-ish wp_options-only search/replace. Specifically excludes the posts
 * table by default because serialized post meta needs careful unserialization
 * handling that's well beyond this tool's scope — pass `include_postmeta=true`
 * to opt in to limited postmeta replacement (string values only).
 *
 * For full-site URL migrations, the WP-CLI tool `wp search-replace` is still
 * the right call; this tool covers the common case of "I updated the site URL
 * and now my options are stale".
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Database;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class SearchReplace extends AbstractTool
{
    public function getName(): string
    {
        return 'search_replace';
    }

    public function getDescription(): string
    {
        return 'Search-and-replace strings in wp_options (and optionally postmeta string values). Serialized data is unserialized, replaced, and re-serialized. Always run with dry_run=true first to preview the impact.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'search' => [
                'required',
                'string',
                ['notEmpty' => true],
            ],
            'replace' => [
                'required',
                'string',
            ],
            'dry_run' => [
                'optional',
                'bool',
                'description' => 'When true, count matches without writing changes. Default true.'
            ],
            'include_postmeta' => [
                'optional',
                'bool',
                'description' => 'Also process postmeta. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $search = $parameters['search'];
        $replace = $parameters['replace'];
        $dryRun = $parameters['dry_run'] ?? true;
        $includePostmeta = !empty($parameters['include_postmeta']);

        if ($dryRun === false) {
            $this->checkSafeMode('database search-replace writes');
        }

        $matched_options  = 0;
        $changed_options  = 0;
        $matched_postmeta = 0;
        $changed_postmeta = 0;

        // OPTIONS
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT option_id, option_name, option_value FROM {$wpdb->options}
             WHERE option_value LIKE %s",
            '%' . $wpdb->esc_like($search) . '%'
        ), ARRAY_A);

        foreach ($rows as $r) {
            $matched_options++;
            if ($dryRun) {
                continue;
            }
            $newVal = $this->recursiveReplace($r['option_value'], $search, $replace);
            if ($newVal !== $r['option_value']) {
                $wpdb->update(
                    $wpdb->options,
                    ['option_value' => $newVal],
                    ['option_id' => (int) $r['option_id']]
                );
                $changed_options++;
            }
        }

        // POSTMETA (string values only, opt-in)
        if ($includePostmeta) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT meta_id, meta_value FROM {$wpdb->postmeta}
                 WHERE meta_value LIKE %s",
                '%' . $wpdb->esc_like($search) . '%'
            ), ARRAY_A);

            foreach ($rows as $r) {
                $matched_postmeta++;
                if ($dryRun) {
                    continue;
                }
                $newVal = $this->recursiveReplace($r['meta_value'], $search, $replace);
                if ($newVal !== $r['meta_value']) {
                    $wpdb->update(
                        $wpdb->postmeta,
                        ['meta_value' => $newVal],
                        ['meta_id' => (int) $r['meta_id']]
                    );
                    $changed_postmeta++;
                }
            }
        }

        return $this->success([
            'dry_run'           => $dryRun,
            'search'            => $search,
            'replace'           => $replace,
            'matched_options'   => $matched_options,
            'changed_options'   => $changed_options,
            'matched_postmeta'  => $matched_postmeta,
            'changed_postmeta'  => $changed_postmeta,
            'include_postmeta'  => $includePostmeta,
        ], $dryRun ? 'Dry run complete. Re-run with dry_run=false to apply.' : 'Search-replace applied.');
    }

    /**
     * Recursively str_replace within a value, handling serialized payloads safely.
     */
    private function recursiveReplace($value, string $search, string $replace)
    {
        if (is_string($value)) {
            // Detect serialized data
            $unserialized = @unserialize($value, ['allowed_classes' => false]);
            if ($unserialized !== false || $value === 'b:0;') {
                $rewritten = $this->recursiveReplace($unserialized, $search, $replace);
                return serialize($rewritten);
            }
            return str_replace($search, $replace, $value);
        }
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                $out[$k] = $this->recursiveReplace($v, $search, $replace);
            }
            return $out;
        }
        if (is_object($value)) {
            // Convert to array, replace, return original object class with replaced props
            // For simplicity we only handle stdClass-like objects safely
            $vars = get_object_vars($value);
            $newVars = [];
            foreach ($vars as $k => $v) {
                $newVars[$k] = $this->recursiveReplace($v, $search, $replace);
            }
            $obj = (object) $newVars;
            return $obj;
        }
        return $value;
    }
}
