<?php
/**
 * Repair Tables Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Database;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class RepairTables extends AbstractTool
{
    public function getName(): string
    {
        return 'repair_tables';
    }

    public function getDescription(): string
    {
        return 'Run REPAIR TABLE against database tables. Useful after crashes or corruption. Note: REPAIR only works on MyISAM/ARIA tables; InnoDB tables will return an "is not BASE TABLE" error which the tool reports rather than throws.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'tables' => [
                'required',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Table names to repair.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $results = [];
        foreach ($parameters['tables'] as $t) {
            if (!preg_match('/^[A-Za-z0-9_]+$/', $t)) {
                $results[] = ['table' => $t, 'status' => 'skipped', 'message' => 'invalid name'];
                continue;
            }
            $row = $wpdb->get_row("REPAIR TABLE `{$t}`", ARRAY_A);
            $results[] = [
                'table'   => $t,
                'status'  => $row['Msg_type'] ?? 'unknown',
                'message' => $row['Msg_text'] ?? '',
            ];
        }

        return $this->success([
            'count'   => count($results),
            'results' => $results,
        ], 'Repair complete.');
    }
}
