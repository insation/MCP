<?php
/**
 * DB Table Info Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Database;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class DbTableInfo extends AbstractTool
{
    public function getName(): string
    {
        return 'db_table_info';
    }

    public function getDescription(): string
    {
        return 'Inspect database tables. action=list returns every table with row counts and sizes. action=describe returns column definitions for a specific table.';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['list', 'describe']],
            ],
            'table' => [
                'optional',
                'string',
                'description' => 'Required for action=describe.'
            ],
            'prefix_only' => [
                'optional',
                'bool',
                'description' => 'For action=list: include only tables under the WP prefix. Default true.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        if ($parameters['action'] === 'list') {
            $prefixOnly = $parameters['prefix_only'] ?? true;
            $like = $prefixOnly ? ($wpdb->esc_like($wpdb->prefix) . '%') : '%';

            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT TABLE_NAME AS name,
                        TABLE_ROWS AS row_count,
                        DATA_LENGTH AS data_size,
                        INDEX_LENGTH AS index_size,
                        ENGINE AS engine,
                        TABLE_COLLATION AS collation
                 FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s
                 ORDER BY TABLE_NAME",
                DB_NAME,
                $like
            ), ARRAY_A);

            if ($wpdb->last_error) {
                throw ToolException::wordpressError("SQL error: {$wpdb->last_error}");
            }

            return $this->success([
                'database' => DB_NAME,
                'prefix'   => $wpdb->prefix,
                'count'    => is_array($rows) ? count($rows) : 0,
                'items'    => array_map(static fn($r) => [
                    'name'       => $r['name'],
                    'row_count'  => (int) $r['row_count'],
                    'data_size'  => (int) $r['data_size'],
                    'index_size' => (int) $r['index_size'],
                    'engine'     => $r['engine'],
                    'collation'  => $r['collation'],
                ], (array) $rows),
            ]);
        }

        // action=describe
        if (empty($parameters['table'])) {
            throw ToolException::wordpressError("'table' is required for action=describe");
        }
        $table = $parameters['table'];

        // Sanity-check: only alphanumeric/underscore — protects against injection in the DESCRIBE
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
            throw ToolException::wordpressError('Table name must be alphanumeric/underscores only.');
        }

        $columns = $wpdb->get_results("DESCRIBE `{$table}`", ARRAY_A);
        if ($wpdb->last_error) {
            throw ToolException::wordpressError("SQL error: {$wpdb->last_error}");
        }

        $indexes = $wpdb->get_results("SHOW INDEX FROM `{$table}`", ARRAY_A);

        return $this->success([
            'table'   => $table,
            'columns' => $columns,
            'indexes' => $indexes,
        ]);
    }
}
