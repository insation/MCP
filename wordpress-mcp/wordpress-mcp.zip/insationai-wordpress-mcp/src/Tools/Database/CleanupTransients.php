<?php
/**
 * Cleanup Transients Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Database;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class CleanupTransients extends AbstractTool
{
    public function getName(): string
    {
        return 'cleanup_transients';
    }

    public function getDescription(): string
    {
        return 'Delete expired transients (and optionally all transients) from wp_options. WordPress only purges expired transients opportunistically — they can pile up indefinitely on busy sites. action=count returns sizes; action=delete cleans up.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['count', 'delete']],
            ],
            'mode' => [
                'optional',
                'string',
                ['in' => ['expired', 'all']],
                'description' => 'expired: only remove transients past their expiration. all: remove every transient (forces full re-cache).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $mode = $parameters['mode'] ?? 'expired';

        // Find transient timeout rows
        $now = time();
        if ($mode === 'expired') {
            $timeouts = $wpdb->get_results($wpdb->prepare(
                "SELECT option_name, option_value FROM {$wpdb->options}
                 WHERE option_name LIKE %s AND option_value < %s",
                $wpdb->esc_like('_transient_timeout_') . '%',
                (string) $now
            ), ARRAY_A);
        } else {
            $timeouts = $wpdb->get_results($wpdb->prepare(
                "SELECT option_name, option_value FROM {$wpdb->options}
                 WHERE option_name LIKE %s",
                $wpdb->esc_like('_transient_timeout_') . '%'
            ), ARRAY_A);
        }

        $count = count($timeouts);

        // Also count transients-without-timeout (these never expire)
        $countOrphans = 0;
        if ($mode === 'all') {
            $orphans = $wpdb->get_results($wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options}
                 WHERE option_name LIKE %s
                 AND option_name NOT LIKE %s",
                $wpdb->esc_like('_transient_') . '%',
                $wpdb->esc_like('_transient_timeout_') . '%'
            ), ARRAY_A);
            $countOrphans = count($orphans);
        }

        if ($parameters['action'] === 'count') {
            return $this->success([
                'eligible_with_timeout' => $count,
                'orphan_transients'     => $countOrphans,
                'mode'                  => $mode,
            ]);
        }

        // delete
        $deleted = 0;
        foreach ($timeouts as $row) {
            $name = $row['option_name'];
            $transientName = substr($name, strlen('_transient_timeout_'));
            if (delete_transient($transientName)) {
                $deleted++;
            } else {
                // Force-delete the orphaned timeout row
                delete_option($name);
                delete_option('_transient_' . $transientName);
                $deleted++;
            }
        }

        if ($mode === 'all') {
            // Sweep transients-without-timeout too
            $orphans = $wpdb->get_col($wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options}
                 WHERE option_name LIKE %s
                 AND option_name NOT LIKE %s",
                $wpdb->esc_like('_transient_') . '%',
                $wpdb->esc_like('_transient_timeout_') . '%'
            ));
            foreach ($orphans as $name) {
                delete_option($name);
                $deleted++;
            }
        }

        return $this->success([
            'deleted' => $deleted,
            'mode'    => $mode,
        ], "Deleted {$deleted} transient row(s).");
    }
}
