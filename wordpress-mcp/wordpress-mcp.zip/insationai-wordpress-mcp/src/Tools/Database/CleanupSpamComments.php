<?php
/**
 * Cleanup Spam Comments Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Database;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class CleanupSpamComments extends AbstractTool
{
    public function getName(): string
    {
        return 'cleanup_spam_comments';
    }

    public function getDescription(): string
    {
        return 'Permanently delete spam and trashed comments. action=count returns how many qualify; action=delete actually removes them. Also drops comment meta for the removed rows.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['count', 'delete']],
            ],
            'include_trash' => [
                'optional',
                'bool',
                'description' => 'Also remove trashed comments. Default true.'
            ],
            'older_than_days' => [
                'optional',
                'int',
                ['min' => 0],
                'description' => 'Only operate on comments older than this many days.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $statuses = ['spam'];
        if (($parameters['include_trash'] ?? true)) {
            $statuses[] = 'trash';
            $statuses[] = 'post-trashed';
        }
        $placeholders = implode(',', array_fill(0, count($statuses), '%s'));

        $sql = "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved IN ({$placeholders})";
        $args = $statuses;

        if (!empty($parameters['older_than_days'])) {
            $cutoff = gmdate('Y-m-d H:i:s', time() - ((int) $parameters['older_than_days']) * DAY_IN_SECONDS);
            $sql .= " AND comment_date_gmt < %s";
            $args[] = $cutoff;
        }

        $ids = $wpdb->get_col($wpdb->prepare($sql, $args));
        $count = is_array($ids) ? count($ids) : 0;

        if ($parameters['action'] === 'count') {
            return $this->success([
                'eligible' => $count,
            ]);
        }

        $this->checkSafeMode('deleting spam comments');

        $deleted = 0;
        foreach ($ids as $id) {
            if (wp_delete_comment((int) $id, true)) {
                $deleted++;
            }
        }

        return $this->success([
            'eligible' => $count,
            'deleted'  => $deleted,
        ], "Deleted {$deleted} spam/trash comment(s).");
    }
}
