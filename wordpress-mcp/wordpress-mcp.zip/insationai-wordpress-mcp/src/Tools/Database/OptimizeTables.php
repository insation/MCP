<?php
/**
 * Optimize Tables Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Database;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class OptimizeTables extends AbstractTool
{
    public function getName(): string
    {
        return 'optimize_tables';
    }

    public function getDescription(): string
    {
        return 'Run OPTIMIZE TABLE against database tables to reclaim unused space and update statistics. Defaults to every WP-prefix table. Pass a `tables` list to limit scope.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'tables' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Table names to optimize. Omit for all WP-prefix tables.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $tables = $parameters['tables'] ?? null;
        if (empty($tables)) {
            $tables = $wpdb->get_col($wpdb->prepare(
                "SELECT TABLE_NAME FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s",
                DB_NAME,
                $wpdb->esc_like($wpdb->prefix) . '%'
            ));
        }

        $results = [];
        foreach ($tables as $t) {
            if (!preg_match('/^[A-Za-z0-9_]+$/', $t)) {
                $results[] = ['table' => $t, 'status' => 'skipped', 'message' => 'invalid name'];
                continue;
            }
            $row = $wpdb->get_row("OPTIMIZE TABLE `{$t}`", ARRAY_A);
            $results[] = [
                'table'   => $t,
                'status'  => $row['Msg_type'] ?? 'unknown',
                'message' => $row['Msg_text'] ?? '',
            ];
        }

        return $this->success([
            'count'   => count($results),
            'results' => $results,
        ], 'Optimize complete.');
    }
}
