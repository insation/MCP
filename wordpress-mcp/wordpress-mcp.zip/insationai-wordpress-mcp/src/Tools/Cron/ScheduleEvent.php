<?php
/**
 * Schedule Event Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Cron;

use InsationAI\WordpressMCP\Tools\AbstractTool;
use InsationAI\WordpressMCP\Exceptions\ToolException;

class ScheduleEvent extends AbstractTool
{
    public function getName(): string
    {
        return 'schedule_event';
    }

    public function getDescription(): string
    {
        return 'Schedule a WordPress cron event. For one-off events, omit `schedule`. For recurring events, pass a schedule slug (hourly, twicedaily, daily, weekly, or a custom one).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'hook' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Action hook to fire.'
            ],
            'timestamp' => [
                'optional',
                'int',
                'description' => 'UNIX timestamp for first run. Default: now.'
            ],
            'schedule' => [
                'optional',
                'string',
                'description' => 'Recurring schedule slug. Omit for a one-off event.'
            ],
            'args_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded array of arguments to pass to the hook.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $hook = $parameters['hook'];
        $timestamp = isset($parameters['timestamp']) ? (int) $parameters['timestamp'] : time();

        $args = [];
        if (isset($parameters['args_json'])) {
            $decoded = json_decode($parameters['args_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in args_json: ' . json_last_error_msg());
            }
            if (!is_array($decoded)) {
                throw ToolException::wordpressError('args_json must decode to an array.');
            }
            $args = $decoded;
        }

        if (isset($parameters['schedule'])) {
            $schedules = wp_get_schedules();
            if (!isset($schedules[$parameters['schedule']])) {
                throw ToolException::wordpressError(
                    "Unknown schedule '{$parameters['schedule']}'. Available: " . implode(', ', array_keys($schedules))
                );
            }
            $result = wp_schedule_event($timestamp, $parameters['schedule'], $hook, $args);
            $type = 'recurring';
        } else {
            $result = wp_schedule_single_event($timestamp, $hook, $args);
            $type = 'one-off';
        }

        if (is_wp_error($result) || $result === false) {
            $msg = is_wp_error($result) ? $result->get_error_message() : 'unknown error';
            throw ToolException::wordpressError("Failed to schedule event: {$msg}");
        }

        return $this->success([
            'hook'      => $hook,
            'type'      => $type,
            'schedule'  => $parameters['schedule'] ?? null,
            'timestamp' => $timestamp,
            'next_run'  => gmdate('Y-m-d H:i:s', $timestamp) . ' UTC',
            'args'      => $args,
        ], 'Event scheduled.');
    }
}
