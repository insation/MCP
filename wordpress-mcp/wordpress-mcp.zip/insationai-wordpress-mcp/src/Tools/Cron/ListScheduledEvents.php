<?php
/**
 * List Scheduled Events Tool
 *
 * @package InsationAI\WordpressMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Tools\Cron;

use InsationAI\WordpressMCP\Tools\AbstractTool;

class ListScheduledEvents extends AbstractTool
{
    public function getName(): string
    {
        return 'list_scheduled_events';
    }

    public function getDescription(): string
    {
        return 'List all WordPress cron events with their next-run timestamps, schedules, hooks, and arguments. Optionally filter by hook name.';
    }

    public function getSchema(): array
    {
        return [
            'hook' => [
                'optional',
                'string',
                'description' => 'Filter to events for this hook only.'
            ],
            'overdue_only' => [
                'optional',
                'bool',
                'description' => 'Return only events whose next-run is in the past (i.e. stuck or pending).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $cron = _get_cron_array();
        if (!is_array($cron)) {
            $cron = [];
        }

        $now = time();
        $hookFilter = $parameters['hook'] ?? null;
        $overdueOnly = !empty($parameters['overdue_only']);

        $events = [];
        foreach ($cron as $timestamp => $hooks) {
            if (!is_array($hooks)) {
                continue;
            }
            foreach ($hooks as $hookName => $occurrences) {
                if ($hookFilter && $hookName !== $hookFilter) {
                    continue;
                }
                if (!is_array($occurrences)) {
                    continue;
                }
                foreach ($occurrences as $sig => $occurrence) {
                    if ($overdueOnly && $timestamp >= $now) {
                        continue;
                    }
                    $events[] = [
                        'hook'      => $hookName,
                        'timestamp' => (int) $timestamp,
                        'next_run'  => gmdate('Y-m-d H:i:s', (int) $timestamp) . ' UTC',
                        'overdue_seconds' => max(0, $now - (int) $timestamp),
                        'schedule'  => $occurrence['schedule'] ?? false,
                        'interval'  => $occurrence['interval'] ?? null,
                        'args'      => $occurrence['args'] ?? [],
                        'signature' => $sig,
                    ];
                }
            }
        }

        // Sort by timestamp ascending
        usort($events, static fn($a, $b) => $a['timestamp'] <=> $b['timestamp']);

        return $this->success([
            'count'   => count($events),
            'now'     => $now,
            'now_utc' => gmdate('Y-m-d H:i:s', $now) . ' UTC',
            'items'   => $events,
            'registered_schedules' => array_keys(wp_get_schedules()),
        ]);
    }
}
