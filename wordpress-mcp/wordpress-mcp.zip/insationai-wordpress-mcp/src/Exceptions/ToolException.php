<?php

declare(strict_types=1);

namespace InsationAI\WordpressMCP\Exceptions;

/**
 * Exception thrown by tools during execution
 */
class ToolException extends \Exception
{
    /**
     * Create a validation error exception
     *
     * @param string $message The error message
     * @param array<string, mixed> $errors The validation errors (optional)
     * @return self
     */
    public static function validationFailed(string $message, array $errors = []): self
    {
        $exception = new self($message);
        $exception->errors = $errors;
        return $exception;
    }

    /**
     * Create an execution error exception
     *
     * @param string $message The error message
     * @param array<string, mixed> $errors Additional error details (optional)
     * @return self
     */
    public static function executionFailed(string $message, array $errors = []): self
    {
        $exception = new self("Execution failed: {$message}");
        $exception->errors = $errors;
        return $exception;
    }

    /**
     * Create a not found exception
     *
     * @param string $type The type of resource (e.g., 'post', 'term')
     * @param int|string $id The resource identifier
     * @return self
     */
    public static function notFound(string $type, $id): self
    {
        return new self("{$type} not found with ID: {$id}");
    }

    /**
     * Create a forbidden exception
     *
     * @param string $message The error message
     * @return self
     */
    public static function forbidden(string $message): self
    {
        return new self("Forbidden: {$message}");
    }

    /**
     * Create an insufficient permissions exception
     *
     * @param string $message The error message
     * @return self
     */
    public static function insufficientPermissions(string $message): self
    {
        return new self("Insufficient permissions: {$message}");
    }

    /**
     * Create a WordPress error exception
     *
     * @param string $message The error message
     * @param int $code Error code
     * @return self
     */
    public static function wordpressError(string $message, int $code = 0): self
    {
        return new self("WordPress Error: {$message}", $code);
    }

    /**
     * Create a safe mode violation exception
     *
     * @param string $operation The operation that was blocked
     * @return self
     */
    public static function safeModeViolation(string $operation): self
    {
        $exception = new self(
            "Operation blocked: Safe mode is enabled. {$operation} is not allowed."
        );
        $exception->errors = ['safe_mode' => 'enabled'];
        return $exception;
    }

    /**
     * Validation errors (if any)
     *
     * @var array<string, mixed>
     */
    private array $errors = [];

    /**
     * Get validation errors
     *
     * @return array<string, mixed>
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
}
