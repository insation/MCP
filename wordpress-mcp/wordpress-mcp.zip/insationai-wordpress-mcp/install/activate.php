<?php
/**
 * Plugin Activation
 *
 * Creates necessary database tables and sets default options
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Run plugin activation
 */
function insationai_wpmcp_run_activation() {
    global $wpdb;

    // Validate site authorization first
    if (!class_exists('\InsationAI\WordpressMCP\Validator')) {
        require_once INSATIONAI_WPMCP_PLUGIN_DIR . 'src/Validator.php';
    }

    if (!\InsationAI\WordpressMCP\Validator::isAuthorized()) {
        \InsationAI\WordpressMCP\Validator::logUnauthorizedAttempt('activation');

        // Deactivate the plugin
        deactivate_plugins(plugin_basename(INSATIONAI_WPMCP_PLUGIN_FILE));

        // Display error message
        wp_die(
            \InsationAI\WordpressMCP\Validator::getErrorMessage(),
            'Plugin Activation Error',
            ['back_link' => true]
        );
    }

    $errors = [];

    // Create user tokens table (always needed)
    $tokens_result = insationai_wpmcp_create_user_tokens_table();
    if (!$tokens_result['success']) {
        $errors[] = 'User Tokens Table: ' . $tokens_result['error'];
        // Log to debug.log
        error_log('[WordpressMCP Activation] Failed to create user tokens table: ' . $tokens_result['error']);
    }

    // Only create OAuth tables if feature is enabled
    if (INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED) {
        $oauth_result = insationai_wpmcp_create_oauth_tables();
        if (!$oauth_result['success']) {
            $errors[] = 'OAuth Tables: ' . implode(', ', $oauth_result['errors']);
            // Log to debug.log
            error_log('[WordpressMCP Activation] Failed to create OAuth tables: ' . implode(', ', $oauth_result['errors']));
        }
    }

    // If there were errors, store them for admin notice
    if (!empty($errors)) {
        set_transient('insationai_wpmcp_activation_errors', $errors, 300); // 5 minutes
    }

    // Set default options
    add_option('insationai_wpmcp_endpoint_slug', 'insationai-wordpress-mcp');
    add_option('insationai_wpmcp_safe_mode', true);
    add_option('insationai_wpmcp_oauth_enabled', false);

    // OAuth defaults (only if feature enabled)
    if (INSATIONAI_WPMCP_OAUTH_FEATURE_ENABLED) {
        add_option('insationai_wpmcp_oauth_issuer', home_url('/insationai-wordpress-mcp'));
        add_option('insationai_wpmcp_oauth_resource_identifier', home_url('/insationai-wordpress-mcp'));
        add_option('insationai_wpmcp_oauth_private_key_path', '');
        add_option('insationai_wpmcp_oauth_public_key_path', '');
        add_option('insationai_wpmcp_oauth_access_token_ttl', 3600);
        add_option('insationai_wpmcp_oauth_refresh_token_ttl', 2592000);
        add_option('insationai_wpmcp_oauth_authorization_code_ttl', 600);
    }

    // Create default token for the installing user (only if table was created successfully)
    if ($tokens_result['success']) {
        insationai_wpmcp_create_default_token();
    }

    // Register rewrite rules
    insationai_wpmcp_register_rewrite_rules();

    // Flush rewrite rules to activate our custom endpoints
    flush_rewrite_rules();

    // Store plugin version for upgrade tracking
    update_option('insationai_wpmcp_version', INSATIONAI_WPMCP_VERSION);
}

/**
 * Create user tokens table
 *
 * Stores API tokens tied to WordPress users for simple authentication
 *
 * @return array{success: bool, error: ?string}
 */
function insationai_wpmcp_create_user_tokens_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'insationai_wpmcp_user_tokens';

    $sql = "CREATE TABLE IF NOT EXISTS `{$table_name}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `user_id` bigint(20) unsigned NOT NULL,
        `token_hash` varchar(64) NOT NULL COMMENT 'SHA256 hash of token',
        `label` varchar(255) DEFAULT NULL COMMENT 'User-friendly description',
        `expires_at` datetime DEFAULT NULL COMMENT 'NULL = no expiration',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `last_used_at` datetime DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `token_hash` (`token_hash`),
        KEY `user_id` (`user_id`),
        KEY `expires_at` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Verify table was created
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'");

    if ($table_exists !== $table_name) {
        $error = $wpdb->last_error ?: 'Table creation failed (unknown reason)';
        return [
            'success' => false,
            'error' => $error
        ];
    }

    return [
        'success' => true,
        'error' => null
    ];
}

/**
 * Create default token for the installing user
 */
function insationai_wpmcp_create_default_token() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'insationai_wpmcp_user_tokens';

    $user_id = get_current_user_id();
    $is_cli = defined('WP_CLI') && WP_CLI;
    $preconfigured_token = get_option('instamcp_default_token');

    // Handle WP-CLI activation without user context but with pre-configured token
    if (!$user_id && $is_cli && $preconfigured_token) {
        // Find first administrator user
        $admin_users = get_users([
            'role' => 'administrator',
            'number' => 1,
            'orderby' => 'ID',
            'order' => 'ASC'
        ]);

        if (empty($admin_users)) {
            if ($is_cli) {
                WP_CLI::warning('WordpressMCP: No administrator user found. Token creation skipped.');
            }
            delete_option('instamcp_default_token');
            return;
        }

        $user_id = $admin_users[0]->ID;

        if ($is_cli) {
            WP_CLI::log("WordpressMCP: No user context, assigning token to admin user: {$admin_users[0]->user_login}");
        }
    }

    if (!$user_id) {
        return; // No user context and no pre-configured token
    }

    // Check if user already has a default token
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `{$table_name}` WHERE user_id = %d AND label = %s",
        $user_id,
        'Default Token'
    ));

    if ($existing > 0) {
        if ($is_cli) {
            WP_CLI::log('WordpressMCP: Default token already exists for this user.');
        }
        return; // Default token already exists
    }

    // Determine if we're using pre-configured token or generating new one
    $using_preconfigured = false;

    if ($preconfigured_token && is_string($preconfigured_token) && strlen($preconfigured_token) === 64) {
        // Use the pre-configured token
        $token = $preconfigured_token;
        $using_preconfigured = true;

        // Delete the option after using it (security: don't leave it in the database)
        delete_option('instamcp_default_token');
    } else {
        // Generate secure random token
        $token = bin2hex(random_bytes(32)); // 64 character hex string

        // If a preconfigured token was set but invalid, delete it anyway
        if ($preconfigured_token !== false) {
            delete_option('instamcp_default_token');
            if ($is_cli) {
                WP_CLI::warning('WordpressMCP: Pre-configured token was invalid (must be 64 hex characters). Generated new token instead.');
            }
        }
    }

    $token_hash = hash('sha256', $token);

    // Store token
    $result = $wpdb->insert(
        $table_name,
        [
            'user_id' => $user_id,
            'token_hash' => $token_hash,
            'label' => 'Default Token',
            'expires_at' => null, // No expiration
            'created_at' => current_time('mysql'),
        ],
        ['%d', '%s', '%s', '%s', '%s']
    );

    if ($result === false) {
        if ($is_cli) {
            WP_CLI::error('WordpressMCP: Failed to create default token: ' . $wpdb->last_error);
        }
        return;
    }

    // Get user info for output
    $user = get_userdata($user_id);
    $username = $user ? $user->user_login : "ID {$user_id}";

    // Output to WP-CLI
    if ($is_cli) {
        if ($using_preconfigured) {
            WP_CLI::success("WordpressMCP: Pre-configured token assigned to user '{$username}'");
            WP_CLI::log("Token: {$token}");
        } else {
            WP_CLI::success("WordpressMCP: Default token created for user '{$username}'");
            WP_CLI::log("Token: {$token}");
        }
        WP_CLI::log("Usage: " . home_url('/insationai-wordpress-mcp?t=' . $token));
    }

    // Store the plain token temporarily so user can access it in admin UI
    set_transient('insationai_wpmcp_new_token_' . $user_id, $token, 300); // 5 minutes
}

/**
 * Create OAuth database tables
 *
 * @return array{success: bool, errors: array}
 */
function insationai_wpmcp_create_oauth_tables() {
    global $wpdb;

    $errors = [];

    // Table prefix
    $prefix = $wpdb->prefix . 'insationai_wpmcp_';

    /**
     * Table 1: OAuth Clients
     * Stores registered applications that can connect via OAuth
     */
    $clients_table = $prefix . 'oauth_clients';
    $sql_clients = "CREATE TABLE IF NOT EXISTS `{$clients_table}` (
        `client_id` varchar(80) NOT NULL,
        `client_secret` varchar(255) NOT NULL COMMENT 'Hashed with bcrypt',
        `client_name` varchar(255) NOT NULL,
        `redirect_uris` text NOT NULL COMMENT 'JSON array of allowed redirect URIs',
        `grant_types` varchar(255) DEFAULT 'authorization_code,refresh_token',
        `is_confidential` tinyint(1) DEFAULT 1 COMMENT '1 for confidential clients, 0 for public',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`client_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    /**
     * Table 2: Authorization Codes
     * Stores short-lived authorization codes (10 minutes)
     */
    $codes_table = $prefix . 'oauth_authorization_codes';
    $sql_codes = "CREATE TABLE IF NOT EXISTS `{$codes_table}` (
        `code` varchar(128) NOT NULL,
        `client_id` varchar(80) NOT NULL,
        `user_id` bigint(20) unsigned NOT NULL,
        `redirect_uri` text NOT NULL,
        `scopes` text DEFAULT NULL COMMENT 'Space-separated list of scopes',
        `code_challenge` varchar(128) DEFAULT NULL COMMENT 'PKCE code challenge',
        `code_challenge_method` varchar(10) DEFAULT 'S256',
        `expires_at` datetime NOT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `revoked` tinyint(1) DEFAULT 0,
        PRIMARY KEY (`code`),
        KEY `client_id` (`client_id`),
        KEY `user_id` (`user_id`),
        KEY `expires_at` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    /**
     * Table 3: Access Tokens (for revocation tracking)
     * JWT tokens are stateless, but we track JTI for revocation
     */
    $tokens_table = $prefix . 'oauth_access_tokens';
    $sql_tokens = "CREATE TABLE IF NOT EXISTS `{$tokens_table}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `jti` varchar(128) NOT NULL COMMENT 'JWT ID for revocation',
        `client_id` varchar(80) NOT NULL,
        `user_id` bigint(20) unsigned NOT NULL,
        `scopes` text DEFAULT NULL,
        `expires_at` datetime NOT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `revoked` tinyint(1) DEFAULT 0,
        PRIMARY KEY (`id`),
        UNIQUE KEY `jti` (`jti`),
        KEY `client_id` (`client_id`),
        KEY `user_id` (`user_id`),
        KEY `expires_at` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    /**
     * Table 4: Refresh Tokens
     * Long-lived tokens for obtaining new access tokens
     */
    $refresh_table = $prefix . 'oauth_refresh_tokens';
    $sql_refresh = "CREATE TABLE IF NOT EXISTS `{$refresh_table}` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `refresh_token` varchar(128) NOT NULL,
        `access_token_jti` varchar(128) NOT NULL COMMENT 'Linked to access token',
        `client_id` varchar(80) NOT NULL,
        `user_id` bigint(20) unsigned NOT NULL,
        `scopes` text DEFAULT NULL,
        `expires_at` datetime NOT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `revoked` tinyint(1) DEFAULT 0,
        PRIMARY KEY (`id`),
        UNIQUE KEY `refresh_token` (`refresh_token`),
        KEY `access_token_jti` (`access_token_jti`),
        KEY `client_id` (`client_id`),
        KEY `user_id` (`user_id`),
        KEY `expires_at` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    // Execute table creation using dbDelta for safe upgrades
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    dbDelta($sql_clients);
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    if ($wpdb->get_var("SHOW TABLES LIKE '{$clients_table}'") !== $clients_table) {
        $errors[] = 'oauth_clients: ' . ($wpdb->last_error ?: 'Failed to create');
    }

    dbDelta($sql_codes);
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    if ($wpdb->get_var("SHOW TABLES LIKE '{$codes_table}'") !== $codes_table) {
        $errors[] = 'oauth_authorization_codes: ' . ($wpdb->last_error ?: 'Failed to create');
    }

    dbDelta($sql_tokens);
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    if ($wpdb->get_var("SHOW TABLES LIKE '{$tokens_table}'") !== $tokens_table) {
        $errors[] = 'oauth_access_tokens: ' . ($wpdb->last_error ?: 'Failed to create');
    }

    dbDelta($sql_refresh);
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    if ($wpdb->get_var("SHOW TABLES LIKE '{$refresh_table}'") !== $refresh_table) {
        $errors[] = 'oauth_refresh_tokens: ' . ($wpdb->last_error ?: 'Failed to create');
    }

    return [
        'success' => empty($errors),
        'errors' => $errors
    ];
}
