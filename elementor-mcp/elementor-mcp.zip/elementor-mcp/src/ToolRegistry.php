<?php
/**
 * Tool Registry — ElementorMCP
 *
 * Central source of truth for tool metadata. Both the runtime registrars
 * (mcp-http.php, register-abilities.php) and the admin Tools toggle UI
 * consume this so they stay in lockstep.
 *
 * Tools are only built when Elementor is active. When Elementor is missing,
 * buildAllTools / buildEnabledTools return an empty array. The admin Tools
 * tab still renders (so users can see what would be available), but
 * tools/list returns nothing to MCP clients until Elementor is loaded.
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Services\ContentPatchingService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ToolRegistry
{
    public const DISABLED_OPTION = 'insationai_emcp_disabled_tools';

    /**
     * Build every tool instance.
     *
     * @return AbstractTool[]
     */
    public static function buildAllTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        if (!class_exists('\Elementor\Plugin')) {
            return [];
        }

        $elementor = new ElementorService();

        return [
            // Documents
            new Tools\Document\ListElementorDocuments($wp, $validator, $elementor, $logger),
            new Tools\Document\GetElementorDocument($wp, $validator, $elementor, $logger),
            new Tools\Document\GetDocumentData($wp, $validator, $elementor, $logger),
            new Tools\Document\ReplaceDocumentData($wp, $validator, $elementor, $logger),
            new Tools\Document\DuplicateDocument($wp, $validator, $elementor, $logger),
            new Tools\Document\DeleteDocument($wp, $validator, $elementor, $logger),
            new Tools\Document\GetDocumentSettings($wp, $validator, $elementor, $logger),
            new Tools\Document\UpdateDocumentSettings($wp, $validator, $elementor, $logger),
            new Tools\Document\CountElementorDocuments($wp, $validator, $elementor, $logger),
            new Tools\Document\GetElementorVersion($wp, $validator, $elementor, $logger),

            // Element tree (1.0.3)
            new Tools\Element\FindElement($wp, $validator, $elementor, $logger),
            new Tools\Element\GetElement($wp, $validator, $elementor, $logger),
            new Tools\Element\ListElements($wp, $validator, $elementor, $logger),
            new Tools\Element\CountElementsInDocument($wp, $validator, $elementor, $logger),
            new Tools\Element\GetElementParent($wp, $validator, $elementor, $logger),
            new Tools\Element\GetElementPath($wp, $validator, $elementor, $logger),
            new Tools\Element\FindWidgetsByType($wp, $validator, $elementor, $logger),
            new Tools\Element\FindElementsByClass($wp, $validator, $elementor, $logger),
            new Tools\Element\InsertElement($wp, $validator, $elementor, $logger),
            new Tools\Element\UpdateElement($wp, $validator, $elementor, $logger),
            new Tools\Element\ReplaceElement($wp, $validator, $elementor, $logger),
            new Tools\Element\DeleteElement($wp, $validator, $elementor, $logger),
            new Tools\Element\DuplicateElement($wp, $validator, $elementor, $logger),
            new Tools\Element\MoveElement($wp, $validator, $elementor, $logger),
            new Tools\Element\WrapElementInContainer($wp, $validator, $elementor, $logger),
            new Tools\Element\UnwrapElement($wp, $validator, $elementor, $logger),

            // Widget types (1.0.3)
            new Tools\Widget\ListWidgetTypes($wp, $validator, $elementor, $logger),
            new Tools\Widget\GetWidgetSchema($wp, $validator, $elementor, $logger),
            new Tools\Widget\ListRegisteredWidgetCategories($wp, $validator, $elementor, $logger),
            new Tools\Widget\CountWidgetsByType($wp, $validator, $elementor, $logger),
            new Tools\Widget\FindUnusedWidgetTypes($wp, $validator, $elementor, $logger),
            new Tools\Widget\GetWidgetDefaultSettings($wp, $validator, $elementor, $logger),
            new Tools\Widget\ValidateWidgetSettings($wp, $validator, $elementor, $logger),
            new Tools\Widget\BulkReplaceWidgetType($wp, $validator, $elementor, $logger),

            // Templates & Library (1.0.4)
            new Tools\Template\ListTemplates($wp, $validator, $elementor, $logger),
            new Tools\Template\GetTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\CreateTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\UpdateTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\DeleteTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\DuplicateTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\ExportTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\ImportTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\ApplyTemplateToDocument($wp, $validator, $elementor, $logger),
            new Tools\Template\SaveElementAsTemplate($wp, $validator, $elementor, $logger),
            new Tools\Template\CountTemplates($wp, $validator, $elementor, $logger),
            new Tools\Template\GetTemplateConditions($wp, $validator, $elementor, $logger),

            // Global Kit & Styles (1.0.4)
            new Tools\Kit\GetActiveKit($wp, $validator, $elementor, $logger),
            new Tools\Kit\GetKitSettings($wp, $validator, $elementor, $logger),
            new Tools\Kit\UpdateKitSettings($wp, $validator, $elementor, $logger),
            new Tools\Kit\ListGlobalColors($wp, $validator, $elementor, $logger),
            new Tools\Kit\ListGlobalFonts($wp, $validator, $elementor, $logger),
            new Tools\Kit\UpdateGlobalColor($wp, $validator, $elementor, $logger),
            new Tools\Kit\AddGlobalColor($wp, $validator, $elementor, $logger),
            new Tools\Kit\DeleteGlobalColor($wp, $validator, $elementor, $logger),
            new Tools\Kit\GetKitCustomCss($wp, $validator, $elementor, $logger),
            new Tools\Kit\ListAllKits($wp, $validator, $elementor, $logger),

            // Revisions (1.0.5)
            new Tools\Revision\ListDocumentRevisions($wp, $validator, $elementor, $logger),
            new Tools\Revision\GetRevisionData($wp, $validator, $elementor, $logger),
            new Tools\Revision\RestoreRevision($wp, $validator, $elementor, $logger),
            new Tools\Revision\DeleteRevision($wp, $validator, $elementor, $logger),
            new Tools\Revision\PruneDocumentRevisions($wp, $validator, $elementor, $logger),

            // Page Settings (1.0.5)
            new Tools\PageSettings\GetPageSettings($wp, $validator, $elementor, $logger),
            new Tools\PageSettings\UpdatePageSettings($wp, $validator, $elementor, $logger),
            new Tools\PageSettings\GetPageTemplate($wp, $validator, $elementor, $logger),
            new Tools\PageSettings\SetPageTemplate($wp, $validator, $elementor, $logger),

            // Custom CSS (1.0.5)
            new Tools\CustomCss\GetPageCustomCss($wp, $validator, $elementor, $logger),
            new Tools\CustomCss\SetPageCustomCss($wp, $validator, $elementor, $logger),
            new Tools\CustomCss\GetElementCustomCss($wp, $validator, $elementor, $logger),

            // Dynamic Tags (1.0.5)
            new Tools\DynamicTags\ListDynamicTags($wp, $validator, $elementor, $logger),
            new Tools\DynamicTags\ListDynamicTagGroups($wp, $validator, $elementor, $logger),
            new Tools\DynamicTags\FindDynamicTagUsage($wp, $validator, $elementor, $logger),
            new Tools\DynamicTags\GetDynamicTagConfig($wp, $validator, $elementor, $logger),

            // Experiments (1.0.6)
            new Tools\Experiment\ListExperiments($wp, $validator, $elementor, $logger),
            new Tools\Experiment\GetExperiment($wp, $validator, $elementor, $logger),
            new Tools\Experiment\SetExperimentState($wp, $validator, $elementor, $logger),

            // Diagnostics (1.0.6)
            new Tools\Diagnostics\GetElementorSystemInfo($wp, $validator, $elementor, $logger),
            new Tools\Diagnostics\ValidateDocumentData($wp, $validator, $elementor, $logger),
            new Tools\Diagnostics\FindOrphanedElementorData($wp, $validator, $elementor, $logger),
            new Tools\Diagnostics\GetElementorSettings($wp, $validator, $elementor, $logger),
            new Tools\Diagnostics\CheckElementorRequirements($wp, $validator, $elementor, $logger),
            new Tools\Diagnostics\GetDocumentCssStatus($wp, $validator, $elementor, $logger),

            // Cache (1.0.6)
            new Tools\Cache\ClearElementorCache($wp, $validator, $elementor, $logger),
            new Tools\Cache\RegenerateDocumentCss($wp, $validator, $elementor, $logger),
            new Tools\Cache\RegenerateAllCss($wp, $validator, $elementor, $logger),
            new Tools\Cache\SyncGlobalCss($wp, $validator, $elementor, $logger),
            new Tools\Cache\GetCacheStatus($wp, $validator, $elementor, $logger),

            // Maintenance (1.0.6)
            new Tools\Maintenance\GetMaintenanceMode($wp, $validator, $elementor, $logger),
            new Tools\Maintenance\SetMaintenanceMode($wp, $validator, $elementor, $logger),

            // Search & Replace (1.0.6)
            new Tools\Search\SearchDocumentContent($wp, $validator, $elementor, $logger),
            new Tools\Search\ReplaceInDocument($wp, $validator, $elementor, $logger),
            new Tools\Search\ReplaceUrlAcrossDocuments($wp, $validator, $elementor, $logger),

            // Editor Roles (1.0.7)
            new Tools\Roles\GetEditorRoleAccess($wp, $validator, $elementor, $logger),
            new Tools\Roles\SetEditorRoleAccess($wp, $validator, $elementor, $logger),

            // Fonts (1.0.7)
            new Tools\Fonts\ListFonts($wp, $validator, $elementor, $logger),
            new Tools\Fonts\ListFontGroups($wp, $validator, $elementor, $logger),
            new Tools\Fonts\FindFontUsage($wp, $validator, $elementor, $logger),

            // Style Variations (1.0.7)
            new Tools\StyleVariations\ExportKitStyles($wp, $validator, $elementor, $logger),
            new Tools\StyleVariations\ApplyKitStyleVariation($wp, $validator, $elementor, $logger),
            new Tools\StyleVariations\CompareKitStyles($wp, $validator, $elementor, $logger),
            new Tools\StyleVariations\SaveKitStyleVariationAsKit($wp, $validator, $elementor, $logger),
        ];
    }

    /**
     * Build enabled tools (filters out admin-disabled ones).
     *
     * @return AbstractTool[]
     */
    public static function buildEnabledTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $all = self::buildAllTools($wp, $validator, $logger, $patching);
        $disabled = self::getDisabledToolNames();
        if (empty($disabled) || empty($all)) {
            return $all;
        }
        return array_values(array_filter(
            $all,
            static fn(AbstractTool $t) => !in_array($t->getName(), $disabled, true)
        ));
    }

    /**
     * @return string[]
     */
    public static function getDisabledToolNames(): array
    {
        $stored = get_option(self::DISABLED_OPTION, []);
        return is_array($stored) ? array_values(array_filter(array_map('strval', $stored))) : [];
    }

    /**
     * @param string[] $names
     */
    public static function setDisabledToolNames(array $names): void
    {
        $clean = array_values(array_unique(array_filter(array_map('sanitize_text_field', $names))));
        update_option(self::DISABLED_OPTION, $clean);
    }

    /**
     * Stable category slug for a tool name.
     */
    public static function categoryFor(string $toolName): string
    {
        $documents = [
            'list_elementor_documents', 'get_elementor_document', 'get_document_data',
            'replace_document_data', 'duplicate_document', 'delete_elementor_document',
            'get_document_settings', 'update_document_settings', 'count_elementor_documents',
            'get_elementor_version',
        ];
        if (in_array($toolName, $documents, true)) {
            return 'documents';
        }

        $elements = [
            'find_element', 'get_element', 'list_elements', 'count_elements_in_document',
            'get_element_parent', 'get_element_path', 'find_widgets_by_type',
            'find_elements_by_class', 'insert_element', 'update_element', 'replace_element',
            'delete_element', 'duplicate_element', 'move_element',
            'wrap_element_in_container', 'unwrap_element',
        ];
        if (in_array($toolName, $elements, true)) {
            return 'elements';
        }

        $widgets = [
            'list_widget_types', 'get_widget_schema', 'list_registered_widget_categories',
            'count_widgets_by_type', 'find_unused_widget_types', 'get_widget_default_settings',
            'validate_widget_settings', 'bulk_replace_widget_type',
        ];
        if (in_array($toolName, $widgets, true)) {
            return 'widgets';
        }

        $templates = [
            'list_templates', 'get_template', 'create_template', 'update_template',
            'delete_template', 'duplicate_template', 'export_template', 'import_template',
            'apply_template_to_document', 'save_element_as_template', 'count_templates',
            'get_template_conditions',
        ];
        if (in_array($toolName, $templates, true)) {
            return 'templates';
        }

        $kit = [
            'get_active_kit', 'get_kit_settings', 'update_kit_settings', 'list_global_colors',
            'list_global_fonts', 'update_global_color', 'add_global_color',
            'delete_global_color', 'get_kit_custom_css', 'list_all_kits',
        ];
        if (in_array($toolName, $kit, true)) {
            return 'kit';
        }

        $revisions = [
            'list_document_revisions', 'get_revision_data', 'restore_revision',
            'delete_revision', 'prune_document_revisions',
        ];
        if (in_array($toolName, $revisions, true)) {
            return 'revisions';
        }

        $pageSettings = [
            'get_page_settings', 'update_page_settings', 'get_page_template', 'set_page_template',
        ];
        if (in_array($toolName, $pageSettings, true)) {
            return 'page-settings';
        }

        $customCss = [
            'get_page_custom_css', 'set_page_custom_css', 'get_element_custom_css',
        ];
        if (in_array($toolName, $customCss, true)) {
            return 'custom-css';
        }

        $dynamicTags = [
            'list_dynamic_tags', 'list_dynamic_tag_groups', 'find_dynamic_tag_usage',
            'get_dynamic_tag_config',
        ];
        if (in_array($toolName, $dynamicTags, true)) {
            return 'dynamic-tags';
        }

        $experiments = [
            'list_experiments', 'get_experiment', 'set_experiment_state',
        ];
        if (in_array($toolName, $experiments, true)) {
            return 'experiments';
        }

        $diagnostics = [
            'get_elementor_system_info', 'validate_document_data', 'find_orphaned_elementor_data',
            'get_elementor_settings', 'check_elementor_requirements', 'get_document_css_status',
        ];
        if (in_array($toolName, $diagnostics, true)) {
            return 'diagnostics';
        }

        $cache = [
            'clear_elementor_cache', 'regenerate_document_css', 'regenerate_all_css',
            'sync_global_css', 'get_cache_status',
        ];
        if (in_array($toolName, $cache, true)) {
            return 'cache';
        }

        $maintenance = ['get_maintenance_mode', 'set_maintenance_mode'];
        if (in_array($toolName, $maintenance, true)) {
            return 'maintenance';
        }

        $search = [
            'search_document_content', 'replace_in_document', 'replace_url_across_documents',
        ];
        if (in_array($toolName, $search, true)) {
            return 'search';
        }

        $roles = ['get_editor_role_access', 'set_editor_role_access'];
        if (in_array($toolName, $roles, true)) {
            return 'roles';
        }

        $fonts = ['list_fonts', 'list_font_groups', 'find_font_usage'];
        if (in_array($toolName, $fonts, true)) {
            return 'fonts';
        }

        $styleVariations = [
            'export_kit_styles', 'apply_kit_style_variation', 'compare_kit_styles',
            'save_kit_style_variation_as_kit',
        ];
        if (in_array($toolName, $styleVariations, true)) {
            return 'style-variations';
        }

        // Future categories will go here as we expand
        return 'misc';
    }

    /**
     * Human-readable label for a category slug.
     */
    public static function categoryLabel(string $slug): string
    {
        $labels = [
            'documents'  => __('Documents', 'elementor-mcp'),
            'elements'   => __('Element Tree', 'elementor-mcp'),
            'widgets'    => __('Widget Types', 'elementor-mcp'),
            'templates'  => __('Templates & Library', 'elementor-mcp'),
            'kit'        => __('Global Kit & Styles', 'elementor-mcp'),
            'revisions'  => __('Revisions', 'elementor-mcp'),
            'page-settings' => __('Page Settings', 'elementor-mcp'),
            'custom-css' => __('Custom CSS', 'elementor-mcp'),
            'dynamic-tags' => __('Dynamic Tags', 'elementor-mcp'),
            'experiments' => __('Experiments', 'elementor-mcp'),
            'diagnostics'=> __('Diagnostics', 'elementor-mcp'),
            'cache'      => __('Cache & CSS Regen', 'elementor-mcp'),
            'maintenance'=> __('Maintenance Mode', 'elementor-mcp'),
            'search'     => __('Search & Replace', 'elementor-mcp'),
            'roles'      => __('Editor Roles', 'elementor-mcp'),
            'fonts'      => __('Fonts', 'elementor-mcp'),
            'style-variations' => __('Style Variations', 'elementor-mcp'),
            'misc'       => __('Misc', 'elementor-mcp'),
        ];
        return $labels[$slug] ?? ucfirst(str_replace('-', ' ', $slug));
    }
}
