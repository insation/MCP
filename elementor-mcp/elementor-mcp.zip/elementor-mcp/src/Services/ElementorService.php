<?php
/**
 * Elementor Service
 *
 * Lightweight wrapper around Elementor's plugin singleton. Keeps tools free
 * of hard \Elementor\Plugin references and centralizes the "Elementor
 * available?" check.
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Services;

use InsationAI\ElementorMCP\Exceptions\ToolException;

class ElementorService
{
    /**
     * Throw if Elementor is not loaded. Tools call this at the top of doExecute.
     *
     * @throws ToolException
     */
    public function requireElementor(): void
    {
        if (!class_exists('\Elementor\Plugin')) {
            throw ToolException::wordpressError(
                'Elementor (free) is not installed or active. ElementorMCP requires Elementor to function.'
            );
        }
    }

    /**
     * Get the Elementor Plugin singleton.
     *
     * @return \Elementor\Plugin
     */
    public function plugin(): object
    {
        $this->requireElementor();
        return \Elementor\Plugin::$instance;
    }

    /**
     * Get a document by post ID. Returns the Elementor Document object.
     *
     * @param int $post_id
     * @return object|null Document instance, or null if not Elementor-built.
     */
    public function getDocument(int $post_id): ?object
    {
        $doc = $this->plugin()->documents->get($post_id);
        if (!$doc || !is_object($doc)) {
            return null;
        }
        // Some calls return ProxyClass — confirm it's an actual Document
        if (!method_exists($doc, 'is_built_with_elementor')) {
            return null;
        }
        return $doc->is_built_with_elementor() ? $doc : null;
    }

    /**
     * Get the raw Elementor data tree (array of element dictionaries) for a post.
     * Decoded from the _elementor_data post meta.
     *
     * @param int $post_id
     * @return array<int, array<string, mixed>>
     */
    public function getDocumentData(int $post_id): array
    {
        $doc = $this->getDocument($post_id);
        if (!$doc) {
            return [];
        }
        $data = $doc->get_elements_data();
        return is_array($data) ? $data : [];
    }

    /**
     * Save data back to a document. Uses Elementor's own save_elements method
     * which handles validation, sanitization, and CSS regen invalidation.
     *
     * @param int $post_id
     * @param array<int, array<string, mixed>> $data
     * @return bool True on success.
     */
    public function saveDocumentData(int $post_id, array $data): bool
    {
        $doc = $this->getDocument($post_id);
        if (!$doc) {
            return false;
        }
        return (bool) $doc->save([
            'elements' => $data,
        ]);
    }

    /**
     * Recursively walk every element in a document tree, yielding [path, element].
     * The path is an integer array describing how to navigate from the root to
     * this element (e.g. [0, 1, 2] = root[0].elements[1].elements[2]).
     *
     * @param array<int, array<string, mixed>> $elements
     * @param array<int> $pathPrefix
     * @return \Generator<array{path: array<int>, element: array<string, mixed>}>
     */
    public function walkElements(array $elements, array $pathPrefix = []): \Generator
    {
        foreach ($elements as $i => $el) {
            $path = array_merge($pathPrefix, [$i]);
            yield ['path' => $path, 'element' => $el];
            if (!empty($el['elements']) && is_array($el['elements'])) {
                yield from $this->walkElements($el['elements'], $path);
            }
        }
    }

    /**
     * Find an element by its `id` field anywhere in the tree.
     *
     * @return array{path: array<int>, element: array<string, mixed>}|null
     */
    public function findElementById(array $elements, string $elementId): ?array
    {
        foreach ($this->walkElements($elements) as $entry) {
            if (($entry['element']['id'] ?? null) === $elementId) {
                return $entry;
            }
        }
        return null;
    }

    /**
     * Replace the element at the given path within $elements. Returns the
     * modified tree.
     *
     * @param array<int, array<string, mixed>> $elements
     * @param array<int> $path
     * @param array<string, mixed>|null $newElement Pass null to delete.
     * @return array<int, array<string, mixed>>
     */
    public function replaceAtPath(array $elements, array $path, ?array $newElement): array
    {
        if (empty($path)) {
            return $elements;
        }
        return $this->writeAtPath($elements, $path, $newElement);
    }

    private function writeAtPath(array $elements, array $path, ?array $newElement): array
    {
        if (count($path) === 1) {
            $i = $path[0];
            if ($newElement === null) {
                array_splice($elements, $i, 1);
            } else {
                $elements[$i] = $newElement;
            }
            return array_values($elements);
        }
        $i = array_shift($path);
        if (!isset($elements[$i])) {
            return $elements;
        }
        $children = $elements[$i]['elements'] ?? [];
        $elements[$i]['elements'] = $this->writeAtPath($children, $path, $newElement);
        return $elements;
    }

    /**
     * Insert $newElement at $path. The last index of $path becomes its
     * position among its siblings.
     */
    public function insertAtPath(array $elements, array $path, array $newElement): array
    {
        if (empty($path)) {
            return $elements;
        }
        return $this->doInsertAtPath($elements, $path, $newElement);
    }

    private function doInsertAtPath(array $elements, array $path, array $newElement): array
    {
        if (count($path) === 1) {
            $i = $path[0];
            array_splice($elements, $i, 0, [$newElement]);
            return array_values($elements);
        }
        $i = array_shift($path);
        if (!isset($elements[$i])) {
            return $elements;
        }
        $children = $elements[$i]['elements'] ?? [];
        $elements[$i]['elements'] = $this->doInsertAtPath($children, $path, $newElement);
        return $elements;
    }

    /**
     * Generate a new random Elementor element ID (7-char hex, matching Elementor's format).
     */
    public function newElementId(): string
    {
        return substr(md5(uniqid('emcp_', true)), 0, 7);
    }

    /**
     * Recursively assign fresh element IDs to an element and all of its
     * descendants. Used when duplicating or inserting an element so the tree
     * never contains two elements with the same id (which corrupts Elementor's
     * editor and CSS generation).
     *
     * @param array<string, mixed> $element
     * @return array<string, mixed>
     */
    public function regenerateIds(array $element): array
    {
        $element['id'] = $this->newElementId();
        if (!empty($element['elements']) && is_array($element['elements'])) {
            $element['elements'] = array_map(
                fn($child) => $this->regenerateIds($child),
                $element['elements']
            );
        }
        return $element;
    }

    /**
     * Validate that an element dictionary has the minimum shape Elementor
     * requires: an elType, and (for widgets) a widgetType. Returns an array
     * of human-readable problems; empty array means the element looks valid.
     *
     * @param array<string, mixed> $element
     * @return string[]
     */
    public function validateElementShape(array $element): array
    {
        $problems = [];
        $elType = $element['elType'] ?? null;
        if (!is_string($elType) || $elType === '') {
            $problems[] = 'Missing or empty "elType".';
        } elseif (!in_array($elType, ['section', 'column', 'container', 'widget'], true)) {
            $problems[] = "Unrecognized elType '{$elType}' (expected section, column, container, or widget).";
        }
        if ($elType === 'widget' && empty($element['widgetType'])) {
            $problems[] = 'elType is "widget" but "widgetType" is missing.';
        }
        if (isset($element['settings']) && !is_array($element['settings'])) {
            $problems[] = '"settings" must be an object.';
        }
        if (isset($element['elements']) && !is_array($element['elements'])) {
            $problems[] = '"elements" must be an array.';
        }
        return $problems;
    }

    /**
     * Find the integer path to an element by id, or null if not present.
     *
     * @param array<int, array<string, mixed>> $elements
     * @return array<int>|null
     */
    public function pathToId(array $elements, string $elementId): ?array
    {
        $found = $this->findElementById($elements, $elementId);
        return $found['path'] ?? null;
    }

    /* ------------------------------------------------------------------ */
    /* Templates & Library helpers (1.0.4)                                */
    /* ------------------------------------------------------------------ */

    /**
     * The post type Elementor uses for its template library.
     */
    public const TEMPLATE_CPT = 'elementor_library';

    /**
     * Get the Elementor template-library type of a library post
     * (page, section, container, header, footer, popup, etc.) from its
     * elementor_library_type taxonomy term, falling back to the
     * _elementor_template_type post meta.
     */
    public function getTemplateType(int $postId): ?string
    {
        $terms = wp_get_object_terms($postId, 'elementor_library_type', ['fields' => 'slugs']);
        if (!is_wp_error($terms) && !empty($terms)) {
            return (string) $terms[0];
        }
        $meta = get_post_meta($postId, '_elementor_template_type', true);
        return $meta !== '' ? (string) $meta : null;
    }

    /**
     * Set the template-library type for a library post — writes both the
     * taxonomy term and the meta key so Elementor's UI and queries agree.
     */
    public function setTemplateType(int $postId, string $type): void
    {
        wp_set_object_terms($postId, $type, 'elementor_library_type');
        update_post_meta($postId, '_elementor_template_type', $type);
    }

    /**
     * Return the Elementor templates_manager, or throw if unavailable.
     */
    public function templatesManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->templates_manager ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor templates manager is not available.');
        }
        return $mgr;
    }

    /* ------------------------------------------------------------------ */
    /* Global Kit helpers (1.0.4)                                         */
    /* ------------------------------------------------------------------ */

    /**
     * Return the kits_manager, or throw if unavailable.
     */
    public function kitsManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->kits_manager ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor kits manager is not available.');
        }
        return $mgr;
    }

    /**
     * The active kit's post ID (0 if none).
     */
    public function activeKitId(): int
    {
        return (int) $this->kitsManager()->get_active_id();
    }

    /**
     * Read the active kit's settings array (the full _elementor_page_settings
     * meta of the kit post — colors, fonts, typography, layout defaults).
     *
     * @return array<string, mixed>
     */
    public function getKitSettings(?int $kitId = null): array
    {
        $kitId = $kitId ?? $this->activeKitId();
        if ($kitId <= 0) {
            return [];
        }
        $settings = get_post_meta($kitId, '_elementor_page_settings', true);
        return is_array($settings) ? $settings : [];
    }

    /**
     * Write the kit's settings array back to post meta and clear Elementor's
     * CSS cache so the change takes effect on the front end.
     *
     * @param array<string, mixed> $settings
     */
    public function saveKitSettings(array $settings, ?int $kitId = null): bool
    {
        $kitId = $kitId ?? $this->activeKitId();
        if ($kitId <= 0) {
            return false;
        }
        update_post_meta($kitId, '_elementor_page_settings', $settings);
        // Regenerate CSS so the kit change is reflected on the front end.
        if (method_exists($this->plugin()->files_manager, 'clear_cache')) {
            $this->plugin()->files_manager->clear_cache();
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* Revisions helpers (1.0.5)                                          */
    /* ------------------------------------------------------------------ */

    /**
     * Return the Elementor revisions for a document as lightweight rows.
     * Uses WordPress' own revision store; Elementor revisions are just WP
     * post revisions that carry the _elementor_data meta.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getRevisions(int $postId, int $limit = 30): array
    {
        $revisions = wp_get_post_revisions($postId, [
            'posts_per_page' => $limit,
        ]);
        $rows = [];
        foreach ($revisions as $rev) {
            $rows[] = [
                'revision_id' => $rev->ID,
                'author_id'   => (int) $rev->post_author,
                'date_gmt'    => $rev->post_modified_gmt,
                'type'        => (false !== strpos($rev->post_name, 'autosave')) ? 'autosave' : 'revision',
                'has_elementor_data' => (get_metadata('post', $rev->ID, '_elementor_data', true) !== ''),
            ];
        }
        return $rows;
    }

    /**
     * Read the parsed Elementor element tree stored on a specific revision.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getRevisionData(int $revisionId): array
    {
        $raw = get_metadata('post', $revisionId, '_elementor_data', true);
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            return is_array($decoded) ? $decoded : [];
        }
        return is_array($raw) ? $raw : [];
    }

    /* ------------------------------------------------------------------ */
    /* Page settings helpers (1.0.5)                                      */
    /* ------------------------------------------------------------------ */

    /**
     * Read a document's per-page Elementor settings (the _elementor_page_settings
     * meta — page layout, custom CSS for Pro, body background, etc.).
     *
     * @return array<string, mixed>
     */
    public function getPageSettings(int $postId): array
    {
        $settings = get_post_meta($postId, '_elementor_page_settings', true);
        return is_array($settings) ? $settings : [];
    }

    /**
     * Write a document's per-page Elementor settings and clear that
     * document's CSS cache.
     *
     * @param array<string, mixed> $settings
     */
    public function savePageSettings(int $postId, array $settings): bool
    {
        update_post_meta($postId, '_elementor_page_settings', $settings);
        // Clear the per-post CSS so the change is reflected.
        if (method_exists($this->plugin()->files_manager, 'clear_cache')) {
            $this->plugin()->files_manager->clear_cache();
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* Dynamic tags helpers (1.0.5)                                       */
    /* ------------------------------------------------------------------ */

    /**
     * Return the dynamic_tags manager, or throw if unavailable.
     */
    public function dynamicTagsManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->dynamic_tags ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor dynamic tags manager is not available.');
        }
        return $mgr;
    }

    /* ------------------------------------------------------------------ */
    /* Experiments helpers (1.0.6)                                        */
    /* ------------------------------------------------------------------ */

    /**
     * Return the experiments manager, or throw if unavailable.
     */
    public function experimentsManager(): object
    {
        $this->requireElementor();
        $mgr = $this->plugin()->experiments ?? null;
        if ($mgr === null) {
            throw new \RuntimeException('Elementor experiments manager is not available.');
        }
        return $mgr;
    }

    /**
     * The wp_options key Elementor uses to store an experiment's state.
     */
    public function experimentOptionKey(string $featureName): string
    {
        return 'elementor_experiment-' . $featureName;
    }

    /* ------------------------------------------------------------------ */
    /* Cache helpers (1.0.6)                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Clear Elementor's generated CSS / file cache. Returns true if the
     * files manager exposed a clear_cache method and it was called.
     */
    public function clearCache(): bool
    {
        $fm = $this->plugin()->files_manager ?? null;
        if ($fm !== null && method_exists($fm, 'clear_cache')) {
            $fm->clear_cache();
            return true;
        }
        return false;
    }

    /* ------------------------------------------------------------------ */
    /* Maintenance mode helpers (1.0.6)                                   */
    /* ------------------------------------------------------------------ */

    /**
     * Elementor stores maintenance-mode settings under wp_options keys
     * prefixed with this string (mode, exclude_mode, exclude_roles,
     * template_id).
     */
    public const MAINTENANCE_OPTION_PREFIX = 'elementor_maintenance_mode_';

    /**
     * Read a maintenance-mode option (e.g. 'mode', 'template_id').
     *
     * @return mixed
     */
    public function getMaintenanceOption(string $key, $default = false)
    {
        return get_option(self::MAINTENANCE_OPTION_PREFIX . $key, $default);
    }

    /**
     * Write a maintenance-mode option.
     *
     * @param mixed $value
     */
    public function setMaintenanceOption(string $key, $value): bool
    {
        return update_option(self::MAINTENANCE_OPTION_PREFIX . $key, $value);
    }

    /* ------------------------------------------------------------------ */
    /* Role manager helpers (1.0.7)                                       */
    /* ------------------------------------------------------------------ */

    /**
     * The wp_options key Elementor's Role Manager stores its restrictions in.
     * The value is an array keyed by role slug; a role mapped to
     * ['type' => 'do-not-allow'] cannot use the Elementor editor.
     */
    public const ROLE_MANAGER_OPTION = 'elementor_role-manager';

    /**
     * Read the Elementor Role Manager restrictions array.
     *
     * @return array<string, mixed>
     */
    public function getRoleRestrictions(): array
    {
        $value = get_option(self::ROLE_MANAGER_OPTION, []);
        return is_array($value) ? $value : [];
    }

    /**
     * Write the Elementor Role Manager restrictions array.
     *
     * @param array<string, mixed> $restrictions
     */
    public function saveRoleRestrictions(array $restrictions): bool
    {
        return update_option(self::ROLE_MANAGER_OPTION, $restrictions);
    }

    /* ------------------------------------------------------------------ */
    /* Fonts helpers (1.0.7)                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Return Elementor's font list as [font_name => group] pairs.
     * Uses the static \Elementor\Fonts API.
     *
     * @return array<string, string>
     */
    public function getFonts(): array
    {
        $this->requireElementor();
        if (class_exists('\Elementor\Fonts') && method_exists('\Elementor\Fonts', 'get_fonts')) {
            $fonts = \Elementor\Fonts::get_fonts();
            return is_array($fonts) ? $fonts : [];
        }
        return [];
    }

    /**
     * Return Elementor's font groups as [group_slug => label] pairs.
     *
     * @return array<string, string>
     */
    public function getFontGroups(): array
    {
        $this->requireElementor();
        if (class_exists('\Elementor\Fonts') && method_exists('\Elementor\Fonts', 'get_font_groups')) {
            $groups = \Elementor\Fonts::get_font_groups();
            return is_array($groups) ? $groups : [];
        }
        return [];
    }
}
