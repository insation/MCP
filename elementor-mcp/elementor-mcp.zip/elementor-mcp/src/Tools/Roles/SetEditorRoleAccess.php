<?php
/**
 * Set Editor Role Access Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Roles;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SetEditorRoleAccess extends AbstractTool
{
    protected ElementorService $elementor;

    private const VALID_ACCESS = ['full', 'content-only', 'no-access'];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'set_editor_role_access';
    }

    public function getDescription(): string
    {
        return 'Set a WordPress role\'s Elementor editor access via the Role Manager: "full" (remove any restriction), "content-only" (can edit text/content but not styling/structure), or "no-access" (cannot open the Elementor editor at all). The administrator role cannot be restricted. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'role'   => ['required', 'string', ['notEmpty' => true], 'description' => 'The role slug (e.g. editor, author, contributor).'],
            'access' => ['required', 'string', ['in' => self::VALID_ACCESS], 'description' => 'full, content-only, or no-access.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('changing Elementor editor role access');

        $role = $parameters['role'];
        $access = $parameters['access'];

        // Validate the role exists.
        if (!isset(wp_roles()->roles[$role])) {
            throw ToolException::wordpressError(
                "No WordPress role named '{$role}'. Valid roles: " . implode(', ', array_keys(wp_roles()->roles)) . '.'
            );
        }

        // Guard: administrator cannot be restricted.
        if ($role === 'administrator' && $access !== 'full') {
            throw ToolException::wordpressError(
                'The administrator role cannot have its Elementor access restricted.'
            );
        }

        $restrictions = $this->elementor->getRoleRestrictions();

        switch ($access) {
            case 'full':
                // Remove any restriction entry for this role.
                unset($restrictions[$role]);
                break;
            case 'content-only':
                $restrictions[$role] = ['type' => 'content-only'];
                break;
            case 'no-access':
                $restrictions[$role] = ['type' => 'do-not-allow'];
                break;
        }

        if (!$this->elementor->saveRoleRestrictions($restrictions)) {
            throw ToolException::wordpressError('Failed to save role restrictions.');
        }

        return $this->success([
            'role'   => $role,
            'access' => $access,
        ], "Role '{$role}' Elementor access set to '{$access}'.");
    }
}
