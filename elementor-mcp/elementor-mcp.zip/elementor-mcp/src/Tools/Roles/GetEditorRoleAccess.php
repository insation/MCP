<?php
/**
 * Get Editor Role Access Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Roles;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class GetEditorRoleAccess extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_editor_role_access';
    }

    public function getDescription(): string
    {
        return 'Report which WordPress roles are allowed to use the Elementor editor, based on Elementor\'s Role Manager settings. For each role on the site, returns whether Elementor access is allowed and whether it is restricted to content-only editing (no style/structure controls). Roles with no restriction entry have full access by default.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $restrictions = $this->elementor->getRoleRestrictions();

        // administrator always has full access regardless of Role Manager.
        $roles = [];
        $wpRoles = wp_roles()->roles;
        foreach ($wpRoles as $slug => $roleData) {
            $entry = $restrictions[$slug] ?? null;

            $allowed = true;
            $contentOnly = false;

            if ($slug !== 'administrator' && is_array($entry)) {
                // Elementor stores restriction types; 'do-not-allow' blocks the editor.
                $type = $entry['type'] ?? null;
                if ($type === 'do-not-allow') {
                    $allowed = false;
                }
                // 'content-only' / 'content' restricts to content editing.
                if (in_array($type, ['content-only', 'content'], true)) {
                    $contentOnly = true;
                }
            }

            $roles[] = [
                'role'         => $slug,
                'display_name' => $roleData['name'] ?? $slug,
                'elementor_access' => $allowed,
                'content_only' => $contentOnly,
                'has_restriction_entry' => $entry !== null,
            ];
        }

        return $this->success([
            'role_count'   => count($roles),
            'roles'        => $roles,
            'option_key'   => ElementorService::ROLE_MANAGER_OPTION,
        ]);
    }
}
