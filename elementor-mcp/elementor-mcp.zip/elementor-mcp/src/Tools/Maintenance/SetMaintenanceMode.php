<?php
/**
 * Set Maintenance Mode Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Maintenance;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SetMaintenanceMode extends AbstractTool
{
    protected ElementorService $elementor;

    private const VALID_MODES = ['off', 'maintenance', 'coming_soon'];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'set_maintenance_mode';
    }

    public function getDescription(): string
    {
        return 'Turn Elementor Maintenance Mode on or off. Mode "off" disables it; "maintenance" takes the site offline with an HTTP 503; "coming_soon" shows a pre-launch page with HTTP 200. When enabling, a template_id is required for the splash page — pass the id of an Elementor library template. This affects what every logged-out visitor sees, so it requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'mode'        => ['required', 'string', ['in' => self::VALID_MODES], 'description' => 'off, maintenance, or coming_soon.'],
            'template_id' => ['optional', 'int', 'description' => 'Elementor template id for the splash page. Required when mode is not "off".'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('changing Elementor maintenance mode');

        $mode = $parameters['mode'];

        if ($mode === 'off') {
            // Empty string is how Elementor represents "disabled".
            $this->elementor->setMaintenanceOption('mode', '');
            return $this->success([
                'enabled' => false,
                'mode'    => 'off',
            ], 'Maintenance mode turned off.');
        }

        // Enabling: a template is required for the splash page.
        $templateId = isset($parameters['template_id']) ? (int) $parameters['template_id'] : 0;
        if ($templateId <= 0) {
            throw ToolException::wordpressError(
                'A template_id is required to enable maintenance mode. Pass the id of an Elementor library template to use as the splash page.'
            );
        }
        $tpl = get_post($templateId);
        if (!$tpl || $tpl->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError(
                "Template id {$templateId} is not an Elementor library template."
            );
        }

        $this->elementor->setMaintenanceOption('mode', $mode);
        $this->elementor->setMaintenanceOption('template_id', $templateId);

        return $this->success([
            'enabled'     => true,
            'mode'        => $mode,
            'template_id' => $templateId,
        ], "Maintenance mode set to '{$mode}' using template {$templateId}.");
    }
}
