<?php
/**
 * Get Maintenance Mode Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Maintenance;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class GetMaintenanceMode extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_maintenance_mode';
    }

    public function getDescription(): string
    {
        return 'Read Elementor\'s Maintenance Mode configuration — whether it is off, in "maintenance" mode (HTTP 503, temporarily offline), or "coming_soon" mode (HTTP 200, pre-launch); which template is used for the splash page; and which roles are excluded so they still see the live site.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        // Elementor stores these under elementor_maintenance_mode_* options.
        $mode         = $this->elementor->getMaintenanceOption('mode', '');
        $templateId   = (int) $this->elementor->getMaintenanceOption('template_id', 0);
        $excludeMode  = $this->elementor->getMaintenanceOption('exclude_mode', '');
        $excludeRoles = $this->elementor->getMaintenanceOption('exclude_roles', []);

        $isEnabled = in_array($mode, ['maintenance', 'coming_soon'], true);

        $templateTitle = null;
        if ($templateId > 0) {
            $tpl = get_post($templateId);
            $templateTitle = $tpl ? $tpl->post_title : null;
        }

        return $this->success([
            'enabled'        => $isEnabled,
            'mode'           => $mode !== '' ? $mode : 'off',
            'template_id'    => $templateId ?: null,
            'template_title' => $templateTitle,
            'exclude_mode'   => $excludeMode !== '' ? $excludeMode : null,
            'exclude_roles'  => is_array($excludeRoles) ? $excludeRoles : [],
        ]);
    }
}
