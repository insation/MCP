<?php
/**
 * List Experiments Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Experiment;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListExperiments extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_experiments';
    }

    public function getDescription(): string
    {
        return 'List Elementor\'s experiments / features (the items under Elementor > Settings > Features) — each with its name, title, current state (active, inactive, default), default state, and release status (stable, beta, alpha). These flags control opt-in Elementor capabilities like the Flexbox Container, nested elements, and performance features.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $mgr = $this->elementor->experimentsManager();
        $features = method_exists($mgr, 'get_features') ? $mgr->get_features() : [];

        $items = [];
        foreach ((array) $features as $name => $feature) {
            if (!is_array($feature)) {
                continue;
            }
            $active = method_exists($mgr, 'is_feature_active') ? $mgr->is_feature_active($name) : null;
            $items[] = [
                'name'          => $name,
                'title'         => $feature['title'] ?? $name,
                'state'         => $feature['state'] ?? null,
                'default'       => $feature['default'] ?? null,
                'release_status'=> $feature['release_status'] ?? null,
                'is_active'     => $active,
                'description'   => isset($feature['description']) ? wp_strip_all_tags((string) $feature['description']) : null,
            ];
        }

        usort($items, static fn($a, $b) => strcmp($a['name'], $b['name']));

        return $this->success([
            'count'       => count($items),
            'experiments' => $items,
        ]);
    }
}
