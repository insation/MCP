<?php
/**
 * Get Experiment Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Experiment;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetExperiment extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_experiment';
    }

    public function getDescription(): string
    {
        return 'Get full detail on a single Elementor experiment by name — its state, default state, release status, dependencies, and whether it is currently active. Use list_experiments to discover valid names.';
    }

    public function getSchema(): array
    {
        return [
            'feature_name' => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $mgr = $this->elementor->experimentsManager();
        $name = $parameters['feature_name'];
        $feature = method_exists($mgr, 'get_features') ? $mgr->get_features($name) : null;

        if (!$feature || !is_array($feature)) {
            throw ToolException::wordpressError(
                "No Elementor experiment named '{$name}'. Use list_experiments to see valid names."
            );
        }

        $deps = [];
        if (!empty($feature['dependencies']) && is_array($feature['dependencies'])) {
            foreach ($feature['dependencies'] as $dep) {
                $deps[] = is_object($dep) && method_exists($dep, 'get_name') ? $dep->get_name() : (string) $dep;
            }
        }

        return $this->success([
            'name'           => $name,
            'title'          => $feature['title'] ?? $name,
            'state'          => $feature['state'] ?? null,
            'default'        => $feature['default'] ?? null,
            'release_status' => $feature['release_status'] ?? null,
            'is_active'      => method_exists($mgr, 'is_feature_active') ? $mgr->is_feature_active($name) : null,
            'dependencies'   => $deps,
            'option_key'     => $this->elementor->experimentOptionKey($name),
            'description'    => isset($feature['description']) ? wp_strip_all_tags((string) $feature['description']) : null,
        ]);
    }
}
