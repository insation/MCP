<?php
/**
 * Set Experiment State Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Experiment;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SetExperimentState extends AbstractTool
{
    protected ElementorService $elementor;

    private const VALID_STATES = ['active', 'inactive', 'default'];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'set_experiment_state';
    }

    public function getDescription(): string
    {
        return 'Enable, disable, or reset an Elementor experiment. State must be "active", "inactive", or "default" (default returns it to Elementor\'s shipped default). Changing experiments can significantly alter how the editor and front end behave — for example toggling the Flexbox Container — so this requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'feature_name' => ['required', 'string', ['notEmpty' => true]],
            'state'        => ['required', 'string', ['in' => self::VALID_STATES], 'description' => 'active, inactive, or default.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('changing Elementor experiment state');

        $mgr = $this->elementor->experimentsManager();
        $name = $parameters['feature_name'];
        $state = $parameters['state'];

        $feature = method_exists($mgr, 'get_features') ? $mgr->get_features($name) : null;
        if (!$feature || !is_array($feature)) {
            throw ToolException::wordpressError(
                "No Elementor experiment named '{$name}'. Use list_experiments to see valid names."
            );
        }

        // Elementor stores per-experiment state in a wp_option. Writing it
        // directly is how Elementor's own settings screen persists the choice.
        $optionKey = $this->elementor->experimentOptionKey($name);
        $previous = get_option($optionKey, $feature['default'] ?? 'default');

        update_option($optionKey, $state);

        // Clear cache — many experiments change generated CSS/markup.
        $this->elementor->clearCache();

        return $this->success([
            'feature_name'   => $name,
            'previous_state' => $previous,
            'new_state'      => $state,
        ], "Experiment '{$name}' set to '{$state}'. CSS cache cleared.");
    }
}
