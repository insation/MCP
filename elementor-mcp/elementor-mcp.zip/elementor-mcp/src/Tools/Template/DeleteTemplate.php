<?php
/**
 * Delete Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DeleteTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_template';
    }

    public function getDescription(): string
    {
        return 'Delete an Elementor library template. By default it goes to trash and can be restored; pass force=true to delete it permanently. Requires mcp:delete and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => ['required', 'int'],
            'force'       => ['optional', 'bool', 'description' => 'Permanently delete instead of trashing. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('deleting Elementor templates');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);
        if (!$post || $post->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        $force = !empty($parameters['force']);
        $result = wp_delete_post($templateId, $force);

        if (!$result) {
            throw ToolException::wordpressError("Failed to delete template {$templateId}.");
        }

        return $this->success([
            'template_id' => $templateId,
            'permanently' => $force,
        ], $force ? 'Template permanently deleted.' : 'Template moved to trash.');
    }
}
