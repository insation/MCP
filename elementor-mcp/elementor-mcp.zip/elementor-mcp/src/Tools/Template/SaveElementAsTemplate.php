<?php
/**
 * Save Element As Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SaveElementAsTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'save_element_as_template';
    }

    public function getDescription(): string
    {
        return 'Take an element (by id) from an existing document and save it as a reusable library template. The element and its subtree are copied with fresh ids; the original document is left untouched. The template type is inferred from the element (container/section) or can be set explicitly. Requires mcp:write.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'   => ['required', 'int'],
            'element_id'    => ['required', 'string', ['notEmpty' => true]],
            'title'         => ['required', 'string', ['notEmpty' => true]],
            'template_type' => ['optional', 'string', 'description' => 'Override the inferred library type (section, container, etc.).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('saving elements as templates');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $element = $found['element'];

        // Infer the template type from the element if not given.
        $type = $parameters['template_type'] ?? null;
        if ($type === null) {
            $elType = $element['elType'] ?? '';
            $type = in_array($elType, ['section', 'container'], true) ? $elType : 'section';
        }

        // Fresh ids for the saved copy.
        $copy = $this->elementor->regenerateIds($element);

        $newId = wp_insert_post([
            'post_title'  => sanitize_text_field($parameters['title']),
            'post_type'   => ElementorService::TEMPLATE_CPT,
            'post_status' => 'publish',
        ], true);
        if (is_wp_error($newId)) {
            throw ToolException::wordpressError('Failed to create the template: ' . $newId->get_error_message());
        }
        $newId = (int) $newId;

        update_post_meta($newId, '_elementor_edit_mode', 'builder');
        update_post_meta($newId, '_elementor_version', ELEMENTOR_VERSION);
        $this->elementor->setTemplateType($newId, (string) $type);

        // The template content is the element wrapped as a top-level array.
        $this->elementor->saveDocumentData($newId, [$copy]);

        return $this->success([
            'source_document_id' => $docId,
            'source_element_id'  => $parameters['element_id'],
            'new_template_id'    => $newId,
            'template_type'      => $type,
        ], 'Element saved as a library template.');
    }
}
