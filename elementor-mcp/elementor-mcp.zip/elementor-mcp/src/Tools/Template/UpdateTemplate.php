<?php
/**
 * Update Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UpdateTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_template';
    }

    public function getDescription(): string
    {
        return 'Update an existing Elementor library template — its title, status, and/or its element tree content. Only the fields you supply are changed. Requires mcp:write.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id'  => ['required', 'int'],
            'title'        => ['optional', 'string'],
            'status'       => ['optional', 'string'],
            'content_json' => ['optional', 'string', 'description' => 'JSON array of top-level elements to replace the template content.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('updating Elementor templates');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);
        if (!$post || $post->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        $changed = [];

        // Post fields
        $postUpdate = ['ID' => $templateId];
        if (isset($parameters['title'])) {
            $postUpdate['post_title'] = sanitize_text_field($parameters['title']);
            $changed[] = 'title';
        }
        if (isset($parameters['status'])) {
            $postUpdate['post_status'] = sanitize_key($parameters['status']);
            $changed[] = 'status';
        }
        if (count($postUpdate) > 1) {
            $res = wp_update_post($postUpdate, true);
            if (is_wp_error($res)) {
                throw ToolException::wordpressError('Failed to update template post: ' . $res->get_error_message());
            }
        }

        // Element tree content
        if (isset($parameters['content_json'])) {
            $content = json_decode($parameters['content_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in content_json: ' . json_last_error_msg());
            }
            if (!is_array($content)) {
                throw ToolException::wordpressError('content_json must decode to an array of elements.');
            }
            if (!$this->elementor->saveDocumentData($templateId, $content)) {
                throw ToolException::wordpressError('Failed to save template content.');
            }
            $changed[] = 'content';
        }

        if (empty($changed)) {
            throw ToolException::wordpressError('Nothing to update — supply at least one of title, status, content_json.');
        }

        return $this->success([
            'template_id' => $templateId,
            'changed'     => $changed,
        ], 'Template updated.');
    }
}
