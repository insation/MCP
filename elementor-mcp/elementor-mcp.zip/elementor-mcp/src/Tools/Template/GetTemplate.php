<?php
/**
 * Get Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_template';
    }

    public function getDescription(): string
    {
        return 'Get a single Elementor library template by id — its metadata plus, optionally, the full element tree. Set include_content=false for just the metadata.';
    }

    public function getSchema(): array
    {
        return [
            'template_id'     => ['required', 'int'],
            'include_content' => ['optional', 'bool', 'description' => 'Include the full element tree. Default true.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);
        if (!$post || $post->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        $result = [
            'id'            => $post->ID,
            'title'         => $post->post_title,
            'template_type' => $this->elementor->getTemplateType($post->ID),
            'status'        => $post->post_status,
            'modified'      => $post->post_modified_gmt,
            'author_id'     => (int) $post->post_author,
        ];

        $includeContent = !array_key_exists('include_content', $parameters)
            || !empty($parameters['include_content']);

        if ($includeContent) {
            $result['content'] = $this->elementor->getDocumentData($templateId);
            $result['page_settings'] = get_post_meta($templateId, '_elementor_page_settings', true) ?: [];
        }

        return $this->success($result);
    }
}
