<?php
/**
 * Count Templates Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class CountTemplates extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'count_templates';
    }

    public function getDescription(): string
    {
        return 'Return counts of Elementor library templates broken down by template type and by post status. A quick inventory of the template library.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $q = new \WP_Query([
            'post_type'      => ElementorService::TEMPLATE_CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ]);

        $byType = [];
        $byStatus = [];
        foreach ($q->posts as $id) {
            $id = (int) $id;
            $type = $this->elementor->getTemplateType($id) ?? 'unknown';
            $byType[$type] = ($byType[$type] ?? 0) + 1;
            $status = get_post_status($id) ?: 'unknown';
            $byStatus[$status] = ($byStatus[$status] ?? 0) + 1;
        }

        arsort($byType);
        arsort($byStatus);

        return $this->success([
            'total'     => count($q->posts),
            'by_type'   => $byType,
            'by_status' => $byStatus,
        ]);
    }
}
