<?php
/**
 * List Templates Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListTemplates extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_templates';
    }

    public function getDescription(): string
    {
        return 'List saved Elementor templates from the template library (the elementor_library post type) — page templates, sections, containers, headers, footers, popups, etc. Each entry returns id, title, template type, status, and modified date. Optionally filter by template type.';
    }

    public function getSchema(): array
    {
        return [
            'template_type' => ['optional', 'string', 'description' => 'Filter by library type: page, section, container, header, footer, popup, etc.'],
            'status'        => ['optional', 'string', 'description' => 'Post status filter. Default: any.'],
            'per_page'      => ['optional', 'int', ['min' => 1], ['max' => 200], 'description' => 'Max results. Default 100.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $args = [
            'post_type'      => ElementorService::TEMPLATE_CPT,
            'post_status'    => $parameters['status'] ?? 'any',
            'posts_per_page' => (int) ($parameters['per_page'] ?? 100),
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];

        if (!empty($parameters['template_type'])) {
            $args['tax_query'] = [[
                'taxonomy' => 'elementor_library_type',
                'field'    => 'slug',
                'terms'    => $parameters['template_type'],
            ]];
        }

        $q = new \WP_Query($args);
        $items = [];
        foreach ($q->posts as $post) {
            $items[] = [
                'id'            => $post->ID,
                'title'         => $post->post_title,
                'template_type' => $this->elementor->getTemplateType($post->ID),
                'status'        => $post->post_status,
                'modified'      => $post->post_modified_gmt,
                'author_id'     => (int) $post->post_author,
            ];
        }

        return $this->success([
            'count'     => count($items),
            'templates' => $items,
        ]);
    }
}
