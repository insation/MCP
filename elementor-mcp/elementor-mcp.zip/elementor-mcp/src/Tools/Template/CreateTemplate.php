<?php
/**
 * Create Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class CreateTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    private const VALID_TYPES = [
        'page', 'section', 'container', 'header', 'footer',
        'single', 'archive', 'popup', 'loop-item', 'widget',
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'create_template';
    }

    public function getDescription(): string
    {
        return 'Create a new Elementor library template. Provide a title, a template type (page, section, container, header, footer, popup, etc.), and optionally the element tree as JSON. Returns the new template id. Requires mcp:write.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'title'         => ['required', 'string', ['notEmpty' => true]],
            'template_type' => ['required', 'string', ['notEmpty' => true], 'description' => 'page, section, container, header, footer, popup, single, archive, loop-item, or widget.'],
            'content_json'  => ['optional', 'string', 'description' => 'JSON array of top-level elements. Omit to create an empty template.'],
            'status'        => ['optional', 'string', 'description' => 'Post status. Default: publish.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('creating Elementor templates');

        $type = $parameters['template_type'];
        if (!in_array($type, self::VALID_TYPES, true)) {
            throw ToolException::wordpressError(
                "Invalid template_type '{$type}'. Valid types: " . implode(', ', self::VALID_TYPES) . '.'
            );
        }

        $content = [];
        if (!empty($parameters['content_json'])) {
            $content = json_decode($parameters['content_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in content_json: ' . json_last_error_msg());
            }
            if (!is_array($content)) {
                throw ToolException::wordpressError('content_json must decode to an array of elements.');
            }
        }

        $postId = wp_insert_post([
            'post_title'  => sanitize_text_field($parameters['title']),
            'post_type'   => ElementorService::TEMPLATE_CPT,
            'post_status' => $parameters['status'] ?? 'publish',
        ], true);

        if (is_wp_error($postId)) {
            throw ToolException::wordpressError('Failed to create template: ' . $postId->get_error_message());
        }

        // Mark it as an Elementor document and set the library type.
        update_post_meta($postId, '_elementor_edit_mode', 'builder');
        update_post_meta($postId, '_elementor_version', ELEMENTOR_VERSION);
        $this->elementor->setTemplateType((int) $postId, $type);

        if (!empty($content)) {
            $this->elementor->saveDocumentData((int) $postId, $content);
        }

        return $this->success([
            'template_id'   => (int) $postId,
            'title'         => $parameters['title'],
            'template_type' => $type,
        ], 'Template created.');
    }
}
