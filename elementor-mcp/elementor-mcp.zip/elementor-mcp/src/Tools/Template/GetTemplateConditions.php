<?php
/**
 * Get Template Conditions Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetTemplateConditions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_template_conditions';
    }

    public function getDescription(): string
    {
        return 'Read the display conditions assigned to a theme-builder template (header, footer, single, archive, popup). Conditions are stored by Elementor Pro in the _elementor_conditions post meta and control where the template is shown. Returns an empty conditions list (and pro_active=false) when Elementor Pro is not installed.';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);
        if (!$post || $post->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        // _elementor_conditions is an Elementor Pro feature.
        $conditions = get_post_meta($templateId, '_elementor_conditions', true);
        if (!is_array($conditions)) {
            $conditions = [];
        }

        return $this->success([
            'template_id'   => $templateId,
            'template_type' => $this->elementor->getTemplateType($templateId),
            'pro_active'    => defined('ELEMENTOR_PRO_VERSION'),
            'conditions'    => $conditions,
        ]);
    }
}
