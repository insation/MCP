<?php
/**
 * Duplicate Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DuplicateTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'duplicate_template';
    }

    public function getDescription(): string
    {
        return 'Duplicate an Elementor library template — creates a new template of the same type with a copy of the element tree (every element gets a fresh id) and page settings. Optionally give the copy a new title. Requires mcp:write.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => ['required', 'int'],
            'new_title'   => ['optional', 'string', 'description' => 'Title for the copy. Defaults to "<original> (copy)".'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('duplicating Elementor templates');

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);
        if (!$post || $post->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        $type = $this->elementor->getTemplateType($templateId) ?? 'page';
        $title = $parameters['new_title'] ?? ($post->post_title . ' (copy)');

        $newId = wp_insert_post([
            'post_title'  => sanitize_text_field($title),
            'post_type'   => ElementorService::TEMPLATE_CPT,
            'post_status' => $post->post_status,
        ], true);

        if (is_wp_error($newId)) {
            throw ToolException::wordpressError('Failed to create the duplicate: ' . $newId->get_error_message());
        }
        $newId = (int) $newId;

        // Carry over Elementor markers + type.
        update_post_meta($newId, '_elementor_edit_mode', 'builder');
        update_post_meta($newId, '_elementor_version', ELEMENTOR_VERSION);
        $this->elementor->setTemplateType($newId, $type);

        // Copy page settings.
        $pageSettings = get_post_meta($templateId, '_elementor_page_settings', true);
        if (is_array($pageSettings) && !empty($pageSettings)) {
            update_post_meta($newId, '_elementor_page_settings', $pageSettings);
        }

        // Copy the element tree with fresh ids throughout.
        $data = $this->elementor->getDocumentData($templateId);
        if (!empty($data)) {
            $fresh = array_map(
                fn($el) => $this->elementor->regenerateIds($el),
                $data
            );
            $this->elementor->saveDocumentData($newId, $fresh);
        }

        return $this->success([
            'source_template_id' => $templateId,
            'new_template_id'    => $newId,
            'template_type'      => $type,
        ], 'Template duplicated.');
    }
}
