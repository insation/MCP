<?php
/**
 * Import Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ImportTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'import_template';
    }

    public function getDescription(): string
    {
        return 'Import a template from an Elementor export JSON structure (the envelope produced by export_template or Elementor\'s own .json export — version, title, type, content, page_settings). Creates a new library template with fresh element ids. Requires mcp:write.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'import_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'The Elementor export JSON envelope.'],
            'title'       => ['optional', 'string', 'description' => 'Override the title from the import. Defaults to the title inside the JSON.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('importing Elementor templates');

        $envelope = json_decode($parameters['import_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in import_json: ' . json_last_error_msg());
        }
        if (!is_array($envelope)) {
            throw ToolException::wordpressError('import_json must decode to an object.');
        }

        // Accept either the full envelope or a bare content array.
        $content = $envelope['content'] ?? null;
        if ($content === null && isset($envelope[0])) {
            // Looks like a bare element array.
            $content = $envelope;
            $envelope = [];
        }
        if (!is_array($content)) {
            throw ToolException::wordpressError('No "content" element array found in the import JSON.');
        }

        $type = $envelope['type'] ?? 'page';
        $title = $parameters['title'] ?? ($envelope['title'] ?? 'Imported Template');

        $newId = wp_insert_post([
            'post_title'  => sanitize_text_field($title),
            'post_type'   => ElementorService::TEMPLATE_CPT,
            'post_status' => 'publish',
        ], true);
        if (is_wp_error($newId)) {
            throw ToolException::wordpressError('Failed to create the imported template: ' . $newId->get_error_message());
        }
        $newId = (int) $newId;

        update_post_meta($newId, '_elementor_edit_mode', 'builder');
        update_post_meta($newId, '_elementor_version', ELEMENTOR_VERSION);
        $this->elementor->setTemplateType($newId, (string) $type);

        if (isset($envelope['page_settings']) && is_array($envelope['page_settings'])) {
            update_post_meta($newId, '_elementor_page_settings', $envelope['page_settings']);
        }

        // Fresh ids throughout so the import never collides with existing content.
        $fresh = array_map(
            fn($el) => $this->elementor->regenerateIds($el),
            $content
        );
        $this->elementor->saveDocumentData($newId, $fresh);

        return $this->success([
            'new_template_id' => $newId,
            'template_type'   => $type,
            'title'           => $title,
        ], 'Template imported.');
    }
}
