<?php
/**
 * Apply Template To Document Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ApplyTemplateToDocument extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'apply_template_to_document';
    }

    public function getDescription(): string
    {
        return 'Insert a saved library template\'s element tree into a target Elementor document — either appended after the document\'s existing content, prepended before it, or replacing it entirely. Every inserted element gets a fresh id so the two documents never share ids. Requires mcp:write.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'template_id'        => ['required', 'int'],
            'target_document_id' => ['required', 'int'],
            'mode'               => ['optional', 'string', ['in' => ['append', 'prepend', 'replace']], 'description' => 'append (default), prepend, or replace.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('applying Elementor templates');

        $templateId = (int) $parameters['template_id'];
        $targetId = (int) $parameters['target_document_id'];
        $mode = $parameters['mode'] ?? 'append';

        $templatePost = get_post($templateId);
        if (!$templatePost || $templatePost->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        $targetData = $this->elementor->getDocumentData($targetId);
        if (empty($targetData) && !$this->elementor->getDocument($targetId)) {
            throw ToolException::wordpressError("Target post {$targetId} is not built with Elementor.");
        }

        $templateData = $this->elementor->getDocumentData($templateId);
        if (empty($templateData)) {
            throw ToolException::wordpressError("Template {$templateId} has no content to apply.");
        }

        // Fresh ids for the inserted copy.
        $insert = array_map(
            fn($el) => $this->elementor->regenerateIds($el),
            $templateData
        );

        switch ($mode) {
            case 'replace':
                $newData = $insert;
                break;
            case 'prepend':
                $newData = array_merge($insert, $targetData);
                break;
            case 'append':
            default:
                $newData = array_merge($targetData, $insert);
                break;
        }

        if (!$this->elementor->saveDocumentData($targetId, $newData)) {
            throw ToolException::wordpressError('Save failed after applying the template.');
        }

        return $this->success([
            'template_id'        => $templateId,
            'target_document_id' => $targetId,
            'mode'               => $mode,
            'elements_inserted'  => count($insert),
        ], "Template applied ({$mode}).");
    }
}
