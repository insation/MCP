<?php
/**
 * Export Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Template;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ExportTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'export_template';
    }

    public function getDescription(): string
    {
        return 'Export an Elementor library template as a portable JSON structure — the same shape Elementor\'s own .json export produces (version, title, type, content, page_settings). Returns the JSON inline so it can be saved or fed straight into import_template on another site.';
    }

    public function getSchema(): array
    {
        return [
            'template_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $templateId = (int) $parameters['template_id'];
        $post = get_post($templateId);
        if (!$post || $post->post_type !== ElementorService::TEMPLATE_CPT) {
            throw ToolException::wordpressError("No Elementor library template with id {$templateId}.");
        }

        $content = $this->elementor->getDocumentData($templateId);
        $pageSettings = get_post_meta($templateId, '_elementor_page_settings', true);

        // Match Elementor's export envelope.
        $export = [
            'version'       => defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : null,
            'title'         => $post->post_title,
            'type'          => $this->elementor->getTemplateType($templateId) ?? 'page',
            'content'       => $content,
            'page_settings' => is_array($pageSettings) ? $pageSettings : [],
        ];

        return $this->success([
            'template_id'  => $templateId,
            'export'       => $export,
            'export_json'  => wp_json_encode($export),
        ]);
    }
}
