<?php
/**
 * Get Widget Schema Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetWidgetSchema extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_widget_schema';
    }

    public function getDescription(): string
    {
        return 'Get the full controls schema for a single widget type — every setting the widget exposes, with its control type, default value, available options, and the section/tab it appears under. This is what you need to know which settings keys are valid when building or updating that widget.';
    }

    public function getSchema(): array
    {
        return [
            'widget_type' => ['required', 'string', ['notEmpty' => true], 'description' => 'The widget type name (e.g. "heading", "image", "button").'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        $widgetType = $parameters['widget_type'];
        $widget = $widgetsManager->get_widget_types($widgetType);

        if ($widget === null) {
            throw ToolException::wordpressError(
                "Widget type '{$widgetType}' is not registered on this site. Use list_widget_types to see available widgets."
            );
        }

        // get_controls() returns the full control definitions keyed by control name.
        $controls = method_exists($widget, 'get_controls') ? $widget->get_controls() : [];

        $simplified = [];
        foreach ($controls as $controlName => $control) {
            $simplified[$controlName] = [
                'type'        => $control['type'] ?? null,
                'label'       => $control['label'] ?? null,
                'default'     => $control['default'] ?? null,
                'tab'         => $control['tab'] ?? null,
                'section'     => $control['section'] ?? null,
                // options present for select/choose controls
                'options'     => isset($control['options']) ? $control['options'] : null,
                'description' => $control['description'] ?? null,
            ];
        }

        return $this->success([
            'widget_type'   => $widgetType,
            'title'         => method_exists($widget, 'get_title') ? $widget->get_title() : $widgetType,
            'categories'    => method_exists($widget, 'get_categories') ? $widget->get_categories() : [],
            'control_count' => count($simplified),
            'controls'      => $simplified,
        ]);
    }
}
