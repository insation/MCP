<?php
/**
 * List Widget Types Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListWidgetTypes extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_widget_types';
    }

    public function getDescription(): string
    {
        return 'List every widget type registered with Elementor on this site — core widgets, plus any from Elementor Pro or third-party addons. Returns each widget\'s name, title, icon, and categories.';
    }

    public function getSchema(): array
    {
        return [
            'category' => ['optional', 'string', 'description' => 'Filter to widgets in a single category (e.g. "basic", "general", "pro-elements").'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        $widgetTypes = $widgetsManager->get_widget_types();

        $categoryFilter = $parameters['category'] ?? null;
        $items = [];
        foreach ($widgetTypes as $name => $widget) {
            $categories = method_exists($widget, 'get_categories') ? $widget->get_categories() : [];
            if ($categoryFilter !== null && !in_array($categoryFilter, $categories, true)) {
                continue;
            }
            $items[] = [
                'name'       => $name,
                'title'      => method_exists($widget, 'get_title') ? $widget->get_title() : $name,
                'icon'       => method_exists($widget, 'get_icon') ? $widget->get_icon() : null,
                'categories' => $categories,
                'keywords'   => method_exists($widget, 'get_keywords') ? $widget->get_keywords() : [],
            ];
        }

        // Sort alphabetically by name for stable output.
        usort($items, static fn($a, $b) => strcmp($a['name'], $b['name']));

        return $this->success([
            'count'      => count($items),
            'pro_active' => defined('ELEMENTOR_PRO_VERSION'),
            'widgets'    => $items,
        ]);
    }
}
