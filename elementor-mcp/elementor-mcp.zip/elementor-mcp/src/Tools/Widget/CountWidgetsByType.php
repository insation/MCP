<?php
/**
 * Count Widgets By Type Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class CountWidgetsByType extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'count_widgets_by_type';
    }

    public function getDescription(): string
    {
        return 'Scan every Elementor document on the site and count how many times each widget type is actually used. Returns a usage tally sorted most-used first. Useful for understanding which widgets a site depends on before a migration or cleanup.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $q = new \WP_Query([
            'post_type'      => 'any',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [[
                'key'   => '_elementor_edit_mode',
                'value' => 'builder',
            ]],
        ]);

        $counts = [];
        $docsScanned = 0;
        $totalWidgets = 0;

        foreach ($q->posts as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            $docsScanned++;
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                if (($el['elType'] ?? '') === 'widget') {
                    $wt = $el['widgetType'] ?? 'unknown';
                    $counts[$wt] = ($counts[$wt] ?? 0) + 1;
                    $totalWidgets++;
                }
            }
        }

        arsort($counts);

        return $this->success([
            'documents_scanned' => $docsScanned,
            'total_widgets'     => $totalWidgets,
            'distinct_types'    => count($counts),
            'usage'             => $counts,
        ]);
    }
}
