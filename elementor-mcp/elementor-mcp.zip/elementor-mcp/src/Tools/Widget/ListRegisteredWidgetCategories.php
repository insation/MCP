<?php
/**
 * List Registered Widget Categories Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListRegisteredWidgetCategories extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_registered_widget_categories';
    }

    public function getDescription(): string
    {
        return 'List the widget categories registered with Elementor (the groupings shown in the editor\'s widget panel — "Basic", "General", "Pro", theme/addon categories, etc.) with a count of how many widgets fall into each.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $elementsManager = $this->elementor->plugin()->elements_manager;
        $rawCategories = method_exists($elementsManager, 'get_categories')
            ? $elementsManager->get_categories()
            : [];

        // Count widgets per category.
        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        $widgetTypes = $widgetsManager->get_widget_types();
        $counts = [];
        foreach ($widgetTypes as $widget) {
            $cats = method_exists($widget, 'get_categories') ? $widget->get_categories() : [];
            foreach ($cats as $cat) {
                $counts[$cat] = ($counts[$cat] ?? 0) + 1;
            }
        }

        $categories = [];
        foreach ($rawCategories as $slug => $cat) {
            $categories[] = [
                'slug'         => $slug,
                'title'        => is_array($cat) ? ($cat['title'] ?? $slug) : $slug,
                'widget_count' => $counts[$slug] ?? 0,
            ];
        }

        // Include any categories that widgets reference but aren't formally registered.
        foreach ($counts as $slug => $count) {
            $known = array_filter($categories, static fn($c) => $c['slug'] === $slug);
            if (empty($known)) {
                $categories[] = [
                    'slug'         => $slug,
                    'title'        => $slug,
                    'widget_count' => $count,
                    'unregistered' => true,
                ];
            }
        }

        return $this->success([
            'count'      => count($categories),
            'categories' => $categories,
        ]);
    }
}
