<?php
/**
 * Validate Widget Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ValidateWidgetSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'validate_widget_settings';
    }

    public function getDescription(): string
    {
        return 'Check a proposed settings object for a widget type against that widget\'s registered controls. Reports which settings keys are unknown (not real controls for this widget) and, for select/choose controls, which values are not among the allowed options. This is a lint check — it does not modify anything.';
    }

    public function getSchema(): array
    {
        return [
            'widget_type'   => ['required', 'string', ['notEmpty' => true]],
            'settings_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'JSON object of the settings to validate.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        $widgetType = $parameters['widget_type'];
        $widget = $widgetsManager->get_widget_types($widgetType);

        if ($widget === null) {
            throw ToolException::wordpressError(
                "Widget type '{$widgetType}' is not registered. Use list_widget_types to see available widgets."
            );
        }

        $settings = json_decode($parameters['settings_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in settings_json: ' . json_last_error_msg());
        }
        if (!is_array($settings)) {
            throw ToolException::wordpressError('settings_json must decode to an object.');
        }

        $controls = method_exists($widget, 'get_controls') ? $widget->get_controls() : [];

        $unknownKeys = [];
        $invalidValues = [];

        foreach ($settings as $key => $value) {
            // Elementor internal/global keys (prefixed with _) are always allowed.
            if (is_string($key) && str_starts_with($key, '_')) {
                continue;
            }
            if (!isset($controls[$key])) {
                $unknownKeys[] = $key;
                continue;
            }
            $control = $controls[$key];
            // For select/choose controls, check the value is an allowed option.
            if (isset($control['options']) && is_array($control['options']) && !empty($control['options'])) {
                $allowed = array_keys($control['options']);
                // Some controls store arrays (multi-select); check each.
                $values = is_array($value) ? $value : [$value];
                foreach ($values as $v) {
                    if ($v !== '' && $v !== null && !in_array($v, $allowed, true)) {
                        $invalidValues[] = [
                            'key'             => $key,
                            'value'           => $v,
                            'allowed_options' => $allowed,
                        ];
                    }
                }
            }
        }

        $valid = empty($unknownKeys) && empty($invalidValues);

        return $this->success([
            'widget_type'    => $widgetType,
            'valid'          => $valid,
            'checked_keys'   => count($settings),
            'unknown_keys'   => $unknownKeys,
            'invalid_values' => $invalidValues,
        ], $valid ? 'All settings keys and values are valid for this widget.' : 'Validation found problems — see unknown_keys and invalid_values.');
    }
}
