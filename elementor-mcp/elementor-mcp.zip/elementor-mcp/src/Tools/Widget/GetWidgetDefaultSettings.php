<?php
/**
 * Get Widget Default Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetWidgetDefaultSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_widget_default_settings';
    }

    public function getDescription(): string
    {
        return 'Return the default settings object for a widget type — every control\'s default value, collapsed into the flat settings map Elementor stores. Use this as a starting point for the settings of a new widget element, then override only what you need.';
    }

    public function getSchema(): array
    {
        return [
            'widget_type' => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        $widgetType = $parameters['widget_type'];
        $widget = $widgetsManager->get_widget_types($widgetType);

        if ($widget === null) {
            throw ToolException::wordpressError(
                "Widget type '{$widgetType}' is not registered. Use list_widget_types to see available widgets."
            );
        }

        $controls = method_exists($widget, 'get_controls') ? $widget->get_controls() : [];

        $defaults = [];
        foreach ($controls as $controlName => $control) {
            // Skip UI-only controls (headings, dividers) that have no stored value.
            $type = $control['type'] ?? '';
            if (in_array($type, ['heading', 'divider', 'raw_html', 'tab', 'tabs', 'section'], true)) {
                continue;
            }
            if (array_key_exists('default', $control)) {
                $defaults[$controlName] = $control['default'];
            }
        }

        return $this->success([
            'widget_type'   => $widgetType,
            'setting_count' => count($defaults),
            'defaults'      => $defaults,
            'example_element' => [
                'elType'     => 'widget',
                'widgetType' => $widgetType,
                'settings'   => $defaults,
                'elements'   => [],
            ],
        ]);
    }
}
