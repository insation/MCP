<?php
/**
 * Find Unused Widget Types Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class FindUnusedWidgetTypes extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_unused_widget_types';
    }

    public function getDescription(): string
    {
        return 'Compare the widget types registered on this site against the widget types actually used in documents, and return the registered widgets that appear nowhere. Helps identify addon widgets that could potentially be deprecated, or just understand what is available but unused.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        // Registered widget types
        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        $registered = array_keys($widgetsManager->get_widget_types());

        // Used widget types across all documents
        $q = new \WP_Query([
            'post_type'      => 'any',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [[
                'key'   => '_elementor_edit_mode',
                'value' => 'builder',
            ]],
        ]);

        $used = [];
        foreach ($q->posts as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                if (($el['elType'] ?? '') === 'widget' && !empty($el['widgetType'])) {
                    $used[$el['widgetType']] = true;
                }
            }
        }

        $unused = array_values(array_diff($registered, array_keys($used)));
        sort($unused);

        return $this->success([
            'registered_count' => count($registered),
            'used_count'       => count($used),
            'unused_count'     => count($unused),
            'unused_widgets'   => $unused,
        ]);
    }
}
