<?php
/**
 * Bulk Replace Widget Type Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Widget;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class BulkReplaceWidgetType extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'bulk_replace_widget_type';
    }

    public function getDescription(): string
    {
        return 'Change the widgetType of every widget of a given type, in one document or across all Elementor documents. Only the widgetType string is changed — element ids, settings, and positions are preserved. This is a blunt instrument: if the two widgets do not share settings keys the result may need cleanup. Supports dry_run to preview the count of affected widgets without saving. Subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'from_widget_type' => ['required', 'string', ['notEmpty' => true]],
            'to_widget_type'   => ['required', 'string', ['notEmpty' => true]],
            'document_id'      => ['optional', 'int', 'description' => 'Limit to one document. Omit to apply across all Elementor documents.'],
            'dry_run'          => ['optional', 'bool', 'description' => 'When true, only report what would change without saving. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $from = $parameters['from_widget_type'];
        $to = $parameters['to_widget_type'];
        $dryRun = !empty($parameters['dry_run']);

        if (!$dryRun) {
            $this->checkSafeMode('bulk-replacing widget types');
        }

        // Confirm the target widget type actually exists (avoid creating broken docs).
        $widgetsManager = $this->elementor->plugin()->widgets_manager;
        if ($widgetsManager->get_widget_types($to) === null) {
            throw ToolException::wordpressError(
                "Target widget type '{$to}' is not registered on this site. Refusing to create elements with an unknown widgetType."
            );
        }

        if (!empty($parameters['document_id'])) {
            $docIds = [(int) $parameters['document_id']];
        } else {
            $q = new \WP_Query([
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [[
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ]],
            ]);
            $docIds = $q->posts;
        }

        $documentsAffected = 0;
        $widgetsChanged = 0;
        $perDocument = [];

        foreach ($docIds as $docId) {
            $docId = (int) $docId;
            $data = $this->elementor->getDocumentData($docId);
            if (empty($data)) {
                continue;
            }

            $changedInDoc = 0;
            $newData = $this->recursiveReplace($data, $from, $to, $changedInDoc);

            if ($changedInDoc > 0) {
                $documentsAffected++;
                $widgetsChanged += $changedInDoc;
                $perDocument[] = ['document_id' => $docId, 'widgets_changed' => $changedInDoc];

                if (!$dryRun) {
                    if (!$this->elementor->saveDocumentData($docId, $newData)) {
                        throw ToolException::wordpressError("Save failed for document {$docId} during bulk replace.");
                    }
                }
            }
        }

        return $this->success([
            'from_widget_type'   => $from,
            'to_widget_type'     => $to,
            'dry_run'            => $dryRun,
            'documents_affected' => $documentsAffected,
            'widgets_changed'    => $widgetsChanged,
            'per_document'       => $perDocument,
        ], $dryRun
            ? "Dry run: {$widgetsChanged} widget(s) across {$documentsAffected} document(s) would be changed."
            : "Changed {$widgetsChanged} widget(s) across {$documentsAffected} document(s).");
    }

    /**
     * Recursively walk the element tree, rewriting widgetType on matches.
     *
     * @param array<int, array<string,mixed>> $elements
     * @param int $changed Passed by reference; incremented per match.
     * @return array<int, array<string,mixed>>
     */
    private function recursiveReplace(array $elements, string $from, string $to, int &$changed): array
    {
        foreach ($elements as $i => $el) {
            if (($el['elType'] ?? '') === 'widget' && ($el['widgetType'] ?? '') === $from) {
                $elements[$i]['widgetType'] = $to;
                $changed++;
            }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                $elements[$i]['elements'] = $this->recursiveReplace($el['elements'], $from, $to, $changed);
            }
        }
        return $elements;
    }
}
