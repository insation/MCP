<?php
/**
 * Save Kit Style Variation As Kit Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\StyleVariations;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SaveKitStyleVariationAsKit extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'save_kit_style_variation_as_kit';
    }

    public function getDescription(): string
    {
        return 'Create a new, inactive kit that is a copy of an existing kit with a style variation applied on top. The new kit becomes a saved, switchable theme variation — it does NOT become active, so the live site is unaffected until you switch to it. The variation\'s style keys are merged over the source kit\'s full settings. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'name'           => ['required', 'string', ['notEmpty' => true], 'description' => 'Title for the new kit.'],
            'variation_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'The style variation JSON envelope from export_kit_styles.'],
            'source_kit_id'  => ['optional', 'int', 'description' => 'Kit to base the copy on. Omit to use the active kit.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('saving a kit style variation as a new kit');

        $sourceKitId = isset($parameters['source_kit_id'])
            ? (int) $parameters['source_kit_id']
            : $this->elementor->activeKitId();
        if ($sourceKitId <= 0 || !get_post($sourceKitId)) {
            throw ToolException::wordpressError('Source kit is not available — pass a valid source_kit_id or ensure the site has an active kit.');
        }

        $envelope = json_decode($parameters['variation_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($envelope)) {
            throw ToolException::wordpressError('Invalid JSON in variation_json.');
        }
        $styles = $envelope['styles'] ?? $envelope;
        if (!is_array($styles) || empty($styles)) {
            throw ToolException::wordpressError('No "styles" object found in variation_json.');
        }

        // Base settings = full settings of the source kit, with the variation merged over.
        $baseSettings = $this->elementor->getKitSettings($sourceKitId);
        $newSettings = array_merge($baseSettings, $styles);

        // Create the new kit post (elementor_library + "kit" type), inactive.
        $newKitId = wp_insert_post([
            'post_title'  => sanitize_text_field($parameters['name']),
            'post_type'   => ElementorService::TEMPLATE_CPT,
            'post_status' => 'publish',
        ], true);
        if (is_wp_error($newKitId)) {
            throw ToolException::wordpressError('Failed to create the new kit: ' . $newKitId->get_error_message());
        }
        $newKitId = (int) $newKitId;

        // Mark it as a kit and an Elementor document.
        $this->elementor->setTemplateType($newKitId, 'kit');
        update_post_meta($newKitId, '_elementor_edit_mode', 'builder');
        update_post_meta($newKitId, '_elementor_version', defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '');

        // Write the merged settings WITHOUT touching the active kit / CSS cache —
        // this kit is inactive, so we write the meta directly rather than via
        // saveKitSettings (which clears cache for the live site).
        update_post_meta($newKitId, '_elementor_page_settings', $newSettings);

        return $this->success([
            'source_kit_id'  => $sourceKitId,
            'new_kit_id'     => $newKitId,
            'name'           => $parameters['name'],
            'is_active'      => false,
            'merged_style_keys' => array_keys($styles),
        ], "New kit '{$parameters['name']}' created (id {$newKitId}). It is inactive — switch to it to make it live.");
    }
}
