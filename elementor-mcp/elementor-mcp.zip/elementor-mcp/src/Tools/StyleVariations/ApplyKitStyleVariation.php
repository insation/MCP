<?php
/**
 * Apply Kit Style Variation Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\StyleVariations;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ApplyKitStyleVariation extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'apply_kit_style_variation';
    }

    public function getDescription(): string
    {
        return 'Apply a style variation (the JSON envelope produced by export_kit_styles) to a kit. The variation\'s style keys — global colors, typography, button/link styles, layout defaults — are merged into the target kit\'s settings, leaving non-style settings untouched. The CSS cache is cleared afterward. This changes the whole site\'s look, so it requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'variation_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'The style variation JSON envelope from export_kit_styles.'],
            'kit_id'         => ['optional', 'int', 'description' => 'Target kit id. Omit to apply to the active kit.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('applying a kit style variation');

        $kitId = isset($parameters['kit_id']) ? (int) $parameters['kit_id'] : $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('No kit available to apply the variation to.');
        }
        if (!get_post($kitId)) {
            throw ToolException::wordpressError("No kit post with id {$kitId}.");
        }

        $envelope = json_decode($parameters['variation_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in variation_json: ' . json_last_error_msg());
        }
        if (!is_array($envelope)) {
            throw ToolException::wordpressError('variation_json must decode to an object.');
        }

        // Accept either the full envelope or a bare styles object.
        $styles = $envelope['styles'] ?? null;
        if ($styles === null && !isset($envelope['variation_format'])) {
            $styles = $envelope;
        }
        if (!is_array($styles) || empty($styles)) {
            throw ToolException::wordpressError('No "styles" object found in the variation JSON.');
        }

        $existing = $this->elementor->getKitSettings($kitId);
        $merged = array_merge($existing, $styles);

        if (!$this->elementor->saveKitSettings($merged, $kitId)) {
            throw ToolException::wordpressError('Failed to save the kit after applying the variation.');
        }

        return $this->success([
            'kit_id'           => $kitId,
            'applied_keys'     => array_keys($styles),
            'variation_name'   => $envelope['name'] ?? null,
        ], 'Style variation applied to the kit and CSS cache cleared.');
    }
}
