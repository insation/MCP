<?php
/**
 * Export Kit Styles Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\StyleVariations;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ExportKitStyles extends AbstractTool
{
    protected ElementorService $elementor;

    /** The kit setting groups that constitute a "style variation". */
    private const STYLE_KEYS = [
        'system_colors', 'custom_colors',
        'system_typography', 'custom_typography',
        'default_generic_fonts',
        'body_background_background', 'body_background_color',
        'button_typography_typography', 'button_text_color', 'button_background_color',
        'link_normal_color', 'link_hover_color',
        'container_width', 'space_between_widgets',
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'export_kit_styles';
    }

    public function getDescription(): string
    {
        return 'Export the style-relevant portion of a kit as a portable "style variation" JSON object — global colors, typography, button/link styles, layout defaults. This is a focused subset of the full kit settings, suitable for saving as a named theme variation and applying to another kit or site with apply_kit_style_variation.';
    }

    public function getSchema(): array
    {
        return [
            'kit_id' => ['optional', 'int', 'description' => 'Specific kit id. Omit for the active kit.'],
            'name'   => ['optional', 'string', 'description' => 'A label to embed in the exported variation.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $kitId = isset($parameters['kit_id']) ? (int) $parameters['kit_id'] : $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('No kit available to export.');
        }
        if (!get_post($kitId)) {
            throw ToolException::wordpressError("No kit post with id {$kitId}.");
        }

        $settings = $this->elementor->getKitSettings($kitId);

        // Pull only the style-relevant keys that are actually present.
        $style = [];
        foreach (self::STYLE_KEYS as $key) {
            if (array_key_exists($key, $settings)) {
                $style[$key] = $settings[$key];
            }
        }

        $variation = [
            'variation_format' => 1,
            'name'             => $parameters['name'] ?? ('Kit ' . $kitId . ' styles'),
            'source_kit_id'    => $kitId,
            'elementor_version'=> defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : null,
            'styles'           => $style,
        ];

        return $this->success([
            'kit_id'         => $kitId,
            'style_key_count'=> count($style),
            'variation'      => $variation,
            'variation_json' => wp_json_encode($variation),
        ]);
    }
}
