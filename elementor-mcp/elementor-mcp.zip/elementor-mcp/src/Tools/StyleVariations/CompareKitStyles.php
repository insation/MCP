<?php
/**
 * Compare Kit Styles Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\StyleVariations;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class CompareKitStyles extends AbstractTool
{
    protected ElementorService $elementor;

    /** The style keys a variation tracks — same set ExportKitStyles uses. */
    private const STYLE_KEYS = [
        'system_colors', 'custom_colors',
        'system_typography', 'custom_typography',
        'default_generic_fonts',
        'body_background_background', 'body_background_color',
        'button_typography_typography', 'button_text_color', 'button_background_color',
        'link_normal_color', 'link_hover_color',
        'container_width', 'space_between_widgets',
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'compare_kit_styles';
    }

    public function getDescription(): string
    {
        return 'Compare the style settings of two kits, or of one kit against a style-variation JSON envelope. Reports, per style key, whether the values match, differ, or are present on only one side. A read-only diff — useful for previewing what apply_kit_style_variation would change before running it.';
    }

    public function getSchema(): array
    {
        return [
            'kit_id_a'       => ['optional', 'int', 'description' => 'First kit id. Omit to use the active kit.'],
            'kit_id_b'       => ['optional', 'int', 'description' => 'Second kit id to compare against kit A.'],
            'variation_json' => ['optional', 'string', 'description' => 'Alternatively, compare kit A against this style-variation JSON envelope.'],
        ];
    }

    /**
     * Extract only the tracked style keys from a settings array.
     *
     * @param array<string,mixed> $settings
     * @return array<string,mixed>
     */
    private function styleSubset(array $settings): array
    {
        $out = [];
        foreach (self::STYLE_KEYS as $key) {
            if (array_key_exists($key, $settings)) {
                $out[$key] = $settings[$key];
            }
        }
        return $out;
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $kitIdA = isset($parameters['kit_id_a']) ? (int) $parameters['kit_id_a'] : $this->elementor->activeKitId();
        if ($kitIdA <= 0 || !get_post($kitIdA)) {
            throw ToolException::wordpressError('Kit A is not available — pass a valid kit_id_a or ensure the site has an active kit.');
        }
        $stylesA = $this->styleSubset($this->elementor->getKitSettings($kitIdA));

        // Side B is either another kit or a variation envelope.
        $sideBLabel = null;
        if (!empty($parameters['variation_json'])) {
            $envelope = json_decode($parameters['variation_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($envelope)) {
                throw ToolException::wordpressError('Invalid JSON in variation_json.');
            }
            $stylesB = $envelope['styles'] ?? $envelope;
            if (!is_array($stylesB)) {
                throw ToolException::wordpressError('No "styles" object found in variation_json.');
            }
            $stylesB = $this->styleSubset($stylesB);
            $sideBLabel = 'variation:' . ($envelope['name'] ?? 'unnamed');
        } elseif (isset($parameters['kit_id_b'])) {
            $kitIdB = (int) $parameters['kit_id_b'];
            if ($kitIdB <= 0 || !get_post($kitIdB)) {
                throw ToolException::wordpressError("Kit B (id {$kitIdB}) does not exist.");
            }
            $stylesB = $this->styleSubset($this->elementor->getKitSettings($kitIdB));
            $sideBLabel = 'kit:' . $kitIdB;
        } else {
            throw ToolException::wordpressError('Provide either kit_id_b or variation_json to compare against.');
        }

        // Build the per-key diff.
        $allKeys = array_unique(array_merge(array_keys($stylesA), array_keys($stylesB)));
        sort($allKeys);

        $diff = [];
        $matchCount = 0;
        $diffCount = 0;
        foreach ($allKeys as $key) {
            $inA = array_key_exists($key, $stylesA);
            $inB = array_key_exists($key, $stylesB);
            if ($inA && $inB) {
                $same = wp_json_encode($stylesA[$key]) === wp_json_encode($stylesB[$key]);
                $status = $same ? 'match' : 'differ';
                $same ? $matchCount++ : $diffCount++;
            } elseif ($inA) {
                $status = 'only_in_a';
                $diffCount++;
            } else {
                $status = 'only_in_b';
                $diffCount++;
            }
            $diff[] = ['key' => $key, 'status' => $status];
        }

        return $this->success([
            'side_a'       => 'kit:' . $kitIdA,
            'side_b'       => $sideBLabel,
            'match_count'  => $matchCount,
            'diff_count'   => $diffCount,
            'identical'    => $diffCount === 0,
            'diff'         => $diff,
        ]);
    }
}
