<?php
/**
 * Get Dynamic Tag Config Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\DynamicTags;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetDynamicTagConfig extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_dynamic_tag_config';
    }

    public function getDescription(): string
    {
        return 'Get the configuration of a single dynamic tag — its title, group, the categories of widget setting it can bind to (text, image, URL, color, etc.), and its own controls (the options shown when you configure the tag, e.g. which custom field to read). This is what you need to construct a valid __dynamic binding for a widget setting.';
    }

    public function getSchema(): array
    {
        return [
            'tag_name' => ['required', 'string', ['notEmpty' => true], 'description' => 'The dynamic tag name (from list_dynamic_tags).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $mgr = $this->elementor->dynamicTagsManager();
        $tagName = $parameters['tag_name'];

        // get_tag_info returns the registered info for a single tag in recent
        // Elementor versions; fall back to scanning get_tags() otherwise.
        $tag = null;
        if (method_exists($mgr, 'get_tag_info')) {
            $info = $mgr->get_tag_info($tagName);
            $tag = is_array($info) ? ($info['instance'] ?? null) : null;
        }
        if ($tag === null) {
            $tags = method_exists($mgr, 'get_tags') ? $mgr->get_tags() : [];
            $tag = $tags[$tagName] ?? null;
        }

        if ($tag === null || !is_object($tag)) {
            throw ToolException::wordpressError(
                "Dynamic tag '{$tagName}' is not registered. Use list_dynamic_tags to see available tags."
            );
        }

        $group = method_exists($tag, 'get_group') ? $tag->get_group() : [];
        $categories = method_exists($tag, 'get_categories') ? $tag->get_categories() : [];

        // Tag controls describe how the tag is configured by the user.
        $controls = [];
        if (method_exists($tag, 'get_controls')) {
            foreach ($tag->get_controls() as $name => $control) {
                $controls[$name] = [
                    'type'    => $control['type'] ?? null,
                    'label'   => $control['label'] ?? null,
                    'default' => $control['default'] ?? null,
                    'options' => $control['options'] ?? null,
                ];
            }
        }

        return $this->success([
            'tag_name'   => $tagName,
            'title'      => method_exists($tag, 'get_title') ? $tag->get_title() : $tagName,
            'groups'     => is_array($group) ? $group : [$group],
            'categories' => $categories,
            'controls'   => $controls,
        ]);
    }
}
