<?php
/**
 * Find Dynamic Tag Usage Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\DynamicTags;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class FindDynamicTagUsage extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_dynamic_tag_usage';
    }

    public function getDescription(): string
    {
        return 'Scan a document (or all Elementor documents) for elements that use dynamic tags. Elementor stores dynamic bindings in an element\'s __dynamic settings key. Returns each element that has dynamic bindings, with the setting keys bound and the raw tag values. Useful for auditing which pages depend on dynamic data.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['optional', 'int', 'description' => 'Limit to one document. Omit to scan all Elementor documents.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        if (!empty($parameters['document_id'])) {
            $docIds = [(int) $parameters['document_id']];
        } else {
            $q = new \WP_Query([
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [[
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ]],
            ]);
            $docIds = $q->posts;
        }

        $usages = [];
        $scanned = 0;
        foreach ($docIds as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            $scanned++;
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                $settings = $el['settings'] ?? [];
                // Elementor stores dynamic bindings under the __dynamic key.
                if (is_array($settings) && !empty($settings['__dynamic']) && is_array($settings['__dynamic'])) {
                    $usages[] = [
                        'document_id' => (int) $docId,
                        'element_id'  => $el['id'] ?? null,
                        'elType'      => $el['elType'] ?? null,
                        'widgetType'  => $el['widgetType'] ?? null,
                        'bound_keys'  => array_keys($settings['__dynamic']),
                        'bindings'    => $settings['__dynamic'],
                    ];
                }
            }
        }

        return $this->success([
            'documents_scanned' => $scanned,
            'usage_count'       => count($usages),
            'usages'            => $usages,
        ]);
    }
}
