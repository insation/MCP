<?php
/**
 * List Dynamic Tag Groups Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\DynamicTags;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListDynamicTagGroups extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_dynamic_tag_groups';
    }

    public function getDescription(): string
    {
        return 'List the dynamic-tag groups registered with Elementor — the categories ("Post", "Archive", "Site", "Media", "Author", etc.) that organize dynamic tags in the editor UI. Includes a count of tags in each group.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $mgr = $this->elementor->dynamicTagsManager();
        $groups = method_exists($mgr, 'get_groups') ? $mgr->get_groups() : [];
        $tags = method_exists($mgr, 'get_tags') ? $mgr->get_tags() : [];

        // Count tags per group.
        $counts = [];
        foreach ($tags as $tag) {
            if (!is_object($tag)) {
                continue;
            }
            $g = method_exists($tag, 'get_group') ? $tag->get_group() : [];
            $g = is_array($g) ? $g : ($g !== null ? [$g] : []);
            foreach ($g as $slug) {
                $counts[$slug] = ($counts[$slug] ?? 0) + 1;
            }
        }

        $items = [];
        foreach ($groups as $slug => $group) {
            $items[] = [
                'slug'      => $slug,
                'title'     => is_array($group) ? ($group['title'] ?? $slug) : (string) $group,
                'tag_count' => $counts[$slug] ?? 0,
            ];
        }

        return $this->success([
            'count'      => count($items),
            'pro_active' => defined('ELEMENTOR_PRO_VERSION'),
            'groups'     => $items,
        ]);
    }
}
