<?php
/**
 * List Dynamic Tags Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\DynamicTags;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListDynamicTags extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_dynamic_tags';
    }

    public function getDescription(): string
    {
        return 'List the dynamic tags registered with Elementor — the data sources (post title, featured image, author, custom field, site URL, etc.) that can be bound to widget settings instead of static values. Each entry returns its name, title, and group. The free Elementor plugin registers only a few; most dynamic tags come from Elementor Pro.';
    }

    public function getSchema(): array
    {
        return [
            'group' => ['optional', 'string', 'description' => 'Filter to a single dynamic-tag group.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $mgr = $this->elementor->dynamicTagsManager();
        $tags = method_exists($mgr, 'get_tags') ? $mgr->get_tags() : [];

        $groupFilter = $parameters['group'] ?? null;
        $items = [];
        foreach ($tags as $name => $tag) {
            // $tag may be a class name string or an instance depending on Elementor version.
            $group = null;
            $title = $name;
            if (is_object($tag)) {
                $group = method_exists($tag, 'get_group') ? $tag->get_group() : null;
                $title = method_exists($tag, 'get_title') ? $tag->get_title() : $name;
            }
            // get_group can return an array of groups.
            $groups = is_array($group) ? $group : ($group !== null ? [$group] : []);
            if ($groupFilter !== null && !in_array($groupFilter, $groups, true)) {
                continue;
            }
            $items[] = [
                'name'   => $name,
                'title'  => $title,
                'groups' => $groups,
            ];
        }

        usort($items, static fn($a, $b) => strcmp($a['name'], $b['name']));

        return $this->success([
            'count'      => count($items),
            'pro_active' => defined('ELEMENTOR_PRO_VERSION'),
            'tags'       => $items,
        ]);
    }
}
