<?php
/**
 * Get Elementor Document Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetElementorDocument extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_elementor_document';
    }

    public function getDescription(): string
    {
        return 'Get full information about a single Elementor document: post info, document type, top-level element count, edit and preview URLs, and basic stats. Use get_document_data for the full element tree.';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                'description' => 'Post ID.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $id = (int) $parameters['id'];
        $post = get_post($id);
        if (!$post) {
            throw ToolException::wordpressError("Post not found: ID {$id}");
        }

        $doc = $this->elementor->getDocument($id);
        if (!$doc) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $data = $this->elementor->getDocumentData($id);

        // Count elements at each depth
        $stats = ['top_level' => count($data), 'total_elements' => 0, 'widgets' => 0, 'containers' => 0, 'sections' => 0, 'columns' => 0];
        foreach ($this->elementor->walkElements($data) as $entry) {
            $stats['total_elements']++;
            $type = $entry['element']['elType'] ?? '';
            $widgetType = $entry['element']['widgetType'] ?? '';
            if ($type === 'widget') {
                $stats['widgets']++;
            } elseif ($type === 'container') {
                $stats['containers']++;
            } elseif ($type === 'section') {
                $stats['sections']++;
            } elseif ($type === 'column') {
                $stats['columns']++;
            }
        }

        return $this->success([
            'id'            => $post->ID,
            'title'         => $post->post_title,
            'post_type'     => $post->post_type,
            'status'        => $post->post_status,
            'modified'      => $post->post_modified,
            'document_type' => $doc->get_name(),
            'edit_url'      => $doc->get_edit_url(),
            'preview_url'   => $doc->get_preview_url(),
            'permalink'     => get_permalink($post->ID),
            'stats'         => $stats,
            'author_id'     => (int) $post->post_author,
        ]);
    }
}
