<?php
/**
 * Get Document Data Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetDocumentData extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_document_data';
    }

    public function getDescription(): string
    {
        return 'Get the full Elementor element tree for a document — the raw structured data Elementor stores in _elementor_data post meta. The tree is a nested array of element dictionaries (sections, columns, containers, widgets) each with id, elType, settings, and elements (children).';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'shallow' => [
                'optional',
                'bool',
                'description' => 'When true, return only top-level elements with element counts (not their children). Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $id = (int) $parameters['id'];
        $doc = $this->elementor->getDocument($id);
        if (!$doc) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $data = $this->elementor->getDocumentData($id);

        if (!empty($parameters['shallow'])) {
            $shallow = array_map(static function ($el) {
                return [
                    'id'         => $el['id'] ?? null,
                    'elType'     => $el['elType'] ?? null,
                    'widgetType' => $el['widgetType'] ?? null,
                    'children'   => isset($el['elements']) && is_array($el['elements']) ? count($el['elements']) : 0,
                ];
            }, $data);
            return $this->success([
                'id'         => $id,
                'top_level'  => count($shallow),
                'elements'   => $shallow,
            ]);
        }

        return $this->success([
            'id'       => $id,
            'top_level'=> count($data),
            'elements' => $data,
        ]);
    }
}
