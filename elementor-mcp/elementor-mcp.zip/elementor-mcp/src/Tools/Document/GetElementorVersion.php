<?php
/**
 * Get Elementor Version Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class GetElementorVersion extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_elementor_version';
    }

    public function getDescription(): string
    {
        return 'Return Elementor\'s installed version, whether Elementor Pro is also active (if available), and the ElementorMCP plugin version.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $elementor_version = defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : null;
        $pro_active        = defined('ELEMENTOR_PRO_VERSION');
        $pro_version       = $pro_active ? ELEMENTOR_PRO_VERSION : null;

        return $this->success([
            'elementor_version'    => $elementor_version,
            'elementor_pro_active' => $pro_active,
            'elementor_pro_version'=> $pro_version,
            'plugin_version'       => defined('INSATIONAI_EMCP_VERSION') ? INSATIONAI_EMCP_VERSION : null,
        ]);
    }
}
