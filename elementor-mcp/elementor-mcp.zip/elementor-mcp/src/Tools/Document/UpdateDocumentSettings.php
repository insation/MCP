<?php
/**
 * Update Document Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UpdateDocumentSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_document_settings';
    }

    public function getDescription(): string
    {
        return 'Update per-document Elementor page settings. Merge-replaces with existing settings (pass replace=true for a full overwrite instead).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'settings_json' => [
                'required',
                'string',
                'description' => 'JSON-encoded settings object.'
            ],
            'replace' => [
                'optional',
                'bool',
                'description' => 'When true, fully replace settings rather than merge. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $id = (int) $parameters['id'];
        if (!$this->elementor->getDocument($id)) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $new = json_decode($parameters['settings_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in settings_json: ' . json_last_error_msg());
        }
        if (!is_array($new)) {
            throw ToolException::wordpressError('settings_json must decode to an object.');
        }

        if (empty($parameters['replace'])) {
            $existing = get_post_meta($id, '_elementor_page_settings', true);
            $existing = is_array($existing) ? $existing : [];
            $new = array_merge($existing, $new);
        }

        update_post_meta($id, '_elementor_page_settings', $new);

        return $this->success([
            'id'       => $id,
            'settings' => $new,
        ], 'Document settings updated.');
    }
}
