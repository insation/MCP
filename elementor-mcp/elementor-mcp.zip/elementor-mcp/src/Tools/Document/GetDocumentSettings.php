<?php
/**
 * Get Document Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetDocumentSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_document_settings';
    }

    public function getDescription(): string
    {
        return 'Get the per-document Elementor page settings (the _elementor_page_settings meta) — page-level styling, custom CSS, hide title flag, page layout, etc.';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $id = (int) $parameters['id'];
        if (!$this->elementor->getDocument($id)) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $settings = get_post_meta($id, '_elementor_page_settings', true);
        return $this->success([
            'id'       => $id,
            'settings' => is_array($settings) ? $settings : [],
        ]);
    }
}
