<?php
/**
 * Delete Document Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DeleteDocument extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_elementor_document';
    }

    public function getDescription(): string
    {
        return 'Trash or permanently delete an Elementor document. Defaults to trashing; pass force=true to bypass trash. Subject to safe mode. (Equivalent to deleting the underlying WordPress post.)';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'force' => [
                'optional',
                'bool',
                'description' => 'When true, permanently delete (skip trash). Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('deleting Elementor documents');

        $id = (int) $parameters['id'];
        $post = get_post($id);
        if (!$post) {
            throw ToolException::wordpressError("Post not found: ID {$id}");
        }
        $doc = $this->elementor->getDocument($id);
        if (!$doc) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $force = !empty($parameters['force']);
        $result = wp_delete_post($id, $force);
        if (!$result) {
            throw ToolException::wordpressError('Delete failed.');
        }

        return $this->success([
            'id'        => $id,
            'permanent' => $force,
        ], $force ? 'Document permanently deleted.' : 'Document moved to trash.');
    }
}
