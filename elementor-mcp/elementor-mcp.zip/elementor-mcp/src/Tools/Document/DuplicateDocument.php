<?php
/**
 * Duplicate Document Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DuplicateDocument extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'duplicate_document';
    }

    public function getDescription(): string
    {
        return 'Duplicate an Elementor document: creates a new post of the same type with a fresh _elementor_data copy. Useful for A/B testing layouts or scaffolding new pages from existing ones.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'new_title' => [
                'optional',
                'string',
                'description' => 'Title for the duplicate. Defaults to "<original> (Copy)".'
            ],
            'status' => [
                'optional',
                'string',
                ['in' => ['draft', 'publish', 'private', 'pending']],
                'description' => 'Status for the duplicate. Default: draft.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $id = (int) $parameters['id'];
        $source = get_post($id);
        if (!$source) {
            throw ToolException::wordpressError("Post not found: ID {$id}");
        }
        $doc = $this->elementor->getDocument($id);
        if (!$doc) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $newPostId = wp_insert_post([
            'post_title'   => $parameters['new_title'] ?? ($source->post_title . ' (Copy)'),
            'post_status'  => $parameters['status'] ?? 'draft',
            'post_type'    => $source->post_type,
            'post_content' => $source->post_content,
            'post_author'  => get_current_user_id() ?: $source->post_author,
        ]);

        if (is_wp_error($newPostId)) {
            throw ToolException::wordpressError('Failed to create duplicate: ' . $newPostId->get_error_message());
        }

        // Copy Elementor meta
        $metaKeys = [
            '_elementor_data',
            '_elementor_version',
            '_elementor_edit_mode',
            '_elementor_template_type',
            '_elementor_page_settings',
            '_elementor_css',
            '_elementor_pro_version',
        ];
        foreach ($metaKeys as $key) {
            $val = get_post_meta($id, $key, true);
            if ($val !== '' && $val !== null) {
                update_post_meta($newPostId, $key, $val);
            }
        }

        // Force Elementor edit mode so the duplicate opens in the editor
        update_post_meta($newPostId, '_elementor_edit_mode', 'builder');

        return $this->success([
            'source_id'      => $id,
            'new_id'         => (int) $newPostId,
            'new_edit_url'   => admin_url("post.php?post={$newPostId}&action=elementor"),
            'new_view_url'   => get_permalink($newPostId),
        ], 'Document duplicated.');
    }
}
