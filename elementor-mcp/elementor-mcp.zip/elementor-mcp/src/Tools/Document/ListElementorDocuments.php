<?php
/**
 * List Elementor Documents Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListElementorDocuments extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_elementor_documents';
    }

    public function getDescription(): string
    {
        return 'List all WordPress posts/pages/CPTs that are built with Elementor. Returns ID, title, post type, status, last modified, and document type.';
    }

    public function getSchema(): array
    {
        return [
            'post_type' => [
                'optional',
                'string',
                'description' => 'Filter by post type. Default: all post types.'
            ],
            'status' => [
                'optional',
                'string',
                ['in' => ['publish', 'draft', 'pending', 'private', 'any']],
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1], ['max' => 100],
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1],
            ],
            'search' => ['optional', 'string'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $perPage = $parameters['per_page'] ?? 20;
        $page    = $parameters['page'] ?? 1;

        $args = [
            'post_type'      => $parameters['post_type'] ?? 'any',
            'post_status'    => $parameters['status'] ?? 'any',
            'posts_per_page' => $perPage,
            'paged'          => $page,
            'meta_query'     => [
                [
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ],
            ],
        ];
        if (!empty($parameters['search'])) {
            $args['s'] = $parameters['search'];
        }

        $query = new \WP_Query($args);

        $items = array_map(function (\WP_Post $p) {
            $doc = $this->elementor->getDocument($p->ID);
            return [
                'id'           => $p->ID,
                'title'        => $p->post_title,
                'post_type'    => $p->post_type,
                'status'       => $p->post_status,
                'modified'     => $p->post_modified,
                'document_type'=> $doc ? $doc->get_name() : null,
                'edit_url'     => $doc ? $doc->get_edit_url() : null,
                'url'          => get_permalink($p->ID),
            ];
        }, $query->posts);

        return $this->success([
            'count'    => count($items),
            'total'    => (int) $query->found_posts,
            'page'     => $page,
            'per_page' => $perPage,
            'items'    => $items,
        ]);
    }
}
