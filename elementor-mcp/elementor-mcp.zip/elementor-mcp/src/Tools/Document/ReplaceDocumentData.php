<?php
/**
 * Replace Document Data Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ReplaceDocumentData extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'replace_document_data';
    }

    public function getDescription(): string
    {
        return 'Replace the entire Elementor element tree of a document with the supplied JSON. Use carefully — this overwrites everything. Pair with get_document_data first if you want to read-modify-write. A backup revision is created automatically by Elementor on save.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'elements_json' => [
                'required',
                'string',
                'description' => 'JSON-encoded array of element dictionaries (the same shape get_document_data.elements returns).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('replacing Elementor document data');

        $id = (int) $parameters['id'];
        $doc = $this->elementor->getDocument($id);
        if (!$doc) {
            throw ToolException::wordpressError("Post {$id} is not built with Elementor.");
        }

        $elements = json_decode($parameters['elements_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in elements_json: ' . json_last_error_msg());
        }
        if (!is_array($elements)) {
            throw ToolException::wordpressError('elements_json must decode to an array.');
        }

        $beforeCount = count($this->elementor->getDocumentData($id));
        $ok = $this->elementor->saveDocumentData($id, $elements);

        if (!$ok) {
            throw ToolException::wordpressError('Save failed. Check that the supplied elements have the correct shape (each must have id, elType, settings).');
        }

        return $this->success([
            'id'                 => $id,
            'top_level_before'   => $beforeCount,
            'top_level_after'    => count($elements),
        ], 'Document data replaced.');
    }
}
