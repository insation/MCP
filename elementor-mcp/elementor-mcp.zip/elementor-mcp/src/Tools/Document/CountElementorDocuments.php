<?php
/**
 * Count Elementor Documents Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Document;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class CountElementorDocuments extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'count_elementor_documents';
    }

    public function getDescription(): string
    {
        return 'Return counts of Elementor-built documents broken down by post type and post status.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT p.post_type, p.post_status, COUNT(*) AS c
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm
                 ON pm.post_id = p.ID AND pm.meta_key = '_elementor_edit_mode' AND pm.meta_value = 'builder'
             GROUP BY p.post_type, p.post_status",
            ARRAY_A
        );

        $byType = [];
        $byStatus = [];
        $total = 0;
        foreach ((array) $rows as $r) {
            $c = (int) $r['c'];
            $byType[$r['post_type']] = ($byType[$r['post_type']] ?? 0) + $c;
            $byStatus[$r['post_status']] = ($byStatus[$r['post_status']] ?? 0) + $c;
            $total += $c;
        }

        return $this->success([
            'total'      => $total,
            'by_type'    => $byType,
            'by_status'  => $byStatus,
        ]);
    }
}
