<?php
/**
 * List Font Groups Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Fonts;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListFontGroups extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_font_groups';
    }

    public function getDescription(): string
    {
        return 'List Elementor\'s font groups — the categories fonts are organized into (System, Google, Google Early Access, plus any added by addons or custom-font plugins) — each with a count of how many fonts it contains. Use the slugs here as the "group" filter for list_fonts.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $groups = $this->elementor->getFontGroups();
        $fonts = $this->elementor->getFonts();

        // Count fonts per group.
        $counts = [];
        foreach ($fonts as $group) {
            $counts[$group] = ($counts[$group] ?? 0) + 1;
        }

        $items = [];
        foreach ($groups as $slug => $label) {
            $items[] = [
                'slug'       => $slug,
                'label'      => $label,
                'font_count' => $counts[$slug] ?? 0,
            ];
        }

        return $this->success([
            'count'  => count($items),
            'groups' => $items,
        ]);
    }
}
