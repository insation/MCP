<?php
/**
 * List Fonts Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Fonts;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListFonts extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_fonts';
    }

    public function getDescription(): string
    {
        return 'List the fonts available in Elementor — system fonts, Google Fonts, and any custom or addon-provided fonts. Each entry returns the font name and its group. Optionally filter by group. This is the set of valid values for any font-family control in a widget or kit setting.';
    }

    public function getSchema(): array
    {
        return [
            'group'    => ['optional', 'string', 'description' => 'Filter by font group: system, googlefonts, earlyaccess, etc.'],
            'per_page' => ['optional', 'int', ['min' => 1], ['max' => 2000], 'description' => 'Max fonts to return. Default 500. Google Fonts alone number 1000+.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $fonts = $this->elementor->getFonts();
        $groups = $this->elementor->getFontGroups();

        $groupFilter = $parameters['group'] ?? null;
        $limit = (int) ($parameters['per_page'] ?? 500);

        $items = [];
        foreach ($fonts as $name => $group) {
            if ($groupFilter !== null && $group !== $groupFilter) {
                continue;
            }
            $items[] = [
                'name'        => $name,
                'group'       => $group,
                'group_label' => $groups[$group] ?? $group,
            ];
            if (count($items) >= $limit) {
                break;
            }
        }

        return $this->success([
            'count'        => count($items),
            'total_available' => count($fonts),
            'truncated'    => count($fonts) > count($items) && $groupFilter === null,
            'fonts'        => $items,
        ]);
    }
}
