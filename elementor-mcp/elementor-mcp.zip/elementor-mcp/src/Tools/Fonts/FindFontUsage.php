<?php
/**
 * Find Font Usage Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Fonts;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class FindFontUsage extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_font_usage';
    }

    public function getDescription(): string
    {
        return 'Scan Elementor documents for direct font-family usage. Walks every element\'s settings looking for keys that contain "font_family" and tallies which fonts are explicitly set on elements (as opposed to inherited from global typography). Optionally narrow to a single font name. Useful before removing a font or auditing performance (each distinct Google Font is a separate request).';
    }

    public function getSchema(): array
    {
        return [
            'font_name'   => ['optional', 'string', 'description' => 'Only report usage of this specific font.'],
            'document_id' => ['optional', 'int', 'description' => 'Limit to one document. Omit to scan all.'],
        ];
    }

    /**
     * Recursively collect font_family values. $hits passed by reference:
     * map of font name => list of [setting_key].
     *
     * @param mixed $value
     */
    private function collectFonts($value, array &$hits, string $keyPath = ''): void
    {
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $childPath = $keyPath === '' ? (string) $k : $keyPath . '.' . $k;
                // A font_family control stores the family name as a string value.
                if (is_string($v) && $v !== '' && stripos((string) $k, 'font_family') !== false) {
                    $hits[$v][] = $childPath;
                } else {
                    $this->collectFonts($v, $hits, $childPath);
                }
            }
        }
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $fontFilter = $parameters['font_name'] ?? null;

        if (!empty($parameters['document_id'])) {
            $docIds = [(int) $parameters['document_id']];
        } else {
            $q = new \WP_Query([
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [[
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ]],
            ]);
            $docIds = $q->posts;
        }

        $usageByFont = [];
        $perElement = [];
        $scanned = 0;

        foreach ($docIds as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            $scanned++;
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                $settings = $el['settings'] ?? [];
                if (!is_array($settings)) {
                    continue;
                }
                $hits = [];
                $this->collectFonts($settings, $hits);
                foreach ($hits as $font => $keys) {
                    if ($fontFilter !== null && $font !== $fontFilter) {
                        continue;
                    }
                    $usageByFont[$font] = ($usageByFont[$font] ?? 0) + count($keys);
                    $perElement[] = [
                        'document_id' => (int) $docId,
                        'element_id'  => $el['id'] ?? null,
                        'font'        => $font,
                        'setting_keys'=> $keys,
                    ];
                }
            }
        }

        arsort($usageByFont);

        return $this->success([
            'documents_scanned' => $scanned,
            'font_filter'       => $fontFilter,
            'distinct_fonts'    => count($usageByFont),
            'usage_by_font'     => $usageByFont,
            'occurrences'       => $perElement,
        ]);
    }
}
