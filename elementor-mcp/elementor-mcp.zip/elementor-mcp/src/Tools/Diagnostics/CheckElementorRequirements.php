<?php
/**
 * Check Elementor Requirements Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Diagnostics;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class CheckElementorRequirements extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'check_elementor_requirements';
    }

    public function getDescription(): string
    {
        return 'Check the server environment against Elementor\'s recommended requirements: PHP version, memory limit, max_input_vars, post_max_size, max_execution_time, and key PHP extensions. Each check is reported as pass / warn / fail with the current value, so you can spot environment issues that cause editor timeouts or save failures.';
    }

    public function getSchema(): array
    {
        return [];
    }

    private function bytes(string $val): int
    {
        $val = trim($val);
        if ($val === '') {
            return 0;
        }
        $last = strtolower($val[strlen($val) - 1]);
        $num = (int) $val;
        switch ($last) {
            case 'g': $num *= 1024; // fall through
            case 'm': $num *= 1024; // fall through
            case 'k': $num *= 1024;
        }
        return $num;
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $checks = [];

        // PHP version — Elementor recommends 7.4+.
        $phpOk = version_compare(PHP_VERSION, '7.4', '>=');
        $checks[] = [
            'check'   => 'php_version',
            'value'   => PHP_VERSION,
            'status'  => $phpOk ? 'pass' : 'fail',
            'note'    => $phpOk ? null : 'Elementor recommends PHP 7.4 or newer.',
        ];

        // Memory limit — recommend 256M+.
        $mem = ini_get('memory_limit');
        $memBytes = $this->bytes((string) $mem);
        $memStatus = $memBytes < 0 ? 'pass' : ($memBytes >= 256 * 1024 * 1024 ? 'pass' : ($memBytes >= 128 * 1024 * 1024 ? 'warn' : 'fail'));
        $checks[] = [
            'check'  => 'memory_limit',
            'value'  => $mem,
            'status' => $memStatus,
            'note'   => $memStatus === 'pass' ? null : 'Elementor recommends 256M or higher.',
        ];

        // max_input_vars — recommend 2000+.
        $miv = (int) ini_get('max_input_vars');
        $mivStatus = $miv >= 2000 ? 'pass' : ($miv >= 1000 ? 'warn' : 'fail');
        $checks[] = [
            'check'  => 'max_input_vars',
            'value'  => $miv,
            'status' => $mivStatus,
            'note'   => $mivStatus === 'pass' ? null : 'Low max_input_vars can truncate large page saves. Recommend 2000+.',
        ];

        // post_max_size — recommend 8M+.
        $pms = ini_get('post_max_size');
        $pmsStatus = $this->bytes((string) $pms) >= 8 * 1024 * 1024 ? 'pass' : 'warn';
        $checks[] = [
            'check'  => 'post_max_size',
            'value'  => $pms,
            'status' => $pmsStatus,
            'note'   => $pmsStatus === 'pass' ? null : 'Recommend 8M or higher.',
        ];

        // max_execution_time — recommend 30+ (0 = unlimited is fine).
        $met = (int) ini_get('max_execution_time');
        $metStatus = ($met === 0 || $met >= 30) ? 'pass' : 'warn';
        $checks[] = [
            'check'  => 'max_execution_time',
            'value'  => $met,
            'status' => $metStatus,
            'note'   => $metStatus === 'pass' ? null : 'Short execution limits can interrupt large saves/regeneration.',
        ];

        // Key PHP extensions.
        foreach (['dom', 'gd', 'mbstring', 'zip', 'json'] as $ext) {
            $loaded = extension_loaded($ext);
            $checks[] = [
                'check'  => "ext_{$ext}",
                'value'  => $loaded ? 'loaded' : 'missing',
                'status' => $loaded ? 'pass' : ($ext === 'json' || $ext === 'mbstring' ? 'fail' : 'warn'),
                'note'   => $loaded ? null : "PHP extension '{$ext}' is not loaded.",
            ];
        }

        $fail = count(array_filter($checks, static fn($c) => $c['status'] === 'fail'));
        $warn = count(array_filter($checks, static fn($c) => $c['status'] === 'warn'));

        return $this->success([
            'overall' => $fail > 0 ? 'fail' : ($warn > 0 ? 'warn' : 'pass'),
            'fail'    => $fail,
            'warn'    => $warn,
            'checks'  => $checks,
        ]);
    }
}
