<?php
/**
 * Validate Document Data Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Diagnostics;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ValidateDocumentData extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'validate_document_data';
    }

    public function getDescription(): string
    {
        return 'Walk an Elementor document\'s element tree and report structural problems: elements missing an elType, widgets missing a widgetType, duplicate element ids, non-array settings or children, and unusually deep nesting. A read-only health check — it never modifies the document.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $problems = [];
        $seenIds = [];
        $elementCount = 0;
        $maxDepth = 0;

        foreach ($this->elementor->walkElements($data) as $entry) {
            $elementCount++;
            $el = $entry['element'];
            $depth = count($entry['path']) - 1;
            if ($depth > $maxDepth) {
                $maxDepth = $depth;
            }
            $id = $el['id'] ?? null;

            // Shape problems via the shared validator.
            foreach ($this->elementor->validateElementShape($el) as $msg) {
                $problems[] = [
                    'element_id' => $id,
                    'path'       => $entry['path'],
                    'problem'    => $msg,
                ];
            }

            // Duplicate id check.
            if ($id !== null) {
                if (isset($seenIds[$id])) {
                    $problems[] = [
                        'element_id' => $id,
                        'path'       => $entry['path'],
                        'problem'    => 'Duplicate element id — also appears at path ' . implode('.', $seenIds[$id]) . '.',
                    ];
                } else {
                    $seenIds[$id] = $entry['path'];
                }
            } else {
                $problems[] = [
                    'element_id' => null,
                    'path'       => $entry['path'],
                    'problem'    => 'Element has no id.',
                ];
            }

            // Excessive nesting warning.
            if ($depth > 12) {
                $problems[] = [
                    'element_id' => $id,
                    'path'       => $entry['path'],
                    'problem'    => "Unusually deep nesting (depth {$depth}).",
                ];
            }
        }

        return $this->success([
            'document_id'   => $docId,
            'valid'         => empty($problems),
            'element_count' => $elementCount,
            'max_depth'     => $maxDepth,
            'problem_count' => count($problems),
            'problems'      => $problems,
        ], empty($problems)
            ? 'Document structure looks valid.'
            : count($problems) . ' structural problem(s) found.');
    }
}
