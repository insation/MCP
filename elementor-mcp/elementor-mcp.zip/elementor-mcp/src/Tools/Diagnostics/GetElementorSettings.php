<?php
/**
 * Get Elementor Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Diagnostics;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class GetElementorSettings extends AbstractTool
{
    protected ElementorService $elementor;

    /**
     * The wp_options keys that hold Elementor's global (non-kit) settings.
     * These are the values from Elementor > Settings (General / Advanced /
     * Performance / Features tabs).
     */
    private const SETTING_KEYS = [
        'elementor_cpt_support',
        'elementor_disable_color_schemes',
        'elementor_disable_typography_schemes',
        'elementor_allow_tracking',
        'elementor_css_print_method',
        'elementor_editor_break_lines',
        'elementor_unfiltered_files_upload',
        'elementor_google_font',
        'elementor_font_display',
        'elementor_load_fa4_shim',
        'elementor_optimized_dom_output',
        'elementor_optimized_image_loading',
        'elementor_optimized_gutenberg_loading',
        'elementor_lazy_load_background_images',
        'elementor_enable_inline_font_icons',
        'elementor_experiment-container',
        'elementor_default_generic_fonts',
        'elementor_container_width',
        'elementor_space_between_widgets',
        'elementor_page_title_selector',
        'elementor_viewport_lg',
        'elementor_viewport_md',
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_elementor_settings';
    }

    public function getDescription(): string
    {
        return 'Read Elementor\'s global plugin settings — the values from Elementor > Settings (General, Advanced, Performance tabs): CSS print method, breakpoints, container width, CPT support, font handling, performance flags, and more. Returns each known setting key with its current value (or null if unset).';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $settings = [];
        foreach (self::SETTING_KEYS as $key) {
            $value = get_option($key, null);
            // Trim the "elementor_" prefix for a cleaner key in the response.
            $shortKey = (strpos($key, 'elementor_') === 0) ? substr($key, 10) : $key;
            $settings[$shortKey] = $value;
        }

        return $this->success([
            'settings' => $settings,
        ]);
    }
}
