<?php
/**
 * Get Elementor System Info Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Diagnostics;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class GetElementorSystemInfo extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_elementor_system_info';
    }

    public function getDescription(): string
    {
        return 'Elementor-focused environment snapshot: Elementor and Elementor Pro versions, the active kit id, CSS print method, whether the editor loader / optimized DOM / other key settings are on, counts of Elementor documents and templates, and the active theme. The first thing to gather when diagnosing an Elementor issue.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        // Count Elementor-built documents.
        $docQuery = new \WP_Query([
            'post_type'      => 'any',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [[
                'key'   => '_elementor_edit_mode',
                'value' => 'builder',
            ]],
        ]);

        $templateQuery = new \WP_Query([
            'post_type'      => ElementorService::TEMPLATE_CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ]);

        $theme = wp_get_theme();

        return $this->success([
            'elementor_version'     => defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : null,
            'elementor_pro_version' => defined('ELEMENTOR_PRO_VERSION') ? ELEMENTOR_PRO_VERSION : null,
            'pro_active'            => defined('ELEMENTOR_PRO_VERSION'),
            'active_kit_id'         => $this->elementor->activeKitId(),
            'css_print_method'      => get_option('elementor_css_print_method', 'external'),
            'editor_break_lines'    => get_option('elementor_editor_break_lines', ''),
            'optimized_dom_output'  => get_option('elementor_optimized_dom_output', ''),
            'optimized_image_loading' => get_option('elementor_optimized_image_loading', ''),
            'document_count'        => count($docQuery->posts),
            'template_count'        => count($templateQuery->posts),
            'active_theme'          => [
                'name'    => $theme->get('Name'),
                'version' => $theme->get('Version'),
            ],
            'wordpress_version'     => get_bloginfo('version'),
            'php_version'           => PHP_VERSION,
        ]);
    }
}
