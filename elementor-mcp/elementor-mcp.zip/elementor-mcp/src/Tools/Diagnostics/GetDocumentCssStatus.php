<?php
/**
 * Get Document CSS Status Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Diagnostics;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetDocumentCssStatus extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_document_css_status';
    }

    public function getDescription(): string
    {
        return 'Report the CSS generation status for one Elementor document — the site-wide CSS print method, whether a generated CSS file exists for this post (in the uploads/elementor/css directory), its size and last-modified time, and the _elementor_css meta Elementor keeps to track generation. Helps diagnose "my style changes are not showing" problems.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $printMethod = get_option('elementor_css_print_method', 'external');

        // Elementor tracks per-post CSS generation state in _elementor_css meta.
        $cssMeta = get_post_meta($docId, '_elementor_css', true);

        // Look for the generated file in the uploads dir.
        $upload = wp_upload_dir();
        $cssFile = trailingslashit($upload['basedir']) . 'elementor/css/post-' . $docId . '.css';
        $fileExists = file_exists($cssFile);

        $fileInfo = null;
        if ($fileExists) {
            $fileInfo = [
                'path'           => $cssFile,
                'size_bytes'     => filesize($cssFile),
                'last_modified'  => gmdate('Y-m-d H:i:s', filemtime($cssFile)) . ' UTC',
            ];
        }

        return $this->success([
            'document_id'      => $docId,
            'css_print_method' => $printMethod,
            'css_meta'         => is_array($cssMeta) ? $cssMeta : ($cssMeta ?: null),
            'generated_file'   => $fileExists ? $fileInfo : null,
            'file_exists'      => $fileExists,
            'hint'             => $printMethod === 'internal'
                ? 'Print method is "internal" — CSS is inlined in the page <head>, so no file is expected.'
                : 'Print method is "external" — if file_exists is false, regenerate CSS for this document.',
        ]);
    }
}
