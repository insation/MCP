<?php
/**
 * Find Orphaned Elementor Data Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Diagnostics;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class FindOrphanedElementorData extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_orphaned_elementor_data';
    }

    public function getDescription(): string
    {
        return 'Scan for posts in an inconsistent Elementor state: posts that have _elementor_data meta but are not flagged with _elementor_edit_mode=builder, posts flagged as builder-mode but carrying empty/missing _elementor_data, and _elementor_data that fails to JSON-decode. These mismatches cause pages that look broken in the editor or render blank. Read-only diagnostic.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        global $wpdb;

        // All posts that have either of the two key Elementor meta keys.
        $rows = $wpdb->get_results(
            "SELECT p.ID, p.post_type, p.post_status,
                    MAX(CASE WHEN pm.meta_key = '_elementor_edit_mode' THEN pm.meta_value END) AS edit_mode,
                    MAX(CASE WHEN pm.meta_key = '_elementor_data' THEN pm.meta_value END) AS data
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
             WHERE pm.meta_key IN ('_elementor_edit_mode', '_elementor_data')
             GROUP BY p.ID, p.post_type, p.post_status",
            ARRAY_A
        );

        $orphans = [];
        foreach ((array) $rows as $row) {
            $id = (int) $row['ID'];
            $editMode = $row['edit_mode'];
            $data = $row['data'];
            $hasData = is_string($data) && trim($data) !== '' && trim($data) !== '[]';

            if ($hasData && $editMode !== 'builder') {
                $orphans[] = [
                    'post_id'   => $id,
                    'post_type' => $row['post_type'],
                    'status'    => $row['post_status'],
                    'issue'     => 'Has _elementor_data but is not flagged builder-mode.',
                ];
                continue;
            }
            if ($editMode === 'builder' && !$hasData) {
                $orphans[] = [
                    'post_id'   => $id,
                    'post_type' => $row['post_type'],
                    'status'    => $row['post_status'],
                    'issue'     => 'Flagged builder-mode but _elementor_data is empty or missing.',
                ];
                continue;
            }
            if ($hasData) {
                $decoded = json_decode((string) $data, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $orphans[] = [
                        'post_id'   => $id,
                        'post_type' => $row['post_type'],
                        'status'    => $row['post_status'],
                        'issue'     => '_elementor_data fails to JSON-decode: ' . json_last_error_msg(),
                    ];
                }
            }
        }

        return $this->success([
            'posts_scanned' => count((array) $rows),
            'orphan_count'  => count($orphans),
            'orphans'       => $orphans,
        ], empty($orphans)
            ? 'No orphaned or inconsistent Elementor data found.'
            : count($orphans) . ' post(s) with inconsistent Elementor data.');
    }
}
