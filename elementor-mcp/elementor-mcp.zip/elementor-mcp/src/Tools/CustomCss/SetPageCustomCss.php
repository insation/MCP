<?php
/**
 * Set Page Custom CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\CustomCss;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SetPageCustomCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'set_page_custom_css';
    }

    public function getDescription(): string
    {
        return 'Set the page-level Custom CSS of an Elementor document (the page-settings Custom CSS panel). Pass append=true to add to the existing CSS instead of replacing it. The document\'s CSS cache is cleared afterward. Note this feature only renders on the front end when Elementor Pro is active; the value is still stored and returned regardless. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'css'         => ['required', 'string', 'description' => 'The CSS to set. Pass an empty string to clear it.'],
            'append'      => ['optional', 'bool', 'description' => 'Append to existing CSS instead of replacing. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('setting page custom CSS');

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $pageSettings = $this->elementor->getPageSettings($docId);
        $existing = $pageSettings['custom_css'] ?? '';
        if (!is_string($existing)) {
            $existing = '';
        }

        $newCss = $parameters['css'];
        if (!empty($parameters['append']) && $existing !== '') {
            $newCss = $existing . "\n" . $newCss;
        }

        $pageSettings['custom_css'] = $newCss;

        if (!$this->elementor->savePageSettings($docId, $pageSettings)) {
            throw ToolException::wordpressError('Failed to save page custom CSS.');
        }

        return $this->success([
            'document_id' => $docId,
            'appended'    => !empty($parameters['append']),
            'length'      => strlen($newCss),
            'pro_active'  => defined('ELEMENTOR_PRO_VERSION'),
        ], defined('ELEMENTOR_PRO_VERSION')
            ? 'Page custom CSS saved and CSS cache cleared.'
            : 'Page custom CSS saved. Note: it will only render on the front end with Elementor Pro active.');
    }
}
