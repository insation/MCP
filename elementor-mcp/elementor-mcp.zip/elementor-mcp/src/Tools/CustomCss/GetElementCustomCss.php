<?php
/**
 * Get Element Custom CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\CustomCss;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetElementCustomCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_element_custom_css';
    }

    public function getDescription(): string
    {
        return 'Read the per-element Custom CSS of a single element inside a document — the CSS from that element\'s Advanced > Custom CSS control, stored in the element\'s settings under the custom_css key. This is an Elementor Pro control; on free-only sites it is typically empty.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'element_id'  => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $settings = $found['element']['settings'] ?? [];
        $css = is_array($settings) ? ($settings['custom_css'] ?? '') : '';
        if (!is_string($css)) {
            $css = '';
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $parameters['element_id'],
            'pro_active'  => defined('ELEMENTOR_PRO_VERSION'),
            'custom_css'  => $css,
            'length'      => strlen($css),
        ]);
    }
}
