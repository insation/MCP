<?php
/**
 * Get Page Custom CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\CustomCss;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetPageCustomCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_page_custom_css';
    }

    public function getDescription(): string
    {
        return 'Read the page-level Custom CSS of an Elementor document — the CSS entered in the page-settings "Custom CSS" panel. This is an Elementor Pro feature stored in the page settings under the custom_css key; on free-only sites it is typically empty.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $pageSettings = $this->elementor->getPageSettings($docId);
        $css = $pageSettings['custom_css'] ?? '';
        if (!is_string($css)) {
            $css = '';
        }

        return $this->success([
            'document_id' => $docId,
            'pro_active'  => defined('ELEMENTOR_PRO_VERSION'),
            'custom_css'  => $css,
            'length'      => strlen($css),
        ]);
    }
}
