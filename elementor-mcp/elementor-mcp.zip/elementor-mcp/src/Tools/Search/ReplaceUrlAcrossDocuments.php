<?php
/**
 * Replace URL Across Documents Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Search;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ReplaceUrlAcrossDocuments extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'replace_url_across_documents';
    }

    public function getDescription(): string
    {
        return 'Site-wide URL find-and-replace across every Elementor document — the Elementor-data equivalent of a database search-replace after a domain migration. Replaces a URL (or any string) inside all element settings of all Elementor-built posts. Always supports dry_run, and dry_run defaults to TRUE here because this touches the whole site — you must explicitly pass dry_run=false to actually write. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'search'  => ['required', 'string', ['notEmpty' => true], 'description' => 'The URL or string to find (e.g. https://old-domain.com).'],
            'replace' => ['required', 'string', ['notEmpty' => true], 'description' => 'The replacement (e.g. https://new-domain.com).'],
            'dry_run' => ['optional', 'bool', 'description' => 'Preview only. DEFAULTS TO TRUE — pass false to actually write changes.'],
        ];
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    private function replaceValue($value, string $search, string $replace, int &$count)
    {
        if (is_string($value)) {
            $n = 0;
            $result = str_replace($search, $replace, $value, $n);
            $count += $n;
            return $result;
        }
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $value[$k] = $this->replaceValue($v, $search, $replace, $count);
            }
        }
        return $value;
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        // dry_run defaults to TRUE for this site-wide operation.
        $dryRun = !array_key_exists('dry_run', $parameters) || (bool) $parameters['dry_run'];

        if (!$dryRun) {
            $this->checkSafeMode('site-wide URL replacement in Elementor documents');
        }

        $search = $parameters['search'];
        $replace = $parameters['replace'];

        $q = new \WP_Query([
            'post_type'      => 'any',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [[
                'key'   => '_elementor_edit_mode',
                'value' => 'builder',
            ]],
        ]);

        $documentsAffected = 0;
        $totalReplacements = 0;
        $perDocument = [];

        foreach ($q->posts as $docId) {
            $docId = (int) $docId;
            $data = $this->elementor->getDocumentData($docId);
            if (empty($data)) {
                continue;
            }
            $count = 0;
            $newData = $this->replaceValue($data, $search, $replace, $count);
            if ($count > 0) {
                $documentsAffected++;
                $totalReplacements += $count;
                $perDocument[] = ['document_id' => $docId, 'replacements' => $count];
                if (!$dryRun) {
                    if (!$this->elementor->saveDocumentData($docId, $newData)) {
                        throw ToolException::wordpressError("Save failed for document {$docId} during URL replacement.");
                    }
                }
            }
        }

        return $this->success([
            'dry_run'            => $dryRun,
            'search'             => $search,
            'replace'            => $replace,
            'documents_affected' => $documentsAffected,
            'total_replacements' => $totalReplacements,
            'per_document'       => $perDocument,
        ], $dryRun
            ? "Dry run: {$totalReplacements} replacement(s) across {$documentsAffected} document(s) would be made. Pass dry_run=false to apply."
            : "{$totalReplacements} replacement(s) made across {$documentsAffected} document(s).");
    }
}
