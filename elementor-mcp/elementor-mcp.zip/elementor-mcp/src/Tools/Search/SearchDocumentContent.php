<?php
/**
 * Search Document Content Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Search;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class SearchDocumentContent extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'search_document_content';
    }

    public function getDescription(): string
    {
        return 'Search the text inside Elementor element settings — across one document or every Elementor document. Looks through all string values in element settings (headings, text, button labels, URLs, etc.) and returns each element where the search term appears, with the matching setting keys. Read-only; case-insensitive by default.';
    }

    public function getSchema(): array
    {
        return [
            'search'         => ['required', 'string', ['notEmpty' => true], 'description' => 'Text to search for.'],
            'document_id'    => ['optional', 'int', 'description' => 'Limit to one document. Omit to search all.'],
            'case_sensitive' => ['optional', 'bool', 'description' => 'Default false.'],
        ];
    }

    /**
     * Recursively collect string-valued setting keys that contain the needle.
     *
     * @param mixed $value
     * @return string[] dotted key paths that matched
     */
    private function searchValue($value, string $needle, bool $caseSensitive, string $prefix = ''): array
    {
        $hits = [];
        if (is_string($value)) {
            $haystack = $caseSensitive ? $value : strtolower($value);
            $find = $caseSensitive ? $needle : strtolower($needle);
            if ($find !== '' && strpos($haystack, $find) !== false) {
                $hits[] = $prefix;
            }
        } elseif (is_array($value)) {
            foreach ($value as $k => $v) {
                $childPrefix = $prefix === '' ? (string) $k : $prefix . '.' . $k;
                $hits = array_merge($hits, $this->searchValue($v, $needle, $caseSensitive, $childPrefix));
            }
        }
        return $hits;
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $needle = $parameters['search'];
        $caseSensitive = !empty($parameters['case_sensitive']);

        if (!empty($parameters['document_id'])) {
            $docIds = [(int) $parameters['document_id']];
        } else {
            $q = new \WP_Query([
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [[
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ]],
            ]);
            $docIds = $q->posts;
        }

        $matches = [];
        $scanned = 0;
        foreach ($docIds as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            $scanned++;
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                $settings = $el['settings'] ?? [];
                if (!is_array($settings)) {
                    continue;
                }
                $hitKeys = $this->searchValue($settings, $needle, $caseSensitive);
                if (!empty($hitKeys)) {
                    $matches[] = [
                        'document_id' => (int) $docId,
                        'element_id'  => $el['id'] ?? null,
                        'elType'      => $el['elType'] ?? null,
                        'widgetType'  => $el['widgetType'] ?? null,
                        'matched_keys'=> $hitKeys,
                    ];
                }
            }
        }

        return $this->success([
            'search'            => $needle,
            'case_sensitive'    => $caseSensitive,
            'documents_scanned' => $scanned,
            'match_count'       => count($matches),
            'matches'           => $matches,
        ]);
    }
}
