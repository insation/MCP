<?php
/**
 * Replace In Document Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Search;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ReplaceInDocument extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'replace_in_document';
    }

    public function getDescription(): string
    {
        return 'Find-and-replace plain text inside one Elementor document\'s element settings. Every string value in every element\'s settings is searched; matches are replaced. Supports dry_run to preview the replacement count without saving. This is a literal string replace, not regex. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'search'      => ['required', 'string', ['notEmpty' => true]],
            'replace'     => ['required', 'string', 'description' => 'Replacement text. May be empty to delete the search term.'],
            'dry_run'     => ['optional', 'bool', 'description' => 'Preview only — count replacements without saving. Default false.'],
        ];
    }

    /**
     * Recursively replace in all string values. $count passed by reference.
     *
     * @param mixed $value
     * @return mixed
     */
    private function replaceValue($value, string $search, string $replace, int &$count)
    {
        if (is_string($value)) {
            $n = 0;
            $result = str_replace($search, $replace, $value, $n);
            $count += $n;
            return $result;
        }
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $value[$k] = $this->replaceValue($v, $search, $replace, $count);
            }
        }
        return $value;
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $dryRun = !empty($parameters['dry_run']);
        if (!$dryRun) {
            $this->checkSafeMode('find-and-replace in an Elementor document');
        }

        $search = $parameters['search'];
        $replace = $parameters['replace'];
        $count = 0;

        // Walk the whole tree, replacing within each element's settings.
        $newData = $this->replaceValue($data, $search, $replace, $count);

        if (!$dryRun && $count > 0) {
            if (!$this->elementor->saveDocumentData($docId, $newData)) {
                throw ToolException::wordpressError('Save failed after find-and-replace.');
            }
        }

        return $this->success([
            'document_id'  => $docId,
            'dry_run'      => $dryRun,
            'search'       => $search,
            'replacements' => $count,
            'saved'        => !$dryRun && $count > 0,
        ], $dryRun
            ? "Dry run: {$count} replacement(s) would be made."
            : ($count > 0 ? "{$count} replacement(s) made and saved." : 'Search term not found; nothing changed.'));
    }
}
