<?php
/**
 * Get Kit Custom CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetKitCustomCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_kit_custom_css';
    }

    public function getDescription(): string
    {
        return 'Read the site-wide Custom CSS stored in the active Elementor kit (the "Custom CSS" panel under Site Settings). This is an Elementor Pro feature — on free-only sites the field will typically be empty.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $kitId = $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('This site has no active Elementor kit.');
        }

        $settings = $this->elementor->getKitSettings($kitId);
        // Elementor Pro stores kit-level custom CSS under the `custom_css` setting key.
        $css = $settings['custom_css'] ?? '';

        return $this->success([
            'kit_id'      => $kitId,
            'pro_active'  => defined('ELEMENTOR_PRO_VERSION'),
            'custom_css'  => is_string($css) ? $css : '',
            'length'      => is_string($css) ? strlen($css) : 0,
        ]);
    }
}
