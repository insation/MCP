<?php
/**
 * Get Active Kit Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetActiveKit extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_active_kit';
    }

    public function getDescription(): string
    {
        return 'Get the site\'s active Elementor kit — the special document that holds global site styles (colors, fonts, typography, layout defaults, custom CSS). Returns the kit post id, title, and a summary of which setting groups it defines.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $kitId = $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('This site has no active Elementor kit.');
        }

        $post = get_post($kitId);
        $settings = $this->elementor->getKitSettings($kitId);

        // Summarize which setting groups are populated.
        $systemColors  = $settings['system_colors'] ?? [];
        $customColors  = $settings['custom_colors'] ?? [];
        $systemFonts   = $settings['system_typography'] ?? [];
        $customFonts   = $settings['custom_typography'] ?? [];

        return $this->success([
            'kit_id'              => $kitId,
            'title'               => $post ? $post->post_title : null,
            'system_color_count'  => is_array($systemColors) ? count($systemColors) : 0,
            'custom_color_count'  => is_array($customColors) ? count($customColors) : 0,
            'system_font_count'   => is_array($systemFonts) ? count($systemFonts) : 0,
            'custom_font_count'   => is_array($customFonts) ? count($customFonts) : 0,
            'setting_keys'        => array_keys($settings),
        ]);
    }
}
