<?php
/**
 * List All Kits Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListAllKits extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_all_kits';
    }

    public function getDescription(): string
    {
        return 'List every Elementor kit on the site. Most sites have exactly one active kit, but additional kits can exist from imports or kit experiments. Each entry is flagged with whether it is the currently active kit.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $activeId = $this->elementor->activeKitId();

        // Elementor kits are stored as the elementor_library post type with the
        // "kit" library type. Query that taxonomy term.
        $q = new \WP_Query([
            'post_type'      => ElementorService::TEMPLATE_CPT,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'tax_query'      => [[
                'taxonomy' => 'elementor_library_type',
                'field'    => 'slug',
                'terms'    => 'kit',
            ]],
        ]);

        $kits = [];
        foreach ($q->posts as $post) {
            $kits[] = [
                'kit_id'    => $post->ID,
                'title'     => $post->post_title,
                'status'    => $post->post_status,
                'is_active' => $post->ID === $activeId,
                'modified'  => $post->post_modified_gmt,
            ];
        }

        // Safety net: if the taxonomy query missed the active kit, include it.
        if ($activeId > 0) {
            $hasActive = false;
            foreach ($kits as $k) {
                if ($k['kit_id'] === $activeId) {
                    $hasActive = true;
                    break;
                }
            }
            if (!$hasActive) {
                $activePost = get_post($activeId);
                if ($activePost) {
                    $kits[] = [
                        'kit_id'    => $activeId,
                        'title'     => $activePost->post_title,
                        'status'    => $activePost->post_status,
                        'is_active' => true,
                        'modified'  => $activePost->post_modified_gmt,
                    ];
                }
            }
        }

        return $this->success([
            'count'         => count($kits),
            'active_kit_id' => $activeId,
            'kits'          => $kits,
        ]);
    }
}
