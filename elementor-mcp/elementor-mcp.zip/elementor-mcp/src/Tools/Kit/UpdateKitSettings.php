<?php
/**
 * Update Kit Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UpdateKitSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_kit_settings';
    }

    public function getDescription(): string
    {
        return 'Update the active Elementor kit\'s settings. By default the supplied keys are merged into the existing kit settings; pass replace=true to overwrite the whole settings object. After saving, Elementor\'s CSS cache is cleared so the change shows on the front end. Requires mcp:admin (kit changes are site-wide) and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'settings_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'JSON object of kit settings to apply.'],
            'kit_id'        => ['optional', 'int', 'description' => 'Specific kit id. Omit for the active kit.'],
            'replace'       => ['optional', 'bool', 'description' => 'Replace the whole settings object instead of merging. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('updating the Elementor global kit');

        $kitId = isset($parameters['kit_id']) ? (int) $parameters['kit_id'] : $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('No kit available to update.');
        }
        if (!get_post($kitId)) {
            throw ToolException::wordpressError("No kit post with id {$kitId}.");
        }

        $incoming = json_decode($parameters['settings_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in settings_json: ' . json_last_error_msg());
        }
        if (!is_array($incoming)) {
            throw ToolException::wordpressError('settings_json must decode to an object.');
        }

        $existing = $this->elementor->getKitSettings($kitId);
        $merged = !empty($parameters['replace']) ? $incoming : array_merge($existing, $incoming);

        if (!$this->elementor->saveKitSettings($merged, $kitId)) {
            throw ToolException::wordpressError('Failed to save kit settings.');
        }

        return $this->success([
            'kit_id'       => $kitId,
            'merged'       => empty($parameters['replace']),
            'setting_keys' => array_keys($merged),
        ], 'Kit settings updated and CSS cache cleared.');
    }
}
