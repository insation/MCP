<?php
/**
 * Get Kit Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetKitSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_kit_settings';
    }

    public function getDescription(): string
    {
        return 'Get the full settings object of an Elementor kit — every global style value: colors, typography, buttons, form fields, image defaults, layout settings, and custom CSS. Defaults to the active kit; pass kit_id to read a specific one. Optionally return only one top-level settings key.';
    }

    public function getSchema(): array
    {
        return [
            'kit_id' => ['optional', 'int', 'description' => 'Specific kit post id. Omit for the active kit.'],
            'key'    => ['optional', 'string', 'description' => 'Return only this top-level settings key (e.g. system_colors, custom_typography).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $kitId = isset($parameters['kit_id']) ? (int) $parameters['kit_id'] : $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('No kit available (and no active kit on this site).');
        }

        $post = get_post($kitId);
        if (!$post) {
            throw ToolException::wordpressError("No kit post with id {$kitId}.");
        }

        $settings = $this->elementor->getKitSettings($kitId);

        if (!empty($parameters['key'])) {
            $key = $parameters['key'];
            if (!array_key_exists($key, $settings)) {
                return $this->success([
                    'kit_id' => $kitId,
                    'key'    => $key,
                    'value'  => null,
                    'exists' => false,
                ], "Kit has no setting key '{$key}'.");
            }
            return $this->success([
                'kit_id' => $kitId,
                'key'    => $key,
                'value'  => $settings[$key],
                'exists' => true,
            ]);
        }

        return $this->success([
            'kit_id'   => $kitId,
            'settings' => $settings,
        ]);
    }
}
