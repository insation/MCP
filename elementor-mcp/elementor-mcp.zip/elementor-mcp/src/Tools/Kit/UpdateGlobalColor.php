<?php
/**
 * Update Global Color Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UpdateGlobalColor extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_global_color';
    }

    public function getDescription(): string
    {
        return 'Change the value (and optionally the label) of a single global color in the active kit, identified by its _id. Searches both system and custom colors. Because global colors are referenced by id throughout the site, changing the value here updates every element using that global color. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'color_id' => ['required', 'string', ['notEmpty' => true], 'description' => 'The _id of the global color (from list_global_colors).'],
            'color'    => ['required', 'string', ['notEmpty' => true], 'description' => 'New color value, e.g. "#1A1A1A" or "rgba(0,0,0,0.5)".'],
            'title'    => ['optional', 'string', 'description' => 'New label for the color.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('updating Elementor global colors');

        $kitId = $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('This site has no active Elementor kit.');
        }

        $settings = $this->elementor->getKitSettings($kitId);
        $colorId = $parameters['color_id'];
        $found = false;

        foreach (['system_colors', 'custom_colors'] as $group) {
            if (!isset($settings[$group]) || !is_array($settings[$group])) {
                continue;
            }
            foreach ($settings[$group] as $idx => $entry) {
                if (is_array($entry) && ($entry['_id'] ?? null) === $colorId) {
                    $settings[$group][$idx]['color'] = sanitize_text_field($parameters['color']);
                    if (isset($parameters['title'])) {
                        $settings[$group][$idx]['title'] = sanitize_text_field($parameters['title']);
                    }
                    $found = true;
                    break 2;
                }
            }
        }

        if (!$found) {
            throw ToolException::wordpressError(
                "No global color with _id '{$colorId}' in the active kit. Use list_global_colors to see valid ids."
            );
        }

        if (!$this->elementor->saveKitSettings($settings, $kitId)) {
            throw ToolException::wordpressError('Failed to save the kit after updating the color.');
        }

        return $this->success([
            'kit_id'   => $kitId,
            'color_id' => $colorId,
            'color'    => $parameters['color'],
        ], 'Global color updated and CSS cache cleared.');
    }
}
