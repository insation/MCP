<?php
/**
 * List Global Colors Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListGlobalColors extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_global_colors';
    }

    public function getDescription(): string
    {
        return 'List the global colors defined in the active Elementor kit — both the system colors (primary, secondary, text, accent) and any custom colors. Each entry returns its internal _id, label, and color value.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $settings = $this->elementor->getKitSettings();

        $normalize = static function ($list): array {
            if (!is_array($list)) {
                return [];
            }
            $out = [];
            foreach ($list as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $out[] = [
                    '_id'   => $entry['_id'] ?? null,
                    'title' => $entry['title'] ?? null,
                    'color' => $entry['color'] ?? null,
                ];
            }
            return $out;
        };

        $system = $normalize($settings['system_colors'] ?? []);
        $custom = $normalize($settings['custom_colors'] ?? []);

        return $this->success([
            'kit_id'        => $this->elementor->activeKitId(),
            'system_colors' => $system,
            'custom_colors' => $custom,
            'total'         => count($system) + count($custom),
        ]);
    }
}
