<?php
/**
 * Delete Global Color Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DeleteGlobalColor extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_global_color';
    }

    public function getDescription(): string
    {
        return 'Delete a custom global color from the active Elementor kit by its _id. Only custom colors can be deleted — the four system colors (primary, secondary, text, accent) are part of Elementor\'s core and are protected. Note that elements still referencing the deleted color will fall back to their local value. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'color_id' => ['required', 'string', ['notEmpty' => true], 'description' => 'The _id of the custom global color to delete.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('deleting Elementor global colors');

        $kitId = $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('This site has no active Elementor kit.');
        }

        $colorId = $parameters['color_id'];
        $settings = $this->elementor->getKitSettings($kitId);

        // Guard: refuse to delete a system color.
        if (isset($settings['system_colors']) && is_array($settings['system_colors'])) {
            foreach ($settings['system_colors'] as $entry) {
                if (is_array($entry) && ($entry['_id'] ?? null) === $colorId) {
                    throw ToolException::wordpressError(
                        "'{$colorId}' is a system color and cannot be deleted. System colors can only be updated."
                    );
                }
            }
        }

        if (!isset($settings['custom_colors']) || !is_array($settings['custom_colors'])) {
            throw ToolException::wordpressError('The active kit has no custom colors.');
        }

        $before = count($settings['custom_colors']);
        $settings['custom_colors'] = array_values(array_filter(
            $settings['custom_colors'],
            static fn($entry) => !(is_array($entry) && ($entry['_id'] ?? null) === $colorId)
        ));

        if (count($settings['custom_colors']) === $before) {
            throw ToolException::wordpressError(
                "No custom global color with _id '{$colorId}' in the active kit."
            );
        }

        if (!$this->elementor->saveKitSettings($settings, $kitId)) {
            throw ToolException::wordpressError('Failed to save the kit after deleting the color.');
        }

        return $this->success([
            'kit_id'   => $kitId,
            'color_id' => $colorId,
        ], 'Global color deleted.');
    }
}
