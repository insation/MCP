<?php
/**
 * Add Global Color Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class AddGlobalColor extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'add_global_color';
    }

    public function getDescription(): string
    {
        return 'Add a new custom global color to the active Elementor kit. A unique _id is generated and returned — use it to reference the color elsewhere or to update/delete it later. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'title' => ['required', 'string', ['notEmpty' => true], 'description' => 'Label for the new color.'],
            'color' => ['required', 'string', ['notEmpty' => true], 'description' => 'Color value, e.g. "#1A1A1A".'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('adding Elementor global colors');

        $kitId = $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('This site has no active Elementor kit.');
        }

        $settings = $this->elementor->getKitSettings($kitId);
        if (!isset($settings['custom_colors']) || !is_array($settings['custom_colors'])) {
            $settings['custom_colors'] = [];
        }

        // Elementor uses short alphanumeric ids for global entries.
        $newId = substr(md5(uniqid('emcp_color_', true)), 0, 7);

        $settings['custom_colors'][] = [
            '_id'   => $newId,
            'title' => sanitize_text_field($parameters['title']),
            'color' => sanitize_text_field($parameters['color']),
        ];

        if (!$this->elementor->saveKitSettings($settings, $kitId)) {
            throw ToolException::wordpressError('Failed to save the kit after adding the color.');
        }

        return $this->success([
            'kit_id'   => $kitId,
            'color_id' => $newId,
            'title'    => $parameters['title'],
            'color'    => $parameters['color'],
        ], 'Global color added.');
    }
}
