<?php
/**
 * List Global Fonts Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Kit;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class ListGlobalFonts extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_global_fonts';
    }

    public function getDescription(): string
    {
        return 'List the global typography styles defined in the active Elementor kit — both system typography (primary, secondary, text, accent) and any custom typography presets. Each entry returns its internal _id, label, and the typography properties (font family, weight, size, etc.).';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $settings = $this->elementor->getKitSettings();

        $normalize = static function ($list): array {
            if (!is_array($list)) {
                return [];
            }
            $out = [];
            foreach ($list as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                // Collect the typography_* keys into a compact properties map.
                $props = [];
                foreach ($entry as $k => $v) {
                    if (str_starts_with((string) $k, 'typography_')) {
                        $props[$k] = $v;
                    }
                }
                $out[] = [
                    '_id'        => $entry['_id'] ?? null,
                    'title'      => $entry['title'] ?? null,
                    'properties' => $props,
                ];
            }
            return $out;
        };

        $system = $normalize($settings['system_typography'] ?? []);
        $custom = $normalize($settings['custom_typography'] ?? []);

        return $this->success([
            'kit_id'            => $this->elementor->activeKitId(),
            'system_typography' => $system,
            'custom_typography' => $custom,
            'total'             => count($system) + count($custom),
        ]);
    }
}
