<?php
/**
 * Sync Global CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Cache;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SyncGlobalCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'sync_global_css';
    }

    public function getDescription(): string
    {
        return 'Rebuild the global CSS file — the stylesheet generated from the active kit (global colors, fonts, typography). Run this after changing kit settings outside of update_kit_settings, or when global style changes are not reflected on the front end. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('syncing global Elementor CSS');

        $kitId = $this->elementor->activeKitId();
        if ($kitId <= 0) {
            throw ToolException::wordpressError('This site has no active Elementor kit to sync.');
        }

        // Drop the kit document's cached CSS meta.
        delete_post_meta($kitId, '_elementor_css');

        // Remove the generated global/kit CSS files if present.
        $upload = wp_upload_dir();
        $cssDir = trailingslashit($upload['basedir']) . 'elementor/css/';
        $removed = [];
        foreach (["post-{$kitId}.css", 'global.css'] as $file) {
            $path = $cssDir . $file;
            if (file_exists($path) && @unlink($path)) {
                $removed[] = $file;
            }
        }

        // Rebuild via the kit's Post_CSS if available.
        $regenerated = false;
        if (class_exists('\Elementor\Core\Files\CSS\Post')) {
            try {
                \Elementor\Core\Files\CSS\Post::create($kitId)->update();
                $regenerated = true;
            } catch (\Throwable $e) {
                $this->logger->warning('Kit CSS update failed: ' . $e->getMessage());
            }
        }

        // Also clear the wider cache so dependent documents pick up the change.
        $this->elementor->clearCache();

        return $this->success([
            'kit_id'        => $kitId,
            'files_removed' => $removed,
            'regenerated'   => $regenerated,
        ], 'Global CSS synced from the active kit.');
    }
}
