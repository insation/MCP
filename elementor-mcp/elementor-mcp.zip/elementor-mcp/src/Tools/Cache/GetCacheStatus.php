<?php
/**
 * Get Cache Status Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Cache;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;

class GetCacheStatus extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_cache_status';
    }

    public function getDescription(): string
    {
        return 'Report the state of Elementor\'s CSS file cache: the print method, whether the uploads/elementor/css directory exists and is writable, how many generated CSS files it currently holds, and their total size. Read-only — use it before/after a cache operation to confirm what happened.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $upload = wp_upload_dir();
        $cssDir = trailingslashit($upload['basedir']) . 'elementor/css/';

        $dirExists = is_dir($cssDir);
        $writable = $dirExists && is_writable($cssDir);

        $fileCount = 0;
        $totalBytes = 0;
        if ($dirExists) {
            foreach ((array) glob($cssDir . '*.css') as $file) {
                $fileCount++;
                $totalBytes += (int) filesize($file);
            }
        }

        return $this->success([
            'css_print_method' => get_option('elementor_css_print_method', 'external'),
            'css_dir'          => $cssDir,
            'dir_exists'       => $dirExists,
            'dir_writable'     => $writable,
            'generated_files'  => $fileCount,
            'total_size_bytes' => $totalBytes,
            'total_size_human' => size_format($totalBytes),
        ]);
    }
}
