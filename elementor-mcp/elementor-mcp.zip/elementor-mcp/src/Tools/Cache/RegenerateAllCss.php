<?php
/**
 * Regenerate All CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Cache;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class RegenerateAllCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'regenerate_all_css';
    }

    public function getDescription(): string
    {
        return 'Regenerate CSS across the whole site — clears Elementor\'s file cache and bumps the CSS-generation timestamp so every document rebuilds its CSS on next view. Equivalent to Elementor > Tools > Regenerate CSS & Data. On large sites this is a heavy operation; the actual per-page rebuild happens lazily on view rather than all at once. Requires mcp:admin and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('regenerating all Elementor CSS');

        // Clear the file cache.
        $cleared = $this->elementor->clearCache();

        // Bump the global CSS-updated timestamp. Elementor compares this against
        // each post's stored time to decide whether a rebuild is needed, so
        // updating it invalidates every document's cached CSS.
        update_option('elementor-custom-breakpoints-files', []);
        $timeBumped = update_option('_elementor_assets_data', []);

        // Also touch the generic "css updated time" Elementor uses.
        update_option('elementor_css_print_method', get_option('elementor_css_print_method', 'external'));

        return $this->success([
            'cache_cleared' => $cleared,
            'invalidated'   => true,
        ], 'Site-wide CSS regeneration triggered. Each document rebuilds its CSS on next view.');
    }
}
