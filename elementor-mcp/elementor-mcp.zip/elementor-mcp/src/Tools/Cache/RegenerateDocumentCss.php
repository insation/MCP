<?php
/**
 * Regenerate Document CSS Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Cache;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class RegenerateDocumentCss extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'regenerate_document_css';
    }

    public function getDescription(): string
    {
        return 'Regenerate the CSS for a single Elementor document — deletes the document\'s cached _elementor_css meta and generated file, then asks Elementor to rebuild it. Faster and more targeted than clearing the whole site cache when only one page needs refreshing. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('regenerating document CSS');

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        // Drop the cached CSS meta so Elementor rebuilds it.
        delete_post_meta($docId, '_elementor_css');

        // Remove the generated file if it exists.
        $upload = wp_upload_dir();
        $cssFile = trailingslashit($upload['basedir']) . 'elementor/css/post-' . $docId . '.css';
        $fileRemoved = false;
        if (file_exists($cssFile)) {
            $fileRemoved = @unlink($cssFile);
        }

        // Ask Elementor to rebuild via its Post_CSS API if available.
        $regenerated = false;
        if (class_exists('\Elementor\Core\Files\CSS\Post')) {
            try {
                $postCss = \Elementor\Core\Files\CSS\Post::create($docId);
                $postCss->update();
                $regenerated = true;
            } catch (\Throwable $e) {
                // Non-fatal: clearing the meta alone forces regeneration on next view.
                $this->logger->warning('Post CSS update failed: ' . $e->getMessage());
            }
        }

        return $this->success([
            'document_id'   => $docId,
            'meta_cleared'  => true,
            'file_removed'  => $fileRemoved,
            'regenerated'   => $regenerated,
        ], $regenerated
            ? 'Document CSS regenerated.'
            : 'Document CSS cache cleared; it will rebuild on the next page view.');
    }
}
