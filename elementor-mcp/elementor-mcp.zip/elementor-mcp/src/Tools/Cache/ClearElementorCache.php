<?php
/**
 * Clear Elementor Cache Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.6
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Cache;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ClearElementorCache extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'clear_elementor_cache';
    }

    public function getDescription(): string
    {
        return 'Clear Elementor\'s entire generated CSS / file cache — the same action as Elementor > Tools > Regenerate CSS & Data, but only the clearing step. After this, Elementor regenerates each document\'s CSS on next view. Use this when global style changes are not showing up. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('clearing the Elementor cache');

        $cleared = $this->elementor->clearCache();
        if (!$cleared) {
            throw ToolException::wordpressError(
                'Elementor files manager did not expose a clear_cache method — cache was not cleared.'
            );
        }

        return $this->success([
            'cleared' => true,
        ], 'Elementor CSS/file cache cleared. CSS will regenerate on next page view.');
    }
}
