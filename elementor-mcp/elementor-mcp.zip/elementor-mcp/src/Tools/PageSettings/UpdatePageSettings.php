<?php
/**
 * Update Page Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\PageSettings;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UpdatePageSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_page_settings';
    }

    public function getDescription(): string
    {
        return 'Update a document\'s per-page Elementor settings. By default the supplied keys are merged into the existing page settings; pass replace=true to overwrite the whole object. The document\'s CSS cache is cleared afterward. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'   => ['required', 'int'],
            'settings_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'JSON object of page settings to apply.'],
            'replace'       => ['optional', 'bool', 'description' => 'Replace the whole settings object instead of merging. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('updating Elementor page settings');

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $incoming = json_decode($parameters['settings_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in settings_json: ' . json_last_error_msg());
        }
        if (!is_array($incoming)) {
            throw ToolException::wordpressError('settings_json must decode to an object.');
        }

        $existing = $this->elementor->getPageSettings($docId);
        $merged = !empty($parameters['replace']) ? $incoming : array_merge($existing, $incoming);

        if (!$this->elementor->savePageSettings($docId, $merged)) {
            throw ToolException::wordpressError('Failed to save page settings.');
        }

        return $this->success([
            'document_id' => $docId,
            'merged'      => empty($parameters['replace']),
            'keys'        => array_keys($merged),
        ], 'Page settings updated and CSS cache cleared.');
    }
}
