<?php
/**
 * Get Page Settings Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\PageSettings;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetPageSettings extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_page_settings';
    }

    public function getDescription(): string
    {
        return 'Get the per-page Elementor settings of a document — the values from the page-settings panel: page layout, content width, body background, hide title, page-level custom CSS (Pro), and more. This is distinct from the element tree and from the global kit settings.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'key'         => ['optional', 'string', 'description' => 'Return only this single settings key.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $settings = $this->elementor->getPageSettings($docId);

        if (!empty($parameters['key'])) {
            $key = $parameters['key'];
            return $this->success([
                'document_id' => $docId,
                'key'         => $key,
                'value'       => $settings[$key] ?? null,
                'exists'      => array_key_exists($key, $settings),
            ]);
        }

        return $this->success([
            'document_id' => $docId,
            'settings'    => $settings,
            'keys'        => array_keys($settings),
        ]);
    }
}
