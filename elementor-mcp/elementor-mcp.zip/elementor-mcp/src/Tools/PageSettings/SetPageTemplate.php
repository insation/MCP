<?php
/**
 * Set Page Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\PageSettings;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class SetPageTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    /** Elementor's built-in page templates plus the theme default. */
    private const ELEMENTOR_TEMPLATES = [
        'default',
        'elementor_canvas',
        'elementor_header_footer',
    ];

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'set_page_template';
    }

    public function getDescription(): string
    {
        return 'Set the page template for a document. Accepts Elementor\'s built-in templates — "default" (theme), "elementor_canvas" (blank, no header/footer), "elementor_header_footer" (full width with theme header/footer) — or any custom theme template file slug. Updates both the WordPress page-template meta and Elementor\'s page setting so they stay in sync. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'template'    => ['required', 'string', ['notEmpty' => true], 'description' => 'default, elementor_canvas, elementor_header_footer, or a custom theme template file slug.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('changing the page template');

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $template = $parameters['template'];
        $isElementorTemplate = in_array($template, self::ELEMENTOR_TEMPLATES, true);

        // Update the WordPress page-template meta.
        if ($template === 'default') {
            delete_post_meta($docId, '_wp_page_template');
        } else {
            update_post_meta($docId, '_wp_page_template', $template);
        }

        // Keep Elementor's page-setting in sync for the templates it owns.
        $pageSettings = $this->elementor->getPageSettings($docId);
        if ($isElementorTemplate) {
            $pageSettings['template'] = $template;
        } else {
            // A custom theme template: drop Elementor's override so the theme wins.
            unset($pageSettings['template']);
        }
        $this->elementor->savePageSettings($docId, $pageSettings);

        return $this->success([
            'document_id'           => $docId,
            'template'              => $template,
            'is_elementor_template' => $isElementorTemplate,
        ], 'Page template updated.');
    }
}
