<?php
/**
 * Get Page Template Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\PageSettings;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetPageTemplate extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_page_template';
    }

    public function getDescription(): string
    {
        return 'Get the page template assigned to a document — the WordPress _wp_page_template meta combined with Elementor\'s template page-setting. Tells you whether a page uses the theme default, Elementor Canvas, Elementor Full Width, Elementor Header/Footer, or a custom theme template.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        // WordPress-level page template.
        $wpTemplate = get_post_meta($docId, '_wp_page_template', true);
        if ($wpTemplate === '' || $wpTemplate === false) {
            $wpTemplate = 'default';
        }

        // Elementor page-setting level template (e.g. "elementor_canvas",
        // "elementor_header_footer").
        $pageSettings = $this->elementor->getPageSettings($docId);
        $elementorTemplate = $pageSettings['template'] ?? null;

        // Friendly label for common Elementor templates.
        $labels = [
            'elementor_canvas'         => 'Elementor Canvas (no header/footer)',
            'elementor_header_footer'  => 'Elementor Full Width (theme header/footer)',
            'default'                  => 'Theme default',
        ];
        $label = $labels[$elementorTemplate ?? $wpTemplate] ?? null;

        return $this->success([
            'document_id'        => $docId,
            'wp_page_template'   => $wpTemplate,
            'elementor_template' => $elementorTemplate,
            'effective_label'    => $label,
        ]);
    }
}
