<?php
/**
 * Update Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UpdateElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'update_element';
    }

    public function getDescription(): string
    {
        return 'Update an element\'s settings. By default the supplied settings are merged into the element\'s existing settings (so you only pass the keys you want to change). Pass replace_settings=true to overwrite the settings object entirely. The element id, elType, and children are preserved.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'      => ['required', 'int'],
            'element_id'       => ['required', 'string', ['notEmpty' => true]],
            'settings_json'    => ['required', 'string', ['notEmpty' => true], 'description' => 'JSON object of settings to apply.'],
            'replace_settings' => ['optional', 'bool', 'description' => 'When true, fully replace the settings object instead of merging. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('updating Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $newSettings = json_decode($parameters['settings_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in settings_json: ' . json_last_error_msg());
        }
        if (!is_array($newSettings)) {
            throw ToolException::wordpressError('settings_json must decode to an object.');
        }

        $element = $found['element'];
        $existing = $element['settings'] ?? [];
        if (!is_array($existing)) {
            $existing = [];
        }

        $element['settings'] = !empty($parameters['replace_settings'])
            ? $newSettings
            : array_merge($existing, $newSettings);

        $newData = $this->elementor->replaceAtPath($data, $found['path'], $element);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after updating the element.');
        }

        return $this->success([
            'document_id'  => $docId,
            'element_id'   => $parameters['element_id'],
            'merged'       => empty($parameters['replace_settings']),
            'settings_keys'=> array_keys($element['settings']),
        ], 'Element updated.');
    }
}
