<?php
/**
 * Replace Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ReplaceElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'replace_element';
    }

    public function getDescription(): string
    {
        return 'Replace an element entirely with a new one supplied as JSON. The replacement takes the target\'s exact position in the tree. Unlike update_element (which merges settings), this swaps the whole element — useful for changing a widget\'s type. Fresh ids are generated for the replacement subtree unless keep_id=true, which preserves the original element id on the new top-level element.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'  => ['required', 'int'],
            'element_id'   => ['required', 'string', ['notEmpty' => true]],
            'element_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'JSON for the replacement element.'],
            'keep_id'      => ['optional', 'bool', 'description' => 'When true, the replacement keeps the original element\'s id. Default false (fresh id).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('replacing Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $replacement = json_decode($parameters['element_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in element_json: ' . json_last_error_msg());
        }
        if (!is_array($replacement)) {
            throw ToolException::wordpressError('element_json must decode to an object.');
        }

        $problems = $this->elementor->validateElementShape($replacement);
        if (!empty($problems)) {
            throw ToolException::wordpressError('Replacement element shape invalid: ' . implode(' ', $problems));
        }

        $replacement = $this->elementor->regenerateIds($replacement);
        if (!empty($parameters['keep_id'])) {
            $replacement['id'] = $parameters['element_id'];
        }

        $newData = $this->elementor->replaceAtPath($data, $found['path'], $replacement);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after replacing the element.');
        }

        return $this->success([
            'document_id'        => $docId,
            'replaced_element_id'=> $parameters['element_id'],
            'new_element_id'     => $replacement['id'],
        ], 'Element replaced.');
    }
}
