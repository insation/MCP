<?php
/**
 * Find Elements By Class Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class FindElementsByClass extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_elements_by_class';
    }

    public function getDescription(): string
    {
        return 'Find elements whose Elementor "CSS Classes" setting (the _css_classes control) contains a given class name. Searches one document or all Elementor documents. Useful for locating elements styled by a shared custom class.';
    }

    public function getSchema(): array
    {
        return [
            'css_class'   => ['required', 'string', ['notEmpty' => true], 'description' => 'The CSS class name to search for (without the leading dot).'],
            'document_id' => ['optional', 'int', 'description' => 'Limit search to one document. Omit to search all.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $needle = trim($parameters['css_class']);
        $matches = [];

        if (!empty($parameters['document_id'])) {
            $docIds = [(int) $parameters['document_id']];
        } else {
            $q = new \WP_Query([
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [[
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ]],
            ]);
            $docIds = $q->posts;
        }

        $scannedDocs = 0;
        foreach ($docIds as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            $scannedDocs++;
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                $settings = $el['settings'] ?? [];
                // Elementor stores user CSS classes under the `_css_classes` control.
                $classes = $settings['_css_classes'] ?? '';
                if (!is_string($classes) || $classes === '') {
                    continue;
                }
                $classList = preg_split('/\s+/', trim($classes));
                if (in_array($needle, $classList, true)) {
                    $matches[] = [
                        'document_id' => (int) $docId,
                        'element_id'  => $el['id'] ?? null,
                        'elType'      => $el['elType'] ?? null,
                        'widgetType'  => $el['widgetType'] ?? null,
                        'css_classes' => $classes,
                        'path'        => $entry['path'],
                    ];
                }
            }
        }

        return $this->success([
            'css_class'         => $needle,
            'documents_scanned' => $scannedDocs,
            'match_count'       => count($matches),
            'matches'           => $matches,
        ]);
    }
}
