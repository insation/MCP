<?php
/**
 * List Elements Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ListElements extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_elements';
    }

    public function getDescription(): string
    {
        return 'Flat list of every element in a document — id, elType, widgetType, depth, path, and child count — without the full nested settings. Ideal for getting a map of a page before drilling into specific elements.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'el_type'     => ['optional', 'string', 'description' => 'Filter to a single elType (section, column, container, widget).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $typeFilter = $parameters['el_type'] ?? null;
        $items = [];
        foreach ($this->elementor->walkElements($data) as $entry) {
            $el = $entry['element'];
            $elType = $el['elType'] ?? '';
            if ($typeFilter !== null && $elType !== $typeFilter) {
                continue;
            }
            $items[] = [
                'id'           => $el['id'] ?? null,
                'elType'       => $elType,
                'widgetType'   => $el['widgetType'] ?? null,
                'depth'        => count($entry['path']) - 1,
                'path'         => $entry['path'],
                'children'     => isset($el['elements']) && is_array($el['elements']) ? count($el['elements']) : 0,
            ];
        }

        return $this->success([
            'document_id' => $docId,
            'count'       => count($items),
            'elements'    => $items,
        ]);
    }
}
