<?php
/**
 * Get Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_element';
    }

    public function getDescription(): string
    {
        return 'Get a single element by id, optionally without its children (shallow). Use this to inspect one widget or container\'s settings without pulling the whole document tree.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'element_id'  => ['required', 'string', ['notEmpty' => true]],
            'shallow'     => ['optional', 'bool', 'description' => 'When true, omit the element\'s children. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $element = $found['element'];
        if (!empty($parameters['shallow']) && isset($element['elements'])) {
            $childCount = is_array($element['elements']) ? count($element['elements']) : 0;
            unset($element['elements']);
            $element['_children_count'] = $childCount;
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $parameters['element_id'],
            'path'        => $found['path'],
            'element'     => $element,
        ]);
    }
}
