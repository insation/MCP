<?php
/**
 * Insert Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class InsertElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'insert_element';
    }

    public function getDescription(): string
    {
        return 'Insert a new element into a document. Provide the element as JSON (must have elType, and widgetType for widgets). Insert either as a child of a target element, or at the document root. Fresh element ids are generated automatically for the inserted element and all its children.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'  => ['required', 'int'],
            'element_json' => ['required', 'string', ['notEmpty' => true], 'description' => 'JSON for the element to insert.'],
            'parent_id'    => ['optional', 'string', 'description' => 'Element id to insert into. Omit to insert at the document root.'],
            'position'     => ['optional', 'int', ['min' => 0], 'description' => 'Zero-based index among siblings. Omit to append at the end.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('inserting Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $element = json_decode($parameters['element_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw ToolException::wordpressError('Invalid JSON in element_json: ' . json_last_error_msg());
        }
        if (!is_array($element)) {
            throw ToolException::wordpressError('element_json must decode to an object.');
        }

        $problems = $this->elementor->validateElementShape($element);
        if (!empty($problems)) {
            throw ToolException::wordpressError('Element shape invalid: ' . implode(' ', $problems));
        }

        // Always give the inserted subtree fresh ids.
        $element = $this->elementor->regenerateIds($element);

        if (empty($parameters['parent_id'])) {
            // Insert at document root
            $position = isset($parameters['position'])
                ? min((int) $parameters['position'], count($data))
                : count($data);
            array_splice($data, $position, 0, [$element]);
            $newData = array_values($data);
        } else {
            $parentPath = $this->elementor->pathToId($data, $parameters['parent_id']);
            if ($parentPath === null) {
                throw ToolException::wordpressError("Parent element '{$parameters['parent_id']}' not found.");
            }
            // Resolve current children count of the parent for position clamping
            $cursor = ['elements' => $data];
            foreach ($parentPath as $idx) {
                $cursor = $cursor['elements'][$idx];
            }
            $childCount = isset($cursor['elements']) && is_array($cursor['elements'])
                ? count($cursor['elements'])
                : 0;
            $position = isset($parameters['position'])
                ? min((int) $parameters['position'], $childCount)
                : $childCount;
            // Build the child path: parentPath + [position]
            $childPath = array_merge($parentPath, [$position]);
            $newData = $this->elementor->insertAtPath($data, $childPath, $element);
        }

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after inserting the element.');
        }

        return $this->success([
            'document_id'        => $docId,
            'inserted_element_id'=> $element['id'],
            'parent_id'          => $parameters['parent_id'] ?? null,
        ], 'Element inserted.');
    }
}
