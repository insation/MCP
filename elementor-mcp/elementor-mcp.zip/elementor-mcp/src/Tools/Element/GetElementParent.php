<?php
/**
 * Get Element Parent Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetElementParent extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_element_parent';
    }

    public function getDescription(): string
    {
        return 'Return the parent element of a given element id, plus the full ancestor chain from the root down to (not including) the element. Useful for understanding where an element sits before moving or wrapping it.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'element_id'  => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $path = $found['path'];
        if (count($path) <= 1) {
            return $this->success([
                'document_id' => $docId,
                'element_id'  => $parameters['element_id'],
                'is_top_level'=> true,
                'parent'      => null,
                'ancestors'   => [],
            ], 'Element is top-level; it has no parent.');
        }

        // Walk from root collecting ancestors
        $ancestors = [];
        $cursor = ['elements' => $data];
        $parent = null;
        for ($i = 0; $i < count($path) - 1; $i++) {
            $cursor = $cursor['elements'][$path[$i]];
            $ancestors[] = [
                'id'         => $cursor['id'] ?? null,
                'elType'     => $cursor['elType'] ?? null,
                'widgetType' => $cursor['widgetType'] ?? null,
                'depth'      => $i,
            ];
            $parent = $cursor;
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $parameters['element_id'],
            'is_top_level'=> false,
            'parent'      => [
                'id'         => $parent['id'] ?? null,
                'elType'     => $parent['elType'] ?? null,
                'widgetType' => $parent['widgetType'] ?? null,
            ],
            'ancestors'   => $ancestors,
        ]);
    }
}
