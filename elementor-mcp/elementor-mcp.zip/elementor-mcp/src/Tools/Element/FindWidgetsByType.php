<?php
/**
 * Find Widgets By Type Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class FindWidgetsByType extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_widgets_by_type';
    }

    public function getDescription(): string
    {
        return 'Find every widget of a given widgetType (e.g. "heading", "image", "button") in one document or across all Elementor documents. Returns each match with its document id, element id, and path.';
    }

    public function getSchema(): array
    {
        return [
            'widget_type' => ['required', 'string', ['notEmpty' => true], 'description' => 'The widgetType to search for.'],
            'document_id' => ['optional', 'int', 'description' => 'Limit the search to one document. Omit to search every Elementor document.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $widgetType = $parameters['widget_type'];
        $matches = [];

        if (!empty($parameters['document_id'])) {
            $docIds = [(int) $parameters['document_id']];
        } else {
            // Every Elementor-built document
            $q = new \WP_Query([
                'post_type'      => 'any',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'meta_query'     => [[
                    'key'   => '_elementor_edit_mode',
                    'value' => 'builder',
                ]],
            ]);
            $docIds = $q->posts;
        }

        $scannedDocs = 0;
        foreach ($docIds as $docId) {
            $data = $this->elementor->getDocumentData((int) $docId);
            if (empty($data)) {
                continue;
            }
            $scannedDocs++;
            foreach ($this->elementor->walkElements($data) as $entry) {
                $el = $entry['element'];
                if (($el['elType'] ?? '') === 'widget' && ($el['widgetType'] ?? '') === $widgetType) {
                    $matches[] = [
                        'document_id' => (int) $docId,
                        'element_id'  => $el['id'] ?? null,
                        'path'        => $entry['path'],
                    ];
                }
            }
        }

        return $this->success([
            'widget_type'    => $widgetType,
            'documents_scanned' => $scannedDocs,
            'match_count'    => count($matches),
            'matches'        => $matches,
        ]);
    }
}
