<?php
/**
 * Move Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class MoveElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'move_element';
    }

    public function getDescription(): string
    {
        return 'Move an element to a new location within the same document — either into a different parent, to a new position among its current siblings, or to the document root. The element keeps its id and all its children. Cannot move an element into one of its own descendants.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'   => ['required', 'int'],
            'element_id'    => ['required', 'string', ['notEmpty' => true]],
            'new_parent_id' => ['optional', 'string', 'description' => 'Element id of the new parent. Omit to move to the document root.'],
            'position'      => ['optional', 'int', ['min' => 0], 'description' => 'Zero-based index among the destination siblings. Omit to append at the end.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('moving Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $elementId = $parameters['element_id'];
        $found = $this->elementor->findElementById($data, $elementId);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$elementId}' not found in document {$docId}.");
        }
        $element = $found['element'];

        // Guard: can't move into self or a descendant.
        if (!empty($parameters['new_parent_id'])) {
            $newParentId = $parameters['new_parent_id'];
            if ($newParentId === $elementId) {
                throw ToolException::wordpressError('Cannot move an element into itself.');
            }
            foreach ($this->elementor->walkElements([$element]) as $entry) {
                if (($entry['element']['id'] ?? null) === $newParentId) {
                    throw ToolException::wordpressError('Cannot move an element into one of its own descendants.');
                }
            }
        }

        // Step 1: remove the element from its current location.
        $dataWithout = $this->elementor->replaceAtPath($data, $found['path'], null);

        // Step 2: resolve the destination path on the MODIFIED tree.
        if (empty($parameters['new_parent_id'])) {
            $childCount = count($dataWithout);
            $position = isset($parameters['position'])
                ? min((int) $parameters['position'], $childCount)
                : $childCount;
            $insertPath = [$position];
        } else {
            $parentPath = $this->elementor->pathToId($dataWithout, $parameters['new_parent_id']);
            if ($parentPath === null) {
                throw ToolException::wordpressError(
                    "New parent '{$parameters['new_parent_id']}' not found (it may have been the element being moved, or a descendant of it)."
                );
            }
            $cursor = ['elements' => $dataWithout];
            foreach ($parentPath as $idx) {
                $cursor = $cursor['elements'][$idx];
            }
            $childCount = isset($cursor['elements']) && is_array($cursor['elements'])
                ? count($cursor['elements'])
                : 0;
            $position = isset($parameters['position'])
                ? min((int) $parameters['position'], $childCount)
                : $childCount;
            $insertPath = array_merge($parentPath, [$position]);
        }

        $newData = $this->elementor->insertAtPath($dataWithout, $insertPath, $element);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after moving the element.');
        }

        return $this->success([
            'document_id'   => $docId,
            'element_id'    => $elementId,
            'new_parent_id' => $parameters['new_parent_id'] ?? null,
            'position'      => $position,
        ], 'Element moved.');
    }
}
