<?php
/**
 * Find Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class FindElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'find_element';
    }

    public function getDescription(): string
    {
        return 'Locate a single element inside an Elementor document by its element id. Returns the element dictionary plus its integer path (the navigation indices from the root needed by insert/update/delete tools) and its parent id.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int', 'description' => 'Post ID of the Elementor document.'],
            'element_id'  => ['required', 'string', ['notEmpty' => true], 'description' => 'The element id to find (the 7-char id Elementor assigns each element).'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            return $this->success([
                'document_id' => $docId,
                'element_id'  => $parameters['element_id'],
                'found'       => false,
            ], 'Element not found in this document.');
        }

        // Determine parent id by walking the path one level up
        $parentId = null;
        $path = $found['path'];
        if (count($path) > 1) {
            $parentPath = array_slice($path, 0, -1);
            $cursor = ['elements' => $data];
            foreach ($parentPath as $idx) {
                $cursor = $cursor['elements'][$idx];
            }
            $parentId = $cursor['id'] ?? null;
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $parameters['element_id'],
            'found'       => true,
            'path'        => $found['path'],
            'parent_id'   => $parentId,
            'element'     => $found['element'],
        ]);
    }
}
