<?php
/**
 * Wrap Element In Container Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class WrapElementInContainer extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'wrap_element_in_container';
    }

    public function getDescription(): string
    {
        return 'Wrap an existing element in a new Elementor container (the flexbox container element). The element keeps its place in the tree but becomes the sole child of a freshly created container, which takes the element\'s former position. Optionally pass settings JSON for the new container.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id'             => ['required', 'int'],
            'element_id'              => ['required', 'string', ['notEmpty' => true]],
            'container_settings_json' => ['optional', 'string', 'description' => 'JSON object of settings for the new container element.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('wrapping Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $containerSettings = [];
        if (!empty($parameters['container_settings_json'])) {
            $decoded = json_decode($parameters['container_settings_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in container_settings_json: ' . json_last_error_msg());
            }
            if (!is_array($decoded)) {
                throw ToolException::wordpressError('container_settings_json must decode to an object.');
            }
            $containerSettings = $decoded;
        }

        // Build the wrapping container with the element as its only child.
        $container = [
            'id'       => $this->elementor->newElementId(),
            'elType'   => 'container',
            'settings' => $containerSettings,
            'elements' => [$found['element']],
        ];

        // Replace the element at its path with the container.
        $newData = $this->elementor->replaceAtPath($data, $found['path'], $container);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after wrapping the element.');
        }

        return $this->success([
            'document_id'      => $docId,
            'wrapped_element_id' => $parameters['element_id'],
            'new_container_id' => $container['id'],
        ], 'Element wrapped in a new container.');
    }
}
