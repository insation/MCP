<?php
/**
 * Count Elements In Document Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class CountElementsInDocument extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'count_elements_in_document';
    }

    public function getDescription(): string
    {
        return 'Return element counts for a document broken down by elType and by widgetType, plus the maximum nesting depth. A quick structural fingerprint of a page.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $byElType = [];
        $byWidgetType = [];
        $maxDepth = 0;
        $total = 0;

        foreach ($this->elementor->walkElements($data) as $entry) {
            $total++;
            $el = $entry['element'];
            $depth = count($entry['path']) - 1;
            if ($depth > $maxDepth) {
                $maxDepth = $depth;
            }
            $elType = $el['elType'] ?? 'unknown';
            $byElType[$elType] = ($byElType[$elType] ?? 0) + 1;
            if ($elType === 'widget') {
                $wt = $el['widgetType'] ?? 'unknown';
                $byWidgetType[$wt] = ($byWidgetType[$wt] ?? 0) + 1;
            }
        }

        arsort($byWidgetType);

        return $this->success([
            'document_id'     => $docId,
            'total_elements'  => $total,
            'top_level'       => count($data),
            'max_depth'       => $maxDepth,
            'by_el_type'      => $byElType,
            'by_widget_type'  => $byWidgetType,
        ]);
    }
}
