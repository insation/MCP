<?php
/**
 * Unwrap Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class UnwrapElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'unwrap_element';
    }

    public function getDescription(): string
    {
        return 'Remove a container/section/column wrapper, promoting its children into its parent at the wrapper\'s former position. The inverse of wrap_element_in_container. The wrapper element itself is discarded; its children keep their ids. Fails if the target is a widget (widgets have no children to promote) or is a top-level element with multiple children (no single parent to promote into — that would change document structure ambiguously).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'element_id'  => ['required', 'string', ['notEmpty' => true], 'description' => 'The wrapper element to remove.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('unwrapping Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        $wrapper = $found['element'];
        if (($wrapper['elType'] ?? '') === 'widget') {
            throw ToolException::wordpressError('Cannot unwrap a widget — widgets have no children to promote.');
        }

        $children = $wrapper['elements'] ?? [];
        if (!is_array($children)) {
            $children = [];
        }

        $path = $found['path'];

        // Top-level wrapper: splice children directly into the root array.
        if (count($path) === 1) {
            $index = $path[0];
            array_splice($data, $index, 1, $children);
            $newData = array_values($data);
        } else {
            // Nested wrapper: replace wrapper within its parent's children with the
            // wrapper's children spliced in at the same position.
            $parentPath = array_slice($path, 0, -1);
            $wrapperIndex = $path[count($path) - 1];

            // Navigate to the parent by reference-free recursion: rebuild.
            $newData = $this->spliceChildrenAtParent($data, $parentPath, $wrapperIndex, $children);
        }

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after unwrapping the element.');
        }

        return $this->success([
            'document_id'        => $docId,
            'unwrapped_element_id' => $parameters['element_id'],
            'children_promoted'  => count($children),
        ], 'Element unwrapped; ' . count($children) . ' child element(s) promoted to the parent.');
    }

    /**
     * Replace the element at $parentPath -> children[$index] with $replacement
     * (an array of elements spliced in at that index).
     *
     * @param array<int, array<string,mixed>> $elements
     * @param array<int> $parentPath
     * @param int $index
     * @param array<int, array<string,mixed>> $replacement
     * @return array<int, array<string,mixed>>
     */
    private function spliceChildrenAtParent(array $elements, array $parentPath, int $index, array $replacement): array
    {
        if (empty($parentPath)) {
            array_splice($elements, $index, 1, $replacement);
            return array_values($elements);
        }
        $i = array_shift($parentPath);
        if (!isset($elements[$i])) {
            return $elements;
        }
        $children = $elements[$i]['elements'] ?? [];
        $elements[$i]['elements'] = $this->spliceChildrenAtParent($children, $parentPath, $index, $replacement);
        return $elements;
    }
}
