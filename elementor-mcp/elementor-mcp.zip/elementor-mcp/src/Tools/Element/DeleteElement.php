<?php
/**
 * Delete Element Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DeleteElement extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_element';
    }

    public function getDescription(): string
    {
        return 'Delete an element (and everything nested inside it) from a document by its element id. Returns the number of elements removed. Subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'element_id'  => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('deleting Elementor elements');

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        // Count how many elements are in the subtree we're about to remove.
        $removed = 0;
        foreach ($this->elementor->walkElements([$found['element']]) as $ignored) {
            $removed++;
        }

        // Passing null deletes the element at that path.
        $newData = $this->elementor->replaceAtPath($data, $found['path'], null);

        if (!$this->elementor->saveDocumentData($docId, $newData)) {
            throw ToolException::wordpressError('Save failed after deleting the element.');
        }

        return $this->success([
            'document_id'      => $docId,
            'deleted_element_id' => $parameters['element_id'],
            'elements_removed' => $removed,
        ], "Element deleted ({$removed} element(s) removed including descendants).");
    }
}
