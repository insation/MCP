<?php
/**
 * Get Element Path Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Element;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetElementPath extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_element_path';
    }

    public function getDescription(): string
    {
        return 'Resolve an element id to its integer path (the navigation indices from the document root) and a human-readable breadcrumb of elType/widgetType at each level. The path is what the lower-level tree tools use internally; the breadcrumb helps a human or agent understand where the element sits.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'element_id'  => ['required', 'string', ['notEmpty' => true]],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        $data = $this->elementor->getDocumentData($docId);
        if (empty($data) && !$this->elementor->getDocument($docId)) {
            throw ToolException::wordpressError("Post {$docId} is not built with Elementor.");
        }

        $found = $this->elementor->findElementById($data, $parameters['element_id']);
        if ($found === null) {
            throw ToolException::wordpressError("Element '{$parameters['element_id']}' not found in document {$docId}.");
        }

        // Build a breadcrumb by walking the path from the root.
        $breadcrumb = [];
        $cursor = ['elements' => $data];
        foreach ($found['path'] as $depth => $idx) {
            $cursor = $cursor['elements'][$idx];
            $label = $cursor['elType'] ?? 'unknown';
            if (($cursor['elType'] ?? '') === 'widget' && !empty($cursor['widgetType'])) {
                $label .= ':' . $cursor['widgetType'];
            }
            $breadcrumb[] = [
                'depth'      => $depth,
                'index'      => $idx,
                'id'         => $cursor['id'] ?? null,
                'label'      => $label,
            ];
        }

        return $this->success([
            'document_id' => $docId,
            'element_id'  => $parameters['element_id'],
            'path'        => $found['path'],
            'depth'       => count($found['path']) - 1,
            'breadcrumb'  => $breadcrumb,
        ]);
    }
}
