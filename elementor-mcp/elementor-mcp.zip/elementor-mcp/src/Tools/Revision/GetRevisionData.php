<?php
/**
 * Get Revision Data Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Revision;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class GetRevisionData extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'get_revision_data';
    }

    public function getDescription(): string
    {
        return 'Get the Elementor element tree stored on a specific revision. Lets you inspect exactly what a past version of a page looked like before deciding whether to restore it.';
    }

    public function getSchema(): array
    {
        return [
            'revision_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $revisionId = (int) $parameters['revision_id'];
        $parentId = wp_is_post_revision($revisionId);
        if (!$parentId) {
            throw ToolException::wordpressError("Post {$revisionId} is not a revision.");
        }

        $data = $this->elementor->getRevisionData($revisionId);

        return $this->success([
            'revision_id'      => $revisionId,
            'parent_document'  => (int) $parentId,
            'has_data'         => !empty($data),
            'top_level_count'  => count($data),
            'content'          => $data,
        ]);
    }
}
