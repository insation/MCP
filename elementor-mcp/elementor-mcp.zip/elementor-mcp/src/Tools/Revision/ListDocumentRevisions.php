<?php
/**
 * List Document Revisions Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Revision;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class ListDocumentRevisions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'list_document_revisions';
    }

    public function getDescription(): string
    {
        return 'List the saved revisions of an Elementor document — each with its revision id, author, date, and whether it carries Elementor element data (as opposed to a plain WordPress content revision). Use this to find a revision id to inspect or restore.';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'limit'       => ['optional', 'int', ['min' => 1], ['max' => 100], 'description' => 'Max revisions to return. Default 30.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $limit = (int) ($parameters['limit'] ?? 30);
        $revisions = $this->elementor->getRevisions($docId, $limit);

        return $this->success([
            'document_id' => $docId,
            'count'       => count($revisions),
            'revisions'   => $revisions,
        ]);
    }
}
