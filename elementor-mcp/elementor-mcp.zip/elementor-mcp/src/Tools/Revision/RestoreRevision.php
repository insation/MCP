<?php
/**
 * Restore Revision Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Revision;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class RestoreRevision extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'restore_revision';
    }

    public function getDescription(): string
    {
        return 'Restore an Elementor document to a previous revision. The revision\'s element tree becomes the document\'s live content and the page CSS is regenerated. The current state is itself saved as a revision first, so a restore can be undone by restoring that. Requires mcp:write and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'revision_id' => ['required', 'int', 'description' => 'The revision to restore. Its parent document is restored to this state.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('restoring Elementor revisions');

        $revisionId = (int) $parameters['revision_id'];
        $parentId = wp_is_post_revision($revisionId);
        if (!$parentId) {
            throw ToolException::wordpressError("Post {$revisionId} is not a revision.");
        }
        $parentId = (int) $parentId;

        // Read the revision's element data and write it to the parent document.
        $revisionData = $this->elementor->getRevisionData($revisionId);
        if (empty($revisionData)) {
            throw ToolException::wordpressError(
                "Revision {$revisionId} carries no Elementor element data — nothing to restore."
            );
        }

        // saveDocumentData on the parent creates a fresh revision of the
        // pre-restore state, then writes the revision's tree as the new content.
        if (!$this->elementor->saveDocumentData($parentId, $revisionData)) {
            throw ToolException::wordpressError('Failed to write the restored content to the document.');
        }

        return $this->success([
            'revision_id'       => $revisionId,
            'restored_document' => $parentId,
            'top_level_count'   => count($revisionData),
        ], "Document {$parentId} restored to revision {$revisionId}.");
    }
}
