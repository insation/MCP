<?php
/**
 * Delete Revision Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Revision;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class DeleteRevision extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'delete_revision';
    }

    public function getDescription(): string
    {
        return 'Permanently delete a single document revision. This only removes the stored historical version — the live document is untouched. Useful for pruning a specific bad autosave. Requires mcp:delete and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'revision_id' => ['required', 'int'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();
        $this->checkSafeMode('deleting Elementor revisions');

        $revisionId = (int) $parameters['revision_id'];
        $parentId = wp_is_post_revision($revisionId);
        if (!$parentId) {
            throw ToolException::wordpressError("Post {$revisionId} is not a revision.");
        }

        $result = wp_delete_post_revision($revisionId);
        if (!$result || is_wp_error($result)) {
            throw ToolException::wordpressError("Failed to delete revision {$revisionId}.");
        }

        return $this->success([
            'revision_id'     => $revisionId,
            'parent_document' => (int) $parentId,
        ], 'Revision deleted.');
    }
}
