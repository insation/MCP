<?php
/**
 * Prune Document Revisions Tool
 *
 * @package InsationAI\ElementorMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\ElementorMCP\Tools\Revision;

use InsationAI\ElementorMCP\Services\ElementorService;
use InsationAI\ElementorMCP\Services\ValidationService;
use InsationAI\ElementorMCP\Services\WordPressService;
use InsationAI\ElementorMCP\Logger\WordPressLogger;
use InsationAI\ElementorMCP\Tools\AbstractTool;
use InsationAI\ElementorMCP\Exceptions\ToolException;

class PruneDocumentRevisions extends AbstractTool
{
    protected ElementorService $elementor;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        ElementorService $elementor,
        ?WordPressLogger $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->elementor = $elementor;
    }

    public function getName(): string
    {
        return 'prune_document_revisions';
    }

    public function getDescription(): string
    {
        return 'Delete old revisions of a document, keeping only the most recent N. Useful for cleaning up a page that has accumulated hundreds of autosaves and revisions, which bloats the database. Supports dry_run to preview the count without deleting. Requires mcp:delete and is subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'document_id' => ['required', 'int'],
            'keep'        => ['optional', 'int', ['min' => 0], 'description' => 'How many of the most recent revisions to keep. Default 5.'],
            'dry_run'     => ['optional', 'bool', 'description' => 'Preview only — report what would be deleted without deleting. Default false.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->elementor->requireElementor();

        $docId = (int) $parameters['document_id'];
        if (!get_post($docId)) {
            throw ToolException::wordpressError("No post with id {$docId}.");
        }

        $keep = isset($parameters['keep']) ? (int) $parameters['keep'] : 5;
        $dryRun = !empty($parameters['dry_run']);

        if (!$dryRun) {
            $this->checkSafeMode('pruning Elementor revisions');
        }

        // Newest-first list of all revisions.
        $revisions = wp_get_post_revisions($docId, ['posts_per_page' => -1]);
        $revisions = array_values($revisions);
        $total = count($revisions);

        // Everything past the first $keep is a candidate for deletion.
        $toDelete = array_slice($revisions, $keep);

        $deleted = 0;
        $deletedIds = [];
        if (!$dryRun) {
            foreach ($toDelete as $rev) {
                $res = wp_delete_post_revision($rev->ID);
                if ($res && !is_wp_error($res)) {
                    $deleted++;
                    $deletedIds[] = $rev->ID;
                }
            }
        }

        return $this->success([
            'document_id'      => $docId,
            'dry_run'          => $dryRun,
            'total_revisions'  => $total,
            'keep'             => $keep,
            'candidates'       => count($toDelete),
            'deleted'          => $dryRun ? 0 : $deleted,
            'deleted_ids'      => $dryRun ? [] : $deletedIds,
        ], $dryRun
            ? count($toDelete) . " revision(s) would be deleted, keeping the {$keep} most recent."
            : "Deleted {$deleted} revision(s), kept the {$keep} most recent.");
    }
}
