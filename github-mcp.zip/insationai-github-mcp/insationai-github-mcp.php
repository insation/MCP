<?php
/**
 * Plugin Name: GitHubMCP
 * Plugin URI: https://insationai.com/
 * Description: Publish your plugin releases to GitHub from WordPress - store a repo token once and let your AI assistant cut releases and upload assets server-side. OAuth 2.1, per-site licensing. By InsationAI.
 * Version: 2.0.0
 * Author: InsationAI
 * Author URI: https://insationai.com/
 * Requires PHP: 8.2
 * Requires at least: 6.0
 * Text Domain: insationai-github-mcp
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('INSATIONAI_GHMCP_VERSION', '2.0.0');
define('INSATIONAI_GHMCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('INSATIONAI_GHMCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('INSATIONAI_GHMCP_PLUGIN_FILE', __FILE__);

// Feature flag: OAuth functionality (ENABLED by default in GitHubMCP)
// Set to false to disable OAuth 2.1 authentication
define('INSATIONAI_GHMCP_OAUTH_FEATURE_ENABLED', true);

// Load Composer autoloader
if (file_exists(INSATIONAI_GHMCP_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'vendor/autoload.php';
}

// GHMCP PSR-4 fallback: guarantees our own classes load even if composer's
// optimized autoload map is stale after re-namespacing the fork.
spl_autoload_register(function ($class) {
    $prefix = 'InsationAI\\GitHubMCP\\';
    if (strpos($class, $prefix) !== 0) { return; }
    $rel  = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file = INSATIONAI_GHMCP_PLUGIN_DIR . 'src/' . $rel . '.php';
    if (is_file($file)) { require $file; }
});

/**
 * Plugin Activation
 */
// Load the license service at the earliest point so BOTH the MCP endpoint
// kill-switch (template_redirect priority 1) and the admin UI can call it.
require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/license/class-license-service.php';

function insationai_ghmcp_activate() {
    require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'install/activate.php';
    insationai_ghmcp_run_activation();
    // Schedule daily license re-validation.
    if (class_exists('InsationAI_GHMCP_License_Service')) {
        InsationAI_GHMCP_License_Service::schedule_cron();
    }
}
register_activation_hook(__FILE__, 'insationai_ghmcp_activate');

/**
 * Plugin Deactivation
 */
function insationai_ghmcp_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
    // Stop the daily license cron. (We intentionally do NOT auto-deactivate
    // the license activation on plugin deactivation — a site temporarily
    // deactivating the plugin should not silently consume a deactivate call;
    // the admin clears the key explicitly via the License tab when moving it.)
    if (class_exists('InsationAI_GHMCP_License_Service')) {
        InsationAI_GHMCP_License_Service::unschedule_cron();
    }
}
register_deactivation_hook(__FILE__, 'insationai_ghmcp_deactivate');

/**
 * Initialize plugin
 */
function insationai_ghmcp_init() {
    // Register rewrite rules
    insationai_ghmcp_register_rewrite_rules();

    // Register query vars
    add_filter('query_vars', 'insationai_ghmcp_register_query_vars');

    // Initialize update checker
    insationai_ghmcp_init_update_checker();
}
add_action('init', 'insationai_ghmcp_init');

/**
 * Dual-register GitHubMCP tools as WP Abilities (WP 6.9+).
 *
 * Loaded unconditionally — register-abilities.php no-ops on older WP. Lives
 * in plugins_loaded so AbstractTool's namespace is autoloaded before the
 * Abilities API hook fires on init.
 */
function insationai_ghmcp_load_abilities_bridge() {
    require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/abilities/register-abilities.php';
}
add_action('plugins_loaded', 'insationai_ghmcp_load_abilities_bridge');

/**
 * Initialize automatic update checker.
 *
 * Updates are delivered via the WC Key Manager Software API on insation.ai
 * and are LICENSE-GATED (product owner decision): the checker only runs when
 * this install is licensed and active. An unlicensed/lapsed install does not
 * check for or receive updates — consistent with the strict licensing model.
 */
function insationai_ghmcp_init_update_checker() {
    // License gate: no license = no update checks at all.
    if (
        ! class_exists('InsationAI_GHMCP_License_Service')
        || ! InsationAI_GHMCP_License_Service::is_licensed()
    ) {
        return;
    }
    if (! class_exists('\\GitHubMCP\\UpdateChecker')) {
        require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'src/UpdateChecker.php';
    }
    // metadata_url is the WCKM Software API get_version endpoint. The license
    // key + instance are appended by the checker itself (see UpdateChecker).
    new \GitHubMCP\UpdateChecker(
        'insationai-github-mcp/insationai-github-mcp.php',
        'https://insation.ai/?wckm-api=get_version'
    );

    // Wire the manual "Check for updates" handler + result notice. These
    // existed in UpdateChecker but were never hooked while the updater was
    // disabled; without this the Updates-tab button would be a dead link.
    add_action('admin_init', array('\\GitHubMCP\\UpdateChecker', 'handleManualUpdateCheck'));
    add_action('admin_notices', array('\\GitHubMCP\\UpdateChecker', 'displayUpdateCheckNotice'));
}

/**
 * Handle plugin version upgrades for backward compatibility
 *
 * Automatically migrates existing installations when plugin is updated.
 * This ensures users upgrading from 1.0.0 (no iwp_mcp_active check)
 * to 1.0.1+ (has iwp_mcp_active check) continue to work seamlessly.
 */
function insationai_ghmcp_handle_version_upgrade() {
    global $wpdb;

    $installed_version = get_option('insationai_ghmcp_version');

    // If version hasn't changed, nothing to do
    if ($installed_version === INSATIONAI_GHMCP_VERSION) {
        return;
    }

    // Check if this is an existing installation (has user tokens table and tokens)
    $table_name = $wpdb->prefix . 'insationai_ghmcp_user_tokens';
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'");

    if ($table_exists === $table_name) {
        // Check if there are any existing tokens
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
        $has_tokens = $wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}`") > 0;

        if ($has_tokens) {
            // This is an existing installation being upgraded
            // Auto-set iwp_mcp_active to preserve access for existing users
            $current_value = get_option('iwp_mcp_active');

            if ($current_value !== 'true') {
                update_option('iwp_mcp_active', 'true');

                // Log the migration
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log(sprintf(
                        '[GitHubMCP] Auto-migrated existing installation from version %s to %s - set iwp_mcp_active=true',
                        $installed_version ?: 'unknown',
                        INSATIONAI_GHMCP_VERSION
                    ));
                }
            }
        }
    }

    // Update stored version
    update_option('insationai_ghmcp_version', INSATIONAI_GHMCP_VERSION);
}

/**
 * Register rewrite rules for MCP endpoints and OAuth discovery
 */
function insationai_ghmcp_register_rewrite_rules() {
    $slug = get_option('insationai_ghmcp_endpoint_slug', 'insationai-github-mcp');

    // MCP HTTP endpoint: /insationai-github-mcp (always enabled)
    add_rewrite_rule(
        '^' . $slug . '/?$',
        'index.php?insationai_ghmcp_endpoint=1',
        'top'
    );

    // OAuth routes (only if feature is enabled)
    if (INSATIONAI_GHMCP_OAUTH_FEATURE_ENABLED) {
        // RFC 8414 compliant OAuth metadata discovery
        // /.well-known/oauth-authorization-server/insationai-github-mcp
        add_rewrite_rule(
            '^\.well-known/oauth-authorization-server/' . $slug . '/?$',
            'index.php?insationai_ghmcp_oauth_meta=authorization-server',
            'top'
        );

        add_rewrite_rule(
            '^\.well-known/oauth-protected-resource/' . $slug . '/?$',
            'index.php?insationai_ghmcp_oauth_meta=protected-resource',
            'top'
        );

        add_rewrite_rule(
            '^\.well-known/jwks\.json/' . $slug . '/?$',
            'index.php?insationai_ghmcp_oauth_meta=jwks',
            'top'
        );

        // OAuth authorization and token endpoints
        add_rewrite_rule(
            '^' . $slug . '/oauth/(authorize|token)/?$',
            'index.php?insationai_ghmcp_oauth=$matches[1]',
            'top'
        );
    }
}

/**
 * Register custom query vars
 */
function insationai_ghmcp_register_query_vars($vars) {
    $vars[] = 'insationai_ghmcp_endpoint';
    $vars[] = 'insationai_ghmcp_oauth_meta';
    $vars[] = 'insationai_ghmcp_oauth';
    return $vars;
}

/**
 * Handle template redirect for MCP endpoints
 */
function insationai_ghmcp_handle_request() {
    // Validate site authorization for runtime requests
    if (get_query_var('insationai_ghmcp_endpoint') || get_query_var('insationai_ghmcp_oauth_meta') || get_query_var('insationai_ghmcp_oauth')) {
        // Load validator class if not already loaded
        if (!class_exists('\InsationAI\GitHubMCP\Validator')) {
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'src/Validator.php';
        }

        if (!\InsationAI\GitHubMCP\Validator::isAuthorized()) {
            \InsationAI\GitHubMCP\Validator::logUnauthorizedAttempt('runtime');

            // Return 403 Forbidden
            status_header(403);
            nocache_headers();
            echo 'Forbidden';
            exit;
        }
    }

    // Handle MCP HTTP endpoint — gated on a valid, active license.
    // STRICT model (product owner decision): if the plugin is not licensed
    // (including: no key, invalid/expired key, OR the license server is
    // unreachable — no grace period), the MCP endpoint does not serve.
    if (get_query_var('insationai_ghmcp_endpoint')) {
        if (
            class_exists('InsationAI_GHMCP_License_Service')
            && InsationAI_GHMCP_License_Service::is_licensed()
        ) {
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/endpoints/mcp-http.php';
            exit;
        }
        // Not licensed: refuse with a clear, machine-readable 403 so MCP
        // clients surface an intelligible reason rather than hanging.
        status_header(403);
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        $reason = 'license_inactive';
        if (class_exists('InsationAI_GHMCP_License_Service')) {
            $st = InsationAI_GHMCP_License_Service::get_state();
            $reason = isset($st['reason_code']) ? $st['reason_code'] : $reason;
        }
        echo wp_json_encode(array(
            'error'   => 'license_inactive',
            'reason'  => $reason,
            'message' => 'This GitHubMCP installation is not licensed. '
                       . 'Enter and activate a valid license key in '
                       . 'WP Admin → InsationAI Tools to enable the MCP endpoint.',
        ));
        exit;
    }

    // OAuth endpoints (only if feature is enabled)
    if (!INSATIONAI_GHMCP_OAUTH_FEATURE_ENABLED) {
        return;
    }

    // Handle OAuth metadata endpoints
    if ($meta = get_query_var('insationai_ghmcp_oauth_meta')) {
        insationai_ghmcp_serve_oauth_metadata($meta);
        exit;
    }

    // Handle OAuth flow endpoints
    if ($oauth = get_query_var('insationai_ghmcp_oauth')) {
        insationai_ghmcp_handle_oauth_flow($oauth);
        exit;
    }
}
add_action('template_redirect', 'insationai_ghmcp_handle_request', 1);

/**
 * Serve OAuth metadata endpoints
 */
function insationai_ghmcp_serve_oauth_metadata($type) {
    switch ($type) {
        case 'authorization-server':
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/well-known/oauth-authorization-server.php';
            break;
        case 'protected-resource':
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/well-known/oauth-protected-resource.php';
            break;
        case 'jwks':
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/well-known/jwks.php';
            break;
    }
}

/**
 * Handle OAuth flow endpoints
 */
function insationai_ghmcp_handle_oauth_flow($flow) {
    switch ($flow) {
        case 'authorize':
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/oauth/authorize.php';
            break;
        case 'token':
            require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'includes/oauth/token.php';
            break;
    }
}

/**
 * Add admin menu
 *
 * Registers a top-level "InsationAI Tools" menu positioned between Plugins (65)
 * and Users (70). Under it:
 *   - GitHubMCP    → main settings page (replaces the old Settings → InsationAI item)
 *   - Upload New Version → standard WP plugin-upload page (plugin-install.php?tab=upload)
 */
function insationai_ghmcp_add_admin_menu() {
    $parent_slug = 'github-mcp-tools';
    if (function_exists('insationai_wpmcp_settings_page')) {
        $parent_slug = 'insationai-tools';
    } else {
        add_menu_page(
            __('InsationAI Tools', 'insationai-github-mcp'),
            __('InsationAI Tools', 'insationai-github-mcp'),
            'manage_options',
            $parent_slug,
            'insationai_ghmcp_settings_page',
            'dashicons-superhero-alt',
            68
        );
    }
    add_submenu_page(
        $parent_slug,
        __('GitHubMCP', 'insationai-github-mcp'),
        __('GitHubMCP', 'insationai-github-mcp'),
        'manage_options',
        'github-mcp-tools',
        'insationai_ghmcp_settings_page'
    );
}
add_action('admin_menu', 'insationai_ghmcp_add_admin_menu', 11);

function insationai_ghmcp_add_upload_submenu() {
    if (function_exists('insationai_wpmcp_settings_page')) {
        return;
    }
    add_submenu_page(
        'github-mcp-tools',
        __('Upload New Version', 'insationai-github-mcp'),
        __('Upload New Version', 'insationai-github-mcp'),
        'install_plugins',
        'plugin-install.php?tab=upload',
        '',
        PHP_INT_MAX
    );
}
add_action('admin_menu', 'insationai_ghmcp_add_upload_submenu', 99);

/**
 * Add Settings link to plugin action links
 */
function insationai_ghmcp_add_settings_link($links) {
    $settings_link = sprintf(
        '<a href="%s">%s</a>',
        admin_url('admin.php?page=github-mcp-tools'),
        __('Settings', 'insationai-github-mcp')
    );
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'insationai_ghmcp_add_settings_link');

/**
 * Render admin settings page
 */
function insationai_ghmcp_settings_page() {
    require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'admin/settings.php';
}

/**
 * Get configuration array from WordPress options
 *
 * @return array Configuration array compatible with AuthenticationManager
 */
function insationai_ghmcp_get_config() {
    $config = [
        'safe_mode' => get_option('insationai_ghmcp_safe_mode', true),
        'oauth' => [
            'enabled' => get_option('insationai_ghmcp_oauth_enabled', false),
            'issuer' => get_option('insationai_ghmcp_oauth_issuer', home_url('/insationai-github-mcp')),
            'resource_identifier' => get_option('insationai_ghmcp_oauth_resource_identifier', home_url('/insationai-github-mcp')),
            'private_key_path' => get_option('insationai_ghmcp_oauth_private_key_path', ''),
            'public_key_path' => get_option('insationai_ghmcp_oauth_public_key_path', ''),
            'access_token_ttl' => get_option('insationai_ghmcp_oauth_access_token_ttl', 3600),
            'refresh_token_ttl' => get_option('insationai_ghmcp_oauth_refresh_token_ttl', 2592000),
            'authorization_code_ttl' => get_option('insationai_ghmcp_oauth_authorization_code_ttl', 600),
        ],
    ];

    // Define WP_MCP_SAFE_MODE constant for tools
    if ($config['safe_mode'] && !defined('WP_MCP_SAFE_MODE')) {
        define('WP_MCP_SAFE_MODE', true);
    }

    return $config;
}

/**
 * AJAX handler to dismiss activation error notice
 */
function insationai_ghmcp_dismiss_activation_error() {
    // Verify user has permission
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
        return;
    }

    // Delete the transient
    delete_transient('insationai_ghmcp_activation_errors');
    wp_send_json_success();
}
add_action('wp_ajax_insationai_ghmcp_dismiss_activation_error', 'insationai_ghmcp_dismiss_activation_error');


/**
 * Serve a custom robots.txt body when one is configured via the
 * manage_robots_txt tool. Runs only if a non-empty body is stored.
 */
add_filter('robots_txt', function ($output, $public) {
    $custom = get_option('insationai_ghmcp_robots_txt', '');
    if (is_string($custom) && $custom !== '') {
        return $custom;
    }
    return $output;
}, 99, 2);

/**
 * Apply redirects configured via the manage_redirects tool.
 *
 * Runs at template_redirect priority 1 so it fires before most plugins. Only
 * matches the exact request path (URI without query string). On match, sends
 * the configured status code and exits.
 */
add_action('template_redirect', function () {
    $redirects = get_option('insationai_ghmcp_redirects', []);
    if (!is_array($redirects) || empty($redirects)) {
        return;
    }
    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = parse_url($request_uri, PHP_URL_PATH);
    if (!is_string($path)) {
        return;
    }
    foreach ($redirects as $rule) {
        if (!is_array($rule) || empty($rule['source']) || empty($rule['target'])) {
            continue;
        }
        if ($rule['source'] === $path) {
            $status = (int) ($rule['status'] ?? 301);
            wp_redirect(esc_url_raw($rule['target']), $status);
            exit;
        }
    }
}, 1);

/**
 * AJAX handler — save the Tools tab toggle state.
 */
add_action('wp_ajax_insationai_ghmcp_save_tools', function () {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    check_ajax_referer('insationai_ghmcp_tools_toggle');

    $disabled = isset($_POST['disabled']) && is_array($_POST['disabled'])
        ? array_map('sanitize_text_field', wp_unslash($_POST['disabled']))
        : [];

    \InsationAI\GitHubMCP\ToolRegistry::setDisabledToolNames($disabled);

    wp_send_json_success([
        'disabled_count' => count($disabled),
    ]);
});
