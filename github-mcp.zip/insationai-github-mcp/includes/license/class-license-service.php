<?php
/**
 * InsationAI GitHubMCP — License Service
 *
 * Validates the plugin's license against the WC Key Manager Software API on
 * insation.ai. STRICT model (per product owner decision):
 *   - Unlicensed / invalid / expired  => NOT licensed (endpoint killed, UI gated).
 *   - License server unreachable       => treated as NOT licensed (NO grace period).
 *   - Daily re-validation via WP-Cron.
 *   - Bound to this plugin's WCKM product_id (a key for another product is rejected).
 *   - Designed bundle-ready: is_licensed() is the single decision point; a future
 *     bundle key can be honored by extending is_valid_for_this_product() only.
 *
 * The WCKM Software API contract used here was read directly from the live
 * wc-key-manager source (SoftwareAPI::validate_key / activate_key / deactivate_key):
 *   GET/POST  https://insation.ai/?wckm-api=<action>
 *   params:   key, instance, product_id
 *   response: JSON { success:bool, error?:string, message?:string,
 *                    expires?: 'never'|date, activation_*?, instance_status? }
 *
 * @package InsationAI\GitHubMCP
 */

defined('ABSPATH') || exit;

if (!class_exists('InsationAI_GHMCP_License_Service')) {

class InsationAI_GHMCP_License_Service {

    /** Option key storing the persisted license state. */
    const OPTION = 'insationai_ghmcp_license';

    /** Cron hook for daily re-validation. */
    const CRON_HOOK = 'insationai_ghmcp_license_cron';

    /**
     * The WCKM parent product this plugin licenses against (GitHubMCP =
     * product 65 on insation.ai; variations 66/67/68 = Single/Agency/Unlimited).
     *
     * IMPORTANT: WC Key Manager binds an issued key to the *variation* ID the
     * customer bought (e.g. 66), NOT the parent product ID (65). WCKM's
     * activate_key does a strict `key->product_id !== request product_id`
     * rejection. So we deliberately DO NOT send product_id to the WCKM API
     * (sending 65 would be rejected for a key bound to 66/67/68). Product
     * ownership is instead enforced plugin-side via the GHMCP- key prefix in
     * is_valid_for_this_product() — which also keeps the bundle-ready single
     * extension point intact.
     *
     * This constant is retained for reference / future bundle logic only.
     */
    const PRODUCT_ID = 112;

    /** Key prefix that identifies a key as belonging to THIS plugin. */
    const KEY_PREFIX = 'GHMCP-';


    /** License server base. */
    const API_BASE = 'https://insation.ai/';

    /** HTTP timeout (seconds). Short, so a hung server doesn't hang wp-admin. */
    const TIMEOUT = 12;

    /**
     * Get the persisted license state (never throws; always returns an array).
     *
     * @return array {
     *   key:string, status:string, reason_code:string, reason_message:string,
     *   tier:string, expires:string, last_check:int, last_success:int,
     *   instance:string
     * }
     */
    public static function get_state() {
        $defaults = array(
            'key'            => '',
            'status'         => 'unlicensed', // licensed | unlicensed
            'reason_code'    => 'no_key',
            'reason_message' => 'No license key entered yet.',
            'tier'           => '',
            'expires'        => '',
            'activation_limit'     => 0,
            'activation_count'     => 0,
            'activation_remaining' => '',
            'last_check'     => 0,
            'last_success'   => 0,
            'instance'       => self::get_instance(),
        );
        $state = get_option(self::OPTION, array());
        if (!is_array($state)) {
            $state = array();
        }
        return array_merge($defaults, $state);
    }

    /**
     * THE single licensing decision point. Everything (endpoint kill-switch,
     * UI gate) asks this and nothing else.
     *
     * STRICT: only true when the last validation succeeded AND the key is
     * valid for THIS product AND not expired. Server-unreachable does NOT
     * grant access (no grace period — product owner decision).
     *
     * @return bool
     */
    public static function is_licensed() {
        $state = self::get_state();
        return ('licensed' === $state['status']);
    }

    /**
     * Mask a license key for display: keep the readable prefix + last group,
     * hide the secret middle. e.g. GHMCP-1-6HSM-SSZN-GMCR -> GHMCP-1-••••-••••-GMCR
     * Returns '' for an empty key.
     *
     * @param string $key
     * @return string
     */
    public static function mask_key($key) {
        $key = (string) $key;
        if ('' === $key) {
            return '';
        }
        $parts = explode('-', $key);
        // Expected shape: WPMCP - <tier> - g1 - g2 - g3 (5 parts). Be defensive:
        // if it doesn't match, mask all but the final 4 visible chars.
        if (count($parts) >= 5) {
            $last  = array_pop($parts);          // g3 (kept)
            $first = array_slice($parts, 0, 2);  // WPMCP, tier (kept)
            $mid   = array_slice($parts, 2);     // remaining groups (masked)
            $mid   = array_map(function ($g) { return str_repeat('•', max(4, strlen($g))); }, $mid);
            return implode('-', array_merge($first, $mid, array($last)));
        }
        $tail = substr($key, -4);
        return str_repeat('•', max(0, strlen($key) - 4)) . $tail;
    }

    /**
     * The site instance identifier used as the WCKM activation slot.
     * Stable per site (host + path), sanitized the same way WCKM expects.
     *
     * @return string
     */
    public static function get_instance() {
        $url  = home_url('/');
        $host = wp_parse_url($url, PHP_URL_HOST);
        $path = wp_parse_url($url, PHP_URL_PATH);
        $inst = trailingslashit($host . ($path ? $path : ''));
        return sanitize_text_field($inst);
    }

    /**
     * Low-level call to the WCKM Software API.
     *
     * @param string $action  validate_key | activate_key | deactivate_key
     * @param string $key
     * @return array { ok:bool, http:bool, data:array|null, error:string }
     *   ok    = HTTP succeeded AND JSON parsed (NOT necessarily license-valid)
     *   http  = transport reached the server at all
     */
    protected static function call($action, $key) {
        // NOTE: product_id is intentionally NOT sent. WCKM binds keys to the
        // purchased variation ID and strictly rejects a mismatched product_id.
        // Product ownership is enforced plugin-side via is_valid_for_this_product().
        $url = add_query_arg(
            array(
                'wckm-api'   => $action,
                'key'        => $key,
                'instance'   => self::get_instance(),
            ),
            self::API_BASE
        );

        $resp = wp_remote_get($url, array(
            'timeout'     => self::TIMEOUT,
            'redirection' => 2,
            'sslverify'   => true,
            'headers'     => array('Accept' => 'application/json'),
        ));

        if (is_wp_error($resp)) {
            return array('ok' => false, 'http' => false, 'data' => null,
                'error' => $resp->get_error_message());
        }

        $code = (int) wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);

        if ($code < 200 || $code >= 300) {
            return array('ok' => false, 'http' => true, 'data' => null,
                'error' => 'Unexpected HTTP status ' . $code . ' from license server.');
        }

        $data = json_decode($body, true);
        if (!is_array($data)) {
            // WCKM emits "-1" / non-JSON when the API or action is disabled.
            return array('ok' => false, 'http' => true, 'data' => null,
                'error' => 'License server returned an unreadable response.');
        }

        return array('ok' => true, 'http' => true, 'data' => $data, 'error' => '');
    }

    /**
     * Bundle-ready validity gate. For now: a single-product key whose
     * product_id matches THIS product. A future bundle key can be accepted by
     * extending ONLY this method (e.g. accept a bundle product_id too) —
     * nothing else in the licensing system needs to change.
     *
     * @param array $data Parsed WCKM response.
     * @return bool
     */
    /**
     * Bundle-ready ownership gate — the SINGLE place that decides "is this key
     * for THIS plugin." WCKM has already confirmed the key is real/valid; this
     * adds the product-ownership check WCKM's API can't do for us (it binds to
     * variation IDs, so we can't use product_id). Enforced via the key prefix:
     * GitHubMCP keys are GHMCP-*. A future bundle key (e.g. WPSUITE-*) can be
     * accepted by extending ONLY this method — nothing else changes.
     *
     * @param array  $data Parsed WCKM response (already success===true here).
     * @param string $key  The license key being validated.
     * @return bool
     */
    protected static function is_valid_for_this_product($data, $key) {
        if (empty($data['success'])) {
            return false;
        }
        // Per-plugin key for GitHubMCP.
        if (0 === strpos($key, self::KEY_PREFIX)) {
            return true;
        }
        // --- Bundle-ready extension point ---
        // When the InsationAI Suite bundle exists, accept its prefix here too,
        // e.g.:  if (0 === strpos($key, 'WPSUITE-')) return true;
        return false;
    }

    /**
     * Validate (and, if needed, activate) the stored or supplied key, then
     * persist a structured state + human reason. This is what the cron and
     * the License tab both call.
     *
     * @param string|null $key      Key to use; null = use stored key.
     * @param bool        $activate If true, attempt activation when valid-but-inactive.
     * @return array The new persisted state.
     */
    public static function refresh($key = null, $activate = false) {
        $state = self::get_state();
        if (null === $key) {
            $key = $state['key'];
        }
        $key = trim((string) $key);

        $now = time();
        $state['key']        = $key;
        $state['last_check'] = $now;
        $state['instance']   = self::get_instance();

        if ('' === $key) {
            return self::persist($state, 'unlicensed', 'no_key',
                'No license key entered yet.');
        }

        $res = self::call('validate_key', $key);

        // Transport failure => STRICT: unlicensed, distinct reason so the
        // License tab can reassure the user it's the server, not their key.
        if (!$res['http']) {
            return self::persist($state, 'unlicensed', 'server_unreachable',
                'Could not reach the license server (insation.ai). Your endpoint '
                . 'is temporarily disabled. This is usually a temporary issue and '
                . 'not a problem with your key — it will retry automatically.');
        }
        if (!$res['ok']) {
            return self::persist($state, 'unlicensed', 'server_error',
                'The license server returned an unexpected response. This is '
                . 'usually temporary and not a problem with your key.');
        }

        $data = $res['data'];

        if (empty($data['success'])) {
            $err = isset($data['error']) ? (string) $data['error'] : 'invalid_key';
            if ('expired' === $err) {
                return self::persist($state, 'unlicensed', 'expired',
                    'This license has expired. Renew it to re-enable GitHubMCP.');
            }
            return self::persist($state, 'unlicensed', 'invalid_key',
                'This license key was not recognized. Check for typos, or use the '
                . 'key from your purchase confirmation email.');
        }

        if (!self::is_valid_for_this_product($data, $key)) {
            return self::persist($state, 'unlicensed', 'wrong_product',
                'This key is for a different product and cannot be used to '
                . 'license GitHubMCP.');
        }

        // Key is valid. Is it activated for THIS site?
        $instance_status = isset($data['instance_status'])
            ? (string) $data['instance_status'] : '';

        if ('active' !== $instance_status) {
            if (!$activate) {
                return self::persist($state, 'unlicensed', 'not_activated',
                    'License key recognized but not yet activated on this site. '
                    . 'Click “Activate license”.');
            }
            // Attempt activation.
            $act = self::call('activate_key', $key);
            if (!$act['http']) {
                return self::persist($state, 'unlicensed', 'server_unreachable',
                    'Could not reach the license server (insation.ai) to activate. '
                    . 'This is usually temporary — please try again shortly.');
            }
            if (!$act['ok'] || empty($act['data']['success'])) {
                $msg = (!empty($act['data']['message']))
                    ? (string) $act['data']['message']
                    : 'Activation failed. The activation limit for this key may '
                      . 'have been reached.';
                $code = (!empty($act['data']['error']))
                    ? (string) $act['data']['error'] : 'activation_failed';
                return self::persist($state, 'unlicensed', $code, $msg);
            }
            $data = $act['data']; // success payload carries tier/expiry too
        }

        // LICENSED.
        $expires = isset($data['expires']) ? (string) $data['expires'] : 'never';
        $tier    = '';
        // WCKM doesn't return a tier label directly; derive from key prefix if present.
        if (preg_match('/^GHMCP-([1AU])-/', $key, $m)) {
            $tier = array('1' => 'Single Site', 'A' => 'Agency', 'U' => 'Unlimited')[$m[1]];
        }
        // Activation accounting from the WCKM response. 'activation_remaining'
        // is the string 'unlimited' for limit-0 keys (per WCKM source) — keep
        // it as-is; the UI renders it directly.
        $act_limit = isset($data['activation_limit'])
            ? (int) $data['activation_limit'] : 0;
        $act_count = isset($data['activation_count'])
            ? (int) $data['activation_count'] : 0;
        $act_remain = isset($data['activation_remaining'])
            ? (string) $data['activation_remaining']
            : ($act_limit > 0 ? (string) max(0, $act_limit - $act_count) : 'unlimited');

        $state['tier']                 = $tier;
        $state['expires']              = $expires;
        $state['activation_limit']     = $act_limit;
        $state['activation_count']     = $act_count;
        $state['activation_remaining'] = $act_remain;
        $state['last_success']         = $now;
        return self::persist($state, 'licensed', 'ok',
            'Licensed and active.');
    }

    /**
     * Deactivate this site's activation (called when the admin clears the key).
     *
     * @return array New state.
     */
    public static function deactivate() {
        $state = self::get_state();
        $key   = $state['key'];
        if ('' !== $key) {
            // Best-effort; ignore transport failure (we still clear locally).
            self::call('deactivate_key', $key);
        }
        $blank = array(
            'key' => '', 'tier' => '', 'expires' => '',
            'activation_limit' => 0, 'activation_count' => 0,
            'activation_remaining' => '',
            'last_success' => 0,
        );
        return self::persist(array_merge($state, $blank),
            'unlicensed', 'no_key', 'License removed from this site.');
    }

    /**
     * Persist state with a status + structured reason.
     *
     * @return array The state that was saved.
     */
    protected static function persist($state, $status, $reason_code, $reason_message) {
        $state['status']         = $status;
        $state['reason_code']    = $reason_code;
        $state['reason_message'] = $reason_message;
        update_option(self::OPTION, $state, false);
        return $state;
    }

    /** Schedule the daily re-validation cron (idempotent). */
    public static function schedule_cron() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + DAY_IN_SECONDS, 'daily', self::CRON_HOOK);
        }
    }

    /** Clear the cron (on deactivation). */
    public static function unschedule_cron() {
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) {
            wp_unschedule_event($ts, self::CRON_HOOK);
        }
    }

    /** Cron callback: silent re-validation (no activation attempt). */
    public static function cron_revalidate() {
        self::refresh(null, false);
    }
}

// Wire the cron callback.
add_action(InsationAI_GHMCP_License_Service::CRON_HOOK,
    array('InsationAI_GHMCP_License_Service', 'cron_revalidate'));

}
