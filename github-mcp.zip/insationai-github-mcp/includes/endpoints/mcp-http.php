<?php
/**
 * MCP HTTP Endpoint
 *
 * Handles HTTP requests to the MCP server
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * CORS hardening — runs right before any headers are flushed.
 *
 * The bundled MCP SDK sends `Access-Control-Allow-Origin: *` from
 * StreamableHttpTransport. That is unsafe for an endpoint that accepts
 * bearer-token credentials: any origin's JavaScript can call this endpoint
 * if it has the token, so an XSS anywhere that leaks the token becomes
 * full site compromise.
 *
 * Behavior:
 *   - If the option `insationai_ghmcp_cors_allowed_origins` is unset or
 *     empty, we strip CORS headers entirely. (Server-to-server clients
 *     like Claude Desktop don't need CORS. They make direct HTTP requests
 *     from their own host.)
 *   - If the option contains a comma-separated allowlist of origins,
 *     and the request's Origin header matches one of them, we send that
 *     specific origin back (never `*`).
 *
 * Site owners that legitimately need to embed this from a browser-side app
 * can set the option to that app's origin. The default is the safest:
 * server-to-server only.
 */
header_register_callback(function () {
    $allowed_raw = get_option('insationai_ghmcp_cors_allowed_origins', '');
    $request_origin = $_SERVER['HTTP_ORIGIN'] ?? '';

    // Remove the wildcard the SDK installed.
    header_remove('Access-Control-Allow-Origin');

    if (!empty($allowed_raw) && $request_origin !== '') {
        $allowed = array_map('trim', explode(',', $allowed_raw));
        if (in_array($request_origin, $allowed, true)) {
            header('Access-Control-Allow-Origin: ' . $request_origin);
            header('Vary: Origin', false);
        }
    }
    // If no allowlist and no Origin header, do nothing — server-to-server clients
    // don't need any CORS header and browser-based requests will be blocked by
    // the same-origin policy, which is the safest default.
});

// Validate site authorization before processing request
if (!class_exists('\InsationAI\GitHubMCP\Validator')) {
    require_once INSATIONAI_GHMCP_PLUGIN_DIR . 'src/Validator.php';
}

if (!\InsationAI\GitHubMCP\Validator::isAuthorized()) {
    \InsationAI\GitHubMCP\Validator::logUnauthorizedAttempt('endpoint');

    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', WP_CONTENT_DIR . '/debug.log');

// Import authentication and other classes
use InsationAI\GitHubMCP\Auth\AuthenticationManager;
use Laminas\HttpHandlerRunner\Emitter\SapiEmitter;
use Mcp\Server;
use Mcp\Server\Session\FileSessionStore;
use Mcp\Server\Transport\StreamableHttpTransport;
use Nyholm\Psr7\Factory\Psr17Factory;
use Nyholm\Psr7Server\ServerRequestCreator;

// Import our services and tools
use InsationAI\GitHubMCP\Services\ValidationService;
use InsationAI\GitHubMCP\Services\WordPressService;
use InsationAI\GitHubMCP\Services\ContentPatchingService;
use InsationAI\GitHubMCP\Logger\WordPressLogger;

// Content tools
use InsationAI\GitHubMCP\Tools\Content\ListContent;
use InsationAI\GitHubMCP\Tools\Content\GetContent;
use InsationAI\GitHubMCP\Tools\Content\CreateContent;
use InsationAI\GitHubMCP\Tools\Content\UpdateContent;
use InsationAI\GitHubMCP\Tools\Content\PatchContent;
use InsationAI\GitHubMCP\Tools\Content\DeleteContent;
use InsationAI\GitHubMCP\Tools\Content\DiscoverContentTypes;
use InsationAI\GitHubMCP\Tools\Content\GetContentBySlug;
use InsationAI\GitHubMCP\Tools\Content\FindContentByUrl;

// Taxonomy tools
use InsationAI\GitHubMCP\Tools\Taxonomy\DiscoverTaxonomies;
use InsationAI\GitHubMCP\Tools\Taxonomy\GetTaxonomy;
use InsationAI\GitHubMCP\Tools\Taxonomy\ListTerms;
use InsationAI\GitHubMCP\Tools\Taxonomy\GetTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\CreateTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\UpdateTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\DeleteTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\AssignTermsToContent;
use InsationAI\GitHubMCP\Tools\Taxonomy\GetContentTerms;

// Plugin tools
use InsationAI\GitHubMCP\Tools\Plugin\PluginInfo;
use InsationAI\GitHubMCP\Tools\Plugin\PluginOperations;
use InsationAI\GitHubMCP\Tools\Plugin\PluginFiles;

// Theme tools
use InsationAI\GitHubMCP\Tools\Theme\ThemeInfo;
use InsationAI\GitHubMCP\Tools\Theme\ThemeOperations;
use InsationAI\GitHubMCP\Tools\Theme\ThemeFiles;

// Media tools
use InsationAI\GitHubMCP\Tools\Media\MediaUpload;
use InsationAI\GitHubMCP\Tools\Media\MediaAttach;
use InsationAI\GitHubMCP\Tools\Media\MediaMetadata;

// Code tools (opt-in)
use InsationAI\GitHubMCP\Tools\Code\ExecutePhp;

// User tools
use InsationAI\GitHubMCP\Tools\User\ListUsers;
use InsationAI\GitHubMCP\Tools\User\GetUser;
use InsationAI\GitHubMCP\Tools\User\CreateUser;
use InsationAI\GitHubMCP\Tools\User\UpdateUser;
use InsationAI\GitHubMCP\Tools\User\DeleteUser;
use InsationAI\GitHubMCP\Tools\User\ListRoles;
use InsationAI\GitHubMCP\Tools\User\ManageUserRoles;
use InsationAI\GitHubMCP\Tools\User\ManageCapabilities;

// Comment tools
use InsationAI\GitHubMCP\Tools\Comment\ListComments;
use InsationAI\GitHubMCP\Tools\Comment\GetComment;
use InsationAI\GitHubMCP\Tools\Comment\CreateComment;
use InsationAI\GitHubMCP\Tools\Comment\UpdateComment;
use InsationAI\GitHubMCP\Tools\Comment\DeleteComment;
use InsationAI\GitHubMCP\Tools\Comment\ModerateComment;

// Option tools
use InsationAI\GitHubMCP\Tools\Option\GetOption;
use InsationAI\GitHubMCP\Tools\Option\UpdateOption;
use InsationAI\GitHubMCP\Tools\Option\DeleteOption;
use InsationAI\GitHubMCP\Tools\Option\ListOptions;
use InsationAI\GitHubMCP\Tools\Option\GetTransient;
use InsationAI\GitHubMCP\Tools\Option\SetTransient;
use InsationAI\GitHubMCP\Tools\Option\DeleteTransient;
use InsationAI\GitHubMCP\Tools\Option\ManageThemeMods;

// Menu tools
use InsationAI\GitHubMCP\Tools\Menu\ListMenus;
use InsationAI\GitHubMCP\Tools\Menu\GetMenu;
use InsationAI\GitHubMCP\Tools\Menu\ManageMenu;
use InsationAI\GitHubMCP\Tools\Menu\ManageMenuItems;
use InsationAI\GitHubMCP\Tools\Menu\AssignMenuLocation;

// Widget tools
use InsationAI\GitHubMCP\Tools\Widget\ListSidebars;
use InsationAI\GitHubMCP\Tools\Widget\ListWidgets;
use InsationAI\GitHubMCP\Tools\Widget\ManageWidget;
use InsationAI\GitHubMCP\Tools\Widget\ManageBlockWidgets;

// Pattern tools
use InsationAI\GitHubMCP\Tools\Pattern\ListPatterns;
use InsationAI\GitHubMCP\Tools\Pattern\ManagePattern;
use InsationAI\GitHubMCP\Tools\Pattern\ListReusableBlocks;

// Customizer tools
use InsationAI\GitHubMCP\Tools\Customizer\GetCustomizerSettings;
use InsationAI\GitHubMCP\Tools\Customizer\UpdateCustomizerSetting;
use InsationAI\GitHubMCP\Tools\Customizer\ExportCustomizer;

// Cron tools
use InsationAI\GitHubMCP\Tools\Cron\ListScheduledEvents;
use InsationAI\GitHubMCP\Tools\Cron\ScheduleEvent;
use InsationAI\GitHubMCP\Tools\Cron\UnscheduleEvent;
use InsationAI\GitHubMCP\Tools\Cron\RunEventNow;

// Rewrite tools
use InsationAI\GitHubMCP\Tools\Rewrite\ListRewriteRules;
use InsationAI\GitHubMCP\Tools\Rewrite\FlushRewriteRules;
use InsationAI\GitHubMCP\Tools\Rewrite\AddRewriteRule;

// Database tools
use InsationAI\GitHubMCP\Tools\Database\DbQuery;
use InsationAI\GitHubMCP\Tools\Database\DbTableInfo;
use InsationAI\GitHubMCP\Tools\Database\OptimizeTables;
use InsationAI\GitHubMCP\Tools\Database\RepairTables;
use InsationAI\GitHubMCP\Tools\Database\CleanupRevisions;
use InsationAI\GitHubMCP\Tools\Database\CleanupSpamComments;
use InsationAI\GitHubMCP\Tools\Database\CleanupTransients;
use InsationAI\GitHubMCP\Tools\Database\SearchReplace;

// Diagnostics tools
use InsationAI\GitHubMCP\Tools\Diagnostics\SystemInfo;
use InsationAI\GitHubMCP\Tools\Diagnostics\SiteHealthCheck;
use InsationAI\GitHubMCP\Tools\Diagnostics\DebugLogRead;
use InsationAI\GitHubMCP\Tools\Diagnostics\DebugLogClear;
use InsationAI\GitHubMCP\Tools\Diagnostics\ListHooksOnAction;

// Multisite tools
use InsationAI\GitHubMCP\Tools\Multisite\ListSites;
use InsationAI\GitHubMCP\Tools\Multisite\GetSite;
use InsationAI\GitHubMCP\Tools\Multisite\ManageSite;
use InsationAI\GitHubMCP\Tools\Multisite\ManageNetworkUsers;
use InsationAI\GitHubMCP\Tools\Multisite\NetworkActivatePlugin;

// Load configuration from WordPress options
$config = insationai_ghmcp_get_config();

// Initialize authentication manager
$authManager = new AuthenticationManager($config);

// Validate authentication
$authResult = $authManager->authenticate();
if (!$authResult['authenticated']) {
    $authManager->sendUnauthorizedResponse($authResult['error'], $authResult['headers']);
    exit;
}

// Store user context for tools
$userContext = $authResult['user'];

// Set the current user in WordPress so capability checks work
if ($userContext !== null && isset($userContext['id'])) {
    wp_set_current_user($userContext['id']);
}

// Initialize services
$wpService = new WordPressService();
$validationService = new ValidationService();
$logger = new WordPressLogger();
$patchingService = new ContentPatchingService($wpService, $logger);

// Log that endpoint was hit
$logger->info('MCP HTTP endpoint accessed', [
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
    'user_id' => $userContext['id'] ?? 'unknown'
]);

// Initialize tools through the central registry. This automatically applies
// the disabled-tools allow-list configured in the admin Tools tab, includes
// multisite-only tools when running on a multisite, and includes the optional
// ExecutePhp tool when its own opt-in flag is set.
$tools = \InsationAI\GitHubMCP\ToolRegistry::buildEnabledTools(
    $wpService,
    $validationService,
    $logger,
    $patchingService
);


// Create PSR-7 request factory
$psr17Factory = new Psr17Factory();
$creator = new ServerRequestCreator($psr17Factory, $psr17Factory, $psr17Factory, $psr17Factory);

// Get the incoming request
$request = $creator->fromGlobals();

// Build server info description with capabilities
$capabilities = [
    'safe_mode' => get_option('insationai_ghmcp_safe_mode', true),
    'oauth_feature_enabled' => INSATIONAI_GHMCP_OAUTH_FEATURE_ENABLED,
    'authentication_enabled' => $authManager->isAuthenticationEnabled(),
    'authentication_method' => $authManager->getAuthenticationMethod(),
    'oauth_enabled' => get_option('insationai_ghmcp_oauth_enabled', false),
];

$description = 'GitHubMCP - WordPress MCP Server - Capabilities: ' . json_encode($capabilities);

// Create sessions directory if it doesn't exist
$sessionsDir = WP_CONTENT_DIR . '/insationai-github-mcp-sessions';
if (!is_dir($sessionsDir)) {
    wp_mkdir_p($sessionsDir);
}

// Create the MCP server
$serverBuilder = Server::builder()
    ->setServerInfo('GitHubMCP', INSATIONAI_GHMCP_VERSION, $description)
    ->setSession(new FileSessionStore($sessionsDir));

// Set user context on all tools (for OAuth scope validation)
if ($userContext !== null) {
    foreach ($tools as $tool) {
        $tool->setUserContext($userContext);
    }
}

// Register all tools with dynamic parameter handling
// The MCP SDK uses reflection to get parameter names, so we need to create closures
// with correctly named parameters.
//
// IMPORTANT: the closure captures two variables via `use (...)`. Those captured
// variable names must NEVER collide with a tool's parameter name, or PHP throws
// "Cannot use lexical variable $x as a parameter name" at eval time. We use
// deliberately unusual names (__emcp_tool, __emcp_logger) that no tool schema
// would ever use as a parameter. Tool authors are free to name parameters
// `tool`, `logger`, `params`, etc. without breaking this wrapper.
foreach ($tools as $__emcp_tool) {
    $schema = $__emcp_tool->getSchema();
    $paramNames = array_keys($schema);

    // Build parameter list string for function signature
    $paramStr = implode(', ', array_map(fn($name) => "mixed \${$name} = null", $paramNames));

    // Build code to collect non-null parameters into a local array.
    // We use a collision-proof local name (__emcp_params) for the same reason
    // as the captured variables above.
    $collectParamsCode = "        \$__emcp_params = [];\n";
    foreach ($paramNames as $name) {
        $collectParamsCode .= "        if (\${$name} !== null) { \$__emcp_params['{$name}'] = \${$name}; }\n";
    }

    // Build the complete function code (alternative to heredoc)
    // phpcs:disable Squiz.PHP.Eval.Discouraged -- Required for dynamic parameter names without heredoc
    $functionCode = '
        return function(' . $paramStr . ') use ($__emcp_tool, $__emcp_logger) {
    ' . $collectParamsCode . '
            try {
                $result = $__emcp_tool->execute($__emcp_params);
                return $result["data"] ?? $result;
            } catch (\\Exception $e) {
                $__emcp_logger->error("Tool error: " . $__emcp_tool->getName(), [
                    "error" => $e->getMessage()
                ]);
                // Return error result per MCP protocol (instead of throwing)
                // This allows the error message to be passed to the client
                $errors = method_exists($e, "getErrors") ? $e->getErrors() : [];
                return ["error" => $e->getMessage(), "errors" => $errors];
            }
        };
    ';
    // phpcs:enable

    // The captured $__emcp_logger must exist in this scope for the `use` to bind.
    $__emcp_logger = $logger;

    // Use eval to create the wrapper with correct parameter names
    // phpcs:ignore Squiz.PHP.Eval.Discouraged -- Required for dynamic tool parameter handling
    $wrapper = eval($functionCode);

    $serverBuilder->addTool(
        $wrapper,
        name: $__emcp_tool->getName(),
        description: $__emcp_tool->getDescription(),
        inputSchema: $__emcp_tool->getInputSchema()
    );
}

// Add site info resource
$serverBuilder->addResource(
    function (): array {
        $theme = wp_get_theme();
        $timezone = get_option('timezone_string');

        // If timezone string is empty, try to get it from gmt_offset
        if (empty($timezone)) {
            $gmt_offset = get_option('gmt_offset');
            $timezone = $gmt_offset ? 'UTC' . ($gmt_offset >= 0 ? '+' : '') . $gmt_offset : 'UTC';
        }

        return [
            'site_name' => get_bloginfo('name'),
            'site_description' => get_bloginfo('description'),
            'site_url' => get_bloginfo('url'),
            'home_url' => home_url(),
            'admin_email' => get_bloginfo('admin_email'),
            'language' => get_bloginfo('language'),
            'timezone' => $timezone,
            'wordpress_version' => get_bloginfo('version'),
            'active_theme' => $theme->get('Name'),
            'active_theme_version' => $theme->get('Version'),
            'posts_count' => wp_count_posts('post')->publish,
            'pages_count' => wp_count_posts('page')->publish,
        ];
    },
    uri: 'wordpress://site/info',
    name: 'site_info',
    description: 'WordPress site information and statistics',
    mimeType: 'application/json'
);

$server = $serverBuilder->build();

// Create HTTP transport
$transport = new StreamableHttpTransport($request, $psr17Factory, $psr17Factory);

// Run the server and get response
$response = $server->run($transport);

// Emit the response using SAPI emitter
(new SapiEmitter())->emit($response);
