<?php
/**
 * WordPress Abilities API registration.
 *
 * Dual-registers every GitHubMCP tool as a WordPress Ability via wp_register_ability()
 * (introduced in WP 6.9). The tools also continue to be served via the custom
 * /insationai-github-mcp HTTP endpoint — this file does not replace that endpoint, it
 * mirrors the same tools onto the WP-native Abilities API so that:
 *
 *   - Other WP plugins / first-party WP MCP clients that consume the Abilities
 *     API see GitHubMCP's tools without needing the custom endpoint.
 *   - Sites can keep the GitHubMCP HTTP endpoint disabled (custom-slug or
 *     firewalled) and still expose tools through the official WP MCP Adapter.
 *
 * The WP HTTP endpoint at /insationai-github-mcp remains the canonical transport for
 * cloud-hosted clients (Claude Desktop, Cursor, etc.) using the bearer-token
 * flow this plugin provisions.
 *
 * @package GitHubMCP
 * @since 1.1.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

use InsationAI\GitHubMCP\Services\ContentPatchingService;
use InsationAI\GitHubMCP\Services\ValidationService;
use InsationAI\GitHubMCP\Services\WordPressService;
use InsationAI\GitHubMCP\Logger\WordPressLogger;
use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Tools\Code\ExecutePhp;
use InsationAI\GitHubMCP\Tools\Content\CreateContent;
use InsationAI\GitHubMCP\Tools\Content\DeleteContent;
use InsationAI\GitHubMCP\Tools\Content\DiscoverContentTypes;
use InsationAI\GitHubMCP\Tools\Content\FindContentByUrl;
use InsationAI\GitHubMCP\Tools\Content\GetContent;
use InsationAI\GitHubMCP\Tools\Content\GetContentBySlug;
use InsationAI\GitHubMCP\Tools\Content\ListContent;
use InsationAI\GitHubMCP\Tools\Content\PatchContent;
use InsationAI\GitHubMCP\Tools\Content\UpdateContent;
use InsationAI\GitHubMCP\Tools\Media\MediaAttach;
use InsationAI\GitHubMCP\Tools\Media\MediaMetadata;
use InsationAI\GitHubMCP\Tools\Media\MediaUpload;
use InsationAI\GitHubMCP\Tools\Plugin\PluginFiles;
use InsationAI\GitHubMCP\Tools\Plugin\PluginInfo;
use InsationAI\GitHubMCP\Tools\Plugin\PluginOperations;
use InsationAI\GitHubMCP\Tools\Taxonomy\AssignTermsToContent;
use InsationAI\GitHubMCP\Tools\Taxonomy\CreateTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\DeleteTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\DiscoverTaxonomies;
use InsationAI\GitHubMCP\Tools\Taxonomy\GetContentTerms;
use InsationAI\GitHubMCP\Tools\Taxonomy\GetTaxonomy;
use InsationAI\GitHubMCP\Tools\Taxonomy\GetTerm;
use InsationAI\GitHubMCP\Tools\Taxonomy\ListTerms;
use InsationAI\GitHubMCP\Tools\Taxonomy\UpdateTerm;
use InsationAI\GitHubMCP\Tools\Theme\ThemeFiles;
use InsationAI\GitHubMCP\Tools\Theme\ThemeInfo;
use InsationAI\GitHubMCP\Tools\Theme\ThemeOperations;
use InsationAI\GitHubMCP\Tools\User\ListUsers;
use InsationAI\GitHubMCP\Tools\User\GetUser;
use InsationAI\GitHubMCP\Tools\User\CreateUser;
use InsationAI\GitHubMCP\Tools\User\UpdateUser;
use InsationAI\GitHubMCP\Tools\User\DeleteUser;
use InsationAI\GitHubMCP\Tools\User\ListRoles;
use InsationAI\GitHubMCP\Tools\User\ManageUserRoles;
use InsationAI\GitHubMCP\Tools\User\ManageCapabilities;
use InsationAI\GitHubMCP\Tools\Comment\ListComments;
use InsationAI\GitHubMCP\Tools\Comment\GetComment;
use InsationAI\GitHubMCP\Tools\Comment\CreateComment;
use InsationAI\GitHubMCP\Tools\Comment\UpdateComment;
use InsationAI\GitHubMCP\Tools\Comment\DeleteComment;
use InsationAI\GitHubMCP\Tools\Comment\ModerateComment;
use InsationAI\GitHubMCP\Tools\Option\GetOption;
use InsationAI\GitHubMCP\Tools\Option\UpdateOption;
use InsationAI\GitHubMCP\Tools\Option\DeleteOption;
use InsationAI\GitHubMCP\Tools\Option\ListOptions;
use InsationAI\GitHubMCP\Tools\Option\GetTransient;
use InsationAI\GitHubMCP\Tools\Option\SetTransient;
use InsationAI\GitHubMCP\Tools\Option\DeleteTransient;
use InsationAI\GitHubMCP\Tools\Option\ManageThemeMods;
use InsationAI\GitHubMCP\Tools\Menu\ListMenus;
use InsationAI\GitHubMCP\Tools\Menu\GetMenu;
use InsationAI\GitHubMCP\Tools\Menu\ManageMenu;
use InsationAI\GitHubMCP\Tools\Menu\ManageMenuItems;
use InsationAI\GitHubMCP\Tools\Menu\AssignMenuLocation;
use InsationAI\GitHubMCP\Tools\Widget\ListSidebars;
use InsationAI\GitHubMCP\Tools\Widget\ListWidgets;
use InsationAI\GitHubMCP\Tools\Widget\ManageWidget;
use InsationAI\GitHubMCP\Tools\Widget\ManageBlockWidgets;
use InsationAI\GitHubMCP\Tools\Pattern\ListPatterns;
use InsationAI\GitHubMCP\Tools\Pattern\ManagePattern;
use InsationAI\GitHubMCP\Tools\Pattern\ListReusableBlocks;
use InsationAI\GitHubMCP\Tools\Customizer\GetCustomizerSettings;
use InsationAI\GitHubMCP\Tools\Customizer\UpdateCustomizerSetting;
use InsationAI\GitHubMCP\Tools\Customizer\ExportCustomizer;
use InsationAI\GitHubMCP\Tools\Cron\ListScheduledEvents;
use InsationAI\GitHubMCP\Tools\Cron\ScheduleEvent;
use InsationAI\GitHubMCP\Tools\Cron\UnscheduleEvent;
use InsationAI\GitHubMCP\Tools\Cron\RunEventNow;
use InsationAI\GitHubMCP\Tools\Rewrite\ListRewriteRules;
use InsationAI\GitHubMCP\Tools\Rewrite\FlushRewriteRules;
use InsationAI\GitHubMCP\Tools\Rewrite\AddRewriteRule;
use InsationAI\GitHubMCP\Tools\Database\DbQuery;
use InsationAI\GitHubMCP\Tools\Database\DbTableInfo;
use InsationAI\GitHubMCP\Tools\Database\OptimizeTables;
use InsationAI\GitHubMCP\Tools\Database\RepairTables;
use InsationAI\GitHubMCP\Tools\Database\CleanupRevisions;
use InsationAI\GitHubMCP\Tools\Database\CleanupSpamComments;
use InsationAI\GitHubMCP\Tools\Database\CleanupTransients;
use InsationAI\GitHubMCP\Tools\Database\SearchReplace;
use InsationAI\GitHubMCP\Tools\Diagnostics\SystemInfo;
use InsationAI\GitHubMCP\Tools\Diagnostics\SiteHealthCheck;
use InsationAI\GitHubMCP\Tools\Diagnostics\DebugLogRead;
use InsationAI\GitHubMCP\Tools\Diagnostics\DebugLogClear;
use InsationAI\GitHubMCP\Tools\Diagnostics\ListHooksOnAction;
use InsationAI\GitHubMCP\Tools\Multisite\ListSites;
use InsationAI\GitHubMCP\Tools\Multisite\GetSite;
use InsationAI\GitHubMCP\Tools\Multisite\ManageSite;
use InsationAI\GitHubMCP\Tools\Multisite\ManageNetworkUsers;
use InsationAI\GitHubMCP\Tools\Multisite\NetworkActivatePlugin;

/**
 * Map of OAuth scope → minimum WordPress capability used by the Abilities
 * permission_callback. Mirrors what the OAuth scope check enforces inside
 * AbstractTool::checkScopeAuthorization().
 */
const INSATIONAI_GHMCP_SCOPE_CAPABILITY_MAP = [
    'mcp:read'   => 'read',
    'mcp:write'  => 'edit_posts',
    'mcp:delete' => 'delete_posts',
    'mcp:admin'  => 'manage_options',
];

/**
 * Tool category for the Abilities API — used for grouping in admin UIs that
 * surface registered abilities.
 */
function insationai_ghmcp_ability_category_for(string $toolName): string
{
    if (str_starts_with($toolName, 'plugin_')) {
        return 'wordpress-plugins';
    }
    if (str_starts_with($toolName, 'theme_')) {
        return 'wordpress-themes';
    }
    if (str_starts_with($toolName, 'media_')) {
        return 'wordpress-media';
    }
    if (str_starts_with($toolName, 'execute_')) {
        return 'code-execution';
    }
    if (
        str_starts_with($toolName, 'list_users') ||
        str_starts_with($toolName, 'get_user') ||
        str_starts_with($toolName, 'create_user') ||
        str_starts_with($toolName, 'update_user') ||
        str_starts_with($toolName, 'delete_user') ||
        str_starts_with($toolName, 'list_roles') ||
        str_starts_with($toolName, 'manage_user_roles') ||
        str_starts_with($toolName, 'manage_capabilities')
    ) {
        return 'wordpress-users';
    }
    if (
        $toolName === 'list_comments' ||
        $toolName === 'get_comment' ||
        $toolName === 'create_comment' ||
        $toolName === 'update_comment' ||
        $toolName === 'delete_comment' ||
        $toolName === 'moderate_comment'
    ) {
        return 'wordpress-comments';
    }
    if (
        str_ends_with($toolName, '_option') ||
        $toolName === 'list_options' ||
        str_ends_with($toolName, '_transient') ||
        $toolName === 'manage_theme_mods'
    ) {
        return 'wordpress-options';
    }
    if (
        $toolName === 'list_menus' ||
        $toolName === 'get_menu' ||
        $toolName === 'manage_menu' ||
        $toolName === 'manage_menu_items' ||
        $toolName === 'assign_menu_location'
    ) {
        return 'wordpress-menus';
    }
    if (
        $toolName === 'list_sidebars' ||
        $toolName === 'list_widgets' ||
        $toolName === 'manage_widget' ||
        $toolName === 'manage_block_widgets'
    ) {
        return 'wordpress-widgets';
    }
    if (
        $toolName === 'list_patterns' ||
        $toolName === 'manage_pattern' ||
        $toolName === 'list_reusable_blocks'
    ) {
        return 'wordpress-patterns';
    }
    if (
        $toolName === 'get_customizer_settings' ||
        $toolName === 'update_customizer_setting' ||
        $toolName === 'export_customizer'
    ) {
        return 'wordpress-customizer';
    }
    if (
        $toolName === 'list_scheduled_events' ||
        $toolName === 'schedule_event' ||
        $toolName === 'unschedule_event' ||
        $toolName === 'run_event_now'
    ) {
        return 'wordpress-cron';
    }
    if (
        $toolName === 'list_rewrite_rules' ||
        $toolName === 'flush_rewrite_rules' ||
        $toolName === 'add_rewrite_rule'
    ) {
        return 'wordpress-rewrites';
    }
    if (
        $toolName === 'db_query' ||
        $toolName === 'db_table_info' ||
        $toolName === 'optimize_tables' ||
        $toolName === 'repair_tables' ||
        str_starts_with($toolName, 'cleanup_') ||
        $toolName === 'search_replace'
    ) {
        return 'wordpress-database';
    }
    if (
        $toolName === 'system_info' ||
        $toolName === 'site_health_check' ||
        str_starts_with($toolName, 'debug_log_') ||
        $toolName === 'list_hooks_on_action'
    ) {
        return 'wordpress-diagnostics';
    }
    if (
        $toolName === 'list_sites' ||
        $toolName === 'get_site' ||
        $toolName === 'manage_site' ||
        $toolName === 'manage_network_users' ||
        $toolName === 'network_activate_plugin'
    ) {
        return 'wordpress-multisite';
    }
    if (
        str_contains($toolName, 'term') ||
        str_contains($toolName, 'tax') ||
        str_starts_with($toolName, 'discover_taxonomies')
    ) {
        return 'wordpress-taxonomy';
    }
    return 'wordpress-content';
}

/**
 * Register all GitHubMCP tools as WordPress Abilities (WP 6.9+).
 *
 * No-op on WP < 6.9 (when wp_register_ability is undefined). The /insationai-github-mcp
 * HTTP endpoint continues to work in either case.
 */
function insationai_ghmcp_register_abilities(): void
{
    if (!function_exists('wp_register_ability')) {
        return;
    }

    // Sanity: don't register on a site that hasn't authorized GitHubMCP yet.
    if (class_exists('\InsationAI\GitHubMCP\Validator') && !\InsationAI\GitHubMCP\Validator::isAuthorized()) {
        return;
    }

    $wpService = new WordPressService();
    $validationService = new ValidationService();
    $logger = new WordPressLogger();
    $patchingService = new ContentPatchingService($wpService, $logger);

    $tools = \InsationAI\GitHubMCP\ToolRegistry::buildEnabledTools(
        $wpService,
        $validationService,
        $logger,
        $patchingService
    );


    foreach ($tools as $tool) {
        insationai_ghmcp_register_one_ability($tool);
    }
}

function insationai_ghmcp_register_one_ability(AbstractTool $tool): void
{
    $name = $tool->getName();
    $scope = $tool->getRequiredScope();
    $capability = INSATIONAI_GHMCP_SCOPE_CAPABILITY_MAP[$scope] ?? 'manage_options';
    $isDestructive = in_array($scope, ['mcp:write', 'mcp:delete', 'mcp:admin'], true);
    $isReadonly = $scope === 'mcp:read';

    wp_register_ability("insationai-wpmcp/{$name}", [
        'label'              => $name,
        'description'        => $tool->getDescription(),
        'category'           => insationai_ghmcp_ability_category_for($name),
        'input_schema'       => $tool->getInputSchema(),
        'output_schema'      => [
            'type' => 'object',
            'description' => 'Tool execution result. Shape varies per tool — see description.',
            'additionalProperties' => true,
        ],
        'execute_callback'   => static function ($input) use ($tool) {
            // The Abilities API runs in standard WP request context. The user
            // is whoever WP says — wp_get_current_user(). Build a minimal user
            // context so AbstractTool's scope check has something to look at.
            $current = wp_get_current_user();
            if ($current && $current->ID) {
                $tool->setUserContext([
                    'id' => (int) $current->ID,
                    'login' => (string) $current->user_login,
                    'username' => (string) $current->user_login,
                    'roles' => (array) $current->roles,
                    // Map: an authenticated WP user gets all scopes their
                    // capabilities cover. The capability check inside
                    // permission_callback already gated the call.
                    'scopes' => insationai_ghmcp_scopes_for_user($current),
                ]);
            }

            try {
                return $tool->execute(is_array($input) ? $input : []);
            } catch (\Throwable $e) {
                return new \WP_Error(
                    'insationai_ghmcp_tool_error',
                    $e->getMessage(),
                    ['status' => 400]
                );
            }
        },
        'permission_callback' => static function () use ($capability) {
            return current_user_can($capability);
        },
        'meta' => [
            'show_in_rest' => true,
            'mcp' => ['public' => true],
            'annotations' => [
                'readonly'    => $isReadonly,
                'destructive' => $isDestructive,
                'idempotent'  => false,
                'instructions' => 'Tool source: GitHubMCP. See ' . home_url('/wp-admin/admin.php?page=github-mcp-tools') . ' for token management.',
            ],
        ],
    ]);
}

function insationai_ghmcp_scopes_for_user(\WP_User $user): array
{
    $scopes = [];
    if (user_can($user, 'read')) {
        $scopes[] = 'mcp:read';
    }
    if (user_can($user, 'edit_posts')) {
        $scopes[] = 'mcp:write';
    }
    if (user_can($user, 'delete_posts')) {
        $scopes[] = 'mcp:delete';
    }
    if (user_can($user, 'manage_options')) {
        $scopes[] = 'mcp:admin';
    }
    return $scopes;
}

// WP 6.9+ requires abilities to be registered on the `wp_abilities_api_init`
// hook — registering earlier (e.g. on `init`) is rejected by core with a
// _doing_it_wrong() notice and the ability is NOT registered. We hook there
// when the Abilities API exists, and fall back to `init` priority 20 on older
// WordPress that predates it (where the function_exists('wp_register_ability')
// guard inside the function makes it a harmless no-op anyway). did_action()
// guards the rare case where this file loads after the hook already fired.
if (function_exists('wp_register_ability')) {
    if (did_action('wp_abilities_api_init')) {
        insationai_ghmcp_register_abilities();
    } else {
        add_action('wp_abilities_api_init', 'insationai_ghmcp_register_abilities', 20);
    }
} else {
    add_action('init', 'insationai_ghmcp_register_abilities', 20);
}
