# GitHubMCP

**Stable tag:** 1.0.10
**Requires WordPress:** 6.0
**Tested up to:** 6.7
**Requires PHP:** 8.2
**License:** GPL-2.0-or-later
**License URI:** https://www.gnu.org/licenses/gpl-2.0.html

**A comprehensive Model Context Protocol (MCP) server for WordPress.**

Exposes WordPress as a unified toolkit for AI assistants like Claude. Covers content, taxonomy, media, users, comments, options, menus, widgets, block patterns, the Customizer, cron, rewrites, the database, diagnostics, multisite, SEO, and import/export — all reachable from any MCP-compatible client via a single HTTP endpoint with OAuth 2.1 or bearer-token authentication.

## Features

- ✅ **~95 MCP tools** spanning the full WordPress admin surface (91 on single-site, 96 on multisite networks)
- ✅ **Tools tab** — enable or disable individual tools or whole categories from the admin
- ✅ **OAuth 2.1 Authentication** — enabled by default; bearer tokens still supported
- ✅ **WordPress Abilities API (WP 6.9+)** — every tool is dual-registered via `wp_register_ability()` so the official WP MCP Adapter sees them natively
- ✅ **Revisions Tab** — Settings → GitHubMCP → Revisions shows the full version history from `revisions.json`
- ✅ **Line-Based Content Fetching** — paginate large posts efficiently with line-based access
- ✅ **Content Patching** — sed-style search-replace for long posts
- ✅ **Plugin & Theme Management** — install, activate, update, edit files
- ✅ **Media Management** — upload, attach, set featured images, edit metadata
- ✅ **User Token Authentication** — simple API tokens tied to WordPress users
- ✅ **Role-Based Permissions** — every tool respects WordPress capability checks
- ✅ **Safe Mode** — opt-in flag that blocks destructive operations
- ✅ **Query Param Auth** — convenient `?t=token` authentication for clients that can't send custom headers
- 🔓 **No site-lock** — runs on any WordPress host

## Installation

### From a release zip

1. Download `insationai-github-mcp-1.0.0.zip`
2. WordPress Admin → Plugins → Add New → Upload Plugin → choose the zip → Install Now → Activate
3. Your first API token is created automatically. Check **Settings → GitHubMCP → API Tokens** to view it.

### From Source (Development)

1. Clone the repository or download the source code
2. Copy the `insationai-github-mcp` folder to `/wp-content/plugins/`
3. Run `composer install --no-dev` inside the plugin directory
4. Activate the plugin in WordPress Admin → Plugins
5. Your first API token is automatically created! Check Settings → GitHubMCP → API Tokens

### Automated Deployment (Optional)

For automated deployments, you can pre-configure the default token before activation:

```bash
# Set a pre-configured token (must be 64 hex characters)
wp option add instamcp_default_token "YOUR_64_CHAR_HEX_TOKEN_HERE"

# Activate the plugin
wp plugin activate insationai-github-mcp

# The option is automatically deleted after the token is created for security
```

## Quick Start

### Using Token Authentication (Recommended)

**Step 1: Get Your Token**
1. Go to WordPress Admin → Settings → GitHubMCP → API Tokens
2. Your default token is shown after activation (copy it!)
3. Or create a new token with a custom label and optional expiration

**Step 2: Connect**

```bash
# Method 1: Query parameter (all HTTP methods)
curl "https://your-site.com/insationai-github-mcp?t=YOUR_64_CHAR_TOKEN"

# Method 2: Authorization header (all HTTP methods)
curl -H "Authorization: Bearer YOUR_64_CHAR_TOKEN" https://your-site.com/insationai-github-mcp
```

**Step 3: Connect a client**

Setup guides for 13+ clients are in **[docs/CLIENTS.md](docs/CLIENTS.md)** — Claude
Desktop, Claude Code, Claude.ai, Cursor, Windsurf, Cline, Roo Code, GitHub
Copilot, Zed, Gemini CLI, OpenAI Codex CLI, ChatGPT, Continue.dev.

Quick example for Claude Desktop — `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "wordpress": {
      "command": "npx",
      "args": [
        "-y",
        "mcp-remote",
        "https://your-site.com/insationai-github-mcp?t=YOUR_TOKEN_HERE"
      ]
    }
  }
}
```

## Endpoint

The main MCP endpoint for all requests:

```
https://your-site.com/insationai-github-mcp
https://your-site.com/insationai-github-mcp?t=YOUR_TOKEN  (with query param auth)
```

## Available MCP Tools

GitHubMCP provides 26 tools organized into 5 categories:

### Content Management (9 tools)
- `discover_content_types` - Discover available post types
- `list_content` - List posts/pages/custom post types
- `get_content` - Get content by ID with line-based fetching for large posts
- `get_content_by_slug` - Get content by slug
- `find_content_by_url` - Find content by URL
- `create_content` - Create new posts/pages/CPT
- `update_content` - Update existing content
- `patch_content` - Efficiently edit content with sed-style search-replace operations
- `delete_content` - Delete content (soft/permanent)

**Line-Based Content Fetching:**
- Get `total_lines` metadata to check post size before fetching
- Fetch content in chunks using `start_line` and `line_count` parameters
- Efficient handling of very large posts (avoid memory issues)
- Response includes `has_more` flag for pagination

### Taxonomy Management (9 tools)
- `discover_taxonomies` - List available taxonomies
- `get_taxonomy` - Get taxonomy details
- `list_terms` - List terms in a taxonomy
- `get_term` - Get term by ID
- `create_term` - Create new term
- `update_term` - Update existing term
- `delete_term` - Delete term
- `assign_terms_to_content` - Assign terms to posts/pages
- `get_content_terms` - Get all terms assigned to content

### Plugin Management (3 tools)
- `plugin_info` - Search, list, and get plugin details
- `plugin_operations` - Install, activate, deactivate, update, delete plugins
- `plugin_files` - Read and write plugin files

### Theme Management (3 tools)
- `theme_info` - Search, list, and get theme details
- `theme_operations` - Install, activate, update, delete themes
- `theme_files` - Read and write theme files

### Media Management (3 tools)
- `media_upload` - Upload images from URL or base64 data
- `media_attach` - Attach media to posts, set/remove featured images
- `media_metadata` - Get and update media metadata (alt text, captions, descriptions)

### Optional Tools (off by default)

#### `execute_php` — arbitrary PHP execution

The most powerful and most dangerous tool in GitHubMCP. Lets the connected
agent run any PHP code in the full WordPress context (`$wpdb`, all WP APIs,
loaded plugins).

- **Disabled by default.** Enable in **Settings → GitHubMCP → General → Execute PHP**, or via WP-CLI: `wp option update insationai_ghmcp_execute_php_enabled 1`.
- **Scope-gated** to `mcp:admin` and **capability-gated** to `manage_options`.
- **Hard 30-second time limit** per call.
- Returns `return_value`, captured `output`, captured warnings/notices, and `execution_time_ms`.

> **Use with care.** Anyone holding an `mcp:admin` token can read/write any
> file the web user can touch and run any DB query. Use only on staging or
> development environments, or when you fully trust the connecting client.

When disabled, the tool is *not advertised* in the MCP tool list — agents
won't know it exists. When enabled, it appears alongside the standard 26 tools.

## WordPress Abilities API (WP 6.9+)

In addition to the custom `/insationai-github-mcp` HTTP endpoint, every GitHubMCP tool is
dual-registered via the official WordPress Abilities API
(`wp_register_ability()`, introduced in WP 6.9). This means:

- The official **WordPress MCP Adapter** sees GitHubMCP's tools without any
  extra configuration.
- Other plugins that consume `wp_get_abilities()` can introspect, list, and
  invoke GitHubMCP tools through the WP-native interface.
- The Abilities permission callback enforces WP capabilities (`read`,
  `edit_posts`, `delete_posts`, `manage_options`) mapped to our OAuth scopes
  (`mcp:read` / `:write` / `:delete` / `:admin`).

The custom `/insationai-github-mcp` HTTP endpoint remains the canonical transport for
remote clients (Claude Desktop, Cursor, etc.) using bearer-token auth — the
Abilities API registration is purely additive.

On WP < 6.9, the registration is a no-op and GitHubMCP works exactly as
before.

**Media Management Features:**
- Upload from external URLs or base64-encoded content
- Set title, alt text, caption, and description
- Attach media to posts/pages
- Set and remove featured images
- Update metadata for existing attachments
- Get full attachment info including dimensions, file sizes, and available image sizes
- Access EXIF data for images

## Configuration

### API Tokens (Primary Authentication)

**Create Token:**
1. Navigate to Settings → GitHubMCP → API Tokens
2. Select user (default: current user)
3. Enter a descriptive label (e.g., "Production Server", "Claude Desktop")
4. Optionally set expiration in days (leave empty for no expiration)
5. Click "Create Token"
6. **Copy the token immediately** - it's only shown once!

**Manage Tokens:**
- View all tokens with user, label, created/expires/last used dates
- Revoke tokens at any time
- Admins can create/revoke tokens for any user

**Token Features:**
- 64-character hex tokens (SHA256 hashed in database)
- Per-user authentication (inherits WordPress role permissions)
- Optional expiration dates
- Last used tracking
- Auto-cleanup of expired tokens

### General Settings
- **Endpoint Slug**: Customize the URL slug (default: `insationai-github-mcp`)
- **Safe Mode**: Prevent delete operations for added protection

## Permissions & Security

### WordPress Role to Permission Mapping

Tokens inherit permissions from the associated WordPress user's role:

| WordPress Role | Permission Scopes | Example Capabilities |
|---------------|------------------|---------------------|
| Administrator | `mcp:admin`, `mcp:delete`, `mcp:write`, `mcp:read` | Full access to all content |
| Editor | `mcp:delete`, `mcp:write`, `mcp:read` | Edit/publish any content |
| Author | `mcp:write`, `mcp:read` | Edit/publish own content only |
| Contributor | `mcp:read` | Create drafts only |
| Subscriber | `mcp:read` | Read-only access |

### Dual Permission System

GitHubMCP enforces **two layers of permissions**:

1. **Permission Scopes** - Broad permission categories (read, write, delete, admin)
2. **WordPress Capabilities** - Fine-grained permissions (edit_posts, edit_others_posts, publish_posts, etc.)

**Example:** An Author role user can create and publish content (`mcp:write` scope), but can only edit their **own** posts due to WordPress's `edit_others_posts` capability check.

After successful authentication, `wp_set_current_user()` is called to ensure all WordPress capability checks are enforced.

## Authentication

### User Token Authentication

GitHubMCP uses simple, secure API tokens tied to WordPress users:

- **Easy to create** - Manage tokens via admin UI
- **Flexible authentication** - Use query parameter (`?t=token`) or Authorization header
- **Per-user permissions** - Inherits WordPress role and capabilities
- **Optional expiration** - Set TTL for enhanced security
- **Session tracking** - See when tokens were last used

**Authentication is always required** - no unauthenticated access mode.

**Security:** After successful authentication, `wp_set_current_user()` is called with the authenticated user ID, ensuring all WordPress capability checks (edit_posts, publish_posts, delete_posts, etc.) are properly enforced.

**OAuth 2.1:** Advanced OAuth authentication is currently in development and will be available in a future release.

## Database Tables

The plugin creates the following table on activation:

- `wp_insationai_ghmcp_user_tokens` - Stores user API tokens with SHA256 hashing

## Development

### Requirements
- PHP 8.2+
- WordPress 6.0+
- Composer

### Project Structure
```
insationai-github-mcp/
├── insationai-github-mcp.php           # Main plugin file
├── src/                    # MCP tools and services
├── includes/
│   ├── endpoints/          # MCP HTTP endpoint
│   ├── oauth/              # OAuth authorization/token flows
│   └── well-known/         # OAuth discovery endpoints
├── admin/                  # Admin settings UI
├── install/                # Activation hooks
├── build.sh                # Build script for releases
└── .github/workflows/      # GitHub Actions for automated releases
```

### Building Releases

```bash
# Build production-ready zip file locally
composer build

# Output: builds/insationai-github-mcp-{version}.zip
```

**Automated Releases:**
- Create and push a version tag to trigger automated build and release
- GitHub Actions builds the zip and attaches it to the release
- Example: `git tag v1.0.1 && git push origin v1.0.1`

## Automatic Plugin Updates

GitHubMCP includes a built-in update system that allows users to receive plugin updates without hosting on WordPress.org.

**How it works:**
1. When you push a version tag (e.g., `v1.0.1`), GitHub Actions automatically builds the plugin
2. The workflow generates an `update-info.json` file with version details and changelog from git commits
3. Both the plugin zip and update metadata are uploaded to DigitalOcean Spaces
4. Users see update notifications in WordPress admin just like WordPress.org plugins
5. One-click "Update Now" button installs the new version

**For users:**
- WordPress checks for updates every 12 hours automatically
- Manual check via "Check for Updates" link in plugin actions
- View changelog in "View Details" popup before updating
- Updates download from: `https://artifacts-iwp.ams3.digitaloceanspaces.com/insationai-github-mcp/`
- **Seamless upgrades:** Existing installations automatically migrate without disruption

**For developers:**
1. Update version in `insationai-github-mcp.php` header and `INSATIONAI_GHMCP_VERSION` constant
2. Commit changes: `git commit -m "Bump version to 1.0.1"`
3. Create and push tag: `git tag v1.0.1 && git push origin v1.0.1`
4. GitHub Actions handles the rest automatically

## License

GitHubMCP is dual-licensed to serve both the open-source community and enterprise organizations:

### GPL-2.0 (Open Source)

For community use, personal projects, and GPL-compatible distributions, GitHubMCP is licensed under the GNU General Public License v2.0.

**This license is ideal if you:**
- Use GitHubMCP on your own WordPress sites
- Modify the software for internal use
- Accept the software "as-is" without warranty
- Are comfortable with GPL's copyleft requirements

See the full license text at: https://www.gnu.org/licenses/gpl-2.0.html

### Commercial License

For enterprise deployments, hosting companies, OEM/resellers, and organizations requiring legal protections, a commercial license is available.

**This license provides:**
- ✅ **Legal warranty** and indemnification coverage
- ✅ **Service Level Agreements** (SLA) and priority support
- ✅ **Redistribution rights** for hosting, SaaS, and OEM use cases
- ✅ **White-labeling** and rebranding permissions
- ✅ **Exemption from GPL copyleft** requirements

**Commercial license is required for:**
- Hosting companies offering GitHubMCP as a managed service
- SaaS platforms incorporating GitHubMCP
- OEM or reseller distribution
- Enterprise deployments requiring warranty and indemnification
- Any use case requiring exemption from GPL obligations

### Feature Parity

**Both licenses provide access to the identical codebase.** There are no "pro" or "enterprise" feature locks. The commercial license is purely for legal protections, business rights (redistribution, white-labeling), service guarantees (SLA, priority support), and licensing compliance (copyleft exemption).

### Commercial Licensing

For pricing, terms, and volume licensing inquiries:
- **Email:** sales@instawp.com
- **Website:** https://instawp.com

For detailed licensing information, see [LICENSE.md](LICENSE.md).

## Credits

Developed by [InsationAI](https://insationai.com/)
