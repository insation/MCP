<?php
/**
 * EWD Elementor Importer - one-time use
 * Trigger: /wp-admin/?ewd_import=PAGE_ID
 */
if (!defined('ABSPATH')) exit;

add_action('admin_init', function() {
    if (!current_user_can('manage_options')) return;
    if (!isset($_GET['ewd_import'])) return;

    $page_id = intval($_GET['ewd_import']);
    if (!$page_id) wp_die('No page ID');

    $data_file = WP_CONTENT_DIR . '/uploads/ewd-data/' . $page_id . '.json';
    if (!file_exists($data_file)) {
        wp_die('Data file not found: ' . esc_html($data_file));
    }

    $data = file_get_contents($data_file);
    $decoded = json_decode($data, true);
    if (!is_array($decoded)) {
        wp_die('Invalid JSON: ' . json_last_error_msg());
    }

    update_post_meta($page_id, '_elementor_data', wp_slash($data));
    update_post_meta($page_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page_id, '_elementor_template_type', 'wp-page');
    update_post_meta($page_id, '_wp_page_template', 'elementor_canvas');
    delete_post_meta($page_id, '_elementor_css');

    wp_die('OK: imported page ' . $page_id . ', size=' . strlen($data));
});
