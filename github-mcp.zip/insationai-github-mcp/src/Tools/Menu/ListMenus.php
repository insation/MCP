<?php
/**
 * List Menus Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Menu;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class ListMenus extends AbstractTool
{
    public function getName(): string
    {
        return 'list_menus';
    }

    public function getDescription(): string
    {
        return 'List all navigation menus on the site with their IDs, names, item counts, and assigned theme locations.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $menus = wp_get_nav_menus();
        $locations = get_nav_menu_locations();
        $location_by_menu = [];
        foreach ($locations as $loc => $menu_id) {
            $location_by_menu[(int) $menu_id][] = $loc;
        }

        $items = array_map(function (\WP_Term $menu) use ($location_by_menu) {
            return [
                'id'          => $menu->term_id,
                'name'        => $menu->name,
                'slug'        => $menu->slug,
                'item_count'  => (int) $menu->count,
                'locations'   => $location_by_menu[$menu->term_id] ?? [],
            ];
        }, $menus);

        return $this->success([
            'count' => count($items),
            'items' => array_values($items),
            'registered_locations' => array_keys(get_registered_nav_menus()),
        ]);
    }
}
