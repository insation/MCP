<?php
/**
 * Export Content Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\ExportImport;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ExportContent extends AbstractTool
{
    public function getName(): string
    {
        return 'export_content';
    }

    public function getDescription(): string
    {
        return 'Generate a WXR (WordPress eXtended RSS) export of content. Filter by post type, status, author, and date range. Returns the XML as a string for small exports, or writes to the uploads directory and returns a path for large ones.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'content_type' => [
                'optional',
                'string',
                'description' => 'Post type to export. Use "all" for all post types (default).'
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Post status filter (e.g. publish, draft, any). Default: any.'
            ],
            'author_id' => [
                'optional',
                'int',
                'description' => 'Limit to one author\'s posts.'
            ],
            'start_date' => [
                'optional',
                'string',
                'description' => 'YYYY-MM-DD lower bound (inclusive).'
            ],
            'end_date' => [
                'optional',
                'string',
                'description' => 'YYYY-MM-DD upper bound (inclusive).'
            ],
            'return_mode' => [
                'optional',
                'string',
                'description' => 'inline (return XML in the response) or file (write to uploads dir and return path). Default: file.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!function_exists('export_wp')) {
            require_once ABSPATH . 'wp-admin/includes/export.php';
        }

        $args = [
            'content' => $parameters['content_type'] ?? 'all',
            'status'  => $parameters['status']       ?? '',
        ];
        if (!empty($parameters['author_id'])) {
            $args['author'] = (int) $parameters['author_id'];
        }
        if (!empty($parameters['start_date'])) {
            $args['start_date'] = $parameters['start_date'];
        }
        if (!empty($parameters['end_date'])) {
            $args['end_date'] = $parameters['end_date'];
        }

        // export_wp() echoes to stdout. Buffer and capture.
        ob_start();
        try {
            export_wp($args);
        } catch (\Throwable $e) {
            ob_end_clean();
            throw ToolException::wordpressError('Export failed: ' . $e->getMessage());
        }
        $xml = ob_get_clean();

        if (!is_string($xml) || $xml === '') {
            throw ToolException::wordpressError('Export produced no output.');
        }

        $mode = $parameters['return_mode'] ?? 'file';

        if ($mode === 'inline') {
            return $this->success([
                'mode'    => 'inline',
                'bytes'   => strlen($xml),
                'content' => $xml,
            ], 'Export complete.');
        }

        // file mode
        $upload = wp_upload_dir();
        if (!empty($upload['error'])) {
            throw ToolException::wordpressError('Could not resolve uploads directory: ' . $upload['error']);
        }
        $dir = trailingslashit($upload['basedir']) . 'insationai-wpmcp-exports';
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }
        $filename = 'export-' . gmdate('Ymd-His') . '-' . wp_generate_password(8, false) . '.xml';
        $path = $dir . '/' . $filename;
        $written = file_put_contents($path, $xml);
        if ($written === false) {
            throw ToolException::wordpressError("Failed to write export to {$path}");
        }

        $url = trailingslashit($upload['baseurl']) . 'insationai-wpmcp-exports/' . $filename;

        return $this->success([
            'mode'  => 'file',
            'path'  => $path,
            'url'   => $url,
            'bytes' => (int) $written,
        ], 'Export written.');
    }
}
