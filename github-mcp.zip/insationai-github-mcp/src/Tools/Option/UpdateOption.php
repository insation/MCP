<?php
/**
 * Update Option Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Option;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class UpdateOption extends AbstractTool
{
    private const BLOCKED = [
        'secret', 'auth_key', 'auth_salt',
        'logged_in_key', 'logged_in_salt',
        'nonce_key', 'nonce_salt',
        'secure_auth_key', 'secure_auth_salt',
    ];

    public function getName(): string
    {
        return 'update_option';
    }

    public function getDescription(): string
    {
        return 'Create or update a value in wp_options. Pass JSON-encoded value via `value_json` for arrays/objects, or `value` for scalar strings. Sensitive auth options are blocked. Requires admin scope because options can affect site-wide behavior.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'name' => [
                'required',
                'string',
                ['notEmpty' => true],
            ],
            'value' => [
                'optional',
                'string',
                'description' => 'Scalar string value. Use value_json for arrays/objects.'
            ],
            'value_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded value (decoded before storing). Takes precedence over `value` if both are supplied.'
            ],
            'autoload' => [
                'optional',
                'bool',
                'description' => 'Whether to autoload on page load. Default: true for new options.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $name = $parameters['name'];

        foreach (self::BLOCKED as $blocked) {
            if (stripos($name, $blocked) !== false) {
                throw ToolException::insufficientPermissions(
                    "Option '{$name}' is blocked: contains sensitive auth material."
                );
            }
        }

        if (isset($parameters['value_json'])) {
            $decoded = json_decode($parameters['value_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in value_json: ' . json_last_error_msg());
            }
            $value = $decoded;
        } elseif (isset($parameters['value'])) {
            $value = $parameters['value'];
        } else {
            throw ToolException::wordpressError("Must supply either 'value' or 'value_json'.");
        }

        $autoload = $parameters['autoload'] ?? null;

        if (get_option($name, '__INSATIONAI_GHMCP_MISSING__') === '__INSATIONAI_GHMCP_MISSING__') {
            // New option
            $result = add_option($name, $value, '', $autoload === null ? 'yes' : ($autoload ? 'yes' : 'no'));
            $action = 'created';
        } else {
            $result = update_option($name, $value, $autoload);
            $action = 'updated';
        }

        if (!$result && $action === 'updated') {
            // update_option returns false if value unchanged — not an error
            return $this->success([
                'name'    => $name,
                'changed' => false,
            ], 'Option unchanged (same value already set).');
        }

        if (!$result) {
            throw ToolException::wordpressError("Failed to {$action} option '{$name}'.");
        }

        return $this->success([
            'name'    => $name,
            'action'  => $action,
            'changed' => true,
        ], "Option {$action}.");
    }
}
