<?php
/**
 * Set Transient Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Option;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class SetTransient extends AbstractTool
{
    public function getName(): string
    {
        return 'set_transient';
    }

    public function getDescription(): string
    {
        return 'Set a transient (short-lived cached value). Pass JSON-encoded values via value_json for arrays/objects. expiration is in seconds; 0 means no expiration (until manually deleted).';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'name' => ['required', 'string', ['notEmpty' => true]],
            'value' => ['optional', 'string'],
            'value_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded value. Takes precedence over `value`.'
            ],
            'expiration' => [
                'optional',
                'int',
                ['min' => 0],
                'description' => 'Seconds until expiration. 0 = no expiration. Default 3600 (1 hour).'
            ],
            'site' => [
                'optional',
                'bool',
                'description' => 'Set as site (network) transient.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $name = $parameters['name'];
        $expiration = isset($parameters['expiration']) ? (int) $parameters['expiration'] : 3600;
        $isSite = !empty($parameters['site']);

        if (isset($parameters['value_json'])) {
            $value = json_decode($parameters['value_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in value_json: ' . json_last_error_msg());
            }
        } elseif (isset($parameters['value'])) {
            $value = $parameters['value'];
        } else {
            throw ToolException::wordpressError("Must supply 'value' or 'value_json'.");
        }

        $ok = $isSite
            ? set_site_transient($name, $value, $expiration)
            : set_transient($name, $value, $expiration);

        if (!$ok) {
            throw ToolException::wordpressError("Failed to set transient '{$name}'.");
        }

        return $this->success([
            'name'       => $name,
            'site'       => $isSite,
            'expiration' => $expiration,
        ], 'Transient set.');
    }
}
