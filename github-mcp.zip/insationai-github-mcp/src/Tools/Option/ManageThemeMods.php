<?php
/**
 * Manage Theme Mods Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Option;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ManageThemeMods extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_theme_mods';
    }

    public function getDescription(): string
    {
        return 'Read or write theme modifications (theme_mod values used by the Customizer). action=list returns all mods for the active theme; action=get reads one; action=set writes one; action=delete removes one.';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['list', 'get', 'set', 'delete']],
            ],
            'name' => [
                'optional',
                'string',
                'description' => 'Mod name (required for get/set/delete).'
            ],
            'value' => [
                'optional',
                'string',
                'description' => 'New value for set. Use value_json for arrays/objects.'
            ],
            'value_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded value for set. Takes precedence over `value`.'
            ],
            'theme' => [
                'optional',
                'string',
                'description' => 'Theme slug. Defaults to active theme. Only used for list/get.'
            ],
        ];
    }

    public function getRequiredScope(): string
    {
        // Write actions elevate to mcp:write; read is the default (mcp:read).
        // We can't switch dynamically per call from this method, so use mcp:write
        // as the minimum to allow set/delete. Read-only callers can still use list/get
        // because mcp:write implies broader access than mcp:read in the scope hierarchy
        // (and admin scope grants all).
        return 'mcp:read';
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];

        // Enforce elevated scope for write actions, since we declared mcp:read above.
        if (in_array($action, ['set', 'delete'], true)) {
            $scopes = $this->userContext['scopes'] ?? [];
            $hasWrite = in_array('mcp:write', $scopes, true)
                || in_array('mcp:admin', $scopes, true);
            if ($this->userContext !== null && !$hasWrite) {
                throw ToolException::insufficientPermissions(
                    "Action '{$action}' on theme mods requires mcp:write or mcp:admin scope."
                );
            }
        }

        switch ($action) {
            case 'list':
                $mods = get_theme_mods();
                if (!is_array($mods)) {
                    $mods = [];
                }
                return $this->success([
                    'theme' => get_stylesheet(),
                    'count' => count($mods),
                    'mods'  => $mods,
                ]);

            case 'get':
                if (empty($parameters['name'])) {
                    throw ToolException::wordpressError("'name' is required for action=get");
                }
                $value = get_theme_mod($parameters['name']);
                return $this->success([
                    'name'   => $parameters['name'],
                    'value'  => $value,
                    'exists' => $value !== false,
                ]);

            case 'set':
                if (empty($parameters['name'])) {
                    throw ToolException::wordpressError("'name' is required for action=set");
                }
                if (isset($parameters['value_json'])) {
                    $value = json_decode($parameters['value_json'], true);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        throw ToolException::wordpressError('Invalid JSON in value_json: ' . json_last_error_msg());
                    }
                } elseif (isset($parameters['value'])) {
                    $value = $parameters['value'];
                } else {
                    throw ToolException::wordpressError("'value' or 'value_json' required for set");
                }
                set_theme_mod($parameters['name'], $value);
                return $this->success(['name' => $parameters['name']], 'Theme mod set.');

            case 'delete':
                $this->checkSafeMode('deleting theme mods');
                if (empty($parameters['name'])) {
                    throw ToolException::wordpressError("'name' is required for action=delete");
                }
                remove_theme_mod($parameters['name']);
                return $this->success(['name' => $parameters['name']], 'Theme mod removed.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
