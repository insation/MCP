<?php
/**
 * Flush Rewrite Rules Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Rewrite;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class FlushRewriteRules extends AbstractTool
{
    public function getName(): string
    {
        return 'flush_rewrite_rules';
    }

    public function getDescription(): string
    {
        return 'Flush WordPress rewrite rules and regenerate them from registered post types, taxonomies, and custom rules. Solves the "404 on a custom URL after registering a CPT" problem.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'hard' => [
                'optional',
                'bool',
                'description' => 'When true, also rewrite the .htaccess file (default false — only regenerate WP-level rules).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $hard = !empty($parameters['hard']);
        flush_rewrite_rules($hard);

        $rules = get_option('rewrite_rules');
        $count = is_array($rules) ? count($rules) : 0;

        return $this->success([
            'hard_flush' => $hard,
            'rules_now'  => $count,
        ], 'Rewrite rules flushed.');
    }
}
