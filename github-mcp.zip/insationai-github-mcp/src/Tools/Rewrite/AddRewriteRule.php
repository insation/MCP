<?php
/**
 * Add Rewrite Rule Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Rewrite;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class AddRewriteRule extends AbstractTool
{
    public function getName(): string
    {
        return 'add_rewrite_rule';
    }

    public function getDescription(): string
    {
        return 'Register a new WordPress rewrite rule and immediately flush the rules so it takes effect. Note: rules added this way persist only via the flush — to keep them across restarts, a plugin or theme also needs to call add_rewrite_rule() on init.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'pattern' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Regex pattern (no leading slash, no trailing $).'
            ],
            'query' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Internal target query string (e.g. "index.php?my_var=$matches[1]").'
            ],
            'position' => [
                'optional',
                'string',
                ['in' => ['top', 'bottom']],
                'description' => 'Where to insert in the rule list. Default: top.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $pattern = $parameters['pattern'];
        $query = $parameters['query'];
        $position = $parameters['position'] ?? 'top';

        add_rewrite_rule($pattern, $query, $position);
        flush_rewrite_rules(false);

        $rules = get_option('rewrite_rules');
        $exists = is_array($rules) && isset($rules[$pattern]);

        return $this->success([
            'pattern'  => $pattern,
            'query'    => $query,
            'position' => $position,
            'active'   => $exists,
        ], $exists ? 'Rule added and flushed.' : 'Rule registered, but did not survive the flush — typically means it needs to be re-registered on every request.');
    }
}
