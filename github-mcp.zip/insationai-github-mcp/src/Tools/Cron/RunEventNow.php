<?php
/**
 * Run Event Now Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Cron;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class RunEventNow extends AbstractTool
{
    public function getName(): string
    {
        return 'run_event_now';
    }

    public function getDescription(): string
    {
        return 'Force-run a scheduled cron event immediately by firing its hook in this request. Useful for debugging stuck cron events or triggering one-off jobs on demand. The original schedule entry is preserved unless `unschedule_after` is true.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'hook' => ['required', 'string', ['notEmpty' => true]],
            'args_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded args to pass to the hook. Default: no args.'
            ],
            'unschedule_after' => [
                'optional',
                'bool',
                'description' => 'When true, also unschedule the next occurrence of this hook+args after running. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $hook = $parameters['hook'];

        $args = [];
        if (isset($parameters['args_json'])) {
            $decoded = json_decode($parameters['args_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in args_json: ' . json_last_error_msg());
            }
            if (!is_array($decoded)) {
                throw ToolException::wordpressError('args_json must decode to an array.');
            }
            $args = $decoded;
        }

        $startedAt = microtime(true);

        try {
            // Fire the hook with arguments
            do_action_ref_array($hook, $args);
        } catch (\Throwable $e) {
            throw ToolException::wordpressError("Hook handler threw an exception: {$e->getMessage()}");
        }

        $elapsedMs = (int) ((microtime(true) - $startedAt) * 1000);

        $unscheduled = null;
        if (!empty($parameters['unschedule_after'])) {
            $next = wp_next_scheduled($hook, $args);
            if ($next) {
                $unscheduled = (bool) wp_unschedule_event($next, $hook, $args);
            } else {
                $unscheduled = false;
            }
        }

        return $this->success([
            'hook'              => $hook,
            'args'              => $args,
            'elapsed_ms'        => $elapsedMs,
            'unscheduled_after' => $unscheduled,
        ], "Hook '{$hook}' executed.");
    }
}
