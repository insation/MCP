<?php
/**
 * Unschedule Event Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Cron;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class UnscheduleEvent extends AbstractTool
{
    public function getName(): string
    {
        return 'unschedule_event';
    }

    public function getDescription(): string
    {
        return 'Unschedule cron events. Use action=clear_hook to drop every scheduled occurrence of a hook (regardless of args). Use action=clear_one to drop a specific occurrence at a specific timestamp with specific args.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['clear_hook', 'clear_one']],
            ],
            'hook' => ['required', 'string', ['notEmpty' => true]],
            'timestamp' => [
                'optional',
                'int',
                'description' => 'Required for action=clear_one.'
            ],
            'args_json' => [
                'optional',
                'string',
                'description' => 'For action=clear_one: JSON args matching the event.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $hook = $parameters['hook'];

        if ($action === 'clear_hook') {
            $count = wp_unschedule_hook($hook);
            return $this->success([
                'hook'    => $hook,
                'cleared' => is_int($count) ? $count : null,
            ], 'Hook cleared.');
        }

        // clear_one
        if (empty($parameters['timestamp'])) {
            throw ToolException::wordpressError("'timestamp' is required for action=clear_one");
        }
        $args = [];
        if (isset($parameters['args_json'])) {
            $decoded = json_decode($parameters['args_json'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ToolException::wordpressError('Invalid JSON in args_json: ' . json_last_error_msg());
            }
            if (!is_array($decoded)) {
                throw ToolException::wordpressError('args_json must decode to an array.');
            }
            $args = $decoded;
        }

        $result = wp_unschedule_event((int) $parameters['timestamp'], $hook, $args);
        if (is_wp_error($result) || $result === false) {
            throw ToolException::wordpressError(
                'Failed to unschedule (no matching event found, or error). Use list_scheduled_events to find exact signatures.'
            );
        }

        return $this->success([
            'hook'      => $hook,
            'timestamp' => (int) $parameters['timestamp'],
        ], 'Event unscheduled.');
    }
}
