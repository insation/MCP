<?php
/**
 * Get Customizer Settings Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Customizer;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class GetCustomizerSettings extends AbstractTool
{
    /**
     * Stable WordPress core customizer setting names that map to wp_options
     * or to theme_mod values. These are exposed even when WP_Customize_Manager
     * cannot be bootstrapped at this point in the request lifecycle.
     */
    private const CORE_SETTINGS = [
        'blogname'         => ['source' => 'option'],
        'blogdescription'  => ['source' => 'option'],
        'site_icon'        => ['source' => 'option'],
        'show_on_front'    => ['source' => 'option'],
        'page_on_front'    => ['source' => 'option'],
        'page_for_posts'   => ['source' => 'option'],
        'background_color' => ['source' => 'theme_mod'],
        'background_image' => ['source' => 'theme_mod'],
        'header_image'     => ['source' => 'theme_mod'],
        'header_textcolor' => ['source' => 'theme_mod'],
        'custom_logo'      => ['source' => 'theme_mod'],
        'custom_css'       => ['source' => 'option', 'option_name' => 'wp_custom_css'],
    ];

    public function getName(): string
    {
        return 'get_customizer_settings';
    }

    public function getDescription(): string
    {
        return 'Read WordPress Customizer settings for the active theme: blog name, tagline, site icon, front-page mode, header/background, custom logo, and custom CSS. Also returns all theme_mods.';
    }

    public function getSchema(): array
    {
        return [
            'include_theme_mods' => [
                'optional',
                'bool',
                'description' => 'Include the full theme_mods array. Default true.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $includeMods = $parameters['include_theme_mods'] ?? true;

        $values = [];
        foreach (self::CORE_SETTINGS as $name => $meta) {
            if ($meta['source'] === 'option') {
                $optionName = $meta['option_name'] ?? $name;
                $values[$name] = get_option($optionName, null);
            } else {
                $values[$name] = get_theme_mod($name, null);
            }
        }

        // Custom CSS is stored as a custom post, not a regular option. Pull
        // the real value from wp_get_custom_css if available.
        if (function_exists('wp_get_custom_css')) {
            $values['custom_css'] = wp_get_custom_css();
        }

        $result = [
            'theme'    => get_stylesheet(),
            'settings' => $values,
        ];

        if ($includeMods) {
            $mods = get_theme_mods();
            $result['theme_mods'] = is_array($mods) ? $mods : [];
        }

        return $this->success($result);
    }
}
