<?php
/**
 * Clear Audit Log Tool
 *
 * @package GitHubMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Audit;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class ClearAuditLog extends AbstractTool
{
    public function getName(): string
    {
        return 'clear_audit_log';
    }

    public function getDescription(): string
    {
        return 'Permanently clear the GitHubMCP audit log. The clear action itself is recorded as the first new entry so the log cannot be silently wiped. Admin scope and safe-mode-compliant.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->checkSafeMode('clearing the audit log');

        $before = get_option('insationai_ghmcp_audit_log', []);
        $beforeCount = is_array($before) ? count($before) : 0;

        // Replace with a single "log cleared" entry so the operation itself is audited.
        $marker = [[
            't'           => time(),
            'tool'        => 'clear_audit_log',
            'scope'       => 'mcp:admin',
            'user_id'     => (int) ($this->userContext['user_id'] ?? $this->userContext['id'] ?? 0),
            'user'        => $this->userContext['login'] ?? $this->userContext['username'] ?? 'anonymous',
            'auth'        => $this->userContext['auth_method'] ?? null,
            'param_keys'  => [],
            'outcome'     => 'success',
            'duration_ms' => 0,
            'remote_ip'   => $_SERVER['REMOTE_ADDR'] ?? null,
            'note'        => "Cleared {$beforeCount} previous audit entries.",
        ]];
        update_option('insationai_ghmcp_audit_log', $marker, false);

        return $this->success([
            'cleared_entries' => $beforeCount,
        ], 'Audit log cleared.');
    }
}
