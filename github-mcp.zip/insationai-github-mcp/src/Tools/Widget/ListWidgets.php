<?php
/**
 * List Widgets Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Widget;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class ListWidgets extends AbstractTool
{
    public function getName(): string
    {
        return 'list_widgets';
    }

    public function getDescription(): string
    {
        return 'List widget instances across the site or within a specific sidebar. Returns each widget\'s ID, type (base ID), sidebar placement, and stored settings.';
    }

    public function getSchema(): array
    {
        return [
            'sidebar' => [
                'optional',
                'string',
                'description' => 'Limit to widgets in this sidebar ID.'
            ],
            'include_registered_types' => [
                'optional',
                'bool',
                'description' => 'Also include a list of every widget type registered on the site. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $sidebars_widgets = wp_get_sidebars_widgets();
        $filter = $parameters['sidebar'] ?? null;

        $instances = [];
        foreach ($sidebars_widgets as $sidebar_id => $widget_ids) {
            if ($sidebar_id === 'array_version') {
                continue;
            }
            if ($filter && $sidebar_id !== $filter) {
                continue;
            }
            if (!is_array($widget_ids)) {
                continue;
            }
            foreach ($widget_ids as $widget_id) {
                // Widget ID is like "text-3", "calendar-1"
                $parts = explode('-', $widget_id);
                $number = (int) array_pop($parts);
                $base   = implode('-', $parts);

                $settings = get_option("widget_{$base}");
                $instance = is_array($settings) && isset($settings[$number]) ? $settings[$number] : null;

                $instances[] = [
                    'id'         => $widget_id,
                    'base_id'    => $base,
                    'number'     => $number,
                    'sidebar_id' => $sidebar_id,
                    'settings'   => $instance,
                ];
            }
        }

        $result = [
            'count' => count($instances),
            'items' => $instances,
        ];

        if (!empty($parameters['include_registered_types'])) {
            global $wp_widget_factory;
            $types = [];
            if ($wp_widget_factory && isset($wp_widget_factory->widgets)) {
                foreach ($wp_widget_factory->widgets as $widget) {
                    $types[] = [
                        'id_base' => $widget->id_base ?? null,
                        'name'    => $widget->name ?? null,
                        'class'   => get_class($widget),
                    ];
                }
            }
            $result['registered_types'] = $types;
        }

        return $this->success($result);
    }
}
