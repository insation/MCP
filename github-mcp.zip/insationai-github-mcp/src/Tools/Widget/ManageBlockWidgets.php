<?php
/**
 * Manage Block Widgets Tool — read or replace the block markup for a widget area.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Widget;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ManageBlockWidgets extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_block_widgets';
    }

    public function getDescription(): string
    {
        return 'Read or replace block-based widget content for a sidebar. Block themes store widgets as a series of "block" widgets, each holding raw block markup. Use action=get to read; action=set to replace.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:read';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['get', 'set']],
            ],
            'sidebar_id' => [
                'required',
                'string',
                'description' => 'Target sidebar ID.'
            ],
            'block_markup' => [
                'optional',
                'string',
                'description' => 'For action=set: raw block markup (HTML with block comments). Replaces all "block" widgets in the sidebar.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $sidebar_id = $parameters['sidebar_id'];

        if ($action === 'set') {
            $scopes = $this->userContext['scopes'] ?? [];
            $hasWrite = in_array('mcp:write', $scopes, true) || in_array('mcp:admin', $scopes, true);
            if ($this->userContext !== null && !$hasWrite) {
                throw ToolException::insufficientPermissions(
                    "action=set on block widgets requires mcp:write or mcp:admin scope."
                );
            }
        }

        $sidebars_widgets = wp_get_sidebars_widgets();
        if (!isset($sidebars_widgets[$sidebar_id])) {
            throw ToolException::wordpressError("Sidebar not found: '{$sidebar_id}'");
        }

        $widget_block_instances = get_option('widget_block', []);

        if ($action === 'get') {
            $blocks = [];
            foreach ($sidebars_widgets[$sidebar_id] as $wid) {
                if (!str_starts_with($wid, 'block-')) {
                    continue;
                }
                $num = (int) substr($wid, 6);
                if (isset($widget_block_instances[$num]['content'])) {
                    $blocks[] = [
                        'widget_id' => $wid,
                        'content'   => $widget_block_instances[$num]['content'],
                    ];
                }
            }
            return $this->success([
                'sidebar_id' => $sidebar_id,
                'count'      => count($blocks),
                'blocks'     => $blocks,
            ]);
        }

        // action=set
        if (!isset($parameters['block_markup'])) {
            throw ToolException::wordpressError("'block_markup' is required for action=set");
        }

        // Remove existing block-* widgets from this sidebar
        $sidebars_widgets[$sidebar_id] = array_values(array_filter(
            $sidebars_widgets[$sidebar_id],
            fn($wid) => !str_starts_with($wid, 'block-')
        ));

        // Create a new block widget instance with the supplied markup
        if (!is_array($widget_block_instances)) {
            $widget_block_instances = [];
        }
        $next = 1;
        while (isset($widget_block_instances[$next])) {
            $next++;
        }
        $widget_block_instances[$next] = ['content' => $parameters['block_markup']];
        if (!isset($widget_block_instances['_multiwidget'])) {
            $widget_block_instances['_multiwidget'] = 1;
        }
        update_option('widget_block', $widget_block_instances);

        // Prepend the new widget to the sidebar
        array_unshift($sidebars_widgets[$sidebar_id], "block-{$next}");
        wp_set_sidebars_widgets($sidebars_widgets);

        return $this->success([
            'sidebar_id' => $sidebar_id,
            'widget_id'  => "block-{$next}",
        ], 'Block widget content set.');
    }
}
