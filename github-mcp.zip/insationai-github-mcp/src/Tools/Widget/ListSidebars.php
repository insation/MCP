<?php
/**
 * List Sidebars Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Widget;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class ListSidebars extends AbstractTool
{
    public function getName(): string
    {
        return 'list_sidebars';
    }

    public function getDescription(): string
    {
        return 'List all registered sidebars (widget areas) with their IDs, names, descriptions, and current widget counts. Detects both classic widget areas and block-based theme widget areas.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        global $wp_registered_sidebars;

        $sidebars_widgets = wp_get_sidebars_widgets();
        $items = [];

        foreach ((array) $wp_registered_sidebars as $id => $info) {
            $widgets = $sidebars_widgets[$id] ?? [];
            $items[] = [
                'id'           => $id,
                'name'         => $info['name'] ?? $id,
                'description'  => $info['description'] ?? '',
                'class'        => $info['class'] ?? '',
                'widget_count' => is_array($widgets) ? count($widgets) : 0,
                'widget_ids'   => is_array($widgets) ? array_values($widgets) : [],
            ];
        }

        // Also note inactive widgets
        $inactive = $sidebars_widgets['wp_inactive_widgets'] ?? [];

        return $this->success([
            'count'             => count($items),
            'items'             => $items,
            'inactive_count'    => is_array($inactive) ? count($inactive) : 0,
            'inactive_widgets'  => is_array($inactive) ? array_values($inactive) : [],
        ]);
    }
}
