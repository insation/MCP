<?php
/**
 * Manage Pattern Tool — register or unregister block patterns at runtime.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Pattern;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ManagePattern extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_pattern';
    }

    public function getDescription(): string
    {
        return 'Register, unregister, or register a category for block patterns at runtime. Registrations made this way persist only for the duration of the request — for permanent patterns, write a /patterns/*.php file in your theme.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['register', 'unregister', 'register_category', 'unregister_category']],
            ],
            'name' => [
                'required',
                'string',
                'description' => 'Pattern or category name (e.g. mytheme/hero, my-cat).'
            ],
            'title' => [
                'optional',
                'string',
                'description' => 'Human-readable title (required for register / register_category).'
            ],
            'content' => [
                'optional',
                'string',
                'description' => 'Block markup (required for action=register).'
            ],
            'description' => ['optional', 'string'],
            'categories' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
                'description' => 'Category slugs for the pattern.'
            ],
            'keywords' => [
                'optional',
                'array',
                'items' => ['type' => 'string'],
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $action = $parameters['action'];
        $name   = $parameters['name'];

        switch ($action) {
            case 'register':
                if (empty($parameters['title']) || empty($parameters['content'])) {
                    throw ToolException::wordpressError("'title' and 'content' are required for action=register");
                }
                $args = [
                    'title'   => $parameters['title'],
                    'content' => $parameters['content'],
                ];
                foreach (['description', 'categories', 'keywords'] as $f) {
                    if (isset($parameters[$f])) {
                        $args[$f] = $parameters[$f];
                    }
                }
                register_block_pattern($name, $args);
                return $this->success(['name' => $name], 'Pattern registered (runtime only).');

            case 'unregister':
                unregister_block_pattern($name);
                return $this->success(['name' => $name], 'Pattern unregistered (runtime only).');

            case 'register_category':
                if (empty($parameters['title'])) {
                    throw ToolException::wordpressError("'title' is required for register_category");
                }
                register_block_pattern_category($name, ['label' => $parameters['title']]);
                return $this->success(['name' => $name], 'Pattern category registered.');

            case 'unregister_category':
                unregister_block_pattern_category($name);
                return $this->success(['name' => $name], 'Pattern category unregistered.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
