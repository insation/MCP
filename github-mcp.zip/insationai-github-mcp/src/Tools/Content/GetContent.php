<?php
/**
 * Get Content Tool
 *
 * @package GitHubMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- This tool returns JSON API responses, not HTML output
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Content;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

/**
 * Tool to get a single piece of content by ID
 *
 * Retrieves detailed information about a specific content item
 * (post, page, custom post type) by its ID
 */
class GetContent extends AbstractTool
{
    /**
     * {@inheritdoc}
     */
    public function getName(): string
    {
        return 'get_content';
    }

    /**
     * {@inheritdoc}
     */
    public function getDescription(): string
    {
        return 'Get detailed information about a specific piece of content by ID. '
            . 'Works with any content type (posts, pages, custom post types). '
            . 'Supports line-based content fetching for large posts (use start_line and line_count parameters).';
    }

    /**
     * {@inheritdoc}
     */
    public function getSchema(): array
    {
        return [
            'content_id' => [
                'required',
                'int',
                ['min' => 1]
            ],
            'content_type' => [
                'optional',
                'string',
                ['notEmpty' => true]
            ],
            'start_line' => [
                'optional',
                'int',
                ['min' => 1]
            ],
            'line_count' => [
                'optional',
                'int',
                ['min' => 1, 'max' => 10000]
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    protected function doExecute(array $parameters): array
    {
        $contentId = $parameters['content_id'];
        $expectedType = $parameters['content_type'] ?? null;
        $startLine = $parameters['start_line'] ?? null;
        $lineCount = $parameters['line_count'] ?? null;

        // Fetch the post
        $post = $this->wp->getPost($contentId);

        if ($post === null) {
            throw ToolException::wordpressError(
                "Content with ID {$contentId} not found"
            );
        }

        // Verify content type if specified
        if ($expectedType !== null && $post->post_type !== $expectedType) {
            throw ToolException::wordpressError(
                "Content with ID {$contentId} is of type '{$post->post_type}', not '{$expectedType}'"
            );
        }

        // Format detailed response with line-based content if requested
        return $this->success($this->formatPost($post, $startLine, $lineCount));
    }

    /**
     * Format a post with all details
     *
     * @param \WP_Post $post The post to format
     * @param int|null $startLine Optional starting line number (1-indexed)
     * @param int|null $lineCount Optional number of lines to return
     * @return array<string, mixed>
     */
    private function formatPost(\WP_Post $post, ?int $startLine = null, ?int $lineCount = null): array
    {
        $content = $post->post_content;
        $contentLines = explode("\n", $content);
        $totalLines = count($contentLines);

        // If line-based fetching is requested
        if ($startLine !== null || $lineCount !== null) {
            $start = ($startLine !== null) ? $startLine - 1 : 0; // Convert to 0-indexed
            $count = $lineCount ?? $totalLines;

            // Validate start line
            if ($start < 0 || $start >= $totalLines) {
                throw ToolException::validationFailed(
                    "start_line must be between 1 and {$totalLines}",
                    ['start_line' => "Invalid line number: must be between 1 and {$totalLines}"]
                );
            }

            // Extract requested lines
            $requestedLines = array_slice($contentLines, $start, $count);
            $content = implode("\n", $requestedLines);

            $returnedLines = count($requestedLines);
            $hasMore = ($start + $returnedLines) < $totalLines;
        } else {
            $returnedLines = $totalLines;
            $hasMore = false;
        }

        $result = [
            'id' => $post->ID,
            'title' => $post->post_title,
            'slug' => $post->post_name,
            'content' => $content,
            'content_metadata' => [
                'total_lines' => $totalLines,
                'returned_lines' => $returnedLines,
                'has_more' => $hasMore,
            ],
            'excerpt' => $post->post_excerpt,
            'status' => $post->post_status,
            'type' => $post->post_type,
            'date' => $post->post_date,
            'modified' => $post->post_modified,
            'author' => [
                'id' => $post->post_author,
                'name' => $this->wp->getAuthorName((int)$post->post_author),
            ],
            'parent' => $post->post_parent,
            'menu_order' => $post->menu_order,
            'comment_status' => $post->comment_status,
            'ping_status' => $post->ping_status,
            'url' => $this->wp->getPermalink($post->ID),
            'edit_url' => $this->wp->getEditPostLink($post->ID, 'raw'),
        ];

        // Add range info if line-based fetching was used
        if ($startLine !== null || $lineCount !== null) {
            $result['content_metadata']['start_line'] = $startLine ?? 1;
            $result['content_metadata']['line_count'] = $lineCount ?? $totalLines;
        }

        return $result;
    }
}
