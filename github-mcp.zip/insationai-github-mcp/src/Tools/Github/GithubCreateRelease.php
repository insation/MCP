<?php
declare(strict_types=1);
namespace InsationAI\GitHubMCP\Tools\Github;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;
use InsationAI\GitHubMCP\Services\GithubService;

class GithubCreateRelease extends AbstractTool
{
    public function getName(): string { return 'github_create_release'; }
    public function getDescription(): string { return 'Create a GitHub release (tag) on a repository. Returns the release including its id and upload URL.'; }
    public function getRequiredScope(): string { return 'mcp:admin'; }
    public function getSchema(): array
    {
        return [
            'tag_name'         => ['required', 'string', ['description' => 'Git tag for the release, e.g. v2.0.1.']],
            'name'             => ['optional', 'string', ['description' => 'Release title. Defaults to the tag.']],
            'body'             => ['optional', 'string', ['description' => 'Release notes / changelog (markdown).']],
            'target_commitish' => ['optional', 'string', ['description' => 'Branch or commit the tag points at (default: repo default branch).']],
            'draft'            => ['optional', 'bool', ['description' => 'Create as a draft. Default false.']],
            'prerelease'       => ['optional', 'bool', ['description' => 'Mark as a pre-release. Default false.']],
            'owner'            => ['optional', 'string'],
            'repo'             => ['optional', 'string'],
        ];
    }
    protected function doExecute(array $p): array
    {
        $gh = new GithubService();
        [$o, $r] = $gh->resolve($p['owner'] ?? null, $p['repo'] ?? null);
        if ($o === '' || $r === '') { throw ToolException::invalidInput('owner and repo are required (none configured).'); }
        $tag = trim((string) ($p['tag_name'] ?? ''));
        if ($tag === '') { throw ToolException::invalidInput('tag_name is required.'); }
        $body = [
            'tag_name'   => $tag,
            'name'       => isset($p['name']) && $p['name'] !== '' ? (string) $p['name'] : $tag,
            'body'       => (string) ($p['body'] ?? ''),
            'draft'      => !empty($p['draft']),
            'prerelease' => !empty($p['prerelease']),
        ];
        if (!empty($p['target_commitish'])) { $body['target_commitish'] = (string) $p['target_commitish']; }
        $res = $gh->request('POST', "/repos/{$o}/{$r}/releases", $body);
        if (is_wp_error($res)) { throw ToolException::wordpressError($res->get_error_message()); }
        return $this->success($res['data'], "Created release {$tag} on {$o}/{$r}");
    }
}
