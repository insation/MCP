<?php
declare(strict_types=1);
namespace InsationAI\GitHubMCP\Tools\Github;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;
use InsationAI\GitHubMCP\Services\GithubService;

class GithubGetRepo extends AbstractTool
{
    public function getName(): string { return 'github_get_repo'; }
    public function getDescription(): string { return 'Get metadata for a GitHub repository (default branch, visibility, etc.).'; }
    public function getRequiredScope(): string { return 'mcp:read'; }
    public function getSchema(): array
    {
        return [
            'owner' => ['optional', 'string', ['description' => 'Repo owner/org. Defaults to the configured owner.']],
            'repo'  => ['optional', 'string', ['description' => 'Repo name. Defaults to the configured repo.']],
        ];
    }
    protected function doExecute(array $p): array
    {
        $gh = new GithubService();
        [$o, $r] = $gh->resolve($p['owner'] ?? null, $p['repo'] ?? null);
        if ($o === '' || $r === '') { throw ToolException::invalidInput('owner and repo are required (none configured).'); }
        $res = $gh->request('GET', "/repos/{$o}/{$r}");
        if (is_wp_error($res)) { throw ToolException::wordpressError($res->get_error_message()); }
        return $this->success($res['data'], "{$o}/{$r}");
    }
}
