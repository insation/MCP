<?php
declare(strict_types=1);
namespace InsationAI\GitHubMCP\Tools\Github;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Services\GithubService;

class GithubGetConfig extends AbstractTool
{
    public function getName(): string { return 'github_get_config'; }
    public function getDescription(): string { return 'Return the configured GitHub default owner/repo and whether a token is set (never returns the token itself).'; }
    public function getRequiredScope(): string { return 'mcp:read'; }
    public function getSchema(): array { return []; }
    protected function doExecute(array $parameters): array
    {
        $gh = new GithubService();
        return $this->success([
            'default_owner' => $gh->owner(),
            'default_repo'  => $gh->repo(),
            'token_set'     => $gh->hasToken(),
        ]);
    }
}
