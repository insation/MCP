<?php
declare(strict_types=1);
namespace InsationAI\GitHubMCP\Tools\Github;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;
use InsationAI\GitHubMCP\Services\GithubService;

class GithubPutFile extends AbstractTool
{
    public function getName(): string { return 'github_put_file'; }
    public function getDescription(): string { return 'Create or update a file in a repo via the Contents API (commit). Bytes are fetched server-side from source_url, or passed as text content. Useful for hosting release zips at a stable raw URL.'; }
    public function getRequiredScope(): string { return 'mcp:admin'; }
    public function getSchema(): array
    {
        return [
            'path'       => ['required', 'string', ['description' => 'Repo-relative file path, e.g. github-mcp.zip.']],
            'message'    => ['required', 'string', ['description' => 'Commit message.']],
            'source_url' => ['optional', 'string', ['description' => 'URL the server downloads the file bytes from (binary-safe).']],
            'content'    => ['optional', 'string', ['description' => 'Raw text content (use instead of source_url for text files).']],
            'branch'     => ['optional', 'string', ['description' => 'Target branch. Defaults to the repo default branch.']],
            'owner'      => ['optional', 'string'],
            'repo'       => ['optional', 'string'],
        ];
    }
    protected function doExecute(array $p): array
    {
        $gh = new GithubService();
        [$o, $r] = $gh->resolve($p['owner'] ?? null, $p['repo'] ?? null);
        if ($o === '' || $r === '') { throw ToolException::invalidInput('owner and repo are required (none configured).'); }
        $path = trim((string) ($p['path'] ?? ''));
        if ($path === '') { throw ToolException::invalidInput('path is required.'); }

        if (!empty($p['source_url'])) {
            $bytes = $gh->fetchBytes((string) $p['source_url']);
            if (is_wp_error($bytes)) { throw ToolException::wordpressError($bytes->get_error_message()); }
            $content = base64_encode($bytes);
        } elseif (isset($p['content'])) {
            $content = base64_encode((string) $p['content']);
        } else {
            throw ToolException::invalidInput('Provide source_url or content.');
        }

        $branch  = !empty($p['branch']) ? (string) $p['branch'] : null;
        $encoded = GithubService::encodePath($path);

        // Find existing file sha (update vs create).
        $sha   = null;
        $check = $gh->request('GET', "/repos/{$o}/{$r}/contents/{$encoded}" . ($branch ? "?ref={$branch}" : ''));
        if (!is_wp_error($check) && isset($check['data']['sha'])) { $sha = $check['data']['sha']; }

        $body = ['message' => (string) $p['message'], 'content' => $content];
        if ($branch) { $body['branch'] = $branch; }
        if ($sha)    { $body['sha'] = $sha; }

        $res = $gh->request('PUT', "/repos/{$o}/{$r}/contents/{$encoded}", $body);
        if (is_wp_error($res)) { throw ToolException::wordpressError($res->get_error_message()); }
        return $this->success($res['data'], "Committed {$path} to {$o}/{$r}");
    }
}
