<?php
declare(strict_types=1);
namespace InsationAI\GitHubMCP\Tools\Github;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;
use InsationAI\GitHubMCP\Services\GithubService;

class GithubListReleases extends AbstractTool
{
    public function getName(): string { return 'github_list_releases'; }
    public function getDescription(): string { return 'List releases (tag, name, assets, draft/prerelease flags) for a repository.'; }
    public function getRequiredScope(): string { return 'mcp:read'; }
    public function getSchema(): array
    {
        return [
            'owner'    => ['optional', 'string', ['description' => 'Repo owner/org. Defaults to the configured owner.']],
            'repo'     => ['optional', 'string', ['description' => 'Repo name. Defaults to the configured repo.']],
            'per_page' => ['optional', 'int', ['description' => 'Max releases to return (1-100, default 30).']],
        ];
    }
    protected function doExecute(array $p): array
    {
        $gh = new GithubService();
        [$o, $r] = $gh->resolve($p['owner'] ?? null, $p['repo'] ?? null);
        if ($o === '' || $r === '') { throw ToolException::invalidInput('owner and repo are required (none configured).'); }
        $per = isset($p['per_page']) ? max(1, min(100, (int) $p['per_page'])) : 30;
        $res = $gh->request('GET', "/repos/{$o}/{$r}/releases?per_page={$per}");
        if (is_wp_error($res)) { throw ToolException::wordpressError($res->get_error_message()); }
        return $this->success($res['data'], "Releases for {$o}/{$r}");
    }
}
