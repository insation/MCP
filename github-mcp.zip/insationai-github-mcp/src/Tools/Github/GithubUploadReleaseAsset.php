<?php
declare(strict_types=1);
namespace InsationAI\GitHubMCP\Tools\Github;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;
use InsationAI\GitHubMCP\Services\GithubService;

class GithubUploadReleaseAsset extends AbstractTool
{
    public function getName(): string { return 'github_upload_release_asset'; }
    public function getDescription(): string { return 'Attach a file to a GitHub release. The server fetches the bytes from source_url and uploads them — no file content passes through the AI client.'; }
    public function getRequiredScope(): string { return 'mcp:admin'; }
    public function getSchema(): array
    {
        return [
            'release_id'   => ['required', 'int', ['description' => 'The release id to attach the asset to (from github_create_release).']],
            'asset_name'   => ['required', 'string', ['description' => 'Filename for the asset, e.g. github-mcp.zip.']],
            'source_url'   => ['required', 'string', ['description' => 'URL the server downloads the asset bytes from.']],
            'content_type' => ['optional', 'string', ['description' => 'MIME type. Default application/octet-stream.']],
            'owner'        => ['optional', 'string'],
            'repo'         => ['optional', 'string'],
        ];
    }
    protected function doExecute(array $p): array
    {
        $gh = new GithubService();
        [$o, $r] = $gh->resolve($p['owner'] ?? null, $p['repo'] ?? null);
        if ($o === '' || $r === '') { throw ToolException::invalidInput('owner and repo are required (none configured).'); }
        $relId = (int) ($p['release_id'] ?? 0);
        $name  = trim((string) ($p['asset_name'] ?? ''));
        $src   = trim((string) ($p['source_url'] ?? ''));
        if ($relId <= 0) { throw ToolException::invalidInput('release_id is required.'); }
        if ($name === '') { throw ToolException::invalidInput('asset_name is required.'); }
        if ($src === '')  { throw ToolException::invalidInput('source_url is required.'); }
        $bytes = $gh->fetchBytes($src);
        if (is_wp_error($bytes)) { throw ToolException::wordpressError($bytes->get_error_message()); }
        $ct  = isset($p['content_type']) && $p['content_type'] !== '' ? (string) $p['content_type'] : 'application/octet-stream';
        $res = $gh->uploadAsset($o, $r, $relId, $name, $bytes, $ct);
        if (is_wp_error($res)) { throw ToolException::wordpressError($res->get_error_message()); }
        return $this->success($res['data'], "Uploaded {$name} to release {$relId}");
    }
}
