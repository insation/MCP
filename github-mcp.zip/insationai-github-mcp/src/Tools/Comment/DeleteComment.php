<?php
/**
 * Delete Comment Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Comment;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class DeleteComment extends AbstractTool
{
    public function getName(): string
    {
        return 'delete_comment';
    }

    public function getDescription(): string
    {
        return 'Delete a comment. Defaults to trashing; pass force=true to permanently delete. Subject to safe mode.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:delete';
    }

    public function getSchema(): array
    {
        return [
            'id' => ['required', 'int'],
            'force' => [
                'optional',
                'bool',
                'description' => 'When true, permanently delete (bypass trash). Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $this->checkSafeMode('deleting comments');

        $id = (int) $parameters['id'];
        if (!get_comment($id)) {
            throw ToolException::wordpressError("Comment not found: ID {$id}");
        }

        $force = !empty($parameters['force']);
        $result = wp_delete_comment($id, $force);

        if (!$result) {
            throw ToolException::wordpressError('Failed to delete comment.');
        }

        return $this->success([
            'id'        => $id,
            'permanent' => $force,
        ], $force ? 'Comment permanently deleted.' : 'Comment moved to trash.');
    }
}
