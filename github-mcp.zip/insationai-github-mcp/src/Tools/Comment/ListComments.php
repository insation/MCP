<?php
/**
 * List Comments Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Comment;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ListComments extends AbstractTool
{
    public function getName(): string
    {
        return 'list_comments';
    }

    public function getDescription(): string
    {
        return 'List comments with filtering by status, post, author, and search query.';
    }

    public function getSchema(): array
    {
        return [
            'status' => [
                'optional',
                'string',
                ['in' => ['approve', 'hold', 'spam', 'trash', 'all']],
                'description' => 'approve | hold | spam | trash | all. Default: approve.'
            ],
            'post_id' => [
                'optional',
                'int',
                'description' => 'Limit to comments on this post.'
            ],
            'author_email' => [
                'optional',
                'string',
                'description' => 'Filter by commenter email.'
            ],
            'user_id' => [
                'optional',
                'int',
                'description' => 'Filter by registered commenter user ID.'
            ],
            'search' => [
                'optional',
                'string',
                'description' => 'Search comment content.'
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100]
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1]
            ],
            'orderby' => [
                'optional',
                'string',
                ['in' => ['comment_date', 'comment_date_gmt', 'comment_ID', 'comment_post_ID']]
            ],
            'order' => [
                'optional',
                'string',
                ['in' => ['ASC', 'DESC']]
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $perPage = $parameters['per_page'] ?? 20;
        $page    = $parameters['page'] ?? 1;
        $status  = $parameters['status'] ?? 'approve';

        $args = [
            'status'  => $status,
            'number'  => $perPage,
            'offset'  => ($page - 1) * $perPage,
            'orderby' => $parameters['orderby'] ?? 'comment_date',
            'order'   => $parameters['order'] ?? 'DESC',
        ];

        if (isset($parameters['post_id'])) {
            $args['post_id'] = (int) $parameters['post_id'];
        }
        if (isset($parameters['author_email'])) {
            $args['author_email'] = $parameters['author_email'];
        }
        if (isset($parameters['user_id'])) {
            $args['user_id'] = (int) $parameters['user_id'];
        }
        if (!empty($parameters['search'])) {
            $args['search'] = $parameters['search'];
        }

        $query = new \WP_Comment_Query();
        $comments = $query->query($args);

        // Total count (separate query)
        $countArgs = $args;
        unset($countArgs['number'], $countArgs['offset']);
        $countArgs['count'] = true;
        $total = (new \WP_Comment_Query())->query($countArgs);

        $formatted = array_map(fn(\WP_Comment $c) => $this->formatComment($c), $comments);

        return $this->success([
            'count'    => count($formatted),
            'total'    => (int) $total,
            'page'     => $page,
            'per_page' => $perPage,
            'items'    => $formatted,
        ]);
    }

    private function formatComment(\WP_Comment $c): array
    {
        return [
            'id'         => (int) $c->comment_ID,
            'post_id'    => (int) $c->comment_post_ID,
            'parent_id'  => (int) $c->comment_parent,
            'user_id'    => (int) $c->user_id,
            'author'     => $c->comment_author,
            'email'      => $c->comment_author_email,
            'url'        => $c->comment_author_url,
            'ip'         => $c->comment_author_IP,
            'date'       => $c->comment_date,
            'content'    => $c->comment_content,
            'approved'   => $c->comment_approved, // '0' | '1' | 'spam' | 'trash'
            'type'       => $c->comment_type ?: 'comment',
        ];
    }
}
