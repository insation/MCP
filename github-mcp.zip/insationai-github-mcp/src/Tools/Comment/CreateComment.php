<?php
/**
 * Create Comment Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Comment;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class CreateComment extends AbstractTool
{
    public function getName(): string
    {
        return 'create_comment';
    }

    public function getDescription(): string
    {
        return 'Create a comment or reply on a post. Provide post_id and content. Optionally specify a parent_id to nest as a reply, or a user_id to attribute to a registered user.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'post_id' => [
                'required',
                'int',
                'description' => 'Target post ID.'
            ],
            'content' => [
                'required',
                'string',
                ['notEmpty' => true]
            ],
            'parent_id' => [
                'optional',
                'int',
                'description' => 'Parent comment ID (creates a threaded reply).'
            ],
            'user_id' => [
                'optional',
                'int',
                'description' => 'Attribute to this registered user. Otherwise uses author_name/email.'
            ],
            'author_name' => ['optional', 'string'],
            'author_email' => ['optional', 'string'],
            'author_url' => ['optional', 'string'],
            'approved' => [
                'optional',
                'bool',
                'description' => 'Mark as approved (true) or pending (false). Default approved.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $post_id = (int) $parameters['post_id'];
        if (!get_post($post_id)) {
            throw ToolException::wordpressError("Post not found: ID {$post_id}");
        }

        $data = [
            'comment_post_ID' => $post_id,
            'comment_content' => $parameters['content'],
            'comment_approved' => (isset($parameters['approved']) && $parameters['approved'] === false) ? 0 : 1,
        ];

        if (isset($parameters['parent_id'])) {
            $data['comment_parent'] = (int) $parameters['parent_id'];
        }

        if (isset($parameters['user_id'])) {
            $user = get_userdata((int) $parameters['user_id']);
            if (!$user) {
                throw ToolException::wordpressError("Commenter user not found: ID {$parameters['user_id']}");
            }
            $data['user_id'] = $user->ID;
            $data['comment_author'] = $user->display_name;
            $data['comment_author_email'] = $user->user_email;
            $data['comment_author_url'] = $user->user_url;
        } else {
            $data['comment_author'] = $parameters['author_name'] ?? 'Anonymous';
            $data['comment_author_email'] = sanitize_email($parameters['author_email'] ?? '');
            $data['comment_author_url'] = esc_url_raw($parameters['author_url'] ?? '');
        }

        $comment_id = wp_insert_comment(wp_slash($data));
        if (!$comment_id) {
            throw ToolException::wordpressError('Failed to insert comment.');
        }

        return $this->success([
            'id'      => (int) $comment_id,
            'post_id' => $post_id,
            'approved' => (bool) $data['comment_approved'],
        ], 'Comment created.');
    }
}
