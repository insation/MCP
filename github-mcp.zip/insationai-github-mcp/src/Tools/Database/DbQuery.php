<?php
/**
 * Database Query Tool
 *
 * Read-only by default. Writes require write=true plus mcp:admin scope.
 * Multiple statements per call are rejected. wpdb is used so MySQL/MariaDB
 * differences are handled by WordPress's normal abstraction.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery -- This is the escape hatch tool; arbitrary SQL is the whole point.
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Database;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class DbQuery extends AbstractTool
{
    /**
     * Statement starts that are unambiguously read-only.
     */
    private const READ_ONLY_PREFIXES = ['SELECT', 'SHOW', 'DESCRIBE', 'DESC', 'EXPLAIN'];

    /**
     * Statement starts that we will never execute regardless of write=true.
     * GRANT and DROP DATABASE are not appropriate for a tool of this scope.
     */
    private const FORBIDDEN_PREFIXES = ['GRANT', 'REVOKE', 'DROP DATABASE', 'CREATE DATABASE', 'SHUTDOWN'];

    public function getName(): string
    {
        return 'db_query';
    }

    public function getDescription(): string
    {
        return 'Run a single SQL statement against the WordPress database. Read-only (SELECT/SHOW/DESCRIBE/EXPLAIN) by default. Pass write=true (plus mcp:admin scope) for INSERT/UPDATE/DELETE and any DDL including CREATE/ALTER/DROP/TRUNCATE/RENAME TABLE — these are intentionally allowed for legitimate database maintenance. Multiple semicolon-separated statements are rejected. Statements that escape the WP database scope are always rejected regardless of write=true: GRANT, REVOKE, DROP DATABASE, CREATE DATABASE, SHUTDOWN.';
    }

    public function getRequiredScope(): string
    {
        // Default scope is read; the doExecute path elevates the requirement
        // to mcp:admin when write=true.
        return 'mcp:read';
    }

    public function getSchema(): array
    {
        return [
            'sql' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Single SQL statement. {prefix} is replaced with the wpdb table prefix.'
            ],
            'write' => [
                'optional',
                'bool',
                'description' => 'Opt in to write queries (INSERT/UPDATE/DELETE/CREATE/ALTER). Requires mcp:admin scope.'
            ],
            'limit' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 1000],
                'description' => 'For SELECT-like statements without a LIMIT, append this LIMIT clause. Default 100.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $sql = trim((string) $parameters['sql']);

        // Reject multiple statements (a single trailing ; is OK)
        $trimmed = rtrim($sql, "; \t\n");
        if (str_contains($trimmed, ';')) {
            throw ToolException::wordpressError('Only one SQL statement per call is allowed.');
        }

        // Substitute {prefix}
        $sql = str_replace('{prefix}', $wpdb->prefix, $sql);

        $upper = strtoupper(ltrim($sql));
        foreach (self::FORBIDDEN_PREFIXES as $bad) {
            if (str_starts_with($upper, $bad)) {
                throw ToolException::wordpressError("Statement starting with '{$bad}' is forbidden.");
            }
        }

        $isReadOnly = false;
        foreach (self::READ_ONLY_PREFIXES as $prefix) {
            if (str_starts_with($upper, $prefix)) {
                $isReadOnly = true;
                break;
            }
        }

        if (!$isReadOnly) {
            // This is a write/DDL — needs explicit opt-in and admin scope
            $this->checkSafeMode('db_query write operations');

            if (empty($parameters['write'])) {
                throw ToolException::wordpressError(
                    'This statement is not a SELECT/SHOW/DESCRIBE/EXPLAIN. Pass write=true to allow it.'
                );
            }
            $scopes = $this->userContext['scopes'] ?? [];
            $hasAdmin = in_array('mcp:admin', $scopes, true);
            if ($this->userContext !== null && !$hasAdmin) {
                throw ToolException::insufficientPermissions('Write queries require mcp:admin scope.');
            }
        }

        // For read queries without an explicit LIMIT, append one to keep result sizes safe.
        if ($isReadOnly && str_starts_with($upper, 'SELECT') && !preg_match('/\bLIMIT\b/i', $sql)) {
            $limit = (int) ($parameters['limit'] ?? 100);
            $sql = rtrim($sql, '; ') . " LIMIT {$limit}";
        }

        $started = microtime(true);

        if ($isReadOnly) {
            $rows = $wpdb->get_results($sql, ARRAY_A);
            if ($wpdb->last_error) {
                throw ToolException::wordpressError("SQL error: {$wpdb->last_error}");
            }
            $elapsedMs = (int) ((microtime(true) - $started) * 1000);

            return $this->success([
                'mode'        => 'read',
                'sql'         => $sql,
                'row_count'   => is_array($rows) ? count($rows) : 0,
                'rows'        => is_array($rows) ? $rows : [],
                'elapsed_ms'  => $elapsedMs,
            ]);
        }

        // Write
        $affected = $wpdb->query($sql);
        if ($wpdb->last_error) {
            throw ToolException::wordpressError("SQL error: {$wpdb->last_error}");
        }
        $elapsedMs = (int) ((microtime(true) - $started) * 1000);

        return $this->success([
            'mode'         => 'write',
            'sql'          => $sql,
            'affected_rows'=> (int) $affected,
            'insert_id'    => (int) $wpdb->insert_id,
            'elapsed_ms'   => $elapsedMs,
        ]);
    }
}
