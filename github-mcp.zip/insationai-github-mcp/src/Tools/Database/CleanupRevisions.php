<?php
/**
 * Cleanup Revisions Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable WordPress.DB.DirectDatabaseQuery
 * phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Database;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class CleanupRevisions extends AbstractTool
{
    public function getName(): string
    {
        return 'cleanup_revisions';
    }

    public function getDescription(): string
    {
        return 'Delete post revisions from the database. action=count returns how many would be removed. action=delete removes them. Optionally keep the most-recent N per post.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['count', 'delete']],
            ],
            'keep_per_post' => [
                'optional',
                'int',
                ['min' => 0],
                'description' => 'Keep the most recent N revisions per parent post. Default 0 (delete all).'
            ],
            'older_than_days' => [
                'optional',
                'int',
                ['min' => 0],
                'description' => 'Only operate on revisions older than this many days. Default 0 (no time filter).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wpdb;

        $action = $parameters['action'];
        $keep   = (int) ($parameters['keep_per_post'] ?? 0);
        $olderThan = (int) ($parameters['older_than_days'] ?? 0);

        $cutoff = $olderThan > 0 ? gmdate('Y-m-d H:i:s', time() - ($olderThan * DAY_IN_SECONDS)) : null;

        // Find candidate revision IDs
        $sql = "SELECT ID, post_parent, post_date_gmt FROM {$wpdb->posts}
                WHERE post_type = 'revision'";
        if ($cutoff) {
            $sql .= $wpdb->prepare(' AND post_date_gmt < %s', $cutoff);
        }
        $sql .= ' ORDER BY post_parent ASC, post_date_gmt DESC';

        $candidates = $wpdb->get_results($sql, ARRAY_A);

        $toDelete = [];
        $perParent = [];
        foreach ($candidates as $r) {
            $pid = (int) $r['post_parent'];
            $perParent[$pid] = ($perParent[$pid] ?? 0) + 1;
            if ($keep > 0 && $perParent[$pid] <= $keep) {
                // Keep the most recent N
                continue;
            }
            $toDelete[] = (int) $r['ID'];
        }

        if ($action === 'count') {
            return $this->success([
                'eligible_revisions' => count($candidates),
                'would_delete'       => count($toDelete),
                'keep_per_post'      => $keep,
                'older_than_days'    => $olderThan,
            ]);
        }

        // action=delete
        $this->checkSafeMode('deleting revisions');

        $deleted = 0;
        foreach ($toDelete as $id) {
            $r = wp_delete_post_revision($id);
            if ($r && !is_wp_error($r)) {
                $deleted++;
            }
        }

        return $this->success([
            'eligible_revisions' => count($candidates),
            'deleted'            => $deleted,
            'kept_per_post'      => $keep,
        ], "Deleted {$deleted} revision(s).");
    }
}
