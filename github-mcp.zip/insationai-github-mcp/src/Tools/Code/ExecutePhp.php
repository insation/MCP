<?php
/**
 * Execute PHP Tool
 *
 * Executes arbitrary PHP code on the WordPress server with the full WordPress
 * environment available ($wpdb, WP API, all loaded plugins).
 *
 * SAFETY MODEL
 * ------------
 * This is the most powerful and most dangerous tool in GitHubMCP. It is:
 *   - Off by default. Must be explicitly enabled via the
 *     `insationai_ghmcp_execute_php_enabled` option (admin UI or wp option set).
 *   - Restricted to the `mcp:admin` OAuth scope.
 *   - Restricted to users with the `manage_options` WordPress capability.
 *   - Time-limited to a hard 30 seconds per call.
 *
 * @package GitHubMCP
 * @since 1.1.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 * phpcs:disable Squiz.PHP.Eval.Discouraged
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Code;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ExecutePhp extends AbstractTool
{
    public const MAX_EXECUTION_TIME = 30;
    public const ENABLED_OPTION = 'insationai_ghmcp_execute_php_enabled';
    public const REQUIRED_CONSTANT = 'WPMCP_ALLOW_PHP_EXECUTION';

    public function getName(): string
    {
        return 'execute_php';
    }

    public function getDescription(): string
    {
        return 'Execute PHP code on the WordPress server with the full WordPress environment '
            . '($wpdb, all WordPress functions, loaded plugins). Returns the return value, any '
            . 'echoed output, and captured warnings/notices. Disabled by default — requires BOTH '
            . 'an admin to opt in via the option `insationai_ghmcp_execute_php_enabled` AND the '
            . 'constant `define(\'WPMCP_ALLOW_PHP_EXECUTION\', true);` in wp-config.php. Requires '
            . 'mcp:admin scope. Hard 30-second time limit. Do NOT include <?php opening tags. '
            . 'Use "return $value;" to inspect values.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'code' => [
                'required',
                'string',
                'description' => 'PHP code to execute. Do NOT include <?php opening tags. '
                    . 'Use "return $value;" to return data for inspection. The full WordPress '
                    . 'API is available. Hard 30-second time limit.',
            ],
        ];
    }

    /**
     * Plugin-wide registration check: ExecutePhp is omitted from the tool list
     * entirely unless BOTH conditions are met. This means an admin-scope token
     * can't even discover the tool until explicit opt-in. Defense in depth: a
     * stolen token can't reach PHP execution if the site owner hasn't added
     * the wp-config constant.
     */
    public static function isEnabled(): bool
    {
        // 1. wp_option flag — togglable from the admin UI
        if (!get_option(self::ENABLED_OPTION, false)) {
            return false;
        }
        // 2. wp-config.php constant — requires filesystem access to set, which
        //    a remote attacker holding only a bearer token typically doesn't have.
        if (!defined(self::REQUIRED_CONSTANT) || !constant(self::REQUIRED_CONSTANT)) {
            return false;
        }
        return true;
    }

    protected function doExecute(array $parameters): array
    {
        // Opt-in check: both gates must be open.
        if (!get_option(self::ENABLED_OPTION, false)) {
            throw ToolException::forbidden(
                'execute_php is disabled. A site admin must enable it under '
                . 'Settings → GitHubMCP → General → Execute PHP.'
            );
        }
        if (!defined(self::REQUIRED_CONSTANT) || !constant(self::REQUIRED_CONSTANT)) {
            throw ToolException::forbidden(
                'execute_php requires an additional opt-in gate in wp-config.php. '
                . 'Add: define(\'WPMCP_ALLOW_PHP_EXECUTION\', true); — this prevents a stolen '
                . 'bearer token alone from reaching PHP execution.'
            );
        }


        // Belt-and-suspenders capability check on top of the OAuth scope check.
        if (!current_user_can('manage_options')) {
            throw ToolException::insufficientPermissions(
                'execute_php requires the manage_options WordPress capability.'
            );
        }

        $code = (string) ($parameters['code'] ?? '');
        if ($code === '') {
            throw ToolException::invalidInput('code parameter cannot be empty');
        }

        // Strip a leading <?php / <? if the agent included it anyway.
        $code = preg_replace('/^\s*<\?(php)?\s*/i', '', $code) ?? $code;

        $errors = [];
        $errorTypes = [
            E_WARNING => 'Warning',
            E_NOTICE => 'Notice',
            E_DEPRECATED => 'Deprecated',
            E_USER_WARNING => 'User Warning',
            E_USER_NOTICE => 'User Notice',
            E_USER_DEPRECATED => 'User Deprecated',
            E_STRICT => 'Strict',
        ];

        // Save and bound the time limit.
        $originalTimeLimit = (int) ini_get('max_execution_time');
        @set_time_limit(self::MAX_EXECUTION_TIME);

        // Capture warnings/notices instead of letting them leak.
        set_error_handler(static function ($errno, $errstr, $errfile, $errline) use (&$errors, $errorTypes) {
            $errors[] = [
                'type' => $errorTypes[$errno] ?? "Error ({$errno})",
                'message' => (string) $errstr,
                'file' => (string) $errfile,
                'line' => (int) $errline,
            ];
            // Returning true tells PHP we handled the error — suppresses default output.
            return true;
        });

        $start = microtime(true);
        $output = '';
        $returnValue = null;
        $errorMessage = null;
        $errorClass = null;
        $success = true;

        ob_start();
        try {
            $returnValue = eval($code);
        } catch (\ParseError $e) {
            $success = false;
            $errorMessage = $e->getMessage();
            $errorClass = \ParseError::class;
        } catch (\Throwable $e) {
            $success = false;
            $errorMessage = $e->getMessage();
            $errorClass = $e::class;
        } finally {
            $output = ob_get_clean() ?: '';
            restore_error_handler();
            @set_time_limit($originalTimeLimit > 0 ? $originalTimeLimit : 30);
        }

        $elapsedMs = (microtime(true) - $start) * 1000.0;

        $this->logger->info('execute_php invoked', [
            'success' => $success,
            'elapsed_ms' => $elapsedMs,
            'output_bytes' => strlen($output),
            'user' => $this->userContext['login'] ?? $this->userContext['username'] ?? 'unknown',
        ]);

        return $this->success([
            'success' => $success,
            'return_value' => $returnValue,
            'output' => $output,
            'errors' => $errors,
            'error_message' => $errorMessage,
            'error_class' => $errorClass,
            'execution_time_ms' => round($elapsedMs, 3),
        ]);
    }

}
