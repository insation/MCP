<?php
/**
 * List Hooks On Action Tool
 *
 * Returns every callback registered to a given hook, grouped by priority.
 * Invaluable for debugging "what's running on init?" type questions.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Diagnostics;

use InsationAI\GitHubMCP\Tools\AbstractTool;

class ListHooksOnAction extends AbstractTool
{
    public function getName(): string
    {
        return 'list_hooks_on_action';
    }

    public function getDescription(): string
    {
        return 'List every callback registered to a WordPress hook (action or filter), grouped by priority. Each callback shows its function/method name and where possible the source file. Use for debugging "what runs on init/wp_head/save_post?" questions.';
    }

    public function getSchema(): array
    {
        return [
            'hook' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Hook name (e.g. init, wp_head, save_post).'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        global $wp_filter;

        $hook = $parameters['hook'];

        if (!isset($wp_filter[$hook])) {
            return $this->success([
                'hook'     => $hook,
                'priorities' => [],
                'note'     => 'No callbacks registered for this hook at the time of the call.',
            ]);
        }

        $wp_hook = $wp_filter[$hook];
        $callbacks = is_object($wp_hook) && property_exists($wp_hook, 'callbacks')
            ? $wp_hook->callbacks
            : (array) $wp_hook;

        $priorities = [];
        foreach ($callbacks as $priority => $entries) {
            $list = [];
            foreach ($entries as $entry) {
                $cb = $entry['function'] ?? null;
                $accepted = $entry['accepted_args'] ?? null;
                $list[] = [
                    'name'           => $this->describeCallback($cb),
                    'accepted_args'  => (int) $accepted,
                ];
            }
            $priorities[] = [
                'priority'     => (int) $priority,
                'callback_count' => count($list),
                'callbacks'    => $list,
            ];
        }

        // Sort ascending by priority
        usort($priorities, static fn($a, $b) => $a['priority'] <=> $b['priority']);

        return $this->success([
            'hook'       => $hook,
            'priorities' => $priorities,
        ]);
    }

    private function describeCallback($cb): string
    {
        if (is_string($cb)) {
            return $cb;
        }
        if (is_array($cb) && count($cb) === 2) {
            $cls = is_object($cb[0]) ? get_class($cb[0]) : (string) $cb[0];
            return "{$cls}::{$cb[1]}";
        }
        if ($cb instanceof \Closure) {
            try {
                $r = new \ReflectionFunction($cb);
                $file = $r->getFileName() ?: '?';
                $line = $r->getStartLine() ?: 0;
                return "Closure (" . basename($file) . ":{$line})";
            } catch (\Throwable $e) {
                return 'Closure';
            }
        }
        if (is_object($cb) && method_exists($cb, '__invoke')) {
            return get_class($cb) . '::__invoke';
        }
        return 'unknown';
    }
}
