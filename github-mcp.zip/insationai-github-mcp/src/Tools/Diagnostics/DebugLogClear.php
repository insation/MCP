<?php
/**
 * Debug Log Clear Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Diagnostics;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class DebugLogClear extends AbstractTool
{
    public function getName(): string
    {
        return 'debug_log_clear';
    }

    public function getDescription(): string
    {
        return 'Truncate the WordPress debug log file. Subject to safe mode. Returns the size that was discarded.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $this->checkSafeMode('clearing the debug log');

        $path = $this->resolveLogPath();
        if (!$path) {
            return $this->success([
                'available' => false,
                'reason'    => 'WP_DEBUG_LOG is disabled.',
            ]);
        }
        if (!file_exists($path)) {
            return $this->success([
                'available' => false,
                'path'      => $path,
                'reason'    => 'Log file does not exist.',
            ]);
        }
        if (!is_writable($path)) {
            throw ToolException::wordpressError("Debug log is not writable: {$path}");
        }

        $size = filesize($path);
        $fh = fopen($path, 'wb');
        if (!$fh) {
            throw ToolException::wordpressError("Failed to truncate debug log: {$path}");
        }
        fclose($fh);

        return $this->success([
            'path'           => $path,
            'discarded_bytes'=> (int) $size,
        ], 'Debug log cleared.');
    }

    private function resolveLogPath(): ?string
    {
        if (!defined('WP_DEBUG_LOG') || WP_DEBUG_LOG === false) {
            return null;
        }
        if (is_string(WP_DEBUG_LOG) && WP_DEBUG_LOG !== '') {
            return WP_DEBUG_LOG;
        }
        return WP_CONTENT_DIR . '/debug.log';
    }
}
