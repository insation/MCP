<?php
/**
 * Get User Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\User;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class GetUser extends AbstractTool
{
    public function getName(): string
    {
        return 'get_user';
    }

    public function getDescription(): string
    {
        return 'Get detailed information about a specific WordPress user. Lookup by user ID, login, email, or slug.';
    }

    public function getSchema(): array
    {
        return [
            'user' => [
                'required',
                'string',
                'description' => 'User identifier — numeric ID, user_login, email address, or user_nicename slug.'
            ],
            'include_meta' => [
                'optional',
                'bool',
                'description' => 'When true, include all user meta in the response. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $identifier = $parameters['user'];
        $user = $this->resolveUser($identifier);

        if (!$user) {
            throw ToolException::wordpressError("User not found: '{$identifier}'");
        }

        $data = [
            'id'           => $user->ID,
            'login'        => $user->user_login,
            'email'        => $user->user_email,
            'display_name' => $user->display_name,
            'first_name'   => $user->first_name,
            'last_name'    => $user->last_name,
            'nickname'     => $user->nickname,
            'description'  => $user->description,
            'url'          => $user->user_url,
            'roles'        => $user->roles,
            'capabilities' => array_keys(array_filter($user->allcaps)),
            'registered'   => $user->user_registered,
            'avatar_url'   => get_avatar_url($user->ID),
            'edit_url'     => get_edit_user_link($user->ID),
        ];

        if (!empty($parameters['include_meta'])) {
            $data['meta'] = get_user_meta($user->ID);
        }

        return $this->success($data);
    }

    private function resolveUser(string $identifier): ?\WP_User
    {
        if (ctype_digit($identifier)) {
            $u = get_user_by('id', (int) $identifier);
            if ($u) {
                return $u;
            }
        }
        if (is_email($identifier)) {
            $u = get_user_by('email', $identifier);
            if ($u) {
                return $u;
            }
        }
        $u = get_user_by('login', $identifier);
        if ($u) {
            return $u;
        }
        $u = get_user_by('slug', $identifier);
        return $u ?: null;
    }
}
