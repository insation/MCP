<?php
/**
 * List Roles Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\User;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ListRoles extends AbstractTool
{
    public function getName(): string
    {
        return 'list_roles';
    }

    public function getDescription(): string
    {
        return 'List all WordPress roles registered on this site, including their slugs, display names, and capabilities.';
    }

    public function getSchema(): array
    {
        return [
            'include_capabilities' => [
                'optional',
                'bool',
                'description' => 'When true, include the full capabilities array for each role. Default true.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $includeCaps = $parameters['include_capabilities'] ?? true;

        $wp_roles = wp_roles();
        $roles    = [];

        foreach ($wp_roles->roles as $slug => $info) {
            $entry = [
                'slug' => $slug,
                'name' => $info['name'] ?? $slug,
            ];
            if ($includeCaps) {
                $entry['capabilities'] = array_keys(array_filter($info['capabilities'] ?? []));
            } else {
                $entry['capability_count'] = count(array_filter($info['capabilities'] ?? []));
            }
            $roles[] = $entry;
        }

        return $this->success([
            'count' => count($roles),
            'items' => $roles,
        ]);
    }
}
