<?php
/**
 * Update User Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\User;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class UpdateUser extends AbstractTool
{
    public function getName(): string
    {
        return 'update_user';
    }

    public function getDescription(): string
    {
        return 'Update an existing user. Pass any subset of profile fields. To change roles, use manage_user_roles instead.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                'description' => 'User ID to update.'
            ],
            'email' => ['optional', 'string'],
            'password' => [
                'optional',
                'string',
                'description' => 'New plaintext password. Hashes via wp_set_password internally.'
            ],
            'first_name' => ['optional', 'string'],
            'last_name'  => ['optional', 'string'],
            'display_name' => ['optional', 'string'],
            'nickname' => ['optional', 'string'],
            'url' => ['optional', 'string'],
            'description' => ['optional', 'string'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $user_id = (int) $parameters['id'];
        if (!get_userdata($user_id)) {
            throw ToolException::wordpressError("User not found: ID {$user_id}");
        }

        $update = ['ID' => $user_id];

        if (isset($parameters['email'])) {
            $email = sanitize_email($parameters['email']);
            if (!is_email($email)) {
                throw ToolException::wordpressError("Invalid email: '{$parameters['email']}'");
            }
            $existing = email_exists($email);
            if ($existing && $existing !== $user_id) {
                throw ToolException::wordpressError("Email already in use by another user: '{$email}'");
            }
            $update['user_email'] = $email;
        }

        foreach (['first_name', 'last_name', 'display_name', 'nickname', 'description'] as $f) {
            if (isset($parameters[$f])) {
                $update[$f] = $parameters[$f];
            }
        }
        if (isset($parameters['url'])) {
            $update['user_url'] = esc_url_raw($parameters['url']);
        }
        if (isset($parameters['password'])) {
            $update['user_pass'] = $parameters['password'];
        }

        $result = wp_update_user($update);
        if (is_wp_error($result)) {
            throw ToolException::wordpressError('Failed to update user: ' . $result->get_error_message());
        }

        $user = get_userdata($user_id);
        return $this->success([
            'id'           => $user->ID,
            'login'        => $user->user_login,
            'email'        => $user->user_email,
            'display_name' => $user->display_name,
        ], 'User updated successfully.');
    }
}
