<?php
/**
 * Create User Tool
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\User;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class CreateUser extends AbstractTool
{
    public function getName(): string
    {
        return 'create_user';
    }

    public function getDescription(): string
    {
        return 'Create a new WordPress user. Requires unique login and email. Returns the new user ID. If no password is provided, a random one is generated.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'login' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Unique user_login (no spaces, lowercase recommended).'
            ],
            'email' => [
                'required',
                'string',
                'description' => 'Unique email address.'
            ],
            'password' => [
                'optional',
                'string',
                'description' => 'Plaintext password. If omitted, a strong random one is generated.'
            ],
            'role' => [
                'optional',
                'string',
                'description' => 'Role slug. Defaults to the site default registration role.'
            ],
            'first_name' => ['optional', 'string'],
            'last_name'  => ['optional', 'string'],
            'display_name' => ['optional', 'string'],
            'url' => ['optional', 'string'],
            'description' => ['optional', 'string'],
            'send_notification' => [
                'optional',
                'bool',
                'description' => 'Send the new-user notification email. Default false.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        $login = sanitize_user($parameters['login'], true);
        $email = sanitize_email($parameters['email']);

        if (!is_email($email)) {
            throw ToolException::wordpressError("Invalid email address: '{$parameters['email']}'");
        }
        if (username_exists($login)) {
            throw ToolException::wordpressError("User login already exists: '{$login}'");
        }
        if (email_exists($email)) {
            throw ToolException::wordpressError("Email already registered: '{$email}'");
        }

        $password = $parameters['password'] ?? wp_generate_password(20, true, true);
        $generated_password = empty($parameters['password']);

        $userdata = [
            'user_login' => $login,
            'user_email' => $email,
            'user_pass'  => $password,
        ];
        foreach (['first_name', 'last_name', 'display_name', 'description'] as $f) {
            if (isset($parameters[$f])) {
                $userdata[$f] = $parameters[$f];
            }
        }
        if (isset($parameters['url'])) {
            $userdata['user_url'] = esc_url_raw($parameters['url']);
        }
        if (isset($parameters['role'])) {
            $userdata['role'] = $parameters['role'];
        }

        $user_id = wp_insert_user($userdata);

        if (is_wp_error($user_id)) {
            throw ToolException::wordpressError('Failed to create user: ' . $user_id->get_error_message());
        }

        if (!empty($parameters['send_notification'])) {
            wp_new_user_notification($user_id, null, 'both');
        }

        return $this->success([
            'id'    => $user_id,
            'login' => $login,
            'email' => $email,
            'role'  => $userdata['role'] ?? get_option('default_role'),
            'generated_password' => $generated_password ? $password : null,
        ], 'User created successfully.');
    }
}
