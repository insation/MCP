<?php
/**
 * Manage Site Tool — create, update, archive, or delete a network site.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Multisite;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ManageSite extends AbstractTool
{
    public function getName(): string
    {
        return 'manage_site';
    }

    public function getDescription(): string
    {
        return 'Create, archive, unarchive, or delete a site in a multisite network. Requires admin scope.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:admin';
    }

    public function getSchema(): array
    {
        return [
            'action' => [
                'required',
                'string',
                ['in' => ['create', 'archive', 'unarchive', 'spam', 'unspam', 'delete']],
            ],
            'blog_id' => [
                'optional',
                'int',
                'description' => 'For archive/unarchive/spam/unspam/delete actions.'
            ],
            'domain' => [
                'optional',
                'string',
                'description' => 'For create: site domain (for subdomain installs) or main domain (for subdirectory installs).'
            ],
            'path' => [
                'optional',
                'string',
                'description' => 'For create: site path. Use / for the main site of a domain.'
            ],
            'title' => ['optional', 'string'],
            'admin_email' => ['optional', 'string'],
            'admin_user_id' => [
                'optional',
                'int',
                'description' => 'Existing user ID to assign as the site admin. Required for create.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!is_multisite()) {
            throw ToolException::wordpressError('This site is not a multisite network.');
        }

        $action = $parameters['action'];

        if ($action === 'create') {
            foreach (['domain', 'path', 'title', 'admin_user_id'] as $req) {
                if (empty($parameters[$req])) {
                    throw ToolException::wordpressError("'{$req}' is required for action=create");
                }
            }
            $user = get_userdata((int) $parameters['admin_user_id']);
            if (!$user) {
                throw ToolException::wordpressError("Admin user not found: ID {$parameters['admin_user_id']}");
            }

            if (!function_exists('wpmu_create_blog')) {
                require_once ABSPATH . 'wp-admin/includes/ms.php';
            }

            $network_id = get_current_network_id();
            $blog_id = wpmu_create_blog(
                $parameters['domain'],
                $parameters['path'],
                $parameters['title'],
                $user->ID,
                ['public' => 1],
                $network_id
            );
            if (is_wp_error($blog_id)) {
                throw ToolException::wordpressError('Failed to create site: ' . $blog_id->get_error_message());
            }
            return $this->success([
                'blog_id' => (int) $blog_id,
                'domain'  => $parameters['domain'],
                'path'    => $parameters['path'],
            ], 'Site created.');
        }

        // The remaining actions need a blog_id
        if (empty($parameters['blog_id'])) {
            throw ToolException::wordpressError("'blog_id' is required for action={$action}");
        }
        $blog_id = (int) $parameters['blog_id'];
        if (!get_site($blog_id)) {
            throw ToolException::wordpressError("Site not found: blog_id={$blog_id}");
        }

        switch ($action) {
            case 'archive':
                update_blog_status($blog_id, 'archived', 1);
                return $this->success(['blog_id' => $blog_id], 'Site archived.');
            case 'unarchive':
                update_blog_status($blog_id, 'archived', 0);
                return $this->success(['blog_id' => $blog_id], 'Site unarchived.');
            case 'spam':
                update_blog_status($blog_id, 'spam', 1);
                return $this->success(['blog_id' => $blog_id], 'Site marked as spam.');
            case 'unspam':
                update_blog_status($blog_id, 'spam', 0);
                return $this->success(['blog_id' => $blog_id], 'Site unmarked as spam.');
            case 'delete':
                $this->checkSafeMode('deleting network sites');
                if (!function_exists('wpmu_delete_blog')) {
                    require_once ABSPATH . 'wp-admin/includes/ms.php';
                }
                wpmu_delete_blog($blog_id, true);
                return $this->success(['blog_id' => $blog_id], 'Site permanently deleted.');
        }

        throw ToolException::wordpressError("Unhandled action: {$action}");
    }
}
