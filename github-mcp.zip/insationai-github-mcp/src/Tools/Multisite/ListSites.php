<?php
/**
 * List Sites Tool — multisite network sites.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Multisite;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class ListSites extends AbstractTool
{
    public function getName(): string
    {
        return 'list_sites';
    }

    public function getDescription(): string
    {
        return 'List sites in a WordPress multisite network. Only available on multisite. Use system_info to check whether multisite is enabled.';
    }

    public function getSchema(): array
    {
        return [
            'search' => [
                'optional',
                'string',
                'description' => 'Filter by domain or path substring.'
            ],
            'archived' => [
                'optional',
                'bool',
                'description' => 'When set, filter by archived status. Default: include all.'
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100],
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1],
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!is_multisite()) {
            throw ToolException::wordpressError('This site is not a multisite network.');
        }

        $perPage = $parameters['per_page'] ?? 20;
        $page    = $parameters['page'] ?? 1;

        $args = [
            'number'  => $perPage,
            'offset'  => ($page - 1) * $perPage,
            'orderby' => 'id',
            'order'   => 'ASC',
        ];
        if (!empty($parameters['search'])) {
            $args['search'] = $parameters['search'];
        }
        if (array_key_exists('archived', $parameters)) {
            $args['archived'] = $parameters['archived'] ? '1' : '0';
        }

        $sites = get_sites($args);
        $total = (int) get_sites(array_merge($args, ['count' => true, 'number' => 0, 'offset' => 0]));

        $items = array_map(static function ($s) {
            return [
                'id'          => (int) $s->blog_id,
                'domain'      => $s->domain,
                'path'        => $s->path,
                'site_id'     => (int) $s->site_id,
                'registered'  => $s->registered,
                'last_updated'=> $s->last_updated,
                'public'      => (int) $s->public,
                'archived'    => (int) $s->archived,
                'mature'      => (int) $s->mature,
                'spam'        => (int) $s->spam,
                'deleted'     => (int) $s->deleted,
                'lang_id'     => (int) $s->lang_id,
                'url'         => 'https://' . trim($s->domain, '/') . $s->path,
            ];
        }, $sites);

        return $this->success([
            'count'    => count($items),
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'items'    => $items,
        ]);
    }
}
