<?php
/**
 * Get Site Tool — multisite site details.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Tools\Multisite;

use InsationAI\GitHubMCP\Tools\AbstractTool;
use InsationAI\GitHubMCP\Exceptions\ToolException;

class GetSite extends AbstractTool
{
    public function getName(): string
    {
        return 'get_site';
    }

    public function getDescription(): string
    {
        return 'Get detail for a single multisite network site by blog ID, including its blogname, admin email, theme, and active plugins.';
    }

    public function getSchema(): array
    {
        return [
            'blog_id' => [
                'required',
                'int',
                'description' => 'The blog/site ID within the network.'
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        if (!is_multisite()) {
            throw ToolException::wordpressError('This site is not a multisite network.');
        }

        $blog_id = (int) $parameters['blog_id'];
        $site = get_site($blog_id);
        if (!$site) {
            throw ToolException::wordpressError("Site not found: blog_id={$blog_id}");
        }

        switch_to_blog($blog_id);
        try {
            $blogname    = get_option('blogname');
            $admin_email = get_option('admin_email');
            $template    = get_option('template');
            $stylesheet  = get_option('stylesheet');
            $active      = (array) get_option('active_plugins', []);
            $home        = get_option('home');
            $siteurl     = get_option('siteurl');
            $users_count = count_users();
        } finally {
            restore_current_blog();
        }

        return $this->success([
            'id'           => $blog_id,
            'domain'       => $site->domain,
            'path'         => $site->path,
            'url'          => 'https://' . trim($site->domain, '/') . $site->path,
            'home'         => $home,
            'siteurl'      => $siteurl,
            'blogname'     => $blogname,
            'admin_email'  => $admin_email,
            'template'     => $template,
            'stylesheet'   => $stylesheet,
            'active_plugins' => $active,
            'users'        => $users_count,
            'archived'     => (int) $site->archived,
            'spam'         => (int) $site->spam,
            'deleted'      => (int) $site->deleted,
            'public'       => (int) $site->public,
            'registered'   => $site->registered,
        ]);
    }
}
