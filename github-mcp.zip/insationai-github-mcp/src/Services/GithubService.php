<?php
declare(strict_types=1);

namespace InsationAI\GitHubMCP\Services;

/**
 * Thin GitHub REST wrapper. Reads the token + default owner/repo from options
 * (set in the admin GitHub tab) and performs all calls server-side, so the
 * token never leaves the site.
 */
class GithubService
{
    private const API     = 'https://api.github.com';
    private const UPLOADS = 'https://uploads.github.com';

    public function token(): string { return (string) get_option('insationai_ghmcp_github_token', ''); }
    public function owner(): string { return (string) get_option('insationai_ghmcp_github_owner', ''); }
    public function repo(): string  { return (string) get_option('insationai_ghmcp_github_repo', ''); }
    public function hasToken(): bool { return $this->token() !== ''; }

    public function resolve(?string $owner, ?string $repo): array
    {
        $o = ($owner !== null && $owner !== '') ? $owner : $this->owner();
        $r = ($repo  !== null && $repo  !== '') ? $repo  : $this->repo();
        return [$o, $r];
    }

    public static function encodePath(string $path): string
    {
        return implode('/', array_map('rawurlencode', explode('/', ltrim($path, '/'))));
    }

    private function headers(array $extra = []): array
    {
        return array_merge([
            'Authorization'        => 'Bearer ' . $this->token(),
            'Accept'               => 'application/vnd.github+json',
            'X-GitHub-Api-Version' => '2022-11-28',
            'User-Agent'           => 'GitHubMCP/2.0 (InsationAI)',
        ], $extra);
    }

    /**
     * JSON request against api.github.com. Returns ['status'=>int,'data'=>mixed] or WP_Error.
     */
    public function request(string $method, string $path, ?array $body = null)
    {
        if (!$this->hasToken()) {
            return new \WP_Error('no_token', 'GitHub token is not configured. Set it in the GitHub tab.');
        }
        $url  = strpos($path, 'http') === 0 ? $path : self::API . $path;
        $args = ['method' => $method, 'timeout' => 30, 'headers' => $this->headers()];
        if ($body !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body);
        }
        return $this->parse(wp_remote_request($url, $args));
    }

    /**
     * Upload a release asset to uploads.github.com.
     */
    public function uploadAsset(string $owner, string $repo, int $releaseId, string $name, string $bytes, string $contentType = 'application/octet-stream')
    {
        if (!$this->hasToken()) {
            return new \WP_Error('no_token', 'GitHub token is not configured.');
        }
        $url  = self::UPLOADS . "/repos/{$owner}/{$repo}/releases/{$releaseId}/assets?name=" . rawurlencode($name);
        $resp = wp_remote_post($url, [
            'timeout' => 180,
            'headers' => $this->headers(['Content-Type' => $contentType]),
            'body'    => $bytes,
        ]);
        return $this->parse($resp);
    }

    /**
     * Fetch raw bytes from a URL (server-side), e.g. a built zip to publish.
     */
    public function fetchBytes(string $url)
    {
        $resp = wp_remote_get($url, ['timeout' => 180]);
        if (is_wp_error($resp)) {
            return $resp;
        }
        $code = (int) wp_remote_retrieve_response_code($resp);
        if ($code < 200 || $code >= 300) {
            return new \WP_Error('fetch_failed', "Could not fetch source URL (HTTP {$code}).");
        }
        return wp_remote_retrieve_body($resp);
    }

    private function parse($resp)
    {
        if (is_wp_error($resp)) {
            return $resp;
        }
        $code = (int) wp_remote_retrieve_response_code($resp);
        $raw  = wp_remote_retrieve_body($resp);
        $data = json_decode($raw, true);
        if ($code < 200 || $code >= 300) {
            $msg = (is_array($data) && isset($data['message'])) ? $data['message'] : ('GitHub returned HTTP ' . $code);
            return new \WP_Error('github_error', $msg, ['status' => $code, 'response' => $data]);
        }
        return ['status' => $code, 'data' => $data];
    }
}
