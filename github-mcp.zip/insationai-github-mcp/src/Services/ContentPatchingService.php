<?php

declare(strict_types=1);

namespace InsationAI\GitHubMCP\Services;

use InsationAI\GitHubMCP\Exceptions\ToolException;
use Psr\Log\LoggerInterface;

/**
 * Service for patching WordPress content using search-replace operations.
 *
 * Provides sed-style text replacement with support for:
 * - Literal string search-replace
 * - Regex pattern matching
 * - Configurable replacement counts
 * - Diff preview generation
 * - Automatic content backups
 */
class ContentPatchingService
{
    /**
     * Maximum number of backups to keep per post.
     */
    private const MAX_BACKUPS = 5;

    /**
     * Maximum number of changes to include in diff preview.
     */
    private const MAX_PREVIEW_CHANGES = 10;

    /**
     * Number of context lines to show around changes in diff preview.
     */
    private const CONTEXT_LINES = 3;

    private WordPressService $wpService;
    private LoggerInterface $logger;

    public function __construct(WordPressService $wpService, LoggerInterface $logger)
    {
        $this->wpService = $wpService;
        $this->logger = $logger;
    }

    /**
     * Apply search-replace operations to content.
     *
     * @param string $content Original content to patch
     * @param array $operations Array of operations: [{search, replace, count, regex?}, ...]
     * @return array [patched_content, statistics, changes_detail]
     * @throws ToolException If operations are invalid or fail
     */
    public function applySearchReplace(string $content, array $operations): array
    {
        $this->validateOperations($operations);

        $patchedContent = $content;
        $totalReplacements = 0;
        $changesDetail = [];

        foreach ($operations as $index => $operation) {
            $search = $operation['search'];
            $replace = $operation['replace'];
            $count = $operation['count'];
            $isRegex = $operation['regex'] ?? false;

            $this->logger->info("Applying operation {$index}: search=" . substr($search, 0, 50));

            try {
                $result = $this->performReplacement(
                    $patchedContent,
                    $search,
                    $replace,
                    $count,
                    $isRegex
                );

                $patchedContent = $result['content'];
                $replacements = $result['count'];
                $totalReplacements += $replacements;

                $changesDetail[] = [
                    'operation_index' => $index,
                    'search' => substr($search, 0, 100), // Truncate for response
                    'replace' => substr($replace, 0, 100),
                    'replacements_made' => $replacements,
                    'is_regex' => $isRegex,
                ];

                $this->logger->info("Operation {$index} completed: {$replacements} replacements");
            } catch (\Exception $e) {
                throw ToolException::validationFailed(
                    "Operation {$index} failed: " . $e->getMessage()
                );
            }
        }

        $statistics = [
            'operations_applied' => count($operations),
            'total_replacements' => $totalReplacements,
            'original_length' => strlen($content),
            'new_length' => strlen($patchedContent),
            'length_change' => strlen($patchedContent) - strlen($content),
        ];

        return [
            'patched_content' => $patchedContent,
            'statistics' => $statistics,
            'changes_detail' => $changesDetail,
        ];
    }

    /**
     * Perform a single search-replace operation.
     *
     * @param string $content Content to search in
     * @param string $search Search pattern or literal string
     * @param string $replace Replacement string
     * @param int|string $count Number of replacements (1, "all", or specific number)
     * @param bool $isRegex Whether to treat search as regex pattern
     * @return array [content, count]
     * @throws ToolException
     */
    private function performReplacement(
        string $content,
        string $search,
        string $replace,
        $count,
        bool $isRegex
    ): array {
        if ($isRegex) {
            return $this->performRegexReplacement($content, $search, $replace, $count);
        }

        return $this->performLiteralReplacement($content, $search, $replace, $count);
    }

    /**
     * Perform literal string replacement.
     *
     * @param string $content Content to search in
     * @param string $search Literal string to find
     * @param string $replace Replacement string
     * @param int|string $count Number of replacements
     * @return array [content, count]
     * @throws ToolException
     */
    private function performLiteralReplacement(
        string $content,
        string $search,
        string $replace,
        $count
    ): array {
        // Check if search string exists
        if (strpos($content, $search) === false) {
            throw ToolException::validationFailed(
                "Search text not found in content: '" . substr($search, 0, 50) .
                (strlen($search) > 50 ? '...' : '') . "'",
                ['search' => 'Text not found in content']
            );
        }

        $replacementCount = 0;

        if ($count === 'all') {
            // Replace all occurrences
            $patchedContent = str_replace($search, $replace, $content, $replacementCount);
        } else {
            // Replace specific number of occurrences
            $limit = is_string($count) ? (int) $count : $count;
            if ($limit < 1) {
                throw ToolException::validationFailed("Count must be at least 1 or 'all'");
            }

            $patchedContent = $this->replaceNOccurrences($content, $search, $replace, $limit);
            $replacementCount = min($limit, substr_count($content, $search));
        }

        return [
            'content' => $patchedContent,
            'count' => $replacementCount,
        ];
    }

    /**
     * Perform regex pattern replacement.
     *
     * @param string $content Content to search in
     * @param string $pattern Regex pattern
     * @param string $replace Replacement string
     * @param int|string $count Number of replacements
     * @return array [content, count]
     * @throws ToolException
     */
    private function performRegexReplacement(
        string $content,
        string $pattern,
        string $replace,
        $count
    ): array {
        // Validate regex pattern
        if (@preg_match($pattern, '') === false) {
            throw ToolException::validationFailed("Invalid regex pattern: " . preg_last_error_msg());
        }

        $limit = ($count === 'all') ? -1 : (is_string($count) ? (int) $count : $count);
        if ($limit < -1 || $limit === 0) {
            throw ToolException::validationFailed("Count must be at least 1 or 'all'");
        }

        $patchedContent = preg_replace($pattern, $replace, $content, $limit, $replacementCount);

        if ($patchedContent === null) {
            throw ToolException::executionFailed("Regex replacement failed: " . preg_last_error_msg());
        }

        if ($replacementCount === 0) {
            throw ToolException::validationFailed(
                "Regex pattern not found in content: '" . substr($pattern, 0, 50) .
                (strlen($pattern) > 50 ? '...' : '') . "'"
            );
        }

        return [
            'content' => $patchedContent,
            'count' => $replacementCount,
        ];
    }

    /**
     * Replace first N occurrences of a string.
     *
     * @param string $content Content to search in
     * @param string $search String to find
     * @param string $replace Replacement string
     * @param int $limit Maximum number of replacements
     * @return string Modified content
     */
    private function replaceNOccurrences(
        string $content,
        string $search,
        string $replace,
        int $limit
    ): string {
        $offset = 0;
        $result = $content;

        for ($i = 0; $i < $limit; $i++) {
            $pos = strpos($result, $search, $offset);
            if ($pos === false) {
                break; // No more occurrences found
            }

            $result = substr_replace($result, $replace, $pos, strlen($search));
            $offset = $pos + strlen($replace);
        }

        return $result;
    }

    /**
     * Generate a diff preview showing before/after changes.
     *
     * @param string $original Original content
     * @param string $patched Patched content
     * @return array Array of change previews with context
     */
    public function generateDiffPreview(string $original, string $patched): array
    {
        // Split into lines for comparison
        $originalLines = explode("\n", $original);
        $patchedLines = explode("\n", $patched);

        $preview = [];
        $changesFound = 0;

        // Simple line-by-line comparison
        $maxLines = max(count($originalLines), count($patchedLines));

        for ($i = 0; $i < $maxLines && $changesFound < self::MAX_PREVIEW_CHANGES; $i++) {
            $origLine = $originalLines[$i] ?? '';
            $patchLine = $patchedLines[$i] ?? '';

            if ($origLine !== $patchLine) {
                // Found a change - capture context
                $contextBefore = $this->getContextLines($originalLines, $i, self::CONTEXT_LINES, 'before');
                $contextAfter = $this->getContextLines($patchedLines, $i, self::CONTEXT_LINES, 'after');

                $preview[] = [
                    'line_number' => $i + 1,
                    'before' => $this->truncateLine($origLine, 200),
                    'after' => $this->truncateLine($patchLine, 200),
                    'context_before' => $contextBefore,
                    'context_after' => $contextAfter,
                ];

                $changesFound++;
            }
        }

        // If content is too different (complete rewrite), show summary instead
        if (count($preview) > self::MAX_PREVIEW_CHANGES / 2 && count($preview) === self::MAX_PREVIEW_CHANGES) {
            return [
                [
                    'summary' => 'Extensive changes detected',
                    'total_lines_original' => count($originalLines),
                    'total_lines_patched' => count($patchedLines),
                    'preview_truncated' => true,
                ]
            ];
        }

        return $preview;
    }

    /**
     * Get context lines around a change.
     *
     * @param array $lines All lines
     * @param int $index Index of changed line
     * @param int $count Number of context lines to get
     * @param string $direction 'before' or 'after'
     * @return array Context lines
     */
    private function getContextLines(array $lines, int $index, int $count, string $direction): array
    {
        if ($direction === 'before') {
            $start = max(0, $index - $count);
            $length = $index - $start;
        } else {
            $start = $index + 1;
            $length = $count;
        }

        $context = array_slice($lines, $start, $length);
        return array_map(fn($line) => $this->truncateLine($line, 100), $context);
    }

    /**
     * Truncate a line to a maximum length.
     *
     * @param string $line Line to truncate
     * @param int $maxLength Maximum length
     * @return string Truncated line
     */
    private function truncateLine(string $line, int $maxLength): string
    {
        if (strlen($line) <= $maxLength) {
            return $line;
        }

        return substr($line, 0, $maxLength) . '...';
    }

    /**
     * Create a backup of content in post meta.
     *
     * @param int $postId Post ID
     * @param string $content Content to backup
     * @return string Backup meta key
     */
    public function createBackup(int $postId, string $content): string
    {
        $timestamp = time();
        $backupKey = "_insationai_ghmcp_content_backup_{$timestamp}";

        // Store backup
        update_post_meta($postId, $backupKey, $content);

        $this->logger->info("Created content backup for post {$postId}: {$backupKey}");

        // Clean up old backups
        $this->cleanupOldBackups($postId);

        return $backupKey;
    }

    /**
     * Clean up old backups, keeping only the most recent ones.
     *
     * @param int $postId Post ID
     */
    private function cleanupOldBackups(int $postId): void
    {
        global $wpdb;

        // Get all backup keys for this post
        $backupKeys = $wpdb->get_col($wpdb->prepare(
            "SELECT meta_key FROM {$wpdb->postmeta}
             WHERE post_id = %d
             AND meta_key LIKE '_insationai_ghmcp_content_backup_%%'
             ORDER BY meta_key DESC",
            $postId
        ));

        // Delete old backups (keep only MAX_BACKUPS most recent)
        if (count($backupKeys) > self::MAX_BACKUPS) {
            $toDelete = array_slice($backupKeys, self::MAX_BACKUPS);
            foreach ($toDelete as $key) {
                delete_post_meta($postId, $key);
                $this->logger->info("Deleted old backup: {$key}");
            }
        }
    }

    /**
     * Validate search-replace operations array.
     *
     * @param array $operations Operations to validate
     * @throws ToolException If validation fails
     */
    public function validateOperations(array $operations): void
    {
        if (empty($operations)) {
            throw ToolException::validationFailed("At least one operation is required");
        }

        foreach ($operations as $index => $operation) {
            if (!is_array($operation)) {
                throw ToolException::validationFailed("Operation {$index} must be an array");
            }

            // Check required fields
            if (!isset($operation['search'])) {
                throw ToolException::validationFailed("Operation {$index} missing 'search' field");
            }

            if (!isset($operation['replace'])) {
                throw ToolException::validationFailed("Operation {$index} missing 'replace' field");
            }

            if (!isset($operation['count'])) {
                throw ToolException::validationFailed("Operation {$index} missing 'count' field");
            }

            // Validate types
            if (!is_string($operation['search'])) {
                throw ToolException::validationFailed("Operation {$index} 'search' must be a string");
            }

            if (!is_string($operation['replace'])) {
                throw ToolException::validationFailed("Operation {$index} 'replace' must be a string");
            }

            // Validate count (can be 'all', integer, or numeric string)
            $count = $operation['count'];
            if ($count !== 'all') {
                // Accept both integer and numeric string
                if (is_string($count) && ctype_digit($count)) {
                    $count = (int) $count;
                }
                if (!is_int($count) || $count < 1) {
                    throw ToolException::validationFailed(
                        "Operation {$index} 'count' must be 'all' or a positive integer"
                    );
                }
            }

            // Validate regex flag if present
            if (isset($operation['regex']) && !is_bool($operation['regex'])) {
                throw ToolException::validationFailed("Operation {$index} 'regex' must be a boolean");
            }

            // Don't allow empty search
            if ($operation['search'] === '') {
                throw ToolException::validationFailed("Operation {$index} 'search' cannot be empty");
            }
        }
    }
}
