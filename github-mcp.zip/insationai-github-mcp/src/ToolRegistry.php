<?php
/**
 * Tool Registry
 *
 * Central source of truth for tool metadata. Both the runtime registrars
 * (mcp-http.php, register-abilities.php) and the admin Tools toggle UI
 * consume this so they stay in lockstep — there is no place to add a tool
 * to one side without the other.
 *
 * @package InsationAI\GitHubMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\GitHubMCP;

use InsationAI\GitHubMCP\Services\ValidationService;
use InsationAI\GitHubMCP\Services\WordPressService;
use InsationAI\GitHubMCP\Services\ContentPatchingService;
use InsationAI\GitHubMCP\Logger\WordPressLogger;
use InsationAI\GitHubMCP\Tools\AbstractTool;

class ToolRegistry
{
    public const DISABLED_OPTION = 'insationai_ghmcp_disabled_tools';

    /**
     * Build every tool instance. The optional patching service is required
     * by PatchContent and instantiated only when not supplied (e.g. from
     * Abilities API context that doesn't already have one constructed).
     *
     * @return AbstractTool[]
     */
    public static function buildAllTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        if ($patching === null) {
            $patching = new ContentPatchingService($wp, $logger);
        }

        $tools = [
            // GitHub
            new Tools\Github\GithubGetConfig($wp, $validator, $logger),
            new Tools\Github\GithubGetRepo($wp, $validator, $logger),
            new Tools\Github\GithubListReleases($wp, $validator, $logger),
            new Tools\Github\GithubCreateRelease($wp, $validator, $logger),
            new Tools\Github\GithubUploadReleaseAsset($wp, $validator, $logger),
            new Tools\Github\GithubPutFile($wp, $validator, $logger),
        ];

        // Multisite tools — only when on a multisite network
        if (is_multisite()) {
            $tools[] = new Tools\Multisite\ListSites($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\GetSite($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\ManageSite($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\ManageNetworkUsers($wp, $validator, $logger);
            $tools[] = new Tools\Multisite\NetworkActivatePlugin($wp, $validator, $logger);
        }

        // Opt-in tool gated by its own constant
        if (Tools\Code\ExecutePhp::isEnabled()) {
            $tools[] = new Tools\Code\ExecutePhp($wp, $validator, $logger);
        }

        return $tools;
    }

    /**
     * Build the list of tools, with disabled ones filtered out.
     *
     * @return AbstractTool[]
     */
    public static function buildEnabledTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $all = self::buildAllTools($wp, $validator, $logger, $patching);
        $disabled = self::getDisabledToolNames();
        if (empty($disabled)) {
            return $all;
        }
        return array_values(array_filter(
            $all,
            static fn(AbstractTool $t) => !in_array($t->getName(), $disabled, true)
        ));
    }

    /**
     * Read the option that stores disabled tool names.
     *
     * @return string[]
     */
    public static function getDisabledToolNames(): array
    {
        $stored = get_option(self::DISABLED_OPTION, []);
        return is_array($stored) ? array_values(array_filter(array_map('strval', $stored))) : [];
    }

    /**
     * Persist the disabled tool names array.
     *
     * @param string[] $names
     */
    public static function setDisabledToolNames(array $names): void
    {
        $clean = array_values(array_unique(array_filter(array_map('sanitize_text_field', $names))));
        update_option(self::DISABLED_OPTION, $clean);
    }

    /**
     * Stable category slug for a tool name. Mirrors the category logic in
     * register-abilities.php so the admin UI and the abilities API agree.
     */
    public static function categoryFor(string $toolName): string
    {
        if (strpos($toolName, 'github') === 0) {
            return 'github';
        }
        if (str_starts_with($toolName, 'plugin_')) {
            return 'plugins';
        }
        if (str_starts_with($toolName, 'theme_')) {
            return 'themes';
        }
        if (str_starts_with($toolName, 'media_')) {
            return 'media';
        }
        if (str_starts_with($toolName, 'execute_')) {
            return 'code';
        }
        if (
            $toolName === 'list_users' || $toolName === 'get_user' ||
            $toolName === 'create_user' || $toolName === 'update_user' ||
            $toolName === 'delete_user' || $toolName === 'list_roles' ||
            $toolName === 'manage_user_roles' || $toolName === 'manage_capabilities'
        ) {
            return 'users';
        }
        if (
            $toolName === 'list_comments' || $toolName === 'get_comment' ||
            $toolName === 'create_comment' || $toolName === 'update_comment' ||
            $toolName === 'delete_comment' || $toolName === 'moderate_comment'
        ) {
            return 'comments';
        }
        if (
            str_ends_with($toolName, '_option') || $toolName === 'list_options' ||
            str_ends_with($toolName, '_transient') || $toolName === 'manage_theme_mods'
        ) {
            return 'options';
        }
        if (
            $toolName === 'list_menus' || $toolName === 'get_menu' ||
            $toolName === 'manage_menu' || $toolName === 'manage_menu_items' ||
            $toolName === 'assign_menu_location'
        ) {
            return 'menus';
        }
        if (
            $toolName === 'list_sidebars' || $toolName === 'list_widgets' ||
            $toolName === 'manage_widget' || $toolName === 'manage_block_widgets'
        ) {
            return 'widgets';
        }
        if (
            $toolName === 'list_patterns' || $toolName === 'manage_pattern' ||
            $toolName === 'list_reusable_blocks'
        ) {
            return 'patterns';
        }
        if (
            $toolName === 'get_customizer_settings' ||
            $toolName === 'update_customizer_setting' ||
            $toolName === 'export_customizer'
        ) {
            return 'customizer';
        }
        if (
            $toolName === 'list_scheduled_events' || $toolName === 'schedule_event' ||
            $toolName === 'unschedule_event' || $toolName === 'run_event_now'
        ) {
            return 'cron';
        }
        if (
            $toolName === 'list_rewrite_rules' || $toolName === 'flush_rewrite_rules' ||
            $toolName === 'add_rewrite_rule'
        ) {
            return 'rewrites';
        }
        if (
            $toolName === 'db_query' || $toolName === 'db_table_info' ||
            $toolName === 'optimize_tables' || $toolName === 'repair_tables' ||
            str_starts_with($toolName, 'cleanup_') || $toolName === 'search_replace'
        ) {
            return 'database';
        }
        if (
            $toolName === 'system_info' || $toolName === 'site_health_check' ||
            str_starts_with($toolName, 'debug_log_') || $toolName === 'list_hooks_on_action'
        ) {
            return 'diagnostics';
        }
        if (
            $toolName === 'list_sites' || $toolName === 'get_site' ||
            $toolName === 'manage_site' || $toolName === 'manage_network_users' ||
            $toolName === 'network_activate_plugin'
        ) {
            return 'multisite';
        }
        if (
            $toolName === 'manage_robots_txt' || $toolName === 'manage_sitemap' ||
            $toolName === 'manage_redirects'
        ) {
            return 'seo';
        }
        if (
            $toolName === 'export_content' || $toolName === 'import_content' ||
            $toolName === 'backup_database'
        ) {
            return 'export-import';
        }
        if (
            $toolName === 'list_recent_tool_calls' || $toolName === 'clear_audit_log'
        ) {
            return 'audit';
        }
        if (
            str_contains($toolName, 'term') || str_contains($toolName, 'tax') ||
            str_starts_with($toolName, 'discover_taxonomies')
        ) {
            return 'taxonomy';
        }
        return 'content';
    }

    /**
     * Human-readable label for a category slug.
     */
    public static function categoryLabel(string $slug): string
    {
        $labels = [
            'github' => 'GitHub',
            'content'       => __('Content', 'insationai-github-mcp'),
            'taxonomy'      => __('Taxonomy', 'insationai-github-mcp'),
            'media'         => __('Media', 'insationai-github-mcp'),
            'plugins'       => __('Plugins', 'insationai-github-mcp'),
            'themes'        => __('Themes', 'insationai-github-mcp'),
            'code'          => __('Code Execution', 'insationai-github-mcp'),
            'users'         => __('Users & Roles', 'insationai-github-mcp'),
            'comments'      => __('Comments', 'insationai-github-mcp'),
            'options'       => __('Options & Settings', 'insationai-github-mcp'),
            'menus'         => __('Menus', 'insationai-github-mcp'),
            'widgets'       => __('Widgets', 'insationai-github-mcp'),
            'patterns'      => __('Block Patterns', 'insationai-github-mcp'),
            'customizer'    => __('Customizer', 'insationai-github-mcp'),
            'cron'          => __('Cron', 'insationai-github-mcp'),
            'rewrites'      => __('Rewrites', 'insationai-github-mcp'),
            'database'      => __('Database', 'insationai-github-mcp'),
            'diagnostics'   => __('Diagnostics', 'insationai-github-mcp'),
            'multisite'     => __('Multisite', 'insationai-github-mcp'),
            'seo'           => __('SEO & Redirects', 'insationai-github-mcp'),
            'export-import' => __('Export & Import', 'insationai-github-mcp'),
            'audit'         => __('Audit Log', 'insationai-github-mcp'),
        ];
        return $labels[$slug] ?? ucfirst(str_replace('-', ' ', $slug));
    }
}
