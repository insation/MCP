<?php

namespace InsationAI\GitHubMCP\Auth;

use InsationAI\GitHubMCP\OAuth\JwtService;
use InsationAI\GitHubMCP\OAuth\TokenRepository;

/**
 * Authentication Manager
 *
 * Orchestrates authentication strategy selection:
 * - OAuth (JWT tokens) - highest priority
 * - Static bearer tokens - fallback
 * - No authentication - default
 */
class AuthenticationManager
{
    private array $config;
    private ?OAuthAuthenticator $oauthAuth = null;
    private ?BearerTokenAuth $bearerAuth = null;

    public function __construct(array $config)
    {
        $this->config = $config;
        $this->initializeAuthenticators();
    }

    /**
     * Initialize authenticators based on configuration
     */
    private function initializeAuthenticators(): void
    {
        $oauthConfig = $this->config['oauth'] ?? [];

        // Initialize OAuth if enabled
        if (!empty($oauthConfig['enabled'])) {
            try {
                $jwtService = new JwtService(
                    $oauthConfig['private_key_path'],
                    $oauthConfig['public_key_path'],
                    $oauthConfig['issuer'],
                    $oauthConfig['resource_identifier']
                );

                $tokenRepo = new \InsationAI\GitHubMCP\OAuth\TokenRepository();
                $this->oauthAuth = new OAuthAuthenticator($jwtService, $tokenRepo);
            } catch (\Exception $e) {
                // Log error but don't fail - fall back to other methods
                error_log("Failed to initialize OAuth: " . $e->getMessage());
            }
        }

        // Initialize bearer token auth (always available)
        $this->bearerAuth = new BearerTokenAuth();
    }

    /**
     * Authenticate the incoming request
     *
     * Priority:
     * 1. OAuth (if enabled and JWT token present)
     * 2. User token authentication (query param or header)
     *
     * No open access mode - authentication is always required.
     *
     * @return array{authenticated: bool, error: ?string, headers: array, user: ?array, method: string}
     */
    public function authenticate(): array
    {
        // Try OAuth first (highest priority)
        if ($this->oauthAuth !== null) {
            $result = $this->oauthAuth->validate();

            // If OAuth token present but invalid, fail immediately
            if (!$result['authenticated'] && $result['error'] !== 'Authentication required') {
                return array_merge($result, ['method' => 'oauth']);
            }

            // If OAuth authentication succeeded
            if ($result['authenticated']) {
                return array_merge($result, ['method' => 'oauth']);
            }

            // No OAuth token present - fall through to try user token
        }

        // Try user token authentication (query param or header)
        $result = $this->bearerAuth->validate();

        if (!$result['authenticated']) {
            return array_merge($result, ['method' => 'token']);
        }

        return [
            'authenticated' => true,
            'error' => null,
            'headers' => [],
            'user' => $result['user'],
            'method' => 'token'
        ];
    }

    /**
     * Get authentication method being used
     *
     * @return string 'oauth' or 'token'
     */
    public function getAuthenticationMethod(): string
    {
        if ($this->oauthAuth !== null) {
            return 'oauth_or_token';
        }

        return 'token';
    }

    /**
     * Check if any authentication is enabled
     *
     * @return bool Always true - authentication is always required
     */
    public function isAuthenticationEnabled(): bool
    {
        return true;
    }

    /**
     * Send authentication error response in proper JSON-RPC 2.0 format.
     *
     * Echoes the request's `id` field (or null when it can't be read) so
     * compliant MCP clients can pair the error with the originating request.
     * Falls back to a plain JSON error response on GET / OPTIONS where there
     * is no JSON-RPC payload to echo.
     *
     * @param string $error Error message
     * @param array<string, string> $headers Response headers
     */
    public function sendUnauthorizedResponse(string $error, array $headers = []): void
    {
        http_response_code(401);
        header('Content-Type: application/json');

        foreach ($headers as $name => $value) {
            header("$name: $value");
        }

        // Try to read the incoming JSON-RPC id so we can echo it.
        // POST requests carry the JSON-RPC payload; GET/OPTIONS don't.
        $id = null;
        $hasJsonRpc = false;
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $body = file_get_contents('php://input');
            if (is_string($body) && $body !== '') {
                $decoded = json_decode($body, true);
                if (is_array($decoded) && isset($decoded['jsonrpc']) && $decoded['jsonrpc'] === '2.0') {
                    $hasJsonRpc = true;
                    // id may be a string, int, or null per JSON-RPC spec
                    $id = $decoded['id'] ?? null;
                }
            }
        }

        if ($hasJsonRpc) {
            // Proper JSON-RPC 2.0 error envelope; id is echoed verbatim.
            echo json_encode([
                'jsonrpc' => '2.0',
                'id'      => $id,
                'error'   => [
                    // -32001 is a convention for application-defined auth errors
                    'code'    => -32001,
                    'message' => 'Unauthorized: ' . $error,
                    'data'    => [
                        'authentication_method' => $this->getAuthenticationMethod(),
                    ],
                ],
            ]);
            return;
        }

        // No JSON-RPC payload (likely GET/OPTIONS) — emit a plain JSON error
        // which is what HTTP-aware clients expect at this layer.
        echo json_encode([
            'error'   => 'Unauthorized',
            'message' => $error,
            'authentication_method' => $this->getAuthenticationMethod(),
        ]);
    }
}
