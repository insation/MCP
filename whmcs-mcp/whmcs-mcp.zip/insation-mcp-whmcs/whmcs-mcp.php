<?php
/**
 * Insation MCP Server — root launcher (serves MCP + OAuth from the web root).
 *
 * Many WHMCS/cPanel/LiteSpeed hosts block direct web access to /modules/, so
 * the addon's own mcp.php/oauth.php can't be reached there. Put THIS file at
 * the WHMCS web root (next to init.php / configuration.php), e.g.
 *   public_html/whmcs-mcp.php
 * and point your MCP client at:
 *   https://your-site/whmcs-mcp.php
 *
 * It defines the public URL the OAuth metadata advertises, then includes the
 * real endpoint. `require` keeps each included file's own __DIR__, so all of
 * the addon's internal paths (init.php, lib/*) still resolve.
 *
 * @package InsationMCP
 */
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
if (!defined('INSATION_MCP_PUBLIC')) {
    define(
        'INSATION_MCP_PUBLIC',
        $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . ($_SERVER['SCRIPT_NAME'] ?? '/whmcs-mcp.php')
    );
}

if (isset($_GET['oauth'])) {
    $_GET['a'] = preg_replace('/[^a-z_]/', '', (string) $_GET['oauth']);
    require __DIR__ . '/modules/addons/insation_mcp/oauth.php';
} else {
    require __DIR__ . '/modules/addons/insation_mcp/mcp.php';
}
