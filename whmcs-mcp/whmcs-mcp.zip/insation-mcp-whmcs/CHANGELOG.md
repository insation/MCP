# Changelog

## 2.3.0
- Added `whmcs_update_product` and `whmcs_delete_product` (Products now 4 tools; 70 total). Delete is guarded: requires `force=true` and refuses if active/pending/suspended services still use the product.

## 2.2.0
- Root‑launcher model (`whmcs-mcp.php`): serves the MCP endpoint and all OAuth
  endpoints from the WHMCS web root, so the addon works on hosts that block
  direct access to `/modules/`. All OAuth discovery/metadata URLs derive from
  the launcher automatically.
- OAuth 2.1 authorization: protected‑resource + authorization‑server metadata,
  dynamic client registration, authorization‑code flow with PKCE (S256), and
  refresh tokens. Consent is granted with an API token.
- `mcp.php` accepts OAuth access tokens and advertises discovery via
  `WWW‑Authenticate`.
- Hardened bootstrap: CORS handled before WHMCS loads, OPTIONS short‑circuited,
  fatal‑error safety net returns a readable JSON error.
- Verified on WHMCS 9.0.4 / PHP 8.

## 1.x
- Initial release: 68 WHMCS tools, three‑tab admin (API Keys, Tool Management,
  Settings), per‑site licensing against insation.ai, bearer‑token auth with a
  one‑time token reveal and Usage URL.
