INSATION MCP SERVER — connection setup (v2.2, root-launcher model)
==================================================================

Why: many hosts (cPanel/LiteSpeed) block direct web access to /modules/, so the
addon's endpoints are served through ONE file at the WHMCS web root.

INSTALL
-------
1. Upload the insation_mcp/ folder to:  <whmcs-root>/modules/addons/insation_mcp/
   Activate it in WHMCS and activate your license (Addons > MCP Server).
2. Upload whmcs-mcp.php to the WHMCS web root (next to init.php), e.g.
   public_html/whmcs-mcp.php
3. Your public MCP URL is:   https://YOUR-SITE/whmcs-mcp.php
   Verify in a browser:       https://YOUR-SITE/whmcs-mcp.php?t=YOUR_API_TOKEN
   (should return JSON, not 404/blank)

OPTION A — Bearer token (simplest, works now)
---------------------------------------------
Claude Desktop config (%APPDATA%\Claude\claude_desktop_config.json) or
Claude Code (.claude.json):

  "whmcs": {
    "command": "npx",
    "args": ["-y","mcp-remote","https://YOUR-SITE/whmcs-mcp.php",
             "--header","Authorization: Bearer YOUR_API_TOKEN"]
  }

OPTION B — OAuth 2.1 (native "Add custom connector", no bridge)
--------------------------------------------------------------
Add these rewrite rules to the WHMCS ROOT .htaccess (inside the mod_rewrite
block, ABOVE the WHMCS friendly-url rules) so OAuth discovery can find the
metadata at the domain root:

    RewriteEngine On
    RewriteRule "^\.well-known/oauth-authorization-server/whmcs-mcp\.php$" "whmcs-mcp.php?oauth=asm" [L,QSA]
    RewriteRule "^\.well-known/oauth-protected-resource/whmcs-mcp\.php$"   "whmcs-mcp.php?oauth=prm" [L,QSA]
    RewriteRule "^\.well-known/oauth-authorization-server$"                "whmcs-mcp.php?oauth=asm" [L,QSA]
    RewriteRule "^\.well-known/oauth-protected-resource$"                  "whmcs-mcp.php?oauth=prm" [L,QSA]

Verify (should return JSON):
    https://YOUR-SITE/whmcs-mcp.php?oauth=prm
    https://YOUR-SITE/.well-known/oauth-authorization-server/whmcs-mcp.php

Then in Claude Desktop: Settings > Connectors > Add custom connector >
URL: https://YOUR-SITE/whmcs-mcp.php  > Connect. On the consent screen, paste
an API token (API Keys tab) to approve. Claude exchanges it and loads the tools.

NOTE: all OAuth URLs are derived from whmcs-mcp.php automatically — no hardcoded
paths. If you rename the launcher, the metadata follows it.
