# WHMCSMCP — MCP Server for WHMCS

Turn your WHMCS install into a secure **Model Context Protocol (MCP)** server for
AI assistants (Claude, Cursor, Codex, and any MCP‑compatible client). Exposes 68
WHMCS operations — clients, products, services, invoices, quotes, orders,
support tickets, domains, affiliates and system tools — over an authenticated
HTTP endpoint, with **per‑site licensing** verified against insation.ai.

By **InsationAI** · https://insation.ai

---

## Features

- **70 tools across 10 areas** — Client Management (5), Products (4), Service
  Management (8), Invoice Management (8), Quote Management (6), Order Management
  (6), Support Tickets (9), Domain Management (10), Affiliates & Promotions (3),
  and System/operations (11).
- **Two ways to connect** — OAuth 2.1 (native "Add custom connector" by URL) or a
  bearer token via the `mcp-remote` bridge.
- **Per‑tool controls** — enable/disable any tool from the admin; disabled tools
  are rejected by the API and omitted from `tools/list`.
- **Scoped execution** — every call runs through the WHMCS local API as a WHMCS
  admin user you choose, so the AI can only do what that admin is permitted to do.
- **Strict per‑site licensing** — the endpoint only serves on a licensed,
  activated install (verified against insation.ai).
- **Bearer tokens** stored as SHA‑256 hashes; shown once at creation.

## Requirements

- WHMCS 8.x or 9.x
- PHP 7.4+ (PHP 8.x recommended)
- HTTPS (MCP requires TLS 1.2+)
- Node.js on the client machine only if using the `mcp-remote` bridge

## Install

1. Copy the **`insation_mcp/`** folder to `<whmcs-root>/modules/addons/insation_mcp/`.
2. Copy **`whmcs-mcp.php`** to the WHMCS **web root** (next to `init.php` /
   `configuration.php`, e.g. `public_html/whmcs-mcp.php`). This is the public
   endpoint — it works even on hosts that block direct access to `/modules/`.
3. In WHMCS admin: **Setup → Addon Modules** (or **System Settings → Addon
   Modules**) → activate **MCP Server** and grant admin‑role access.
4. Open the addon → **Settings → License**, paste your license key, **Activate**.
5. **Settings → Configuration** — choose the WHMCS admin the tools run as.
6. **API Keys** — generate a token (shown once).

Your public MCP URL is: `https://YOUR-SITE/whmcs-mcp.php`
Verify in a browser: `https://YOUR-SITE/whmcs-mcp.php?t=YOUR_API_TOKEN` → returns JSON.

## Connecting an AI client

See **[docs/CONNECTING.md](docs/CONNECTING.md)** for full details. In short:

- **Bearer token (simplest):** point an `mcp-remote` config at
  `https://YOUR-SITE/whmcs-mcp.php` with an `Authorization: Bearer <token>` header.
- **OAuth 2.1 (native connector):** add two `.well-known` rewrite rules to your
  root `.htaccess` (in the connecting guide), then Claude Desktop → Add custom
  connector → `https://YOUR-SITE/whmcs-mcp.php` → approve with an API token.

## Why the root launcher?

Many WHMCS/cPanel/LiteSpeed hosts block direct web access to `/modules/`, which
would 404 the addon's own endpoints. `whmcs-mcp.php` lives at the web root (which
is served) and includes the real endpoint, and it tells the OAuth layer its own
public URL so all discovery/metadata uses the root path. It also survives WHMCS
updates that can overwrite files under `/modules/`.

## Security

- Endpoint refuses all requests unless the install is **licensed** and the
  endpoint toggle is **on**.
- Bearer tokens hashed (SHA‑256); OAuth uses authorization‑code + PKCE (S256) with
  short‑lived access tokens and refresh tokens.
- Tools run as a single, configurable WHMCS admin — scope it with WHMCS roles.

## Support

support@insation.ai

## License

Commercial, per‑site. See [LICENSE](LICENSE).
