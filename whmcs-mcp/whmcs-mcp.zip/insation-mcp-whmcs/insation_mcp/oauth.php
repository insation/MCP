<?php
/**
 * Insation MCP Server — OAuth 2.1 endpoint.
 *
 * Dispatches by ?a=:
 *   prm       Protected Resource Metadata (RFC 9728)
 *   asm       Authorization Server Metadata (RFC 8414)
 *   register  Dynamic Client Registration (RFC 7591)  [POST JSON]
 *   authorize Authorization Code consent + issue code (PKCE)
 *   token     Token endpoint (authorization_code / refresh_token) [POST]
 *
 * @package InsationMCP
 */

if (!headers_sent()) {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Vary: Origin');
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(['error' => 'server_error', 'error_description' => $e['message']]);
    }
});

require __DIR__ . '/../../../init.php';

require_once __DIR__ . '/lib/Settings.php';
require_once __DIR__ . '/lib/Auth.php';
require_once __DIR__ . '/lib/OAuth.php';

use InsationMCP\Settings;
use InsationMCP\Auth;
use InsationMCP\OAuth;

Settings::installSchema();

function imcp_oauth_json($data, $status = 200)
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('Access-Control-Allow-Origin: *');
    }
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function imcp_h($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

$a = isset($_GET['a']) ? preg_replace('/[^a-z_]/', '', $_GET['a']) : '';

switch ($a) {
    case 'prm':
        imcp_oauth_json(OAuth::protectedResourceMetadata());
        break;

    case 'asm':
        imcp_oauth_json(OAuth::authServerMetadata());
        break;

    case 'register':
        $body = json_decode(file_get_contents('php://input'), true);
        if (!is_array($body)) {
            $body = $_POST;
        }
        try {
            imcp_oauth_json(OAuth::registerClient($body), 201);
        } catch (\Throwable $e) {
            imcp_oauth_json(['error' => 'invalid_client_metadata', 'error_description' => $e->getMessage()], 400);
        }
        break;

    case 'authorize':
        $clientId    = $_REQUEST['client_id'] ?? '';
        $redirectUri = $_REQUEST['redirect_uri'] ?? '';
        $state       = $_REQUEST['state'] ?? '';
        $challenge   = $_REQUEST['code_challenge'] ?? '';
        $method      = $_REQUEST['code_challenge_method'] ?? 'S256';
        $responseType = $_REQUEST['response_type'] ?? 'code';

        $client = OAuth::getClient($clientId);
        if (!$client || !OAuth::redirectAllowed($client, $redirectUri)) {
            http_response_code(400);
            echo 'Invalid client_id or redirect_uri.';
            exit;
        }
        if ($responseType !== 'code' || $challenge === '' || $method !== 'S256') {
            $sep = (strpos($redirectUri, '?') !== false) ? '&' : '?';
            header('Location: ' . $redirectUri . $sep . 'error=invalid_request&state=' . urlencode($state));
            exit;
        }

        // Consent submission.
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['approve'])) {
            $apiToken = trim($_POST['api_token'] ?? '');
            $key = Auth::verify($apiToken);
            if (!$key) {
                $err = 'Invalid API token. Generate one on the API Keys tab and paste it here.';
            } else {
                $code = OAuth::createCode($clientId, $redirectUri, $challenge, $method, $key->id);
                $sep = (strpos($redirectUri, '?') !== false) ? '&' : '?';
                header('Location: ' . $redirectUri . $sep . 'code=' . urlencode($code) . '&state=' . urlencode($state));
                exit;
            }
        } elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['deny'])) {
            $sep = (strpos($redirectUri, '?') !== false) ? '&' : '?';
            header('Location: ' . $redirectUri . $sep . 'error=access_denied&state=' . urlencode($state));
            exit;
        }

        $cn  = imcp_h($client->client_name ?: 'An MCP client');
        $err = isset($err) ? '<p style="color:#c0392b;margin:0 0 12px;">' . imcp_h($err) . '</p>' : '';
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
           . '<title>Authorize MCP access</title></head>'
           . '<body style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#0f1830;margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center;">'
           . '<form method="post" style="background:#fff;max-width:440px;width:92%;padding:28px;border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,.3);">'
           . '<h2 style="margin:0 0 6px;font-size:20px;color:#15233b;">Authorize MCP access</h2>'
           . '<p style="color:#5a6473;font-size:14px;margin:0 0 16px;"><strong>' . $cn . '</strong> is requesting access to your WHMCS MCP server (68 tools). Approve to connect.</p>'
           . $err
           . '<label style="display:block;font-size:13px;font-weight:600;margin:0 0 4px;color:#33415c;">Paste an API token to approve</label>'
           . '<input type="password" name="api_token" placeholder="bt_…" required style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #d4dae3;border-radius:8px;font-size:14px;margin-bottom:6px;">'
           . '<p style="color:#8a93a2;font-size:12px;margin:0 0 16px;">Generate one in WHMCS &rarr; Addons &rarr; MCP Server &rarr; API Keys.</p>'
           . '<input type="hidden" name="client_id" value="' . imcp_h($clientId) . '">'
           . '<input type="hidden" name="redirect_uri" value="' . imcp_h($redirectUri) . '">'
           . '<input type="hidden" name="state" value="' . imcp_h($state) . '">'
           . '<input type="hidden" name="code_challenge" value="' . imcp_h($challenge) . '">'
           . '<input type="hidden" name="code_challenge_method" value="' . imcp_h($method) . '">'
           . '<input type="hidden" name="response_type" value="code">'
           . '<div style="display:flex;gap:10px;">'
           . '<button type="submit" name="approve" value="1" style="flex:1;background:#23426e;color:#fff;border:none;padding:11px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">Approve</button>'
           . '<button type="submit" name="deny" value="1" style="background:#f1f3f7;color:#33415c;border:1px solid #dfe3ea;padding:11px 16px;border-radius:8px;font-size:14px;cursor:pointer;">Deny</button>'
           . '</div></form></body></html>';
        exit;

    case 'token':
        $grant = $_POST['grant_type'] ?? '';
        $clientId = $_POST['client_id'] ?? '';
        if ($grant === 'authorization_code') {
            $res = OAuth::exchangeCode(
                $_POST['code'] ?? '',
                $_POST['code_verifier'] ?? '',
                $clientId,
                $_POST['redirect_uri'] ?? ''
            );
        } elseif ($grant === 'refresh_token') {
            $res = OAuth::refresh($_POST['refresh_token'] ?? '', $clientId);
        } else {
            imcp_oauth_json(['error' => 'unsupported_grant_type'], 400);
            break;
        }
        if (isset($res['error'])) {
            imcp_oauth_json(['error' => $res['error'], 'error_description' => $res['msg'] ?? ''], 400);
        }
        imcp_oauth_json($res);
        break;

    default:
        imcp_oauth_json(['error' => 'not_found', 'error_description' => 'Unknown OAuth action.'], 404);
}
