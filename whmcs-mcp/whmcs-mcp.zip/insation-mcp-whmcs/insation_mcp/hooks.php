<?php
/**
 * Insation MCP Server — WHMCS hooks.
 *
 * Re-validates the license once per day via the WHMCS daily cron, matching the
 * "daily re-validation" behaviour of the InsationAI plugin family.
 *
 * @package InsationMCP
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/lib/Settings.php';
require_once __DIR__ . '/lib/License.php';

use WHMCS\Database\Capsule;

/**
 * Daily license re-validation (silent — no activation attempt).
 */
add_hook('DailyCronJob', 1, function ($vars) {
    try {
        // Only bother if the addon is actually activated.
        $active = Capsule::table('tbladdonmodules')
            ->where('module', 'insation_mcp')
            ->exists();
        if ($active) {
            \InsationMCP\License::refresh(null, false);
        }
    } catch (\Throwable $e) {
        logActivity('Insation MCP license cron error: ' . $e->getMessage());
    }
});
