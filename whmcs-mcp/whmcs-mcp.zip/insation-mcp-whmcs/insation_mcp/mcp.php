<?php
/**
 * Insation MCP Server — HTTP endpoint.
 *
 * URL external MCP clients connect to, e.g.
 *   https://your-whmcs.example/modules/addons/insation_mcp/mcp.php
 *
 * Transport: Streamable HTTP (JSON request -> JSON response).
 * Auth:      Authorization: Bearer <token>  (or ?t=<token>)
 *
 * @package InsationMCP
 */

// ---------------------------------------------------------------------------
// CORS + safety FIRST — before bootstrapping WHMCS — so preflight never loads
// the framework and any fatal still returns a readable, CORS-enabled response.
// ---------------------------------------------------------------------------
if (!headers_sent()) {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept, Mcp-Session-Id, MCP-Protocol-Version');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Vary: Origin');
}


if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Fatal-error safety net: emit a JSON error (CORS headers already sent) so an
// MCP client receives an intelligible response instead of an empty 500.
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'jsonrpc' => '2.0',
            'id'      => null,
            'error'   => ['code' => -32000, 'message' => 'MCP endpoint bootstrap error: ' . $e['message']],
        ]);
    }
});

// ---------------------------------------------------------------------------
// Bootstrap WHMCS. NOTE: we deliberately do NOT define CLIENTAREA/ADMINAREA —
// those make WHMCS route this as a themed page and can redirect/exit before
// our handler runs. A plain init.php include gives us the DB + localAPI only.
// modules/addons/insation_mcp/mcp.php -> three levels up to the WHMCS root.
// ---------------------------------------------------------------------------
require __DIR__ . '/../../../init.php';

use WHMCS\Database\Capsule;

if (!defined('INSATION_MCP_VERSION')) {
    define('INSATION_MCP_VERSION', '2.2.0');
    define('INSATION_MCP_DIR', __DIR__);
}

require_once __DIR__ . '/lib/Settings.php';
require_once __DIR__ . '/lib/License.php';
require_once __DIR__ . '/lib/Auth.php';
require_once __DIR__ . '/lib/Tools.php';
require_once __DIR__ . '/lib/Server.php';
require_once __DIR__ . '/lib/OAuth.php';

use InsationMCP\Settings;
use InsationMCP\License;
use InsationMCP\Auth;
use InsationMCP\Server;
use InsationMCP\OAuth;

function insation_mcp_send_json($payload, $httpStatus = 200)
{
    if (!headers_sent()) {
        http_response_code($httpStatus);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('Access-Control-Allow-Origin: *');
    }
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

function insation_mcp_rpc_error($id, $code, $message, $httpStatus = 200)
{
    insation_mcp_send_json(Server::error($id, $code, $message), $httpStatus);
}

if (Settings::get('endpoint_enabled', '1') !== '1') {
    insation_mcp_send_json([
        'error'   => 'endpoint_disabled',
        'message' => 'The MCP endpoint is currently disabled by the administrator.',
    ], 503);
}

// Accepts "Authorization: Bearer <token>" (preferred) or the ?t=<token> query
// parameter used by the Usage URL.
$token = Auth::tokenFromRequest();
if ($token === '') {
    if (!headers_sent()) {
        header('WWW-Authenticate: Bearer realm="Insation MCP", resource_metadata="' . OAuth::prmUrl() . '"');
    }
    insation_mcp_send_json([
        'error'   => 'unauthorized',
        'message' => 'Missing bearer token. Send "Authorization: Bearer <token>" or ?t=<token>.',
    ], 401);
}
$key = Auth::verify($token);
if (!$key) {
    $key = OAuth::verifyAccessToken($token);
}
if (!$key) {
    if (!headers_sent()) {
        header('WWW-Authenticate: Bearer realm="Insation MCP", resource_metadata="' . OAuth::prmUrl() . '"');
    }
    insation_mcp_send_json([
        'error'   => 'unauthorized',
        'message' => 'Invalid or revoked token.',
    ], 401);
}

if (!License::isLicensed()) {
    $st = License::getState();
    insation_mcp_send_json([
        'error'   => 'license_inactive',
        'reason'  => $st['reason_code'],
        'message' => 'This MCP Server installation is not licensed. Activate a valid '
                   . 'license key in the WHMCS admin (Addons > MCP Server > Settings).',
    ], 403);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    insation_mcp_send_json([
        'name'      => Server::SERVER_NAME,
        'version'   => INSATION_MCP_VERSION,
        'transport' => 'streamable-http',
        'usage'     => 'POST JSON-RPC 2.0 messages to this URL.',
    ], 200);
}

$raw = file_get_contents('php://input');
if ($raw === '' || $raw === false) {
    insation_mcp_rpc_error(null, -32700, 'Empty request body.');
}
$decoded = json_decode($raw, true);
if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
    insation_mcp_rpc_error(null, -32700, 'Parse error: invalid JSON.');
}

try {
    if (is_array($decoded) && array_is_list_assoc($decoded)) {
        $responses = [];
        foreach ($decoded as $msg) {
            if (!is_array($msg)) {
                $responses[] = Server::error(null, -32600, 'Invalid request.');
                continue;
            }
            $r = Server::handle($msg);
            if ($r !== null) {
                $responses[] = $r;
            }
        }
        if (empty($responses)) {
            insation_mcp_send_json((object) [], 202);
        }
        insation_mcp_send_json($responses);
    }

    if (!is_array($decoded)) {
        insation_mcp_rpc_error(null, -32600, 'Invalid request.');
    }

    $response = Server::handle($decoded);
    if ($response === null) {
        insation_mcp_send_json((object) [], 202);
    }
    insation_mcp_send_json($response);
} catch (\Throwable $e) {
    $id = is_array($decoded) && array_key_exists('id', $decoded) ? $decoded['id'] : null;
    insation_mcp_rpc_error($id, -32603, 'Internal error: ' . $e->getMessage());
}

/**
 * Detect a JSON-RPC batch (a list array of message objects) vs. a single
 * message object.
 */
function array_is_list_assoc($arr)
{
    if (!is_array($arr) || $arr === []) {
        return false;
    }
    return array_keys($arr) === range(0, count($arr) - 1) && is_array($arr[0] ?? null);
}
