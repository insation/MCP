<?php
/**
 * Insation MCP Server — WHMCS Addon Module
 *
 * Turns WHMCS into a secure Model Context Protocol (MCP) server for AI
 * assistants, with per-site licensing verified against insation.ai.
 *
 * @package    InsationMCP
 * @author     InsationAI
 * @link       https://insation.ai/
 * @version    1.0.0
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

use WHMCS\Database\Capsule;

if (!defined('INSATION_MCP_VERSION')) {
    define('INSATION_MCP_VERSION', '2.3.0');
    define('INSATION_MCP_DIR', __DIR__);
    define('INSATION_MCP_SLUG', 'insation_mcp');
}

require_once __DIR__ . '/lib/Settings.php';
require_once __DIR__ . '/lib/License.php';
require_once __DIR__ . '/lib/Auth.php';
require_once __DIR__ . '/lib/Tools.php';
require_once __DIR__ . '/lib/Server.php';
require_once __DIR__ . '/lib/Admin.php';

function insation_mcp_config()
{
    return [
        'name'        => 'MCP Server',
        'description' => 'Turn WHMCS into a secure MCP server for AI assistants — '
                       . 'clients, billing, services, domains, tickets and more, '
                       . 'with per-site licensing by InsationAI.',
        'version'     => INSATION_MCP_VERSION,
        'author'      => 'InsationAI',
        'language'    => 'english',
        'fields'      => [],
    ];
}

function insation_mcp_activate()
{
    try {
        InsationMCP\Settings::installSchema();
        InsationMCP\Settings::set('endpoint_enabled', '1');
        InsationMCP\Settings::set('installed_version', INSATION_MCP_VERSION);

        if (!InsationMCP\Settings::get('admin_username')) {
            $admin = Capsule::table('tbladmins')
                ->where('disabled', 0)
                ->orderBy('id', 'asc')
                ->first();
            if ($admin && isset($admin->username)) {
                InsationMCP\Settings::set('admin_username', $admin->username);
            }
        }

        return [
            'status'      => 'success',
            'description' => 'Insation MCP Server installed. Open the addon to '
                           . 'enter your license key, generate an API token, and '
                           . 'connect your AI client.',
        ];
    } catch (\Throwable $e) {
        return [
            'status'      => 'error',
            'description' => 'Activation failed: ' . $e->getMessage(),
        ];
    }
}

function insation_mcp_deactivate()
{
    return [
        'status'      => 'success',
        'description' => 'Insation MCP Server deactivated. The MCP endpoint will '
                       . 'no longer respond. Your tokens and settings are retained.',
    ];
}

function insation_mcp_upgrade($vars)
{
    try {
        InsationMCP\Settings::installSchema();
        InsationMCP\Settings::set('installed_version', INSATION_MCP_VERSION);
    } catch (\Throwable $e) {
        logActivity('Insation MCP upgrade error: ' . $e->getMessage());
    }
}

function insation_mcp_output($vars)
{
    $admin = new InsationMCP\Admin($vars);
    echo $admin->render();
}

function insation_mcp_sidebar($vars)
{
    $state   = InsationMCP\License::getState();
    $badge   = ($state['status'] === 'licensed')
        ? '<span style="color:#1c8c46;font-weight:600;">&#10003; Licensed</span>'
        : '<span style="color:#c0392b;font-weight:600;">&#10007; Unlicensed</span>';
    $enabled = InsationMCP\Settings::get('endpoint_enabled', '1') === '1';
    $ep      = $enabled
        ? '<span style="color:#1c8c46;">Enabled</span>'
        : '<span style="color:#888;">Disabled</span>';

    return <<<HTML
<div class="sidebar-menu">
  <ul class="menu" style="padding:10px 14px;list-style:none;">
    <li style="margin-bottom:6px;"><strong>MCP Server</strong> v{$vars['version']}</li>
    <li style="margin-bottom:4px;">License: {$badge}</li>
    <li>Endpoint: {$ep}</li>
  </ul>
</div>
HTML;
}
