<?php
/**
 * Insation MCP Server — Bearer token authentication.
 *
 * Tokens are shown to the admin once at creation time; only a SHA-256 hash is
 * stored. The table displays a non-secret prefix afterward.
 *
 * @package InsationMCP
 */

namespace InsationMCP;

use WHMCS\Database\Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class Auth
{
    public static function generate($name = 'mcp')
    {
        $token  = 'bt_' . bin2hex(random_bytes(16));
        $prefix = substr($token, 0, 11);
        $id = Capsule::table(Settings::TABLE_KEYS)->insertGetId([
            'name'         => substr($name ?: 'mcp', 0, 191),
            'type'         => 'bearer',
            'token_prefix' => $prefix,
            'token_hash'   => hash('sha256', $token),
            'status'       => 'active',
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        return ['id' => (int) $id, 'token' => $token, 'prefix' => $prefix];
    }

    public static function revoke($id)
    {
        return Capsule::table(Settings::TABLE_KEYS)
            ->where('id', (int) $id)
            ->update(['status' => 'revoked']);
    }

    public static function delete($id)
    {
        return Capsule::table(Settings::TABLE_KEYS)->where('id', (int) $id)->delete();
    }

    public static function all()
    {
        return Capsule::table(Settings::TABLE_KEYS)->orderBy('id', 'desc')->get();
    }

    public static function verify($token)
    {
        $token = trim((string) $token);
        if ($token === '') {
            return false;
        }
        $row = Capsule::table(Settings::TABLE_KEYS)
            ->where('token_hash', hash('sha256', $token))
            ->where('status', 'active')
            ->first();
        if (!$row) {
            return false;
        }
        Capsule::table(Settings::TABLE_KEYS)
            ->where('id', $row->id)
            ->update(['last_used_at' => date('Y-m-d H:i:s')]);
        return $row;
    }

    public static function bearerFromRequest()
    {
        $auth = '';
        if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'];
        } elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        } elseif (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            foreach ($headers as $k => $v) {
                if (strcasecmp($k, 'Authorization') === 0) {
                    $auth = $v;
                    break;
                }
            }
        }
        if (stripos($auth, 'Bearer ') === 0) {
            return trim(substr($auth, 7));
        }
        return '';
    }

    public static function tokenFromRequest()
    {
        $token = self::bearerFromRequest();
        if ($token !== '') {
            return $token;
        }
        if (!empty($_GET['t'])) {
            return trim((string) $_GET['t']);
        }
        return '';
    }
}
