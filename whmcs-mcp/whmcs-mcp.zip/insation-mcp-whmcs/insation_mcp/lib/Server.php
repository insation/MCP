<?php
/**
 * Insation MCP Server — JSON-RPC 2.0 / MCP protocol handler.
 *
 * Implements the Model Context Protocol methods over a single HTTP endpoint
 * (Streamable HTTP, JSON responses):
 *   initialize, notifications/initialized, ping,
 *   tools/list, tools/call, resources/list, prompts/list.
 *
 * @package InsationMCP
 */

namespace InsationMCP;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class Server
{
    const SERVER_NAME       = 'Insation MCP Server (WHMCS)';
    const DEFAULT_PROTOCOL  = '2025-06-18';
    const SUPPORTED         = ['2025-06-18', '2025-03-26', '2024-11-05'];

    /**
     * Handle one decoded JSON-RPC message. Returns a response array, or null
     * for notifications (no response expected).
     */
    public static function handle(array $msg)
    {
        $jsonrpc = $msg['jsonrpc'] ?? '2.0';
        $id      = array_key_exists('id', $msg) ? $msg['id'] : null;
        $method  = $msg['method'] ?? '';
        $params  = isset($msg['params']) && is_array($msg['params']) ? $msg['params'] : [];

        // Notifications (no id) expect no response.
        $isNotification = !array_key_exists('id', $msg);

        switch ($method) {
            case 'initialize':
                return self::result($id, self::initialize($params));

            case 'notifications/initialized':
            case 'notifications/cancelled':
                return null; // notification, no response

            case 'ping':
                return self::result($id, (object) []);

            case 'tools/list':
                return self::result($id, ['tools' => Tools::listForMcp()]);

            case 'tools/call':
                return self::result($id, self::toolsCall($params));

            case 'resources/list':
                return self::result($id, ['resources' => []]);

            case 'resources/templates/list':
                return self::result($id, ['resourceTemplates' => []]);

            case 'prompts/list':
                return self::result($id, ['prompts' => []]);

            default:
                if ($isNotification) {
                    return null;
                }
                return self::error($id, -32601, 'Method not found: ' . $method);
        }
    }

    protected static function initialize(array $params)
    {
        $requested = $params['protocolVersion'] ?? self::DEFAULT_PROTOCOL;
        $protocol  = in_array($requested, self::SUPPORTED, true) ? $requested : self::DEFAULT_PROTOCOL;

        return [
            'protocolVersion' => $protocol,
            'capabilities'    => [
                'tools' => ['listChanged' => false],
            ],
            'serverInfo'      => [
                'name'    => self::SERVER_NAME,
                'version' => INSATION_MCP_VERSION,
            ],
            'instructions'    => 'WHMCS automation tools: clients, products, services, '
                               . 'invoices, quotes, orders, tickets, domains, affiliates '
                               . 'and system operations. Call tools/list to discover '
                               . 'available operations.',
        ];
    }

    protected static function toolsCall(array $params)
    {
        $name = $params['name'] ?? '';
        $args = isset($params['arguments']) && is_array($params['arguments']) ? $params['arguments'] : [];
        if ($name === '') {
            return [
                'content' => [['type' => 'text', 'text' => 'Missing tool name.']],
                'isError' => true,
            ];
        }
        return Tools::call($name, $args);
    }

    public static function result($id, $result)
    {
        return ['jsonrpc' => '2.0', 'id' => $id, 'result' => $result];
    }

    public static function error($id, $code, $message, $data = null)
    {
        $err = ['code' => $code, 'message' => $message];
        if ($data !== null) {
            $err['data'] = $data;
        }
        return ['jsonrpc' => '2.0', 'id' => $id, 'error' => $err];
    }
}
