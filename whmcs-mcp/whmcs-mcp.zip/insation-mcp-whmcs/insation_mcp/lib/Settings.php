<?php
/**
 * Settings & schema helper for Insation MCP Server.
 *
 * Owns the addon's database tables and a tiny key/value settings store.
 *
 * @package InsationMCP
 */

namespace InsationMCP;

use WHMCS\Database\Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class Settings
{
    const TABLE_KEYS     = 'mod_insation_mcp_keys';
    const TABLE_SETTINGS = 'mod_insation_mcp_settings';
    const TABLE_TOOLS    = 'mod_insation_mcp_tools';

    /**
     * Create/upgrade tables. Idempotent — safe to call on every activate/upgrade.
     */
    public static function installSchema()
    {
        $sm = Capsule::schema();

        if (!$sm->hasTable(self::TABLE_KEYS)) {
            $sm->create(self::TABLE_KEYS, function ($t) {
                $t->increments('id');
                $t->string('name', 191)->default('mcp');
                $t->string('type', 32)->default('bearer');     // bearer
                $t->string('token_prefix', 32);                // shown in UI, e.g. bt_xxxx
                $t->string('token_hash', 191);                 // sha256 of full token
                $t->string('status', 16)->default('active');   // active|revoked
                $t->timestamp('created_at')->nullable();
                $t->timestamp('last_used_at')->nullable();
                $t->index('token_prefix');
                $t->index('status');
            });
        }

        if (!$sm->hasTable(self::TABLE_SETTINGS)) {
            $sm->create(self::TABLE_SETTINGS, function ($t) {
                $t->string('setting', 191)->primary();
                $t->text('value')->nullable();
            });
        }

        if (!$sm->hasTable(self::TABLE_TOOLS)) {
            $sm->create(self::TABLE_TOOLS, function ($t) {
                $t->string('tool_name', 191)->primary();
                $t->tinyInteger('enabled')->default(1);
            });
        }

        if (!$sm->hasTable('mod_insation_mcp_oauth_clients')) {
            $sm->create('mod_insation_mcp_oauth_clients', function ($t) {
                $t->increments('id');
                $t->string('client_id', 191)->unique();
                $t->string('client_secret', 191)->default('');
                $t->text('redirect_uris');
                $t->string('client_name', 191)->default('');
                $t->timestamp('created_at')->nullable();
            });
        }

        if (!$sm->hasTable('mod_insation_mcp_oauth_codes')) {
            $sm->create('mod_insation_mcp_oauth_codes', function ($t) {
                $t->increments('id');
                $t->string('code_hash', 191)->index();
                $t->string('client_id', 191);
                $t->text('redirect_uri');
                $t->string('code_challenge', 191)->default('');
                $t->string('code_challenge_method', 16)->default('S256');
                $t->integer('api_key_id')->default(0);
                $t->timestamp('expires_at')->nullable();
                $t->tinyInteger('used')->default(0);
                $t->timestamp('created_at')->nullable();
            });
        }

        if (!$sm->hasTable('mod_insation_mcp_oauth_tokens')) {
            $sm->create('mod_insation_mcp_oauth_tokens', function ($t) {
                $t->increments('id');
                $t->string('access_hash', 191)->index();
                $t->string('refresh_hash', 191)->index();
                $t->string('client_id', 191);
                $t->integer('api_key_id')->default(0);
                $t->timestamp('expires_at')->nullable();
                $t->timestamp('created_at')->nullable();
            });
        }
    }

    public static function get($key, $default = null)
    {
        try {
            $row = Capsule::table(self::TABLE_SETTINGS)->where('setting', $key)->first();
            return $row ? $row->value : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    public static function set($key, $value)
    {
        Capsule::table(self::TABLE_SETTINGS)->updateOrInsert(
            ['setting' => $key],
            ['value' => (string) $value]
        );
    }

    /**
     * Disabled tool names (stored only for tools the admin has turned OFF).
     *
     * @return string[]
     */
    public static function getDisabledTools()
    {
        try {
            return Capsule::table(self::TABLE_TOOLS)
                ->where('enabled', 0)
                ->pluck('tool_name')
                ->all();
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function isToolEnabled($name)
    {
        try {
            $row = Capsule::table(self::TABLE_TOOLS)->where('tool_name', $name)->first();
            return $row ? ((int) $row->enabled === 1) : true; // default enabled
        } catch (\Throwable $e) {
            return true;
        }
    }

    /**
     * Persist tool enable/disable state for the full list of known tools.
     *
     * @param array $enabledNames Names the admin wants ENABLED.
     * @param array $allNames     Every known tool name.
     */
    public static function saveToolStates(array $enabledNames, array $allNames)
    {
        $enabled = array_flip($enabledNames);
        foreach ($allNames as $name) {
            Capsule::table(self::TABLE_TOOLS)->updateOrInsert(
                ['tool_name' => $name],
                ['enabled' => isset($enabled[$name]) ? 1 : 0]
            );
        }
    }
}
