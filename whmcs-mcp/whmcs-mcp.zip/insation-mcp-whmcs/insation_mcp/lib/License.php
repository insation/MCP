<?php
/**
 * Insation MCP Server — License Service
 *
 * Validates this WHMCS addon's license against the WC Key Manager (WCKM)
 * Software API on insation.ai — the same per-site licensing layer used by the
 * InsationAI WordpressMCP / ElementorMCP family of products.
 *
 * STRICT model (matches the InsationAI plugins):
 *   - Unlicensed / invalid / expired      => NOT licensed (endpoint killed, UI gated).
 *   - License server unreachable          => treated as NOT licensed (NO grace period).
 *   - Daily re-validation via WHMCS cron (see hooks.php).
 *   - Product ownership enforced by the key prefix (KEY_PREFIX) because WCKM
 *     binds keys to the purchased *variation* id and rejects a product_id
 *     mismatch — so product_id is intentionally NOT sent.
 *
 * WCKM Software API contract:
 *   GET  https://insation.ai/?wckm-api=<action>&key=<key>&instance=<instance>
 *   action:   validate_key | activate_key | deactivate_key
 *   response: JSON { success:bool, error?:string, message?:string,
 *                    expires?: 'never'|date, activation_*?, instance_status? }
 *
 * @package InsationMCP
 */

namespace InsationMCP;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class License
{
    /** WCKM Software API base on insation.ai. */
    const API_BASE = 'https://insation.ai/';

    /** Key prefix identifying a key as belonging to THIS product (WHMCS MCP).
     *  Create the WHMCSMCP product in WC Key Manager so its issued keys carry
     *  this prefix, e.g. WHMCSMCP-1-XXXX-XXXX-XXXX. */
    const KEY_PREFIX = 'WHMCSMCP-';

    /** HTTP timeout (seconds). */
    const TIMEOUT = 12;

    /** Settings key under which the license state JSON is persisted. */
    const STATE_KEY = 'license_state';

    /**
     * Return the persisted state (never throws; always a full array).
     */
    public static function getState()
    {
        $defaults = [
            'key'                  => '',
            'status'               => 'unlicensed', // licensed | unlicensed
            'reason_code'          => 'no_key',
            'reason_message'       => 'No license key entered yet.',
            'tier'                 => '',
            'expires'              => '',
            'activation_limit'     => 0,
            'activation_count'     => 0,
            'activation_remaining' => '',
            'last_check'           => 0,
            'last_success'         => 0,
            'instance'             => self::getInstance(),
        ];
        $raw = Settings::get(self::STATE_KEY, '');
        $state = $raw ? json_decode($raw, true) : [];
        if (!is_array($state)) {
            $state = [];
        }
        return array_merge($defaults, $state);
    }

    /** THE single licensing decision point. */
    public static function isLicensed()
    {
        $state = self::getState();
        return $state['status'] === 'licensed';
    }

    /**
     * Stable per-install activation slot: WHMCS system URL host + path.
     */
    public static function getInstance()
    {
        $url = '';
        if (function_exists('App') || class_exists('\\WHMCS\\Config\\Setting')) {
            try {
                $url = \WHMCS\Config\Setting::getValue('SystemURL');
            } catch (\Throwable $e) {
                $url = '';
            }
        }
        if (!$url && defined('WHMCS_URL')) {
            $url = WHMCS_URL;
        }
        if (!$url && isset($_SERVER['HTTP_HOST'])) {
            $url = 'https://' . $_SERVER['HTTP_HOST'];
        }
        $host = parse_url($url, PHP_URL_HOST);
        $path = parse_url($url, PHP_URL_PATH);
        $inst = rtrim($host . ($path ?: ''), '/') . '/';
        return $inst ?: 'unknown/';
    }

    /**
     * Mask a key for display: WHMCSMCP-1-6HSM-SSZN-GMCR -> WHMCSMCP-1-••••-••••-GMCR
     */
    public static function maskKey($key)
    {
        $key = (string) $key;
        if ($key === '') {
            return '';
        }
        $parts = explode('-', $key);
        if (count($parts) >= 5) {
            $last  = array_pop($parts);
            $first = array_slice($parts, 0, 2);
            $mid   = array_slice($parts, 2);
            $mid   = array_map(function ($g) {
                return str_repeat('•', max(4, strlen($g)));
            }, $mid);
            return implode('-', array_merge($first, $mid, [$last]));
        }
        return str_repeat('•', max(0, strlen($key) - 4)) . substr($key, -4);
    }

    /**
     * Low-level WCKM Software API call.
     *
     * @return array { ok:bool, http:bool, data:array|null, error:string }
     */
    protected static function call($action, $key)
    {
        $url = self::API_BASE . '?' . http_build_query([
            'wckm-api' => $action,
            'key'      => $key,
            'instance' => self::getInstance(),
        ]);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => self::TIMEOUT,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 2,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => ['Accept: application/json'],
            CURLOPT_USERAGENT      => 'InsationMCP-WHMCS/' . INSATION_MCP_VERSION,
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $err   = curl_error($ch);
        $code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno !== 0 || $body === false) {
            return ['ok' => false, 'http' => false, 'data' => null, 'error' => $err ?: 'Transport error'];
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'http' => true, 'data' => null, 'error' => 'Unexpected HTTP status ' . $code . '.'];
        }
        $data = json_decode($body, true);
        if (!is_array($data)) {
            return ['ok' => false, 'http' => true, 'data' => null, 'error' => 'Unreadable response from license server.'];
        }
        return ['ok' => true, 'http' => true, 'data' => $data, 'error' => ''];
    }

    /**
     * Product-ownership gate. WCKM has already confirmed the key is real; this
     * adds the "is it for THIS product" check via the key prefix.
     */
    protected static function isValidForThisProduct($data, $key)
    {
        if (empty($data['success'])) {
            return false;
        }
        if (strpos($key, self::KEY_PREFIX) === 0) {
            return true;
        }
        // --- Bundle-ready extension point: accept a suite prefix here too. ---
        // if (strpos($key, 'INSATION-SUITE-') === 0) return true;
        return false;
    }

    /**
     * Validate (and optionally activate) a key, then persist state.
     *
     * @param string|null $key      Key to use; null = stored key.
     * @param bool        $activate Attempt activation if valid-but-inactive.
     * @return array The new persisted state.
     */
    public static function refresh($key = null, $activate = false)
    {
        $state = self::getState();
        if ($key === null) {
            $key = $state['key'];
        }
        $key = trim((string) $key);

        $now = time();
        $state['key']        = $key;
        $state['last_check'] = $now;
        $state['instance']   = self::getInstance();

        if ($key === '') {
            return self::persist($state, 'unlicensed', 'no_key', 'No license key entered yet.');
        }

        $res = self::call('validate_key', $key);

        if (!$res['http']) {
            return self::persist($state, 'unlicensed', 'server_unreachable',
                'Could not reach the license server (insation.ai). Your endpoint is '
                . 'temporarily disabled. This is usually a temporary issue and not a '
                . 'problem with your key — it will retry automatically.');
        }
        if (!$res['ok']) {
            return self::persist($state, 'unlicensed', 'server_error',
                'The license server returned an unexpected response. This is usually '
                . 'temporary and not a problem with your key.');
        }

        $data = $res['data'];

        if (empty($data['success'])) {
            $err = isset($data['error']) ? (string) $data['error'] : 'invalid_key';
            if ($err === 'expired') {
                return self::persist($state, 'unlicensed', 'expired',
                    'This license has expired. Renew it to re-enable the MCP Server.');
            }
            return self::persist($state, 'unlicensed', 'invalid_key',
                'This license key was not recognized. Check for typos, or use the key '
                . 'from your purchase confirmation email.');
        }

        if (!self::isValidForThisProduct($data, $key)) {
            return self::persist($state, 'unlicensed', 'wrong_product',
                'This key is for a different product and cannot be used to license the '
                . 'MCP Server.');
        }

        $instanceStatus = isset($data['instance_status']) ? (string) $data['instance_status'] : '';

        if ($instanceStatus !== 'active') {
            if (!$activate) {
                return self::persist($state, 'unlicensed', 'not_activated',
                    'License key recognized but not yet activated on this site. '
                    . 'Click "Activate License".');
            }
            $act = self::call('activate_key', $key);
            if (!$act['http']) {
                return self::persist($state, 'unlicensed', 'server_unreachable',
                    'Could not reach the license server (insation.ai) to activate. '
                    . 'This is usually temporary — please try again shortly.');
            }
            if (!$act['ok'] || empty($act['data']['success'])) {
                $msg = !empty($act['data']['message']) ? (string) $act['data']['message']
                    : 'Activation failed. The activation limit for this key may have been reached.';
                $code = !empty($act['data']['error']) ? (string) $act['data']['error'] : 'activation_failed';
                return self::persist($state, 'unlicensed', $code, $msg);
            }
            $data = $act['data'];
        }

        // LICENSED.
        $expires = isset($data['expires']) ? (string) $data['expires'] : 'never';
        $tier = '';
        if (preg_match('/^' . preg_quote(self::KEY_PREFIX, '/') . '([1AU])-/', $key, $m)) {
            $tier = ['1' => 'Single Site', 'A' => 'Agency', 'U' => 'Unlimited'][$m[1]];
        }
        $actLimit  = isset($data['activation_limit']) ? (int) $data['activation_limit'] : 0;
        $actCount  = isset($data['activation_count']) ? (int) $data['activation_count'] : 0;
        $actRemain = isset($data['activation_remaining']) ? (string) $data['activation_remaining']
            : ($actLimit > 0 ? (string) max(0, $actLimit - $actCount) : 'unlimited');

        $state['tier']                 = $tier;
        $state['expires']              = $expires;
        $state['activation_limit']     = $actLimit;
        $state['activation_count']     = $actCount;
        $state['activation_remaining'] = $actRemain;
        $state['last_success']         = $now;

        return self::persist($state, 'licensed', 'ok', 'Licensed and active.');
    }

    /**
     * Deactivate this site's activation and clear the local key.
     */
    public static function deactivate()
    {
        $state = self::getState();
        $key   = $state['key'];
        if ($key !== '') {
            self::call('deactivate_key', $key); // best effort
        }
        $blank = [
            'key' => '', 'tier' => '', 'expires' => '',
            'activation_limit' => 0, 'activation_count' => 0, 'activation_remaining' => '',
            'last_success' => 0,
        ];
        return self::persist(array_merge($state, $blank), 'unlicensed', 'no_key',
            'License removed from this site.');
    }

    protected static function persist($state, $status, $reasonCode, $reasonMessage)
    {
        $state['status']         = $status;
        $state['reason_code']    = $reasonCode;
        $state['reason_message'] = $reasonMessage;
        Settings::set(self::STATE_KEY, json_encode($state));
        return $state;
    }
}
