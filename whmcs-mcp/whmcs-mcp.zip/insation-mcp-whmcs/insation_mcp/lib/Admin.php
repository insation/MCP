<?php
/**
 * Insation MCP Server — Admin UI.
 *
 * Renders the three-tab admin interface (API Keys, Tool Management, Settings)
 * and handles all POST actions. Self-contained styling + vanilla JS so it does
 * not depend on a specific WHMCS admin theme.
 *
 * @package InsationMCP
 */

namespace InsationMCP;

use WHMCS\Database\Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class Admin
{
    /** @var array */
    private $vars;
    /** @var string */
    private $link;
    /** @var array notices to show */
    private $notices = [];
    /** @var string|null one-time freshly generated token */
    private $newToken = null;

    public function __construct(array $vars)
    {
        $this->vars = $vars;
        $this->link = $vars['modulelink'] ?? 'addonmodules.php?module=insation_mcp';
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
    }

    // -----------------------------------------------------------------------
    //  Entry
    // -----------------------------------------------------------------------
    public function render()
    {
        $this->handlePost();

        $tab = isset($_GET['tab']) ? preg_replace('/[^a-z]/', '', $_GET['tab']) : 'apikeys';
        if (!in_array($tab, ['apikeys', 'tools', 'settings'], true)) {
            $tab = 'apikeys';
        }

        $html  = $this->styles();
        $html .= '<div class="imcp-wrap">';
        $html .= $this->headerBar();
        $html .= $this->renderNotices();
        $html .= $this->tabNav($tab);

        if ($tab === 'apikeys') {
            $html .= $this->renderApiKeys();
        } elseif ($tab === 'tools') {
            $html .= $this->renderTools();
        } else {
            $html .= $this->renderSettings();
        }

        $html .= '</div>';
        $html .= $this->scripts();
        return $html;
    }

    // -----------------------------------------------------------------------
    //  CSRF
    // -----------------------------------------------------------------------
    private function csrf()
    {
        if (empty($_SESSION['insation_mcp_csrf'])) {
            $_SESSION['insation_mcp_csrf'] = bin2hex(random_bytes(16));
        }
        return $_SESSION['insation_mcp_csrf'];
    }

    private function csrfField()
    {
        return '<input type="hidden" name="csrf" value="' . $this->csrf() . '">';
    }

    private function checkCsrf()
    {
        return isset($_POST['csrf'])
            && hash_equals($_SESSION['insation_mcp_csrf'] ?? '', $_POST['csrf']);
    }

    // -----------------------------------------------------------------------
    //  POST handling
    // -----------------------------------------------------------------------
    private function handlePost()
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['mcp_action'])) {
            return;
        }
        if (!$this->checkCsrf()) {
            $this->notices[] = ['error', 'Security token mismatch. Please try again.'];
            return;
        }

        $action = $_POST['mcp_action'];
        try {
            switch ($action) {
                case 'generate_key':
                    $res = Auth::generate($_POST['key_name'] ?? 'mcp');
                    $this->newToken = $res['token'];
                    $this->notices[] = ['success', 'New API credential generated. Copy the token now — it will not be shown again.'];
                    break;

                case 'revoke_key':
                    Auth::revoke((int) $_POST['id']);
                    $this->notices[] = ['success', 'Credential revoked.'];
                    break;

                case 'delete_key':
                    Auth::delete((int) $_POST['id']);
                    $this->notices[] = ['success', 'Credential deleted.'];
                    break;

                case 'save_tools':
                    $enabled = isset($_POST['enabled']) && is_array($_POST['enabled'])
                        ? array_map('strval', $_POST['enabled']) : [];
                    Settings::saveToolStates($enabled, Tools::names());
                    $this->notices[] = ['success', 'Tool settings saved.'];
                    break;

                case 'toggle_endpoint':
                    Settings::set('endpoint_enabled', !empty($_POST['enabled']) ? '1' : '0');
                    $this->notices[] = ['success', 'Endpoint status updated.'];
                    break;

                case 'save_admin':
                    Settings::set('admin_username', trim($_POST['admin_username'] ?? ''));
                    $this->notices[] = ['success', 'API admin user saved.'];
                    break;

                case 'license_activate':
                    $st = License::refresh(trim($_POST['license_key'] ?? ''), true);
                    $this->notices[] = ($st['status'] === 'licensed')
                        ? ['success', 'License activated: ' . $st['reason_message']]
                        : ['error', 'License not active: ' . $st['reason_message']];
                    break;

                case 'license_recheck':
                    $st = License::refresh(null, false);
                    $this->notices[] = ($st['status'] === 'licensed')
                        ? ['success', 'License re-checked: active.']
                        : ['error', 'License re-checked: ' . $st['reason_message']];
                    break;

                case 'license_deactivate':
                    License::deactivate();
                    $this->notices[] = ['success', 'License removed from this site.'];
                    break;

                case 'test_endpoint':
                    $this->runSelfTest();
                    break;
            }
        } catch (\Throwable $e) {
            $this->notices[] = ['error', 'Action failed: ' . $e->getMessage()];
        }
    }

    private function runSelfTest()
    {
        $problems = [];
        if (Settings::get('endpoint_enabled', '1') !== '1') {
            $problems[] = 'the endpoint is disabled';
        }
        if (!License::isLicensed()) {
            $problems[] = 'the license is not active (' . License::getState()['reason_code'] . ')';
        }
        $active = Capsule::table(Settings::TABLE_KEYS)->where('status', 'active')->count();
        if ($active === 0) {
            $problems[] = 'no active API credential exists';
        }
        // Exercise the protocol path internally.
        $init = Server::handle(['jsonrpc' => '2.0', 'id' => 1, 'method' => 'initialize', 'params' => []]);
        $toolCount = count(Tools::listForMcp());

        if ($problems) {
            $this->notices[] = ['error', 'Test endpoint: would currently REJECT live requests because ' . implode('; ', $problems) . '. (Protocol layer OK — ' . $toolCount . ' tools, serverInfo ' . ($init['result']['serverInfo']['version'] ?? '?') . '.)'];
        } else {
            $this->notices[] = ['success', 'Test endpoint OK — initialize handshake succeeded, ' . $toolCount . ' tools enabled, endpoint live.'];
        }
    }

    // -----------------------------------------------------------------------
    //  Shared UI
    // -----------------------------------------------------------------------
    private function tabUrl($tab)
    {
        return $this->esc($this->link . '&tab=' . $tab);
    }

    private function headerBar()
    {
        $v = $this->esc($this->vars['version'] ?? INSATION_MCP_VERSION);
        return '<div class="imcp-titlebar"><span class="imcp-title">MCP Server</span> '
             . '<span class="imcp-ver">v' . $v . '</span></div>';
    }

    private function tabNav($active)
    {
        $tabs = [
            'apikeys'  => 'API Keys',
            'tools'    => 'Tool Management',
            'settings' => 'Settings',
        ];
        $out = '<div class="imcp-tabs">';
        foreach ($tabs as $key => $label) {
            $cls = $key === $active ? 'imcp-tab active' : 'imcp-tab';
            $out .= '<a class="' . $cls . '" href="' . $this->tabUrl($key) . '">' . $label . '</a>';
        }
        $out .= '</div>';
        return $out;
    }

    private function renderNotices()
    {
        if (!$this->notices) {
            return '';
        }
        $out = '';
        foreach ($this->notices as [$type, $msg]) {
            $out .= '<div class="imcp-alert imcp-' . $type . '">' . $this->esc($msg) . '</div>';
        }
        return $out;
    }

    // -----------------------------------------------------------------------
    //  Tab 1 — API Keys
    // -----------------------------------------------------------------------
    private function renderApiKeys()
    {
        $keys = Auth::all();

        $rows = '';
        if (count($keys) === 0) {
            $rows = '<tr><td colspan="7" class="imcp-empty">No API credentials yet. '
                  . 'Click "Generate New Credential" to create one.</td></tr>';
        } else {
            foreach ($keys as $k) {
                $identifier = $this->esc($k->token_prefix) . '••••••••••••••••••••';
                $statusBadge = $k->status === 'active'
                    ? '<span class="imcp-badge imcp-badge-active">Active</span>'
                    : '<span class="imcp-badge imcp-badge-revoked">Revoked</span>';
                $created = $k->created_at ? date('d/m/Y h:i A', strtotime($k->created_at)) : '—';
                $used    = $k->last_used_at ? date('d/m/Y h:i A', strtotime($k->last_used_at)) : 'Never';

                $menu = '<div class="imcp-rowmenu">'
                    . '<button type="button" class="imcp-kebab" onclick="imcpToggleMenu(this)">&#8942;</button>'
                    . '<div class="imcp-menu">';
                if ($k->status === 'active') {
                    $menu .= '<form method="post">' . $this->csrfField()
                        . '<input type="hidden" name="mcp_action" value="revoke_key">'
                        . '<input type="hidden" name="id" value="' . (int) $k->id . '">'
                        . '<button type="submit" class="imcp-menu-item">Revoke</button></form>';
                }
                $menu .= '<form method="post" onsubmit="return confirm(\'Delete this credential permanently?\');">'
                    . $this->csrfField()
                    . '<input type="hidden" name="mcp_action" value="delete_key">'
                    . '<input type="hidden" name="id" value="' . (int) $k->id . '">'
                    . '<button type="submit" class="imcp-menu-item imcp-danger">Delete</button></form>';
                $menu .= '</div></div>';

                $rows .= '<tr>'
                    . '<td>' . $this->esc($k->name) . '</td>'
                    . '<td><span class="imcp-type">Bearer Token</span></td>'
                    . '<td><code class="imcp-id">' . $identifier . '</code></td>'
                    . '<td>' . $statusBadge . '</td>'
                    . '<td>' . $this->esc($created) . '</td>'
                    . '<td>' . $this->esc($used) . '</td>'
                    . '<td style="text-align:right;">' . $menu . '</td>'
                    . '</tr>';
            }
        }

        $genForm = '<form method="post" class="imcp-genform">' . $this->csrfField()
            . '<input type="hidden" name="mcp_action" value="generate_key">'
            . '<input type="text" name="key_name" value="mcp" class="imcp-input" placeholder="Credential name">'
            . '<button type="submit" class="imcp-btn imcp-btn-primary">Generate New Credential</button>'
            . '</form>';

        $reveal = '';
        if ($this->newToken) {
            $tok      = $this->esc($this->newToken);
            $usageUrl = $this->esc($this->endpointUrl() . '?t=' . $this->newToken);
            $authHdr  = $this->esc('Authorization: Bearer ' . $this->newToken);
            $reveal = '<div class="imcp-card imcp-reveal">'
                . '<h3>Your new token</h3>'
                . '<div class="imcp-copyrow"><input id="imcpNewTok" class="imcp-input imcp-mono" readonly value="' . $tok . '">'
                . '<button type="button" class="imcp-btn imcp-btn-ghost" onclick="imcpCopy(\'imcpNewTok\',this)">Copy</button></div>'
                . '<p class="imcp-sub imcp-warn">Save this token now — it will not be shown again.</p>'
                . '<h4>Usage URL</h4>'
                . '<div class="imcp-copyrow"><input id="imcpUsageUrl" class="imcp-input imcp-mono" readonly value="' . $usageUrl . '">'
                . '<button type="button" class="imcp-btn imcp-btn-ghost" onclick="imcpCopy(\'imcpUsageUrl\',this)">Copy</button></div>'
                . '<p class="imcp-sub">For clients that take a single URL — the token is passed as the <code>t</code> query parameter.</p>'
                . '<h4>Authorization Header</h4>'
                . '<div class="imcp-copyrow"><input id="imcpAuthHdr" class="imcp-input imcp-mono" readonly value="' . $authHdr . '">'
                . '<button type="button" class="imcp-btn imcp-btn-ghost" onclick="imcpCopy(\'imcpAuthHdr\',this)">Copy</button></div>'
                . '<p class="imcp-sub">Recommended for production — header tokens are not written to server access logs the way URL tokens can be.</p>'
                . '</div>';
        }

        return $reveal . '<div class="imcp-card">'
            . '<div class="imcp-card-head">'
            . '<div><h3>API Credentials</h3><p class="imcp-sub">Manage API keys and bearer tokens for MCP server authentication.</p></div>'
            . $genForm
            . '</div>'
            . '<table class="imcp-table"><thead><tr>'
            . '<th>Name</th><th>Type</th><th>Identifier</th><th>Status</th><th>Created</th><th>Last Used</th><th></th>'
            . '</tr></thead><tbody>' . $rows . '</tbody></table>'
            . '</div>';
    }

    // -----------------------------------------------------------------------
    //  Tab 2 — Tool Management
    // -----------------------------------------------------------------------
    private function renderTools()
    {
        $catalogue = Tools::catalogue();
        $allNames  = Tools::names();
        $disabled  = array_flip(Settings::getDisabledTools());
        $total     = count($allNames);
        $enabledCount = $total - count($disabled);

        $groups = '';
        foreach ($catalogue as $category => $defs) {
            $names = array_keys($defs);
            $catEnabled = 0;
            foreach ($names as $n) {
                if (!isset($disabled[$n])) {
                    $catEnabled++;
                }
            }
            $allOn = $catEnabled === count($names);

            $items = '';
            foreach ($defs as $name => $def) {
                $checked = isset($disabled[$name]) ? '' : 'checked';
                $adminTag = !empty($def['admin']) ? ' <span class="imcp-tag-danger">sensitive</span>' : '';
                $items .= '<label class="imcp-toolrow">'
                    . '<span class="imcp-toolname"><code>' . $this->esc($name) . '</code>' . $adminTag
                    . '<span class="imcp-tooldesc">' . $this->esc($def['desc']) . '</span></span>'
                    . '<span class="imcp-switch"><input type="checkbox" class="imcp-tool-cb" data-cat="' . $this->esc($category) . '" name="enabled[]" value="' . $this->esc($name) . '" ' . $checked . '><span class="imcp-slider"></span></span>'
                    . '</label>';
            }

            $groups .= '<div class="imcp-group">'
                . '<div class="imcp-group-head" onclick="imcpToggleGroup(this)">'
                . '<span class="imcp-caret">&#9656;</span>'
                . '<span class="imcp-group-title">' . $this->esc($category) . '</span>'
                . '<span class="imcp-group-count" data-cat="' . $this->esc($category) . '">(' . $catEnabled . '/' . count($names) . ' enabled)</span>'
                . '<span class="imcp-switch imcp-master" onclick="event.stopPropagation();">'
                . '<input type="checkbox" class="imcp-master-cb" data-cat="' . $this->esc($category) . '" ' . ($allOn ? 'checked' : '') . ' onclick="imcpMasterToggle(this)">'
                . '<span class="imcp-slider"></span></span>'
                . '</div>'
                . '<div class="imcp-group-body">' . $items . '</div>'
                . '</div>';
        }

        return '<form method="post">' . $this->csrfField()
            . '<input type="hidden" name="mcp_action" value="save_tools">'
            . '<div class="imcp-card">'
            . '<div class="imcp-toolhead"><strong>&#9432; MCP Tool Management</strong>'
            . '<p class="imcp-sub">Enable or disable individual MCP tools. Disabled tools will be rejected by the API and omitted from tools/list. Use this to restrict which operations AI assistants can perform.</p></div>'
            . '<div class="imcp-counts"><span class="imcp-c-enabled" id="imcpEnabledCount">' . $enabledCount . ' Enabled</span> '
            . '<span class="imcp-c-disabled" id="imcpDisabledCount">' . count($disabled) . ' Disabled</span> '
            . '<span class="imcp-c-total">' . $total . ' Total</span></div>'
            . '<div class="imcp-groups">' . $groups . '</div>'
            . '<div class="imcp-actions"><button type="submit" class="imcp-btn imcp-btn-primary">Save Changes</button> '
            . '<a href="' . $this->tabUrl('tools') . '" class="imcp-btn imcp-btn-ghost">Cancel</a></div>'
            . '</div></form>';
    }

    // -----------------------------------------------------------------------
    //  Tab 3 — Settings (Connection / License / Configuration / About)
    // -----------------------------------------------------------------------
    private function renderSettings()
    {
        $sub = isset($_GET['sub']) ? preg_replace('/[^a-z]/', '', $_GET['sub']) : 'connection';
        if (!in_array($sub, ['connection', 'license', 'configuration', 'about'], true)) {
            $sub = 'connection';
        }

        $nav = '<div class="imcp-settings-nav">'
            . $this->settingsNavItem('connection', '&#9728; Connection', $sub)
            . $this->settingsNavItem('license', '&#128273; License', $sub)
            . $this->settingsNavItem('configuration', '&#9881; Configuration', $sub)
            . $this->settingsNavItem('about', '&#9432; About', $sub)
            . '</div>';

        if ($sub === 'connection') {
            $body = $this->settingsConnection();
        } elseif ($sub === 'license') {
            $body = $this->settingsLicense();
        } elseif ($sub === 'configuration') {
            $body = $this->settingsConfiguration();
        } else {
            $body = $this->settingsAbout();
        }

        return '<div class="imcp-settings">' . $nav . '<div class="imcp-settings-body">' . $body . '</div></div>';
    }

    private function settingsNavItem($key, $label, $active)
    {
        $cls = $key === $active ? 'imcp-snav active' : 'imcp-snav';
        $url = $this->esc($this->link . '&tab=settings&sub=' . $key);
        return '<a class="' . $cls . '" href="' . $url . '">' . $label . '</a>';
    }

    private function endpointUrl()
    {
        $base = '';
        try {
            $base = \WHMCS\Config\Setting::getValue('SystemURL');
        } catch (\Throwable $e) {
        }
        if (!$base) {
            $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
                . '://' . ($_SERVER['HTTP_HOST'] ?? 'your-whmcs') . '/';
        }
        return rtrim($base, '/') . '/modules/addons/insation_mcp/mcp.php';
    }

    private function settingsConnection()
    {
        $enabled = Settings::get('endpoint_enabled', '1') === '1';
        $url = $this->esc($this->endpointUrl());

        $statusCard = '<div class="imcp-card imcp-half">'
            . '<h4>Endpoint Status</h4>'
            . '<form method="post" class="imcp-inline">' . $this->csrfField()
            . '<input type="hidden" name="mcp_action" value="toggle_endpoint">'
            . '<label class="imcp-switch"><input type="checkbox" name="enabled" value="1" ' . ($enabled ? 'checked' : '') . ' onchange="this.form.submit()"><span class="imcp-slider"></span></label>'
            . '<span class="imcp-switch-label">' . ($enabled ? 'Enabled' : 'Disabled') . '</span>'
            . '</form>'
            . '<p class="imcp-sub">MCP HTTP endpoint for external AI client connections.</p></div>';

        $urlCard = '<div class="imcp-card imcp-half">'
            . '<h4>Endpoint URL</h4>'
            . '<div class="imcp-copyrow"><input type="text" readonly value="' . $url . '" id="imcpEpUrl" class="imcp-input imcp-mono">'
            . '<button type="button" class="imcp-btn imcp-btn-ghost" onclick="imcpCopy(\'imcpEpUrl\',this)">Copy</button></div>'
            . '<p class="imcp-sub">This is the URL external MCP clients should connect to.</p></div>';

        $authCard = '<div class="imcp-card imcp-half">'
            . '<h4>Authentication</h4>'
            . '<p class="imcp-sub">External MCP clients authenticate using a Bearer token:</p>'
            . '<pre class="imcp-code">Authorization: Bearer &lt;your-token&gt;</pre>'
            . '<p class="imcp-sub">Manage tokens on the <a href="' . $this->tabUrl('apikeys') . '">API Keys</a> tab.</p></div>';

        $testCard = '<div class="imcp-card imcp-half">'
            . '<h4>Test Endpoint</h4>'
            . '<p class="imcp-sub">Run an internal <code>initialize</code> check to verify the endpoint, license and credentials.</p>'
            . '<form method="post">' . $this->csrfField()
            . '<input type="hidden" name="mcp_action" value="test_endpoint">'
            . '<button type="submit" class="imcp-btn imcp-btn-primary">Test Endpoint</button></form></div>';

        return '<div class="imcp-grid">' . $statusCard . $urlCard . $authCard . $testCard . '</div>'
            . $this->setupAssistant();
    }

    private function setupAssistant()
    {
        $url = $this->endpointUrl();
        $claude = json_encode([
            'mcpServers' => [
                'whmcs' => [
                    'command' => 'npx',
                    'args' => ['-y', 'mcp-remote', $url, '--header', 'Authorization:Bearer <YOUR_BEARER_TOKEN>'],
                ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        $cursor = json_encode([
            'mcpServers' => [
                'whmcs' => [
                    'url' => $url,
                    'headers' => ['Authorization' => 'Bearer <YOUR_BEARER_TOKEN>'],
                ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        $direct = json_encode([
            'type' => 'http',
            'url' => $url,
            'headers' => ['Authorization' => 'Bearer <YOUR_BEARER_TOKEN>'],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        $generic = "POST {$url}\n"
            . "Authorization: Bearer <YOUR_BEARER_TOKEN>\n"
            . "Content-Type: application/json\n\n"
            . '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}';

        $panel = function ($id, $code, $active) {
            return '<div class="imcp-setup-panel' . ($active ? ' active' : '') . '" id="imcp-panel-' . $id . '">'
                . '<pre class="imcp-code" id="imcp-code-' . $id . '">' . htmlspecialchars($code, ENT_QUOTES) . '</pre>'
                . '<div class="imcp-setup-actions">'
                . '<button type="button" class="imcp-btn imcp-btn-ghost" onclick="imcpCopyText(\'imcp-code-' . $id . '\',this)">Copy</button></div>'
                . '</div>';
        };

        return '<div class="imcp-card">'
            . '<h4>Setup Assistant</h4>'
            . '<p class="imcp-sub">Copy the configuration into your MCP client. Replace <code>&lt;YOUR_BEARER_TOKEN&gt;</code> with the token you received when generating a credential.</p>'
            . '<div class="imcp-setup">'
            . '<div class="imcp-setup-tabs">'
            . '<button type="button" class="imcp-setup-tab active" onclick="imcpSetupTab(\'claude\',this)">Claude Desktop / Codex</button>'
            . '<button type="button" class="imcp-setup-tab" onclick="imcpSetupTab(\'cursor\',this)">Cursor</button>'
            . '<button type="button" class="imcp-setup-tab" onclick="imcpSetupTab(\'direct\',this)">Direct HTTP</button>'
            . '<button type="button" class="imcp-setup-tab" onclick="imcpSetupTab(\'generic\',this)">Generic</button>'
            . '</div>'
            . '<div class="imcp-setup-body">'
            . $panel('claude', $claude, true)
            . $panel('cursor', $cursor, false)
            . $panel('direct', $direct, false)
            . $panel('generic', $generic, false)
            . '</div></div>'
            . '<p class="imcp-sub"><strong>File location:</strong><br>'
            . 'macOS: <code>~/Library/Application Support/Claude/claude_desktop_config.json</code><br>'
            . 'Windows: <code>%APPDATA%\\Claude\\claude_desktop_config.json</code></p>'
            . '<p class="imcp-sub">Uses <code>mcp-remote</code> as a bridge. Also works with Codex Desktop.</p>'
            . '</div>';
    }

    private function settingsLicense()
    {
        $st = License::getState();
        $licensed = $st['status'] === 'licensed';
        $badge = $licensed
            ? '<span class="imcp-badge imcp-badge-active">Active</span>'
            : '<span class="imcp-badge imcp-badge-revoked">Inactive</span>';

        $details = '';
        if ($st['key']) {
            $details = '<table class="imcp-kv">'
                . '<tr><td>Status</td><td>' . $badge . '</td></tr>'
                . '<tr><td>Key</td><td><code>' . $this->esc(License::maskKey($st['key'])) . '</code></td></tr>'
                . '<tr><td>Reason</td><td>' . $this->esc($st['reason_message']) . '</td></tr>'
                . ($st['tier'] ? '<tr><td>Tier</td><td>' . $this->esc($st['tier']) . '</td></tr>' : '')
                . ($st['expires'] ? '<tr><td>Expires</td><td>' . $this->esc($st['expires']) . '</td></tr>' : '')
                . ($st['activation_remaining'] !== '' ? '<tr><td>Activations remaining</td><td>' . $this->esc($st['activation_remaining']) . '</td></tr>' : '')
                . '<tr><td>Instance</td><td><code>' . $this->esc($st['instance']) . '</code></td></tr>'
                . '<tr><td>Last checked</td><td>' . ($st['last_check'] ? date('d/m/Y h:i A', $st['last_check']) : '—') . '</td></tr>'
                . '</table>';
        }

        $form = '<form method="post" class="imcp-licform">' . $this->csrfField()
            . '<input type="hidden" name="mcp_action" value="license_activate">'
            . '<label class="imcp-label">License key</label>'
            . '<input type="text" name="license_key" class="imcp-input imcp-mono" placeholder="' . $this->esc(License::KEY_PREFIX) . '1-XXXX-XXXX-XXXX" value="">'
            . '<div class="imcp-actions">'
            . '<button type="submit" class="imcp-btn imcp-btn-primary">Activate License</button>'
            . '</div></form>';

        $extra = '';
        if ($st['key']) {
            $extra = '<div class="imcp-actions">'
                . '<form method="post" style="display:inline"><input type="hidden" name="csrf" value="' . $this->csrf() . '"><input type="hidden" name="mcp_action" value="license_recheck"><button type="submit" class="imcp-btn imcp-btn-ghost">Re-check Now</button></form> '
                . '<form method="post" style="display:inline" onsubmit="return confirm(\'Remove the license from this site? The endpoint will stop serving.\');"><input type="hidden" name="csrf" value="' . $this->csrf() . '"><input type="hidden" name="mcp_action" value="license_deactivate"><button type="submit" class="imcp-btn imcp-btn-ghost imcp-danger">Remove License</button></form>';
        }

        $note = $licensed
            ? '<div class="imcp-alert imcp-success">This installation is licensed and the MCP endpoint is enabled.</div>'
            : '<div class="imcp-alert imcp-error">This installation is not licensed. The MCP endpoint will refuse client requests until a valid key is activated.</div>';

        return '<div class="imcp-card">'
            . '<h4>License</h4>'
            . '<p class="imcp-sub">Per-site licensing is verified against insation.ai. Enter the license key from your purchase to activate this site.</p>'
            . $note . $details . $form . $extra
            . '</div>';
    }

    private function settingsConfiguration()
    {
        $admins = Capsule::table('tbladmins')->where('disabled', 0)->orderBy('username')->get();
        $current = Settings::get('admin_username', '');
        $options = '';
        foreach ($admins as $a) {
            $sel = $a->username === $current ? 'selected' : '';
            $options .= '<option value="' . $this->esc($a->username) . '" ' . $sel . '>' . $this->esc($a->username) . ' (' . $this->esc(trim($a->firstname . ' ' . $a->lastname)) . ')</option>';
        }

        return '<div class="imcp-card">'
            . '<h4>API Admin User</h4>'
            . '<p class="imcp-sub">MCP tools execute WHMCS local API calls as this administrator. Choose an admin with the permissions you want the AI assistant to have. Tip: create a dedicated, role-limited admin to scope access.</p>'
            . '<form method="post" class="imcp-inline">' . $this->csrfField()
            . '<input type="hidden" name="mcp_action" value="save_admin">'
            . '<select name="admin_username" class="imcp-input">' . $options . '</select> '
            . '<button type="submit" class="imcp-btn imcp-btn-primary">Save</button>'
            . '</form>'
            . '<hr class="imcp-hr">'
            . '<h4>Security notes</h4>'
            . '<ul class="imcp-list">'
            . '<li>Bearer tokens are stored as SHA-256 hashes; the full token is shown only once at creation.</li>'
            . '<li>Disabled tools are rejected by the endpoint and hidden from <code>tools/list</code>.</li>'
            . '<li>The endpoint refuses all requests when the license is inactive or the endpoint is disabled.</li>'
            . '</ul>'
            . '</div>';
    }

    private function settingsAbout()
    {
        $v = $this->esc($this->vars['version'] ?? INSATION_MCP_VERSION);
        return '<div class="imcp-card">'
            . '<h4>About</h4>'
            . '<table class="imcp-kv">'
            . '<tr><td>Module</td><td>Insation MCP Server</td></tr>'
            . '<tr><td>Version</td><td>v' . $v . '</td></tr>'
            . '<tr><td>Author</td><td>InsationAI — <a href="https://insation.ai" target="_blank">insation.ai</a></td></tr>'
            . '<tr><td>Protocol</td><td>Model Context Protocol (Streamable HTTP)</td></tr>'
            . '<tr><td>Tools</td><td>' . count(Tools::names()) . ' across ' . count(Tools::catalogue()) . ' categories</td></tr>'
            . '</table>'
            . '<p class="imcp-sub">Turns WHMCS into a secure MCP server for AI assistants. Per-site licensing by InsationAI.</p>'
            . '</div>';
    }

    // -----------------------------------------------------------------------
    //  Helpers
    // -----------------------------------------------------------------------
    private function esc($s)
    {
        return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
    }

    // -----------------------------------------------------------------------
    //  Styles + scripts
    // -----------------------------------------------------------------------
    private function styles()
    {
        return <<<CSS
<style>
.imcp-wrap{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:#1f2733;max-width:1200px;background:#f5f7fa;padding:18px 22px;border-radius:12px;box-sizing:border-box;}
.imcp-titlebar{display:flex;align-items:baseline;gap:10px;margin:6px 0 14px;}
.imcp-title{font-size:26px;font-weight:700;color:#15233b;}
.imcp-ver{color:#8a93a2;font-size:13px;}
.imcp-tabs{display:flex;gap:6px;border-bottom:1px solid #e3e7ee;margin-bottom:18px;}
.imcp-tab{padding:8px 16px;border-radius:6px 6px 0 0;text-decoration:none;color:#2b3a55;font-weight:600;font-size:14px;}
.imcp-tab.active{background:#23426e;color:#fff;}
.imcp-card{background:#fff;border:1px solid #e6e9ef;border-radius:10px;padding:20px 22px;margin-bottom:18px;box-shadow:0 1px 2px rgba(20,30,50,.04);}
.imcp-card h3{margin:0 0 2px;font-size:18px;}
.imcp-card h4{margin:0 0 10px;font-size:15px;}
.imcp-sub{color:#7b8494;font-size:13px;margin:4px 0;}
.imcp-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:16px;flex-wrap:wrap;}
.imcp-btn{display:inline-block;border:none;border-radius:7px;padding:9px 16px;font-size:14px;font-weight:600;cursor:pointer;text-decoration:none;}
.imcp-btn-primary{background:#23426e;color:#fff;}
.imcp-btn-primary:hover{background:#1b3358;}
.imcp-btn-ghost{background:#f1f3f7;color:#33415c;border:1px solid #dfe3ea;}
.imcp-danger{color:#c0392b!important;}
.imcp-input{border:1px solid #d4dae3;border-radius:7px;padding:8px 11px;font-size:14px;min-width:180px;}
.imcp-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;}
.imcp-genform{display:flex;gap:8px;align-items:center;}
.imcp-table{width:100%;border-collapse:collapse;font-size:14px;}
.imcp-table th{text-align:left;color:#5a6473;font-weight:700;padding:10px 12px;border-bottom:2px solid #eef1f5;font-size:13px;}
.imcp-table td{padding:14px 12px;border-bottom:1px solid #f0f2f6;vertical-align:middle;}
.imcp-empty{text-align:center;color:#9aa3b2;padding:30px!important;}
.imcp-type{color:#2f6fd0;font-weight:600;}
.imcp-id{color:#c2185b;background:#fbe9f1;padding:3px 7px;border-radius:5px;font-size:12px;}
.imcp-token-new{color:#1c8c46;background:#e6f6ec;padding:3px 7px;border-radius:5px;font-weight:700;}
.imcp-badge{padding:3px 11px;border-radius:20px;font-size:12px;font-weight:600;}
.imcp-badge-active{background:#e6f6ec;color:#1c8c46;}
.imcp-badge-revoked{background:#f1f3f7;color:#8a93a2;}
.imcp-alert{padding:11px 15px;border-radius:8px;margin-bottom:14px;font-size:14px;}
.imcp-success{background:#e6f6ec;color:#15703a;border:1px solid #b9e6c9;}
.imcp-error{background:#fdecea;color:#a32219;border:1px solid #f5c4be;}
.imcp-rowmenu{position:relative;display:inline-block;}
.imcp-kebab{background:none;border:none;font-size:20px;cursor:pointer;color:#7b8494;padding:0 6px;}
.imcp-menu{display:none;position:absolute;right:0;top:24px;background:#fff;border:1px solid #e0e4ec;border-radius:8px;box-shadow:0 6px 20px rgba(20,30,50,.12);z-index:20;min-width:120px;overflow:hidden;}
.imcp-menu.open{display:block;}
.imcp-menu-item{display:block;width:100%;text-align:left;background:none;border:none;padding:9px 14px;font-size:14px;cursor:pointer;}
.imcp-menu-item:hover{background:#f5f7fa;}
.imcp-toolhead{margin-bottom:8px;}
.imcp-counts{margin:6px 0 16px;font-size:13px;}
.imcp-c-enabled{color:#1c8c46;font-weight:700;}
.imcp-c-disabled{color:#c0392b;font-weight:700;margin:0 8px;}
.imcp-c-total{color:#7b8494;font-weight:700;}
.imcp-group{border:1px solid #eaedf2;border-radius:10px;margin-bottom:10px;overflow:hidden;}
.imcp-group-head{display:flex;align-items:center;gap:10px;padding:14px 16px;cursor:pointer;background:#fff;}
.imcp-group-head:hover{background:#fafbfc;}
.imcp-caret{transition:transform .15s;color:#8a93a2;font-size:12px;}
.imcp-group.open .imcp-caret{transform:rotate(90deg);}
.imcp-group-title{font-weight:700;font-size:14px;}
.imcp-group-count{color:#8a93a2;font-size:13px;}
.imcp-master{margin-left:auto;}
.imcp-group-body{display:none;padding:6px 16px 12px;border-top:1px solid #f0f2f6;}
.imcp-group.open .imcp-group-body{display:block;}
.imcp-toolrow{display:flex;align-items:center;justify-content:space-between;padding:10px 4px;border-bottom:1px solid #f4f6f9;gap:14px;}
.imcp-toolrow:last-child{border-bottom:none;}
.imcp-toolname{display:flex;flex-direction:column;gap:3px;}
.imcp-toolname code{color:#23426e;font-size:13px;font-weight:600;}
.imcp-tooldesc{color:#8a93a2;font-size:12px;}
.imcp-tag-danger{display:inline-block;background:#fdecea;color:#c0392b;font-size:10px;padding:1px 6px;border-radius:10px;margin-left:6px;font-weight:700;}
.imcp-switch{position:relative;display:inline-block;width:42px;height:24px;flex:0 0 auto;}
.imcp-switch input{opacity:0;width:0;height:0;}
.imcp-slider{position:absolute;inset:0;background:#cfd6e0;border-radius:24px;transition:.2s;cursor:pointer;}
.imcp-slider:before{content:"";position:absolute;height:18px;width:18px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s;}
.imcp-switch input:checked + .imcp-slider{background:#23426e;}
.imcp-switch input:checked + .imcp-slider:before{transform:translateX(18px);}
.imcp-switch-label{margin-left:10px;font-weight:600;font-size:14px;}
.imcp-actions{margin-top:16px;}
.imcp-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;}
.imcp-half{margin-bottom:0;}
.imcp-code{background:#1e293b;color:#e2e8f0;padding:14px 16px;border-radius:8px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;overflow:auto;white-space:pre;}
.imcp-copyrow{display:flex;gap:8px;}
.imcp-copyrow .imcp-input{flex:1;}
.imcp-reveal{border-color:#2563EB!important;}
.imcp-reveal h4{margin:16px 0 6px;font-size:14px;}
.imcp-warn{color:#c0392b;font-weight:600;}
.imcp-inline{display:flex;align-items:center;gap:8px;}
.imcp-settings{display:flex;gap:20px;align-items:flex-start;}
.imcp-settings-nav{flex:0 0 180px;display:flex;flex-direction:column;gap:4px;}
.imcp-snav{padding:9px 13px;border-radius:7px;text-decoration:none;color:#2b3a55;font-weight:600;font-size:14px;}
.imcp-snav.active{background:#23426e;color:#fff;}
.imcp-settings-body{flex:1;min-width:0;}
.imcp-setup{border:1px solid #eaedf2;border-radius:10px;overflow:hidden;margin-top:8px;}
.imcp-setup-tabs{display:flex;flex-wrap:wrap;background:#f5f7fa;border-bottom:1px solid #eaedf2;}
.imcp-setup-tab{background:none;border:none;padding:10px 14px;font-size:13px;font-weight:600;cursor:pointer;color:#41506a;}
.imcp-setup-tab.active{background:#23426e;color:#fff;}
.imcp-setup-body{padding:14px;}
.imcp-setup-panel{display:none;}
.imcp-setup-panel.active{display:block;}
.imcp-setup-actions{margin-top:8px;}
.imcp-kv{border-collapse:collapse;font-size:14px;}
.imcp-kv td{padding:7px 14px 7px 0;border-bottom:1px solid #f0f2f6;}
.imcp-kv td:first-child{color:#7b8494;font-weight:600;white-space:nowrap;}
.imcp-list{color:#5a6473;font-size:13px;line-height:1.7;}
.imcp-hr{border:none;border-top:1px solid #eef1f5;margin:18px 0;}
.imcp-label{display:block;font-weight:600;font-size:13px;margin:6px 0 4px;}
.imcp-licform .imcp-input{width:100%;max-width:420px;}
@media(max-width:900px){.imcp-grid{grid-template-columns:1fr;}.imcp-settings{flex-direction:column;}.imcp-settings-nav{flex-direction:row;flex-wrap:wrap;}}
</style>
CSS;
    }

    private function scripts()
    {
        return <<<'JS'
<script>
function imcpToggleMenu(btn){
  var m=btn.nextElementSibling;
  document.querySelectorAll('.imcp-menu.open').forEach(function(x){if(x!==m)x.classList.remove('open');});
  m.classList.toggle('open');
}
document.addEventListener('click',function(e){
  if(!e.target.closest('.imcp-rowmenu')){document.querySelectorAll('.imcp-menu.open').forEach(function(x){x.classList.remove('open');});}
});
function imcpToggleGroup(h){h.parentElement.classList.toggle('open');}
function imcpMasterToggle(cb){
  var cat=cb.getAttribute('data-cat');
  document.querySelectorAll('.imcp-tool-cb[data-cat="'+CSS.escape(cat)+'"]').forEach(function(x){x.checked=cb.checked;});
  imcpRecount();
}
function imcpRecount(){
  var boxes=document.querySelectorAll('.imcp-tool-cb');
  var en=0,total=boxes.length;
  boxes.forEach(function(x){if(x.checked)en++;});
  var ec=document.getElementById('imcpEnabledCount');var dc=document.getElementById('imcpDisabledCount');
  if(ec)ec.textContent=en+' Enabled';
  if(dc)dc.textContent=(total-en)+' Disabled';
  var cats={};
  boxes.forEach(function(x){var c=x.getAttribute('data-cat');if(!cats[c])cats[c]={t:0,e:0};cats[c].t++;if(x.checked)cats[c].e++;});
  Object.keys(cats).forEach(function(c){
    var span=document.querySelector('.imcp-group-count[data-cat="'+CSS.escape(c)+'"]');
    if(span)span.textContent='('+cats[c].e+'/'+cats[c].t+' enabled)';
    var m=document.querySelector('.imcp-master-cb[data-cat="'+CSS.escape(c)+'"]');
    if(m)m.checked=(cats[c].e===cats[c].t);
  });
}
document.addEventListener('change',function(e){if(e.target.classList&&e.target.classList.contains('imcp-tool-cb'))imcpRecount();});
function imcpCopy(id,btn){var el=document.getElementById(id);el.select();document.execCommand('copy');imcpFlash(btn);}
function imcpCopyText(id,btn){var t=document.getElementById(id).innerText;navigator.clipboard?navigator.clipboard.writeText(t):0;imcpFlash(btn);}
function imcpFlash(btn){var o=btn.textContent;btn.textContent='Copied!';setTimeout(function(){btn.textContent=o;},1200);}
function imcpSetupTab(id,btn){
  document.querySelectorAll('.imcp-setup-tab').forEach(function(x){x.classList.remove('active');});
  document.querySelectorAll('.imcp-setup-panel').forEach(function(x){x.classList.remove('active');});
  btn.classList.add('active');
  var p=document.getElementById('imcp-panel-'+id);if(p)p.classList.add('active');
}
</script>
JS;
    }
}
