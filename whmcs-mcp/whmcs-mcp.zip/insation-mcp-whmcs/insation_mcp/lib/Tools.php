<?php
/**
 * Insation MCP Server — Tool registry & dispatcher.
 *
 * Defines every MCP tool, its JSON Schema, the category it belongs to, and how
 * it maps onto WHMCS. Most tools forward straight to the WHMCS local API; a
 * handful with no 1:1 API are implemented as custom handlers (Capsule queries
 * or small compositions).
 *
 * @package InsationMCP
 */

namespace InsationMCP;

use WHMCS\Database\Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class Tools
{
    /**
     * The full tool catalogue, grouped by category.
     *
     * Each entry:
     *   'desc'     => short description (shown to the AI client)
     *   'api'      => WHMCS local API action (direct passthrough), OR
     *   'handler'  => custom method name on this class
     *   'props'    => JSON Schema properties for the tool's arguments
     *   'required' => required property names
     *   'admin'    => bool, true if this is a destructive/sensitive op (UI hint)
     *
     * @return array<string, array<string, array>>  category => [toolName => def]
     */
    public static function catalogue()
    {
        $str  = ['type' => 'string'];
        $int  = ['type' => 'integer'];
        $num  = ['type' => 'number'];
        $bool = ['type' => 'boolean'];

        return [
            'Client Management' => [
                'whmcs_list_clients' => [
                    'desc' => 'List clients with search and pagination.',
                    'api'  => 'GetClients',
                    'props' => [
                        'search'     => ['type' => 'string', 'description' => 'Search by name, email, or company.'],
                        'limitstart' => ['type' => 'integer', 'description' => 'Offset for pagination.'],
                        'limitnum'   => ['type' => 'integer', 'description' => 'Number of records (default 25).'],
                        'status'     => ['type' => 'string', 'description' => 'Active, Inactive or Closed.'],
                    ],
                ],
                'whmcs_get_client' => [
                    'desc' => 'Get detailed client information.',
                    'api'  => 'GetClientsDetails',
                    'props' => [
                        'clientid' => ['type' => 'integer', 'description' => 'Client ID.'],
                        'email'    => ['type' => 'string', 'description' => 'Client email (alternative to clientid).'],
                        'stats'    => ['type' => 'boolean', 'description' => 'Include billing stats.'],
                    ],
                ],
                'whmcs_create_client' => [
                    'desc' => 'Create a new client.',
                    'api'  => 'AddClient',
                    'required' => ['firstname', 'lastname', 'email'],
                    'props' => [
                        'firstname' => $str, 'lastname' => $str, 'email' => $str,
                        'companyname' => $str, 'address1' => $str, 'city' => $str,
                        'state' => $str, 'postcode' => $str, 'country' => ['type' => 'string', 'description' => 'ISO country code, e.g. US.'],
                        'phonenumber' => $str, 'password2' => ['type' => 'string', 'description' => 'Account password.'],
                        'currency' => ['type' => 'integer', 'description' => 'Currency ID.'],
                    ],
                ],
                'whmcs_update_client' => [
                    'desc' => 'Update client information.',
                    'api'  => 'UpdateClient',
                    'required' => ['clientid'],
                    'props' => [
                        'clientid' => $int, 'firstname' => $str, 'lastname' => $str,
                        'email' => $str, 'companyname' => $str, 'address1' => $str,
                        'city' => $str, 'state' => $str, 'postcode' => $str,
                        'country' => $str, 'phonenumber' => $str, 'status' => $str,
                        'credit' => $num,
                    ],
                ],
                'whmcs_delete_client' => [
                    'desc' => 'Delete a client permanently.',
                    'api'  => 'DeleteClient',
                    'required' => ['clientid'],
                    'admin' => true,
                    'props' => ['clientid' => $int],
                ],
            ],

            'Products' => [
                'whmcs_list_products' => [
                    'desc' => 'List available products.',
                    'api'  => 'GetProducts',
                    'props' => [
                        'pid'   => ['type' => 'integer', 'description' => 'Filter by product ID.'],
                        'gid'   => ['type' => 'integer', 'description' => 'Filter by product group ID.'],
                        'module' => $str,
                    ],
                ],
                'whmcs_create_product' => [
                    'desc' => 'Create a new product in the catalog.',
                    'api'  => 'AddProduct',
                    'required' => ['name', 'gid'],
                    'props' => [
                        'name' => $str, 'gid' => ['type' => 'integer', 'description' => 'Product group ID.'],
                        'type' => ['type' => 'string', 'description' => 'hostingaccount, reselleraccount, server or other.'],
                        'paytype' => ['type' => 'string', 'description' => 'free, onetime or recurring.'],
                        'description' => $str, 'module' => $str, 'monthly' => $num, 'annually' => $num,
                    ],
                ],
            ],

            'Service Management' => [
                'whmcs_list_client_services' => [
                    'desc' => 'List services for a client.',
                    'api'  => 'GetClientsProducts',
                    'props' => [
                        'clientid' => $int, 'serviceid' => $int, 'pid' => $int,
                        'domain' => $str, 'limitstart' => $int, 'limitnum' => $int,
                    ],
                ],
                'whmcs_provision_service' => [
                    'desc' => 'Provision service via module command (create on server).',
                    'api'  => 'ModuleCreate',
                    'required' => ['serviceid'],
                    'props' => ['serviceid' => $int],
                ],
                'whmcs_suspend_service' => [
                    'desc' => 'Suspend a service.',
                    'api'  => 'ModuleSuspend',
                    'required' => ['serviceid'],
                    'props' => ['serviceid' => $int, 'suspendreason' => $str],
                ],
                'whmcs_unsuspend_service' => [
                    'desc' => 'Unsuspend/reactivate a service.',
                    'api'  => 'ModuleUnsuspend',
                    'required' => ['serviceid'],
                    'props' => ['serviceid' => $int],
                ],
                'whmcs_terminate_service' => [
                    'desc' => 'Terminate a service.',
                    'api'  => 'ModuleTerminate',
                    'required' => ['serviceid'],
                    'admin' => true,
                    'props' => ['serviceid' => $int],
                ],
                'whmcs_change_password' => [
                    'desc' => 'Change service account password via module.',
                    'api'  => 'ModuleChangePw',
                    'required' => ['serviceid'],
                    'props' => ['serviceid' => $int, 'servicepassword' => $str],
                ],
                'whmcs_change_package' => [
                    'desc' => 'Upgrade or downgrade service package.',
                    'api'  => 'UpgradeProduct',
                    'required' => ['serviceid', 'newproductid'],
                    'props' => [
                        'serviceid' => $int,
                        'type' => ['type' => 'string', 'description' => "Defaults to 'product'."],
                        'newproductid' => $int,
                        'newproductbillingcycle' => $str,
                        'calcdate' => $bool,
                    ],
                ],
                'whmcs_update_service' => [
                    'desc' => 'Update service status or configuration.',
                    'api'  => 'UpdateClientProduct',
                    'required' => ['serviceid'],
                    'props' => [
                        'serviceid' => $int, 'status' => $str, 'domain' => $str,
                        'nextduedate' => $str, 'recurringamount' => $num,
                        'billingcycle' => $str, 'serverid' => $int,
                        'dedicatedip' => $str, 'username' => $str,
                    ],
                ],
            ],

            'Invoice Management' => [
                'whmcs_list_invoices' => [
                    'desc' => 'List invoices with filtering.',
                    'api'  => 'GetInvoices',
                    'props' => [
                        'userid' => $int, 'status' => $str,
                        'limitstart' => $int, 'limitnum' => $int,
                    ],
                ],
                'whmcs_get_invoice' => [
                    'desc' => 'Get detailed invoice information.',
                    'api'  => 'GetInvoice',
                    'required' => ['invoiceid'],
                    'props' => ['invoiceid' => $int],
                ],
                'whmcs_create_invoice' => [
                    'desc' => 'Create a new invoice.',
                    'api'  => 'CreateInvoice',
                    'required' => ['userid'],
                    'props' => [
                        'userid' => $int, 'status' => $str, 'date' => $str,
                        'duedate' => $str, 'paymentmethod' => $str, 'notes' => $str,
                        'sendinvoice' => $bool, 'autoapplycredit' => $bool,
                    ],
                ],
                'whmcs_update_invoice' => [
                    'desc' => 'Update invoice status, dates, or notes.',
                    'api'  => 'UpdateInvoice',
                    'required' => ['invoiceid'],
                    'props' => [
                        'invoiceid' => $int, 'status' => $str, 'date' => $str,
                        'duedate' => $str, 'notes' => $str, 'paymentmethod' => $str,
                    ],
                ],
                'whmcs_add_invoice_line_items' => [
                    'desc' => 'Add line items to an existing invoice.',
                    'handler' => 'addInvoiceLineItems',
                    'required' => ['invoiceid', 'items'],
                    'props' => [
                        'invoiceid' => $int,
                        'items' => [
                            'type' => 'array',
                            'description' => 'Line items to add.',
                            'items' => [
                                'type' => 'object',
                                'properties' => [
                                    'description' => $str,
                                    'amount' => $num,
                                    'taxed' => $bool,
                                ],
                            ],
                        ],
                    ],
                ],
                'whmcs_add_invoice_payment' => [
                    'desc' => 'Record a payment against an invoice.',
                    'api'  => 'AddInvoicePayment',
                    'required' => ['invoiceid', 'amount'],
                    'props' => [
                        'invoiceid' => $int, 'amount' => $num,
                        'transid' => $str, 'gateway' => $str, 'date' => $str,
                        'fees' => $num,
                    ],
                ],
                'whmcs_apply_credit' => [
                    'desc' => 'Apply client credit to reduce an invoice balance.',
                    'handler' => 'applyCredit',
                    'required' => ['invoiceid', 'amount'],
                    'props' => ['invoiceid' => $int, 'amount' => $num],
                ],
                'whmcs_get_transactions' => [
                    'desc' => 'List payment transactions.',
                    'api'  => 'GetTransactions',
                    'props' => ['invoiceid' => $int, 'clientid' => $int, 'transid' => $str],
                ],
            ],

            'Quote Management' => [
                'whmcs_list_quotes' => [
                    'desc' => 'List quotes with filtering.',
                    'api'  => 'GetQuotes',
                    'props' => ['limitstart' => $int, 'limitnum' => $int],
                ],
                'whmcs_get_quote' => [
                    'desc' => 'Get detailed quote information.',
                    'handler' => 'getQuote',
                    'required' => ['quoteid'],
                    'props' => ['quoteid' => $int],
                ],
                'whmcs_create_quote' => [
                    'desc' => 'Create a new quote with line items.',
                    'api'  => 'CreateQuote',
                    'required' => ['subject', 'stage', 'validuntil', 'datecreated'],
                    'props' => [
                        'subject' => $str, 'stage' => $str, 'validuntil' => $str,
                        'datecreated' => $str, 'userid' => $int,
                        'firstname' => $str, 'lastname' => $str, 'email' => $str,
                        'proposal' => $str,
                        'lineitems' => ['type' => 'array', 'description' => 'Array of {desc, qty, up (unit price), taxable}.'],
                    ],
                ],
                'whmcs_update_quote' => [
                    'desc' => 'Update quote details.',
                    'api'  => 'UpdateQuote',
                    'required' => ['quoteid'],
                    'props' => [
                        'quoteid' => $int, 'subject' => $str, 'stage' => $str,
                        'validuntil' => $str, 'proposal' => $str,
                    ],
                ],
                'whmcs_send_quote' => [
                    'desc' => 'Email quote to client.',
                    'api'  => 'SendQuote',
                    'required' => ['quoteid'],
                    'props' => ['quoteid' => $int],
                ],
                'whmcs_accept_quote' => [
                    'desc' => 'Accept quote and convert to invoice.',
                    'api'  => 'AcceptQuote',
                    'required' => ['quoteid'],
                    'props' => ['quoteid' => $int],
                ],
            ],

            'Order Management' => [
                'whmcs_list_orders' => [
                    'desc' => 'List orders with filtering and pagination.',
                    'api'  => 'GetOrders',
                    'props' => [
                        'id' => $int, 'userid' => $int, 'status' => $str,
                        'limitstart' => $int, 'limitnum' => $int,
                    ],
                ],
                'whmcs_get_order' => [
                    'desc' => 'Get detailed order information.',
                    'api'  => 'GetOrders',
                    'required' => ['id'],
                    'props' => ['id' => ['type' => 'integer', 'description' => 'Order ID.']],
                ],
                'whmcs_create_order' => [
                    'desc' => 'Create a new order with products/services.',
                    'api'  => 'AddOrder',
                    'required' => ['clientid', 'paymentmethod'],
                    'props' => [
                        'clientid' => $int, 'paymentmethod' => $str,
                        'pid' => ['type' => 'array', 'description' => 'Array of product IDs.'],
                        'domain' => ['type' => 'array', 'description' => 'Array of domains matching pid order.'],
                        'billingcycle' => ['type' => 'array', 'description' => 'Array of billing cycles.'],
                        'domaintype' => ['type' => 'array'],
                        'promocode' => $str, 'noinvoice' => $bool, 'noemail' => $bool,
                    ],
                ],
                'whmcs_accept_order' => [
                    'desc' => 'Accept a pending order.',
                    'api'  => 'AcceptOrder',
                    'required' => ['orderid'],
                    'props' => [
                        'orderid' => $int, 'serverid' => $int,
                        'sendregistrar' => $bool, 'autosetup' => $bool, 'sendemail' => $bool,
                    ],
                ],
                'whmcs_cancel_order' => [
                    'desc' => 'Cancel an order.',
                    'api'  => 'CancelOrder',
                    'required' => ['orderid'],
                    'props' => ['orderid' => $int, 'cancelsub' => $bool, 'noemail' => $bool],
                ],
                'whmcs_delete_order' => [
                    'desc' => 'Delete a cancelled or fraud order.',
                    'api'  => 'DeleteOrder',
                    'required' => ['orderid'],
                    'admin' => true,
                    'props' => ['orderid' => $int],
                ],
            ],

            'Support Tickets' => [
                'whmcs_list_tickets' => [
                    'desc' => 'List support tickets.',
                    'api'  => 'GetTickets',
                    'props' => [
                        'deptid' => $int, 'status' => $str, 'clientid' => $int,
                        'limitstart' => $int, 'limitnum' => $int,
                    ],
                ],
                'whmcs_get_ticket' => [
                    'desc' => 'Get ticket details including replies.',
                    'api'  => 'GetTicket',
                    'props' => ['ticketid' => $int, 'ticketnum' => $str],
                ],
                'whmcs_create_ticket' => [
                    'desc' => 'Open a new support ticket.',
                    'api'  => 'OpenTicket',
                    'required' => ['deptid', 'subject', 'message'],
                    'props' => [
                        'deptid' => $int, 'subject' => $str, 'message' => $str,
                        'clientid' => $int, 'email' => $str, 'name' => $str,
                        'priority' => $str, 'status' => $str,
                    ],
                ],
                'whmcs_reply_ticket' => [
                    'desc' => 'Add a reply to an existing ticket.',
                    'api'  => 'AddTicketReply',
                    'required' => ['ticketid', 'message'],
                    'props' => [
                        'ticketid' => $int, 'message' => $str, 'clientid' => $int,
                        'adminusername' => $str, 'status' => $str, 'noemail' => $bool,
                    ],
                ],
                'whmcs_add_ticket_note' => [
                    'desc' => 'Add an internal note to a ticket.',
                    'api'  => 'AddTicketNote',
                    'required' => ['ticketid', 'message'],
                    'props' => ['ticketid' => $int, 'message' => $str],
                ],
                'whmcs_update_ticket' => [
                    'desc' => 'Update ticket subject, status, or priority.',
                    'api'  => 'UpdateTicket',
                    'required' => ['ticketid'],
                    'props' => [
                        'ticketid' => $int, 'subject' => $str, 'status' => $str,
                        'priority' => $str, 'deptid' => $int, 'flag' => $int,
                    ],
                ],
                'whmcs_delete_ticket' => [
                    'desc' => 'Delete a ticket permanently.',
                    'api'  => 'DeleteTicket',
                    'required' => ['ticketid'],
                    'admin' => true,
                    'props' => ['ticketid' => $int],
                ],
                'whmcs_list_departments' => [
                    'desc' => 'List support ticket departments.',
                    'api'  => 'GetSupportDepartments',
                    'props' => ['ignore_dept_assignments' => $bool],
                ],
                'whmcs_list_ticket_statuses' => [
                    'desc' => 'List configured ticket statuses.',
                    'handler' => 'listTicketStatuses',
                    'props' => [],
                ],
            ],

            'Domain Management' => [
                'whmcs_list_client_domains' => [
                    'desc' => 'List client domains with optional filters.',
                    'api'  => 'GetClientsDomains',
                    'props' => [
                        'clientid' => $int, 'domainid' => $int, 'domain' => $str,
                        'limitstart' => $int, 'limitnum' => $int,
                    ],
                ],
                'whmcs_get_domain_nameservers' => [
                    'desc' => 'Get nameservers configured for a domain.',
                    'api'  => 'DomainGetNameservers',
                    'required' => ['domainid'],
                    'props' => ['domainid' => $int],
                ],
                'whmcs_update_domain_nameservers' => [
                    'desc' => 'Update nameservers for a domain.',
                    'api'  => 'DomainUpdateNameservers',
                    'required' => ['domainid', 'ns1', 'ns2'],
                    'props' => [
                        'domainid' => $int, 'ns1' => $str, 'ns2' => $str,
                        'ns3' => $str, 'ns4' => $str, 'ns5' => $str,
                    ],
                ],
                'whmcs_get_domain_lock_status' => [
                    'desc' => 'Get registrar lock status for a domain.',
                    'api'  => 'DomainGetLockingStatus',
                    'required' => ['domainid'],
                    'props' => ['domainid' => $int],
                ],
                'whmcs_update_domain_lock' => [
                    'desc' => 'Enable or disable registrar lock on a domain.',
                    'api'  => 'DomainUpdateLockingStatus',
                    'required' => ['domainid', 'lockstatus'],
                    'props' => [
                        'domainid' => $int,
                        'lockstatus' => ['type' => 'boolean', 'description' => 'true to lock, false to unlock.'],
                    ],
                ],
                'whmcs_get_domain_whois' => [
                    'desc' => 'Perform a WHOIS lookup.',
                    'api'  => 'DomainWhois',
                    'required' => ['domain'],
                    'props' => ['domain' => $str],
                ],
                'whmcs_get_tld_pricing' => [
                    'desc' => 'Get TLD pricing matrix.',
                    'api'  => 'GetTLDPricing',
                    'props' => ['currencyid' => $int, 'clientid' => $int],
                ],
                'whmcs_register_domain' => [
                    'desc' => 'Register a domain via the registrar.',
                    'api'  => 'DomainRegister',
                    'required' => ['domainid'],
                    'props' => ['domainid' => $int, 'regperiod' => $int],
                ],
                'whmcs_renew_domain' => [
                    'desc' => 'Renew a domain via the registrar.',
                    'api'  => 'DomainRenew',
                    'required' => ['domainid'],
                    'props' => ['domainid' => $int, 'regperiod' => $int],
                ],
                'whmcs_transfer_domain' => [
                    'desc' => 'Transfer a domain to the registrar.',
                    'api'  => 'DomainTransfer',
                    'required' => ['domainid'],
                    'props' => ['domainid' => $int, 'eppcode' => $str],
                ],
            ],

            'Affiliates & Promotions' => [
                'whmcs_list_affiliates' => [
                    'desc' => 'List affiliate accounts with commission stats.',
                    'api'  => 'GetAffiliates',
                    'props' => ['userid' => $int, 'limitstart' => $int, 'limitnum' => $int],
                ],
                'whmcs_activate_affiliate' => [
                    'desc' => 'Activate a client as an affiliate.',
                    'api'  => 'AffiliateActivate',
                    'required' => ['userid'],
                    'props' => ['userid' => ['type' => 'integer', 'description' => 'Client ID to activate as affiliate.']],
                ],
                'whmcs_list_promotions' => [
                    'desc' => 'List promotion/discount codes.',
                    'api'  => 'GetPromotions',
                    'props' => ['code' => $str],
                ],
            ],

            'System' => [
                'whmcs_get_status' => [
                    'desc' => 'Get WHMCS system status and statistics.',
                    'handler' => 'getStatus',
                    'props' => [],
                ],
                'whmcs_check_capabilities' => [
                    'desc' => 'Check installed addons and capabilities.',
                    'handler' => 'checkCapabilities',
                    'props' => [],
                ],
                'whmcs_activity_log' => [
                    'desc' => 'View recent activity log entries.',
                    'api'  => 'GetActivityLog',
                    'props' => ['userid' => $int, 'limitstart' => $int, 'limitnum' => $int, 'date' => $str],
                ],
                'whmcs_log_activity' => [
                    'desc' => 'Log an activity entry.',
                    'api'  => 'LogActivity',
                    'required' => ['description'],
                    'props' => ['description' => $str, 'userid' => $int],
                ],
                'whmcs_admin_users' => [
                    'desc' => 'List WHMCS admin users.',
                    'handler' => 'adminUsers',
                    'props' => [],
                ],
                'whmcs_list_servers' => [
                    'desc' => 'List configured servers.',
                    'handler' => 'listServers',
                    'props' => [],
                ],
                'whmcs_currencies' => [
                    'desc' => 'List currencies and exchange rates.',
                    'api'  => 'GetCurrencies',
                    'props' => [],
                ],
                'whmcs_payment_methods' => [
                    'desc' => 'List configured payment gateways.',
                    'api'  => 'GetPaymentMethods',
                    'props' => [],
                ],
                'whmcs_email_templates' => [
                    'desc' => 'List email templates by type.',
                    'api'  => 'GetEmailTemplates',
                    'props' => ['type' => $str, 'language' => $str],
                ],
                'whmcs_send_email' => [
                    'desc' => 'Send an email to a client using a template.',
                    'api'  => 'SendEmail',
                    'props' => [
                        'messagename' => ['type' => 'string', 'description' => 'Email template name.'],
                        'id' => ['type' => 'integer', 'description' => 'Related ID (client/invoice/etc.).'],
                        'customtype' => $str, 'customsubject' => $str, 'custommessage' => $str,
                    ],
                ],
                'whmcs_todo_items' => [
                    'desc' => 'List admin to-do items.',
                    'api'  => 'GetToDoItems',
                    'props' => ['status' => $str, 'limitstart' => $int, 'limitnum' => $int],
                ],
            ],
        ];
    }

    /** Flat list of all definitions keyed by tool name. */
    public static function flat()
    {
        $out = [];
        foreach (self::catalogue() as $defs) {
            foreach ($defs as $name => $def) {
                $out[$name] = $def;
            }
        }
        return $out;
    }

    /** All tool names. */
    public static function names()
    {
        return array_keys(self::flat());
    }

    /** Build the MCP tools/list payload for ENABLED tools only. */
    public static function listForMcp()
    {
        $tools = [];
        foreach (self::flat() as $name => $def) {
            if (!Settings::isToolEnabled($name)) {
                continue;
            }
            $schema = [
                'type'       => 'object',
                'properties' => isset($def['props']) ? (object) self::normaliseProps($def['props']) : (object) [],
            ];
            if (!empty($def['required'])) {
                $schema['required'] = $def['required'];
            }
            $tools[] = [
                'name'        => $name,
                'description' => $def['desc'],
                'inputSchema' => $schema,
            ];
        }
        return $tools;
    }

    private static function normaliseProps(array $props)
    {
        // Ensure each property is an object when serialised to JSON.
        $out = [];
        foreach ($props as $k => $v) {
            $out[$k] = $v;
        }
        return $out;
    }

    /**
     * Execute a tool. Returns an MCP tool result array:
     *   ['content' => [['type'=>'text','text'=>...]], 'isError' => bool]
     */
    public static function call($name, array $args)
    {
        $defs = self::flat();
        if (!isset($defs[$name])) {
            return self::err("Unknown tool: {$name}");
        }
        if (!Settings::isToolEnabled($name)) {
            return self::err("Tool '{$name}' is disabled by the administrator.");
        }

        $def = $defs[$name];
        try {
            if (isset($def['handler'])) {
                $method = $def['handler'];
                return self::$method($args);
            }
            // Direct WHMCS local API passthrough.
            $result = self::localApi($def['api'], $args);
            return self::ok($result);
        } catch (\Throwable $e) {
            return self::err('Error executing ' . $name . ': ' . $e->getMessage());
        }
    }

    /**
     * Call the WHMCS local API as the configured admin user.
     */
    public static function localApi($action, array $values)
    {
        $admin = Settings::get('admin_username', '');
        if (!$admin) {
            $row = Capsule::table('tbladmins')->where('disabled', 0)->orderBy('id')->first();
            $admin = $row ? $row->username : '';
        }
        $result = localAPI($action, $values, $admin);
        return $result;
    }

    // ---------------------------------------------------------------------
    //  Custom handlers
    // ---------------------------------------------------------------------

    protected static function addInvoiceLineItems(array $args)
    {
        $invoiceId = (int) ($args['invoiceid'] ?? 0);
        $items     = $args['items'] ?? [];
        if (!$invoiceId || !is_array($items) || !$items) {
            return self::err('invoiceid and a non-empty items array are required.');
        }
        $params = ['invoiceid' => $invoiceId];
        $i = 0;
        foreach ($items as $item) {
            $params['newitemdescription'][$i] = (string) ($item['description'] ?? '');
            $params['newitemamount'][$i]      = (float) ($item['amount'] ?? 0);
            $params['newitemtaxed'][$i]       = !empty($item['taxed']) ? 1 : 0;
            $i++;
        }
        return self::ok(self::localApi('UpdateInvoice', $params));
    }

    protected static function applyCredit(array $args)
    {
        $invoiceId = (int) ($args['invoiceid'] ?? 0);
        $amount    = (float) ($args['amount'] ?? 0);
        if (!$invoiceId || $amount <= 0) {
            return self::err('invoiceid and a positive amount are required.');
        }
        // Look up the invoice to find the owning client.
        $inv = self::localApi('GetInvoice', ['invoiceid' => $invoiceId]);
        if (($inv['result'] ?? '') !== 'success') {
            return self::ok($inv);
        }
        $clientId = (int) ($inv['userid'] ?? 0);

        // 1) Deduct from the client's available credit balance.
        $remove = self::localApi('AddCredit', [
            'clientid'    => $clientId,
            'description' => 'Credit applied to Invoice #' . $invoiceId . ' via MCP',
            'amount'      => $amount,
            'type'        => 'remove',
        ]);
        // 2) Record the payment against the invoice using the credit gateway.
        $pay = self::localApi('AddInvoicePayment', [
            'invoiceid' => $invoiceId,
            'transid'   => 'credit-' . time(),
            'gateway'   => 'credit',
            'amount'    => $amount,
            'date'      => date('Y-m-d H:i:s'),
        ]);
        return self::ok(['credit_removed' => $remove, 'payment_recorded' => $pay]);
    }

    protected static function getQuote(array $args)
    {
        $quoteId = (int) ($args['quoteid'] ?? 0);
        if (!$quoteId) {
            return self::err('quoteid is required.');
        }
        $all = self::localApi('GetQuotes', ['limitnum' => 99999]);
        $found = null;
        if (!empty($all['quotes']['quote']) && is_array($all['quotes']['quote'])) {
            foreach ($all['quotes']['quote'] as $q) {
                if ((int) ($q['id'] ?? 0) === $quoteId) {
                    $found = $q;
                    break;
                }
            }
        }
        return $found ? self::ok($found) : self::err('Quote #' . $quoteId . ' not found.');
    }

    protected static function listTicketStatuses(array $args)
    {
        $rows = Capsule::table('tblticketstatuses')->orderBy('sortorder')->get();
        $out = [];
        foreach ($rows as $r) {
            $out[] = ['id' => (int) $r->id, 'title' => $r->title, 'color' => $r->color ?? '', 'sortorder' => (int) ($r->sortorder ?? 0)];
        }
        return self::ok(['statuses' => $out, 'count' => count($out)]);
    }

    protected static function listServers(array $args)
    {
        $rows = Capsule::table('tblservers')->get();
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id'       => (int) $r->id,
                'name'     => $r->name,
                'hostname' => $r->hostname,
                'ipaddress' => $r->ipaddress,
                'type'     => $r->type,
                'active'   => (int) $r->active,
                'disabled' => (int) ($r->disabled ?? 0),
                'maxaccounts' => (int) ($r->maxaccounts ?? 0),
            ];
        }
        return self::ok(['servers' => $out, 'count' => count($out)]);
    }

    protected static function adminUsers(array $args)
    {
        $rows = Capsule::table('tbladmins')->get();
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id'        => (int) $r->id,
                'username'  => $r->username,
                'firstname' => $r->firstname,
                'lastname'  => $r->lastname,
                'email'     => $r->email,
                'roleid'    => (int) ($r->roleid ?? 0),
                'disabled'  => (int) ($r->disabled ?? 0),
            ];
        }
        return self::ok(['admins' => $out, 'count' => count($out)]);
    }

    protected static function checkCapabilities(array $args)
    {
        $addons = [];
        try {
            $rows = Capsule::table('tbladdonmodules')
                ->select('module')->distinct()->get();
            foreach ($rows as $r) {
                $addons[] = $r->module;
            }
        } catch (\Throwable $e) {
            // ignore
        }
        $version = 'unknown';
        try {
            $version = Capsule::table('tblconfiguration')->where('setting', 'Version')->value('value') ?: 'unknown';
        } catch (\Throwable $e) {
        }
        $registrars = [];
        $gateways   = [];
        try {
            $registrars = Capsule::table('tblregistrars')->distinct()->pluck('registrar')->all();
        } catch (\Throwable $e) {
        }
        try {
            $gateways = Capsule::table('tblpaymentgateways')->where('setting', 'type')->distinct()->pluck('gateway')->all();
        } catch (\Throwable $e) {
        }
        return self::ok([
            'whmcs_version'    => $version,
            'addon_modules'    => array_values(array_unique($addons)),
            'active_registrars' => array_values(array_unique($registrars)),
            'payment_gateways' => array_values(array_unique($gateways)),
            'mcp_version'      => INSATION_MCP_VERSION,
            'tools_total'      => count(self::names()),
        ]);
    }

    protected static function getStatus(array $args)
    {
        $stats = self::localApi('GetStats', []);
        $counts = [];
        try {
            $counts['clients']  = (int) Capsule::table('tblclients')->count();
            $counts['services'] = (int) Capsule::table('tblhosting')->count();
            $counts['domains']  = (int) Capsule::table('tbldomains')->count();
            $counts['invoices'] = (int) Capsule::table('tblinvoices')->count();
            $counts['tickets_open'] = (int) Capsule::table('tbltickets')->where('status', 'Open')->count();
        } catch (\Throwable $e) {
        }
        $version = 'unknown';
        try {
            $version = Capsule::table('tblconfiguration')->where('setting', 'Version')->value('value') ?: 'unknown';
        } catch (\Throwable $e) {
        }
        return self::ok([
            'whmcs_version' => $version,
            'mcp_version'   => INSATION_MCP_VERSION,
            'counts'        => $counts,
            'stats'         => $stats,
            'server_time'   => date('c'),
        ]);
    }

    // ---------------------------------------------------------------------
    //  Result helpers
    // ---------------------------------------------------------------------

    protected static function ok($data)
    {
        return [
            'content' => [[
                'type' => 'text',
                'text' => is_string($data) ? $data : json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
            ]],
            'isError' => false,
        ];
    }

    protected static function err($message)
    {
        return [
            'content' => [['type' => 'text', 'text' => $message]],
            'isError' => true,
        ];
    }
}
