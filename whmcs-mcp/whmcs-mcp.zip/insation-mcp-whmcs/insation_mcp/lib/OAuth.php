<?php
/**
 * Insation MCP Server — OAuth 2.1 authorization (for MCP native connectors).
 *
 * Implements the pieces the MCP authorization spec (2025-06-18) needs so a
 * client like Claude Desktop can connect by URL:
 *   - Protected Resource Metadata (RFC 9728)
 *   - Authorization Server Metadata (RFC 8414)
 *   - Dynamic Client Registration (RFC 7591)
 *   - Authorization Code flow with PKCE S256 (RFC 7636) + refresh tokens
 *
 * Tokens/codes are opaque + stored hashed. The resource owner authorizes by
 * pasting a valid API bearer token (from the API Keys tab) on the consent
 * screen — that ties an OAuth grant to possession of a real API credential.
 *
 * @package InsationMCP
 */

namespace InsationMCP;

use WHMCS\Database\Capsule;

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

class OAuth
{
    const T_CLIENTS = 'mod_insation_mcp_oauth_clients';
    const T_CODES   = 'mod_insation_mcp_oauth_codes';
    const T_TOKENS  = 'mod_insation_mcp_oauth_tokens';

    const CODE_TTL    = 600;      // 10 min
    const ACCESS_TTL  = 3600;     // 1 hour
    const REFRESH_TTL = 2592000;  // 30 days

    /**
     * The single public URL clients use. When a request arrives through the
     * root launcher (whmcs-mcp.php) the launcher defines INSATION_MCP_PUBLIC to
     * its own absolute URL. That one URL serves the MCP resource, the OAuth
     * issuer, and every OAuth endpoint (distinguished by ?oauth=...). Routing
     * through the root is what makes this work on hosts that block /modules/.
     */
    public static function publicBase()
    {
        if (defined('INSATION_MCP_PUBLIC') && INSATION_MCP_PUBLIC) {
            return rtrim(INSATION_MCP_PUBLIC, '/');
        }
        $sys = '';
        try {
            $sys = \WHMCS\Config\Setting::getValue('SystemURL');
        } catch (\Throwable $e) {
        }
        if (!$sys) {
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $sys = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
        }
        return rtrim($sys, '/') . '/modules/addons/insation_mcp/mcp.php';
    }

    private static function withParam($param)
    {
        $base = self::publicBase();
        return $base . (strpos($base, '?') !== false ? '&' : '?') . $param;
    }

    public static function issuer()      { return self::publicBase(); }
    public static function resourceUrl() { return self::publicBase(); }
    public static function prmUrl()      { return self::withParam('oauth=prm'); }

    /** Protected Resource Metadata (RFC 9728). */
    public static function protectedResourceMetadata()
    {
        return [
            'resource'                 => self::resourceUrl(),
            'authorization_servers'    => [self::issuer()],
            'bearer_methods_supported' => ['header'],
            'scopes_supported'         => ['mcp'],
            'resource_name'            => 'Insation MCP Server (WHMCS)',
        ];
    }

    /** Authorization Server Metadata (RFC 8414). */
    public static function authServerMetadata()
    {
        return [
            'issuer'                                => self::issuer(),
            'authorization_endpoint'                => self::withParam('oauth=authorize'),
            'token_endpoint'                        => self::withParam('oauth=token'),
            'registration_endpoint'                 => self::withParam('oauth=register'),
            'response_types_supported'              => ['code'],
            'grant_types_supported'                 => ['authorization_code', 'refresh_token'],
            'code_challenge_methods_supported'      => ['S256'],
            'token_endpoint_auth_methods_supported' => ['none', 'client_secret_post'],
            'scopes_supported'                      => ['mcp'],
        ];
    }

    private static function rand($len = 32)
    {
        return bin2hex(random_bytes($len));
    }

    private static function hash($v)
    {
        return hash('sha256', (string) $v);
    }

    /** Dynamic Client Registration (RFC 7591). */
    public static function registerClient(array $meta)
    {
        $redirects = $meta['redirect_uris'] ?? [];
        if (!is_array($redirects) || !$redirects) {
            throw new \InvalidArgumentException('redirect_uris is required');
        }
        $clientId = 'imcp_' . self::rand(8);
        $public   = (($meta['token_endpoint_auth_method'] ?? 'none') === 'none');
        $secret   = $public ? '' : self::rand(24);
        Capsule::table(self::T_CLIENTS)->insert([
            'client_id'      => $clientId,
            'client_secret'  => $secret ? self::hash($secret) : '',
            'redirect_uris'  => json_encode(array_values($redirects)),
            'client_name'    => substr((string) ($meta['client_name'] ?? 'MCP Client'), 0, 191),
            'created_at'     => date('Y-m-d H:i:s'),
        ]);
        $out = [
            'client_id'                  => $clientId,
            'redirect_uris'              => array_values($redirects),
            'token_endpoint_auth_method' => $public ? 'none' : 'client_secret_post',
            'grant_types'                => ['authorization_code', 'refresh_token'],
            'response_types'             => ['code'],
        ];
        if ($secret) {
            $out['client_secret'] = $secret;
        }
        return $out;
    }

    public static function getClient($clientId)
    {
        return Capsule::table(self::T_CLIENTS)->where('client_id', $clientId)->first();
    }

    public static function redirectAllowed($client, $redirectUri)
    {
        if (!$client) {
            return false;
        }
        $uris = json_decode($client->redirect_uris, true);
        return is_array($uris) && in_array($redirectUri, $uris, true);
    }

    /** Issue an authorization code (after consent). */
    public static function createCode($clientId, $redirectUri, $challenge, $method, $apiKeyId)
    {
        $code = self::rand(24);
        Capsule::table(self::T_CODES)->insert([
            'code_hash'             => self::hash($code),
            'client_id'             => $clientId,
            'redirect_uri'          => $redirectUri,
            'code_challenge'        => (string) $challenge,
            'code_challenge_method' => $method ?: 'S256',
            'api_key_id'            => (int) $apiKeyId,
            'expires_at'            => date('Y-m-d H:i:s', time() + self::CODE_TTL),
            'used'                  => 0,
            'created_at'            => date('Y-m-d H:i:s'),
        ]);
        return $code;
    }

    /** Exchange an authorization code (+PKCE verifier) for tokens. */
    public static function exchangeCode($code, $verifier, $clientId, $redirectUri)
    {
        $row = Capsule::table(self::T_CODES)->where('code_hash', self::hash($code))->first();
        if (!$row || (int) $row->used === 1) {
            return ['error' => 'invalid_grant', 'msg' => 'Authorization code invalid or already used.'];
        }
        if (strtotime($row->expires_at) < time()) {
            return ['error' => 'invalid_grant', 'msg' => 'Authorization code expired.'];
        }
        if ($row->client_id !== $clientId || $row->redirect_uri !== $redirectUri) {
            return ['error' => 'invalid_grant', 'msg' => 'Client or redirect mismatch.'];
        }
        // PKCE S256 verification.
        $calc = rtrim(strtr(base64_encode(hash('sha256', (string) $verifier, true)), '+/', '-_'), '=');
        if (!hash_equals((string) $row->code_challenge, $calc)) {
            return ['error' => 'invalid_grant', 'msg' => 'PKCE verification failed.'];
        }
        Capsule::table(self::T_CODES)->where('id', $row->id)->update(['used' => 1]);
        return self::issueTokens($clientId, (int) $row->api_key_id);
    }

    public static function refresh($refreshToken, $clientId)
    {
        $row = Capsule::table(self::T_TOKENS)
            ->where('refresh_hash', self::hash($refreshToken))
            ->where('client_id', $clientId)
            ->first();
        if (!$row) {
            return ['error' => 'invalid_grant', 'msg' => 'Refresh token not recognized.'];
        }
        Capsule::table(self::T_TOKENS)->where('id', $row->id)->delete();
        return self::issueTokens($clientId, (int) $row->api_key_id);
    }

    private static function issueTokens($clientId, $apiKeyId)
    {
        $access  = 'mcp_at_' . self::rand(24);
        $refresh = 'mcp_rt_' . self::rand(24);
        Capsule::table(self::T_TOKENS)->insert([
            'access_hash'  => self::hash($access),
            'refresh_hash' => self::hash($refresh),
            'client_id'    => $clientId,
            'api_key_id'   => (int) $apiKeyId,
            'expires_at'   => date('Y-m-d H:i:s', time() + self::ACCESS_TTL),
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        return [
            'access_token'  => $access,
            'token_type'    => 'Bearer',
            'expires_in'    => self::ACCESS_TTL,
            'refresh_token' => $refresh,
            'scope'         => 'mcp',
        ];
    }

    /** Verify an OAuth access token presented at the MCP endpoint. */
    public static function verifyAccessToken($token)
    {
        $row = Capsule::table(self::T_TOKENS)->where('access_hash', self::hash($token))->first();
        if (!$row) {
            return false;
        }
        if (strtotime($row->expires_at) < time()) {
            return false;
        }
        return $row;
    }
}
