# User Management Implementation Plan

**Status:** Planned
**Priority:** High
**Estimated Effort:** 3-4 hours
**Tool Count Impact:** +2 tools (26 → 28 total)

---

## Overview

Add complete WordPress user management functionality using 2 consolidated tools following the action-based pattern used by Media, Plugin, and Theme tools.

**Design Philosophy:** Keep MCP tool count minimal to avoid eating up context window of MCP clients. Use action-based tools instead of separate tools for each operation.

---

## Tools to Implement

### **Tool 1: UserInfo** (`user_info`)
**File:** `src/Tools/User/UserInfo.php`
**Scope:** `mcp:read`
**Description:** List, search, and retrieve user information

**Actions:**
- `list` - List all users with optional filtering
- `get` - Get single user by ID, login, or email
- `search` - Search users by name/email

**Parameters:**
- `action` (required) - Operation type
- `user_id` (optional, int) - User ID for get action
- `user_login` (optional, string) - Username for get action
- `user_email` (optional, string) - Email for get action
- `role` (optional, string) - Filter by role
- `search` (optional, string) - Search term
- `number` (optional, int, default: 10, max: 100) - Results limit
- `offset` (optional, int, default: 0) - Pagination offset
- `orderby` (optional, string) - Sort field (login, email, display_name, registered)
- `order` (optional, string) - ASC or DESC

**Returns:**
- List: Array of user objects
- Get: Single user object with full details
- Search: Array of matching user objects

**User Object Structure:**
```json
{
  "id": 1,
  "user_login": "admin",
  "user_email": "admin@example.com",
  "display_name": "Admin User",
  "first_name": "Admin",
  "last_name": "User",
  "roles": ["administrator"],
  "capabilities": {...},
  "registered": "2025-01-01 12:00:00",
  "edit_url": "https://site.com/wp-admin/user-edit.php?user_id=1"
}
```

---

### **Tool 2: UserOperations** (`user_operations`)
**File:** `src/Tools/User/UserOperations.php`
**Scope:** `mcp:admin` (create/delete), `mcp:write` (update self)
**Blocked by:** Safe mode (create/delete only)

**Actions:**
- `create` - Create new user
- `update` - Update user profile, role, password
- `delete` - Delete user with content reassignment

**Parameters:**

**For `create` action:**
- `action` = "create"
- `user_login` (required, string) - Username (3-60 chars, alphanumeric + underscore)
- `user_email` (required, string) - Valid email address
- `user_pass` (optional, string) - Password (auto-generated if not provided)
- `role` (optional, string, default: "subscriber") - User role
- `first_name` (optional, string)
- `last_name` (optional, string)
- `display_name` (optional, string)
- `send_notification` (optional, bool, default: false) - Email new user credentials

**For `update` action:**
- `action` = "update"
- `user_id` (required, int) - User to update
- `user_email` (optional, string) - New email
- `user_pass` (optional, string) - New password
- `role` (optional, string) - Change role (requires `mcp:admin` for other users)
- `first_name` (optional, string)
- `last_name` (optional, string)
- `display_name` (optional, string)
- `description` (optional, string) - User bio
- `user_url` (optional, string) - Website URL

**For `delete` action:**
- `action` = "delete"
- `user_id` (required, int) - User to delete
- `reassign_to` (optional, int) - User ID to reassign content to
- `delete_posts` (optional, bool, default: false) - Delete user's posts if no reassignment

**Returns:**
- Create: User ID, login, email, generated password (if auto-generated)
- Update: Updated user object with modified fields list
- Delete: Confirmation with reassignment details

---

## Implementation Steps

### Step 1: Extend WordPressService.php

Add 15 new user-related methods:

```php
// User retrieval
public function getUsers(array $args): array
public function getUserBy(string $field, string $value): \WP_User|false
public function getUserData(int $userId): \WP_User|false
public function userExists(int $userId): bool
public function emailExists(string $email): int|false
public function usernameExists(string $username): int|false

// User mutations
public function createUser(array $userData): int|\WP_Error
public function updateUser(array $userData): int|\WP_Error
public function deleteUser(int $userId, int $reassignTo = null): bool|\WP_Error

// User meta
public function getUserMeta(int $userId, string $key, bool $single = true): mixed
public function updateUserMeta(int $userId, string $key, mixed $value): bool|int

// Utilities
public function countUsers(): array
public function getUserRoles(): array
public function generatePassword(int $length = 12): string
public function getEditUserLink(int $userId): string
```

### Step 2: Create Tool Files

**File: `src/Tools/User/UserInfo.php`** (~200 lines)
- Implements `list`, `get`, `search` actions
- Validates action parameter
- Handles pagination, filtering, ordering
- Returns formatted user data
- Requires `mcp:read` scope + `list_users` capability

**File: `src/Tools/User/UserOperations.php`** (~350 lines)
- Implements `create`, `update`, `delete` actions
- Dynamic permission validation:
  - Create: `mcp:admin` + `create_users` capability
  - Update self: `mcp:write` + `read` capability
  - Update others: `mcp:admin` + `edit_users` capability
  - Delete: `mcp:admin` + `delete_users` capability
- Prevents self-deletion
- Prevents deletion of user ID 1 (primary admin)
- Checks safe mode for create/delete
- Validates email format, username format, role existence
- Auto-generates secure passwords for create action
- Handles content reassignment for delete action

### Step 3: Register Tools in mcp-http.php

Add imports:
```php
// User tools
use InsationAI\AvadaMCP\Tools\User\UserInfo;
use InsationAI\AvadaMCP\Tools\User\UserOperations;
```

Add to $tools array:
```php
// User tools
new UserInfo($wpService, $validationService, $logger),
new UserOperations($wpService, $validationService, $logger),
```

### Step 4: Create Unit Tests

**File: `tests/Unit/Tools/User/UserInfoTest.php`** (~200 lines)
- Test list action with filtering
- Test get by ID, login, email
- Test search functionality
- Test pagination
- Test user not found errors
- Test permission checks

**File: `tests/Unit/Tools/User/UserOperationsTest.php`** (~300 lines)
- Test create user with auto-generated password
- Test create user with custom password
- Test update own profile
- Test update other user (admin only)
- Test role change (admin only)
- Test delete with reassignment
- Test delete without reassignment
- Test prevent self-deletion
- Test prevent deletion of user ID 1
- Test safe mode blocking create/delete
- Test permission errors

### Step 5: Add Inspector Integration Tests

Update `tests/inspector-tests.sh` with user management tests:

```bash
# ========================================
# User Management Tests
# ========================================

echo ""
echo "Testing User Management Tools..."
echo ""

# Test: Create user with auto-generated password
run_test "Create test user" \
    "$INSPECTOR --method tools/call --tool-name user_operations --tool-arg action=create --tool-arg user_login=mcptest --tool-arg user_email=mcptest@example.com --tool-arg role=editor | grep -q 'user_login.*mcptest'"

# Get the created user ID
CREATED_USER_ID=$(cat /tmp/mcp_test_output | grep -o '"id"[^0-9]*[0-9][0-9]*' | head -1 | grep -o '[0-9][0-9]*')

if [ -n "$CREATED_USER_ID" ]; then
    echo "  → Created user ID: $CREATED_USER_ID"

    # Test: List users
    run_test "List users" \
        "$INSPECTOR --method tools/call --tool-name user_info --tool-arg action=list | grep -q 'mcptest'"

    # Test: Get user by ID
    run_test "Get user by ID" \
        "$INSPECTOR --method tools/call --tool-name user_info --tool-arg action=get --tool-arg user_id=$CREATED_USER_ID | grep -q 'mcptest@example.com'"

    # Test: Update user profile
    run_test "Update user profile" \
        "$INSPECTOR --method tools/call --tool-name user_operations --tool-arg action=update --tool-arg user_id=$CREATED_USER_ID --tool-arg first_name=MCP --tool-arg last_name=Test | grep -q 'updated_fields'"

    # Test: Search users
    run_test "Search users" \
        "$INSPECTOR --method tools/call --tool-name user_info --tool-arg action=search --tool-arg search=mcptest | grep -q 'mcptest'"

    # Test: Delete test user
    run_test "Delete test user" \
        "$INSPECTOR --method tools/call --tool-name user_operations --tool-arg action=delete --tool-arg user_id=$CREATED_USER_ID | grep -q 'deleted'"
else
    echo -e "${YELLOW}  ⚠ Skipping user tests (no user ID)${NC}"
fi
```

### Step 6: Update Documentation

**CLAUDE.md:**
Add User Management section after Media Management:

```markdown
## User Management

AvadaMCP provides 2 tools for managing WordPress users:

### User Tools

**1. UserInfo Tool (`user_info`)**
- **Actions:** `list`, `get`, `search`
- **Scope:** `mcp:read`
- **Description:** List, search, and retrieve user information

**Features:**
- List all users with pagination and filtering
- Get user details by ID, username, or email
- Search users by name or email
- Filter by role
- Sort by various fields (login, email, registered date)

**2. UserOperations Tool (`user_operations`)**
- **Actions:** `create`, `update`, `delete`
- **Scope:** `mcp:admin` (create/delete), `mcp:write` (update self)
- **Blocked by:** Safe mode (create/delete only)
- **Description:** Create, update, and delete users with role management

**Features:**
- Create users with auto-generated or custom passwords
- Update user profiles, roles, and passwords
- Delete users with content reassignment
- Permission checks (users can update own profile, admins can manage all)
- Protection against self-deletion and admin deletion
- Email notifications for new users (optional)

### Implementation Details

**Permission System:**
- List/Get/Search: Requires `mcp:read` scope + `list_users` capability
- Create: Requires `mcp:admin` scope + `create_users` capability
- Update self: Requires `mcp:write` scope
- Update others: Requires `mcp:admin` scope + `edit_users` capability
- Delete: Requires `mcp:admin` scope + `delete_users` capability

**Security:**
- Safe mode blocks user creation and deletion
- Cannot delete self (current authenticated user)
- Cannot delete user ID 1 (primary admin protection)
- Username validation (3-60 chars, alphanumeric + underscore)
- Email validation and uniqueness check
- Role validation (must exist in WordPress)
- Content reassignment required when deleting users with posts

**Auto-generated Passwords:**
- Uses WordPress `wp_generate_password()` for security
- 12 characters by default
- Returned in response for admin to communicate to user
- Optional email notification to new user

### Testing User Tools

```bash
# Create user with auto-generated password
npx @modelcontextprotocol/inspector \
  --cli "https://your-site.com/avada-mcp?t=TOKEN" \
  --transport http \
  --method tools/call \
  --tool-name user_operations \
  --tool-arg action=create \
  --tool-arg user_login=newuser \
  --tool-arg user_email=newuser@example.com \
  --tool-arg role=author

# List users filtered by role
npx @modelcontextprotocol/inspector \
  --cli "https://your-site.com/avada-mcp?t=TOKEN" \
  --transport http \
  --method tools/call \
  --tool-name user_info \
  --tool-arg action=list \
  --tool-arg role=editor \
  --tool-arg number=20

# Get user by email
npx @modelcontextprotocol/inspector \
  --cli "https://your-site.com/avada-mcp?t=TOKEN" \
  --transport http \
  --method tools/call \
  --tool-name user_info \
  --tool-arg action=get \
  --tool-arg user_email=admin@example.com

# Update user profile
npx @modelcontextprotocol/inspector \
  --cli "https://your-site.com/avada-mcp?t=TOKEN" \
  --transport http \
  --method tools/call \
  --tool-name user_operations \
  --tool-arg action=update \
  --tool-arg user_id=5 \
  --tool-arg first_name=John \
  --tool-arg last_name=Doe \
  --tool-arg role=editor

# Delete user with content reassignment
npx @modelcontextprotocol/inspector \
  --cli "https://your-site.com/avada-mcp?t=TOKEN" \
  --transport http \
  --method tools/call \
  --tool-name user_operations \
  --tool-arg action=delete \
  --tool-arg user_id=5 \
  --tool-arg reassign_to=1
```
```

**README.md:**
- Update tool count from 26 to **28 tools**
- Update features list:
  ```markdown
  - ✅ **28 MCP Tools** for WordPress content, taxonomy, plugin, theme, media, and user management
  - ✅ **User Management** - Create, update, delete users with role management
  ```
- Add User Management section to "Available MCP Tools":
  ```markdown
  ### User Management (2 tools)
  - `user_info` - List, search, and get user details
  - `user_operations` - Create, update, delete users with role management

  **User Management Features:**
  - List users with role filtering and search
  - Get user details by ID, login, or email
  - Create users with auto-generated or custom passwords
  - Update user profiles, roles, and passwords
  - Delete users with content reassignment
  - Permission checks (users can update own profile, admins can manage all)
  - Protection against self-deletion and admin deletion
  ```

---

## Security & Validation

### WordPress Capabilities Enforced:
- `list_users` - Required for list/get/search
- `create_users` - Required for create
- `edit_users` - Required to edit other users
- `delete_users` - Required for delete
- Users can always view/edit own profile

### Permission Logic Example:
```php
// UserOperations::update()
if ($userId !== get_current_user_id()) {
    // Updating another user - requires admin scope + edit_users capability
    $this->requireScope('mcp:admin');
    if (!current_user_can('edit_users')) {
        throw ToolException::permissionDenied('You do not have permission to edit other users');
    }
} else {
    // Updating self - just needs write scope
    $this->requireScope('mcp:write');
}
```

### Validation Rules:
- **Username:** 3-60 chars, alphanumeric + underscore only, must be unique
- **Email:** Valid email format, must not already exist
- **Role:** Must exist in WordPress roles (administrator, editor, author, contributor, subscriber, or custom)
- **Cannot delete self:** Prevents authenticated user from deleting their own account
- **Cannot delete user ID 1:** Primary admin protection (even if multiple admins exist)
- **Content handling:** Reassignment required if user has content (unless `delete_posts=true`)

### Safe Mode Behavior:
- ✅ Blocks `create` action (user creation is destructive in terms of database changes)
- ✅ Blocks `delete` action (destructive operation)
- ❌ Does NOT block `update` action (profile updates are safe and reversible)

---

## Files to Create/Modify

### New Files (4):
1. `src/Tools/User/UserInfo.php` (~200 lines)
2. `src/Tools/User/UserOperations.php` (~350 lines)
3. `tests/Unit/Tools/User/UserInfoTest.php` (~200 lines)
4. `tests/Unit/Tools/User/UserOperationsTest.php` (~300 lines)

### Modified Files (4):
1. `src/Services/WordPressService.php` - Add 15 user methods (~200 lines added)
2. `includes/endpoints/mcp-http.php` - Register 2 tools (~4 lines)
3. `tests/inspector-tests.sh` - Add 6 user tests (~60 lines)
4. `README.md` - Update tool count and add User Management section (~40 lines)

### Documentation (1):
1. `CLAUDE.md` - Add User Management section (~100 lines)

**Total New Code:** ~1,450 lines

---

## Use Cases

### 1. Automated User Onboarding
```bash
# Create editor account for new team member
user_operations:
  action: create
  user_login: jane_editor
  user_email: jane@company.com
  role: editor
  first_name: Jane
  last_name: Smith
  send_notification: true
```

### 2. Bulk User Management
```bash
# List all authors
user_info:
  action: list
  role: author
  number: 100

# Update all to contributors
user_operations:
  action: update
  user_id: [loop through results]
  role: contributor
```

### 3. User Cleanup
```bash
# Find inactive users (search by email domain)
user_info:
  action: search
  search: @oldcompany.com

# Delete and reassign content to admin
user_operations:
  action: delete
  user_id: 42
  reassign_to: 1
```

### 4. Customer Support
```bash
# Look up customer by email
user_info:
  action: get
  user_email: customer@example.com

# Reset password
user_operations:
  action: update
  user_id: 123
  user_pass: NewSecurePassword123!
```

### 5. Role Management
```bash
# Promote contributor to author
user_operations:
  action: update
  user_id: 55
  role: author
```

---

## Final Tool Count

- **Before:** 26 tools
- **After:** 28 tools
- **New Category:** User Management (2 tools)
- **Context Window Impact:** Minimal (+7.7% increase)

---

## Benefits

✅ Complete user management functionality
✅ Minimal context window impact (only 2 tools)
✅ Consistent with existing patterns (action-based like Media/Plugin/Theme tools)
✅ Full security with WordPress capabilities + MCP scopes
✅ Safe mode protection for destructive operations
✅ Self-deletion and admin protection
✅ Comprehensive testing (unit + integration)
✅ Enables automated user workflows
✅ Customer support automation
✅ Bulk user operations

---

## Notes

- This design follows the consolidated tool pattern to minimize MCP context window usage
- Alternative approach (5 separate tools) was rejected in favor of 2 consolidated tools
- Pattern matches existing Media, Plugin, and Theme tool implementations
- All user operations respect both MCP scopes AND WordPress capabilities
- User ID 1 protection prevents accidental deletion of primary admin even if multiple admins exist
