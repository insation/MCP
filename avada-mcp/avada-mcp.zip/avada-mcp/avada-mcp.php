<?php
/**
 * Plugin Name: AvadaMCP
 * Plugin URI: https://insationai.com/
 * Description: Turn the Avada theme into a secure MCP server for AI assistants — Theme Options, Theme Builder, Library, global styles, per-site licensing. By InsationAI.
 * Version: 2.0.0
 * Author: InsationAI
 * Author URI: https://insationai.com/
 * Requires PHP: 8.2
 * Requires at least: 6.0
 * Text Domain: avada-mcp
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('INSATIONAI_AVMCP_VERSION', '2.0.0');
define('INSATIONAI_AVMCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('INSATIONAI_AVMCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('INSATIONAI_AVMCP_PLUGIN_FILE', __FILE__);

// Feature flag: OAuth functionality (ENABLED by default in AvadaMCP)
// Set to false to disable OAuth 2.1 authentication
define('INSATIONAI_AVMCP_OAUTH_FEATURE_ENABLED', true);

// Load Composer autoloader
if (file_exists(INSATIONAI_AVMCP_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'vendor/autoload.php';
}

// Load the license service at the earliest point so BOTH the MCP endpoint
// kill-switch (template_redirect priority 1) and the admin UI can call it.
require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/license/class-license-service.php';

/**
 * Plugin Activation
 *
 * Wraps the real activation flow in a try/catch + error_handler so that any
 * fatal during activation is logged to wp-content/debug.log and surfaced
 * via an admin notice. Without this, WordPress just shows the generic
 * "Plugin could not be activated because it triggered a fatal error" with
 * no detail.
 */
function insationai_avmcp_activate() {
    try {
        require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'install/activate.php';
        insationai_avmcp_run_activation();
        // Schedule daily license re-validation.
        if (class_exists('InsationAI_AVMCP_License_Service')) {
            InsationAI_AVMCP_License_Service::schedule_cron();
        }
    } catch (\Throwable $e) {
        $msg = sprintf(
            'AvadaMCP activation failed: %s in %s:%d',
            $e->getMessage(),
            $e->getFile(),
            $e->getLine()
        );
        error_log('[AvadaMCP] ' . $msg);
        error_log('[AvadaMCP] Trace: ' . $e->getTraceAsString());
        set_transient('insationai_avmcp_activation_fatal', $msg, 600);
        // Re-throw so WP knows activation failed
        throw $e;
    }
}
register_activation_hook(__FILE__, 'insationai_avmcp_activate');

/**
 * Show a detailed admin notice if the last activation attempt fataled.
 */
add_action('admin_notices', function () {
    $msg = get_transient('insationai_avmcp_activation_fatal');
    if (!$msg) {
        return;
    }
    if (!current_user_can('activate_plugins')) {
        return;
    }
    echo '<div class="notice notice-error is-dismissible"><p>';
    echo '<strong>AvadaMCP activation error:</strong><br><code>' . esc_html($msg) . '</code>';
    echo '<br><small>Full trace logged to wp-content/debug.log (if WP_DEBUG_LOG is enabled).</small>';
    echo '</p></div>';
    delete_transient('insationai_avmcp_activation_fatal');
});

/**
 * Plugin Deactivation
 */
function insationai_avmcp_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
    // Stop the daily license cron. We intentionally do NOT auto-deactivate the
    // license activation here — a transient plugin deactivation should not
    // consume a deactivate call; the admin clears the key explicitly via the
    // License tab when moving the license to another site.
    if (class_exists('InsationAI_AVMCP_License_Service')) {
        InsationAI_AVMCP_License_Service::unschedule_cron();
    }
}
register_deactivation_hook(__FILE__, 'insationai_avmcp_deactivate');

/**
 * Initialize plugin
 */
function insationai_avmcp_init() {
    // Register rewrite rules
    insationai_avmcp_register_rewrite_rules();

    // Register query vars
    add_filter('query_vars', 'insationai_avmcp_register_query_vars');

    // Initialize update checker
    insationai_avmcp_init_update_checker();
}
add_action('init', 'insationai_avmcp_init');

/**
 * Detect if the Avada theme is active. AvadaMCP needs the Avada theme loaded
 * so it can introspect Theme Options, the Layout Builder, the Library, global
 * colors/typography and the Avada CPTs.
 *
 * Detection is robust across setups:
 *  - AVADA_VERSION constant (defined by the theme's functions.php on load)
 *  - the Avada main class
 *  - the active theme (or its parent, for Avada child themes) being Avada
 *
 * @return bool
 */
function insationai_avmcp_avada_active(): bool {
    // Signal 1 — the theme defines this constant when it loads.
    if (defined('AVADA_VERSION')) {
        return true;
    }
    // Signal 2 — the Avada main class is present.
    if (class_exists('Avada')) {
        return true;
    }
    // Signal 3 — the active theme or its parent is Avada. Handles child
    // themes (very common with Avada) where the stylesheet is the child.
    if (function_exists('wp_get_theme')) {
        $theme = wp_get_theme();
        if ($theme) {
            $names = array(
                $theme->get('Name'),
                $theme->get_template(),                       // parent slug
                $theme->parent() ? $theme->parent()->get('Name') : '',
            );
            foreach ($names as $n) {
                if (is_string($n) && strtolower($n) === 'avada') {
                    return true;
                }
            }
        }
    }
    return false;
}

/**
 * Admin notice when the Avada theme is missing. Tools won't register without it.
 */
function insationai_avmcp_avada_missing_notice() {
    if (insationai_avmcp_avada_active()) {
        return;
    }
    if (!current_user_can('activate_plugins')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    // Only show on plugin admin pages to avoid being noisy everywhere
    $is_relevant_screen = !$screen || in_array($screen->id ?? '', [
        'dashboard', 'plugins', 'toplevel_page_insationai-tools', 'toplevel_page_avada-mcp-tools',
        'insationai-tools_page_avada-mcp-tools', 'admin_page_avada-mcp-tools',
    ], true);
    if (!$is_relevant_screen) {
        return;
    }
    echo '<div class="notice notice-warning"><p>';
    echo '<strong>' . esc_html__('AvadaMCP:', 'avada-mcp') . '</strong> ';
    echo esc_html__('The Avada theme is not active. AvadaMCP\'s tools will not be available until the Avada theme is installed and activated.', 'avada-mcp');
    echo '</p></div>';
}
add_action('admin_notices', 'insationai_avmcp_avada_missing_notice');

/**
 * Dual-register AvadaMCP tools as WP Abilities (WP 6.9+).
 *
 * Loaded unconditionally — register-abilities.php no-ops on older WP. Lives
 * in plugins_loaded so AbstractTool's namespace is autoloaded before the
 * Abilities API hook fires on init.
 */
function insationai_avmcp_load_abilities_bridge() {
    require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/abilities/register-abilities.php';
}
add_action('plugins_loaded', 'insationai_avmcp_load_abilities_bridge');

// Sync the stored version stamp on every load. This is registered here
// (not only on the activation hook) so the version self-heals regardless
// of how the plugin was installed/updated — the activation hook does not
// reliably fire on delete-then-reinstall flows.
add_action('plugins_loaded', 'insationai_avmcp_handle_version_upgrade');

/**
 * Initialize automatic update checker.
 *
 * Updates are delivered via the WC Key Manager Software API on insation.ai
 * and are LICENSE-GATED (product owner decision): the checker only runs when
 * this install is licensed and active. An unlicensed/lapsed install does not
 * check for or receive updates — consistent with the strict licensing model.
 *
 * NOTE: src/UpdateChecker.php declares `namespace AvadaMCP;` — the
 * instantiation below MUST use \AvadaMCP\UpdateChecker. (Using a different
 * plugin's namespace here is the exact bug that fatally crashed the
 * ElementorMCP build; it is deliberately correct for this plugin.)
 */
function insationai_avmcp_init_update_checker() {
    // License gate: no license = no update checks at all.
    if (
        ! class_exists('InsationAI_AVMCP_License_Service')
        || ! InsationAI_AVMCP_License_Service::is_licensed()
    ) {
        return;
    }
    if (! class_exists('\\AvadaMCP\\UpdateChecker')) {
        require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'src/UpdateChecker.php';
    }
    new \AvadaMCP\UpdateChecker(
        'avada-mcp/avada-mcp.php',
        'https://insation.ai/?wckm-api=get_version'
    );

    // Wire the manual "Check for updates" handler + result notice. These
    // existed in UpdateChecker but were never hooked while the updater was
    // disabled; without this the Updates-tab button would be a dead link.
    add_action('admin_init', array('\\AvadaMCP\\UpdateChecker', 'handleManualUpdateCheck'));
    add_action('admin_notices', array('\\AvadaMCP\\UpdateChecker', 'displayUpdateCheckNotice'));
}

/**
 * Handle plugin version upgrades for backward compatibility
 *
 * Automatically migrates existing installations when plugin is updated.
 * This ensures users upgrading from 1.0.0 (no iwp_mcp_active check)
 * to 1.0.1+ (has iwp_mcp_active check) continue to work seamlessly.
 */
function insationai_avmcp_handle_version_upgrade() {
    global $wpdb;

    $installed_version = get_option('insationai_avmcp_version');

    // If version hasn't changed, nothing to do
    if ($installed_version === INSATIONAI_AVMCP_VERSION) {
        return;
    }

    // Check if this is an existing installation (has user tokens table and tokens)
    $table_name = $wpdb->prefix . 'insationai_avmcp_user_tokens';
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'");

    if ($table_exists === $table_name) {
        // Check if there are any existing tokens
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe
        $has_tokens = $wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}`") > 0;

        if ($has_tokens) {
            // This is an existing installation being upgraded
            // Auto-set iwp_mcp_active to preserve access for existing users
            $current_value = get_option('iwp_mcp_active');

            if ($current_value !== 'true') {
                update_option('iwp_mcp_active', 'true');

                // Log the migration
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log(sprintf(
                        '[AvadaMCP] Auto-migrated existing installation from version %s to %s - set iwp_mcp_active=true',
                        $installed_version ?: 'unknown',
                        INSATIONAI_AVMCP_VERSION
                    ));
                }
            }
        }
    }

    // Update stored version
    update_option('insationai_avmcp_version', INSATIONAI_AVMCP_VERSION);
}

/**
 * Register rewrite rules for MCP endpoints and OAuth discovery
 */
function insationai_avmcp_register_rewrite_rules() {
    $slug = get_option('insationai_avmcp_endpoint_slug', 'avada-mcp');

    // MCP HTTP endpoint: /avada-mcp (always enabled)
    add_rewrite_rule(
        '^' . $slug . '/?$',
        'index.php?insationai_avmcp_endpoint=1',
        'top'
    );

    // OAuth routes (only if feature is enabled)
    if (INSATIONAI_AVMCP_OAUTH_FEATURE_ENABLED) {
        // RFC 8414 compliant OAuth metadata discovery
        // /.well-known/oauth-authorization-server/avada-mcp
        add_rewrite_rule(
            '^\.well-known/oauth-authorization-server/' . $slug . '/?$',
            'index.php?insationai_avmcp_oauth_meta=authorization-server',
            'top'
        );

        add_rewrite_rule(
            '^\.well-known/oauth-protected-resource/' . $slug . '/?$',
            'index.php?insationai_avmcp_oauth_meta=protected-resource',
            'top'
        );

        add_rewrite_rule(
            '^\.well-known/jwks\.json/' . $slug . '/?$',
            'index.php?insationai_avmcp_oauth_meta=jwks',
            'top'
        );

        // OAuth authorization and token endpoints
        add_rewrite_rule(
            '^' . $slug . '/oauth/(authorize|token)/?$',
            'index.php?insationai_avmcp_oauth=$matches[1]',
            'top'
        );
    }
}

/**
 * Register custom query vars
 */
function insationai_avmcp_register_query_vars($vars) {
    $vars[] = 'insationai_avmcp_endpoint';
    $vars[] = 'insationai_avmcp_oauth_meta';
    $vars[] = 'insationai_avmcp_oauth';
    return $vars;
}

/**
 * Handle template redirect for MCP endpoints
 */
function insationai_avmcp_handle_request() {
    // Validate site authorization for runtime requests
    if (get_query_var('insationai_avmcp_endpoint') || get_query_var('insationai_avmcp_oauth_meta') || get_query_var('insationai_avmcp_oauth')) {
        // Load validator class if not already loaded
        if (!class_exists('\InsationAI\AvadaMCP\Validator')) {
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'src/Validator.php';
        }

        if (!\InsationAI\AvadaMCP\Validator::isAuthorized()) {
            \InsationAI\AvadaMCP\Validator::logUnauthorizedAttempt('runtime');

            // Return 403 Forbidden
            status_header(403);
            nocache_headers();
            echo 'Forbidden';
            exit;
        }
    }

    // Handle MCP HTTP endpoint — gated on a valid, active license.
    // STRICT model (product owner decision): if the plugin is not licensed
    // (including: no key, invalid/expired key, OR the license server is
    // unreachable — no grace period), the MCP endpoint does not serve.
    if (get_query_var('insationai_avmcp_endpoint')) {
        if (
            class_exists('InsationAI_AVMCP_License_Service')
            && InsationAI_AVMCP_License_Service::is_licensed()
        ) {
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/endpoints/mcp-http.php';
            exit;
        }
        status_header(403);
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        $reason = 'license_inactive';
        if (class_exists('InsationAI_AVMCP_License_Service')) {
            $st = InsationAI_AVMCP_License_Service::get_state();
            $reason = isset($st['reason_code']) ? $st['reason_code'] : $reason;
        }
        echo wp_json_encode(array(
            'error'   => 'license_inactive',
            'reason'  => $reason,
            'message' => 'This AvadaMCP installation is not licensed. '
                       . 'Enter and activate a valid license key in '
                       . 'WP Admin → InsationAI Tools to enable the MCP endpoint.',
        ));
        exit;
    }

    // OAuth endpoints (only if feature is enabled)
    if (!INSATIONAI_AVMCP_OAUTH_FEATURE_ENABLED) {
        return;
    }

    // Handle OAuth metadata endpoints
    if ($meta = get_query_var('insationai_avmcp_oauth_meta')) {
        insationai_avmcp_serve_oauth_metadata($meta);
        exit;
    }

    // Handle OAuth flow endpoints
    if ($oauth = get_query_var('insationai_avmcp_oauth')) {
        insationai_avmcp_handle_oauth_flow($oauth);
        exit;
    }
}
add_action('template_redirect', 'insationai_avmcp_handle_request', 1);

/**
 * Serve OAuth metadata endpoints
 */
function insationai_avmcp_serve_oauth_metadata($type) {
    switch ($type) {
        case 'authorization-server':
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/well-known/oauth-authorization-server.php';
            break;
        case 'protected-resource':
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/well-known/oauth-protected-resource.php';
            break;
        case 'jwks':
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/well-known/jwks.php';
            break;
    }
}

/**
 * Handle OAuth flow endpoints
 */
function insationai_avmcp_handle_oauth_flow($flow) {
    switch ($flow) {
        case 'authorize':
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/oauth/authorize.php';
            break;
        case 'token':
            require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'includes/oauth/token.php';
            break;
    }
}

/**
 * Detect if WordpressMCP is active by checking for its main plugin file.
 *
 * @return bool
 */
function insationai_avmcp_wordpressmcp_active(): bool {
    // Signal 1 — the WordpressMCP main plugin file defines this constant when
    // it loads. By the time admin_menu fires, all active plugins have loaded,
    // so this is reliable regardless of what folder WordpressMCP installed into.
    if (defined('INSATIONAI_WPMCP_VERSION')) {
        return true;
    }

    // Signal 2 — scan the active plugins list for the WordpressMCP main file by
    // FILENAME, not by a hardcoded folder path. WordPress may install the plugin
    // under 'insationai-wordpress-mcp', 'insationai-wordpress-mcp-1', or any
    // name derived from the uploaded zip; matching on the trailing
    // '/insationai-wordpress-mcp.php' (or a bare filename) handles every case.
    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $active = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $active = array_merge($active, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }
    foreach ($active as $plugin_path) {
        if (basename($plugin_path) === 'insationai-wordpress-mcp.php') {
            return true;
        }
    }

    // Signal 3 — a WordpressMCP-defined function exists (covers the edge case
    // where the constant check was missed but the plugin's code is loaded).
    if (function_exists('insationai_wpmcp_register_abilities')) {
        return true;
    }

    return false;
}

/**
 * Add admin menu.
 *
 * Behavior depends on whether WordpressMCP is active on the same site:
 *
 *   - If WordpressMCP is active → AvadaMCP attaches itself as a submenu
 *     under WordpressMCP's "InsationAI Tools" parent menu (slug: "insationai-tools").
 *     This way the user sees a single grouped "InsationAI Tools" item with both
 *     WordpressMCP and AvadaMCP as children, plus shared "Upload New Version".
 *
 *   - If WordpressMCP is NOT active → AvadaMCP creates its own top-level
 *     "InsationAI Tools" menu at position 67. The first time WordpressMCP is
 *     activated alongside it, the two will coexist under separate parent slugs
 *     until AvadaMCP's parent is re-registered. (Either deactivate/reactivate
 *     AvadaMCP after installing WordpressMCP, or just live with two top-level
 *     entries — they don't conflict functionally.)
 *
 * Hook priority 11 fires AFTER WordpressMCP's default priority 10, so when both
 * plugins are active we can reliably detect WordpressMCP's parent menu before
 * attaching to it.
 */
function insationai_avmcp_add_admin_menu() {
    $parent_slug = 'avada-mcp-tools';
    $hasParent   = false;

    if (insationai_avmcp_wordpressmcp_active()) {
        // Attach under WordpressMCP's parent menu
        $parent_slug = 'insationai-tools';
        $hasParent   = true;
    } else {
        // Stand-alone: create our own top-level menu, positioned just below
        // where WordpressMCP would put its own (66) — slot 67 is the convention.
        add_menu_page(
            __('InsationAI Tools', 'avada-mcp'),
            __('InsationAI Tools', 'avada-mcp'),
            'manage_options',
            $parent_slug,
            'insationai_avmcp_settings_page',
            'dashicons-superhero-alt',
            67
        );
    }

    // AvadaMCP submenu — always present, attaching to whichever parent we chose
    add_submenu_page(
        $parent_slug,
        __('AvadaMCP', 'avada-mcp'),
        __('AvadaMCP', 'avada-mcp'),
        'manage_options',
        'avada-mcp-tools',  // page slug always avada-mcp-tools so settings link works
        'insationai_avmcp_settings_page'
    );

    // NOTE: "Upload New Version" is intentionally NOT registered here.
    //   - Companion mode (WordpressMCP active): WordpressMCP registers the
    //     shared "Upload New Version" item on its own late priority-99 hook,
    //     so it already sorts below the AvadaMCP entry. We add nothing.
    //   - Stand-alone mode: insationai_avmcp_add_upload_submenu() adds it on a
    //     late hook with an explicit bottom position. See below.
}
add_action('admin_menu', 'insationai_avmcp_add_admin_menu', 11);

/**
 * Register "Upload New Version" LAST — stand-alone mode only.
 *
 * Runs on admin_menu priority 99. When WordpressMCP is active it owns the
 * shared "Upload New Version" entry (also at priority 99) under the
 * "insationai-tools" parent, so this function does nothing to avoid a
 * duplicate. When AvadaMCP runs stand-alone, this adds the entry under
 * AvadaMCP's own parent menu with an explicit PHP_INT_MAX position so it
 * sorts to the very bottom of the submenu.
 */
function insationai_avmcp_add_upload_submenu() {
    // Companion mode: WordpressMCP handles the shared upload entry.
    if (insationai_avmcp_wordpressmcp_active()) {
        return;
    }

    add_submenu_page(
        'avada-mcp-tools',
        __('Upload New Version', 'avada-mcp'),
        __('Upload New Version', 'avada-mcp'),
        'install_plugins',
        'plugin-install.php?tab=upload',
        '',
        PHP_INT_MAX  // $position — forces this item to the bottom of the submenu
    );
}
add_action('admin_menu', 'insationai_avmcp_add_upload_submenu', 99);

/**
 * Add Settings link to plugin action links
 */
function insationai_avmcp_add_settings_link($links) {
    $settings_link = sprintf(
        '<a href="%s">%s</a>',
        admin_url('admin.php?page=avada-mcp-tools'),
        __('Settings', 'avada-mcp')
    );
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'insationai_avmcp_add_settings_link');

/**
 * Render admin settings page
 */
function insationai_avmcp_settings_page() {
    require_once INSATIONAI_AVMCP_PLUGIN_DIR . 'admin/settings.php';
}

/**
 * Get configuration array from WordPress options
 *
 * @return array Configuration array compatible with AuthenticationManager
 */
function insationai_avmcp_get_config() {
    $config = [
        'safe_mode' => get_option('insationai_avmcp_safe_mode', false),
        'oauth' => [
            'enabled' => get_option('insationai_avmcp_oauth_enabled', false),
            'issuer' => get_option('insationai_avmcp_oauth_issuer', home_url('/avada-mcp')),
            'resource_identifier' => get_option('insationai_avmcp_oauth_resource_identifier', home_url('/avada-mcp')),
            'private_key_path' => get_option('insationai_avmcp_oauth_private_key_path', ''),
            'public_key_path' => get_option('insationai_avmcp_oauth_public_key_path', ''),
            'access_token_ttl' => get_option('insationai_avmcp_oauth_access_token_ttl', 3600),
            'refresh_token_ttl' => get_option('insationai_avmcp_oauth_refresh_token_ttl', 2592000),
            'authorization_code_ttl' => get_option('insationai_avmcp_oauth_authorization_code_ttl', 600),
        ],
    ];

    // Define WP_MCP_SAFE_MODE constant for tools
    if ($config['safe_mode'] && !defined('WP_MCP_SAFE_MODE')) {
        define('WP_MCP_SAFE_MODE', true);
    }

    return $config;
}

/**
 * AJAX handler to dismiss activation error notice
 */
function insationai_avmcp_dismiss_activation_error() {
    // Verify user has permission
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
        return;
    }

    // Delete the transient
    delete_transient('insationai_avmcp_activation_errors');
    wp_send_json_success();
}
add_action('wp_ajax_insationai_avmcp_dismiss_activation_error', 'insationai_avmcp_dismiss_activation_error');


/**
 * Serve a custom robots.txt body when one is configured via the
 * manage_robots_txt tool. Runs only if a non-empty body is stored.
 */
add_filter('robots_txt', function ($output, $public) {
    $custom = get_option('insationai_avmcp_robots_txt', '');
    if (is_string($custom) && $custom !== '') {
        return $custom;
    }
    return $output;
}, 99, 2);

/**
 * Apply redirects configured via the manage_redirects tool.
 *
 * Runs at template_redirect priority 1 so it fires before most plugins. Only
 * matches the exact request path (URI without query string). On match, sends
 * the configured status code and exits.
 */
add_action('template_redirect', function () {
    $redirects = get_option('insationai_avmcp_redirects', []);
    if (!is_array($redirects) || empty($redirects)) {
        return;
    }
    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = parse_url($request_uri, PHP_URL_PATH);
    if (!is_string($path)) {
        return;
    }
    foreach ($redirects as $rule) {
        if (!is_array($rule) || empty($rule['source']) || empty($rule['target'])) {
            continue;
        }
        if ($rule['source'] === $path) {
            $status = (int) ($rule['status'] ?? 301);
            wp_redirect(esc_url_raw($rule['target']), $status);
            exit;
        }
    }
}, 1);

/**
 * AJAX handler — save the Tools tab toggle state.
 */
add_action('wp_ajax_insationai_avmcp_save_tools', function () {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    check_ajax_referer('insationai_avmcp_tools_toggle');

    $disabled = isset($_POST['disabled']) && is_array($_POST['disabled'])
        ? array_map('sanitize_text_field', wp_unslash($_POST['disabled']))
        : [];

    \InsationAI\AvadaMCP\ToolRegistry::setDisabledToolNames($disabled);

    wp_send_json_success([
        'disabled_count' => count($disabled),
    ]);
});
