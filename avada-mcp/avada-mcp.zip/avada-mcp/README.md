# AvadaMCP

**Stable tag:** 1.0.7
**Requires WordPress:** 6.0
**Tested up to:** 6.7
**Requires PHP:** 8.2
**Requires Elementor:** active
**License:** GPL-2.0-or-later

**A comprehensive Model Context Protocol (MCP) server for Elementor.**

Exposes Elementor as a unified toolkit for AI assistants like Claude. Covers documents, the element tree, widget types, templates and the library, global styles (the Kit), revisions, page settings, custom CSS, dynamic tags, experiments, diagnostics, cache regeneration, maintenance mode, search & replace, editor roles, fonts, and style variations — 100 tools across 18 categories, all reachable from any MCP-compatible client via a dedicated HTTP endpoint with OAuth 2.1 or bearer-token authentication.

## Companion to WordpressMCP

AvadaMCP is designed to run **side by side** with [WordpressMCP](https://insationai.com/) on the same WordPress site. It uses entirely separate infrastructure:

| | WordpressMCP | AvadaMCP |
|---|---|---|
| Endpoint | `/insationai-wordpress-mcp` | `/avada-mcp` |
| Token table | `wp_insationai_wpmcp_user_tokens` | `wp_elementor_mcp_user_tokens` |
| Option prefix | `insationai_wpmcp_*` | `insationai_avmcp_*` |
| Admin menu slug | `insationai-tools` | `avada-mcp-tools` |

When WordpressMCP is active alongside, AvadaMCP automatically attaches as a submenu under the existing **InsationAI Tools** sidebar entry. Both plugins remain fully independent — uninstalling one does not affect the other.

## Features

- ✅ **100 MCP tools** across 18 categories (the complete 1.0.x build-out)
- ✅ **Tools tab** — enable or disable individual tools or whole categories from the admin
- ✅ **OAuth 2.1 Authentication** — enabled by default; bearer tokens also supported
- ✅ **WordPress Abilities API (WP 6.9+)** — every tool is dual-registered via `wp_register_ability()`
- ✅ **Revisions Tab** — Settings → AvadaMCP → Revisions shows the full version history
- ✅ **Per-User API Tokens** — separate token set from WordpressMCP
- ✅ **Role-Based Permissions** — every tool respects WordPress capability checks
- ✅ **Safe Mode** — opt-in flag that blocks destructive operations
- ✅ **Auto-detect Elementor** — admin notice when Elementor is missing; tools register only when Elementor is loaded

## Installation

1. Make sure Elementor (free) is installed and active first.
2. Download `avada-mcp-1.0.0.zip`.
3. WordPress Admin → Plugins → Add New → Upload Plugin → choose the zip → Install Now → Activate.
4. Visit **InsationAI Tools → AvadaMCP** (or **AvadaMCP** as a top-level menu if WordpressMCP isn't installed).
5. Generate an API token from the **API Tokens** tab, then point your MCP client at `https://yoursite.com/avada-mcp` with that token.
