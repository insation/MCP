<?php
/**
 * Tool Registry — AvadaMCP
 *
 * Central source of truth for tool metadata. Both the runtime registrars
 * (mcp-http.php, register-abilities.php) and the admin Tools toggle UI
 * consume this so they stay in lockstep.
 *
 * Tools are only built when Elementor is active. When Elementor is missing,
 * buildAllTools / buildEnabledTools return an empty array. The admin Tools
 * tab still renders (so users can see what would be available), but
 * tools/list returns nothing to MCP clients until Elementor is loaded.
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use InsationAI\AvadaMCP\Services\ContentPatchingService;
use InsationAI\AvadaMCP\Logger\WordPressLogger;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ToolRegistry
{
    public const DISABLED_OPTION = 'insationai_avmcp_disabled_tools';

    /**
     * Build every tool instance.
     *
     * @return AbstractTool[]
     */
    public static function buildAllTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $avada = new AvadaService();
        if (!$avada->isAvadaActive()) {
            return [];
        }

        return [
            // ── Theme Options ─────────────────────────────────────────────
            new Tools\ThemeOptions\GetAvadaInfo($wp, $validator, $avada, $logger),
            new Tools\ThemeOptions\GetThemeOptions($wp, $validator, $avada, $logger),
            new Tools\ThemeOptions\SetThemeOption($wp, $validator, $avada, $logger),
            new Tools\ThemeOptions\ResetThemeOption($wp, $validator, $avada, $logger),

            // ── Avada Content Types (Portfolio / FAQ / Slider / etc.) ─────
            new Tools\ContentTypes\ListAvadaContent($wp, $validator, $avada, $logger),
            new Tools\ContentTypes\GetAvadaContent($wp, $validator, $avada, $logger),

            // ── Global Colors & Typography ────────────────────────────────
            new Tools\GlobalStyles\GetGlobalColors($wp, $validator, $avada, $logger),
            new Tools\GlobalStyles\SetGlobalColor($wp, $validator, $avada, $logger),
            new Tools\GlobalStyles\RepairGlobalColors($wp, $validator, $avada, $logger),
            new Tools\GlobalStyles\GetGlobalTypography($wp, $validator, $avada, $logger),
            new Tools\GlobalStyles\SetGlobalTypography($wp, $validator, $avada, $logger),

            // ── Avada Library (fusion_element / fusion_template) ──────────
            new Tools\Library\ListLibraryItems($wp, $validator, $avada, $logger),
            new Tools\Library\ListLibraryCategories($wp, $validator, $avada, $logger),
            new Tools\Library\GetLibraryItem($wp, $validator, $avada, $logger),
            new Tools\Library\CreateLibraryItem($wp, $validator, $avada, $logger),
            new Tools\Library\UpdateLibraryItem($wp, $validator, $avada, $logger),

            // ── Avada Layout / Theme Builder (fusion_tb_layout/section) ───
            new Tools\ThemeBuilder\GetThemeBuilderInfo($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\ListThemeBuilderLayouts($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\GetThemeBuilderLayout($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\ListThemeBuilderSections($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\GetThemeBuilderSection($wp, $validator, $avada, $logger),

            // ── Theme Builder — Conditions write path (guarded) ───────────
            new Tools\ThemeBuilder\GetThemeBuilderConditions($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\SetThemeBuilderConditions($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\AddThemeBuilderCondition($wp, $validator, $avada, $logger),
            new Tools\ThemeBuilder\RevertThemeBuilderConditions($wp, $validator, $avada, $logger),

            // ── Prebuilt Websites / Importer (read-only) ──────────────────
            new Tools\Prebuilt\ListPrebuiltWebsites($wp, $validator, $avada, $logger),
            new Tools\Prebuilt\GetPrebuiltTags($wp, $validator, $avada, $logger),
            new Tools\Prebuilt\GetImportedWebsites($wp, $validator, $avada, $logger),
            new Tools\Prebuilt\GetPrebuiltPluginsInfo($wp, $validator, $avada, $logger),

            // ── Performance & Maintenance ─────────────────────────────────
            new Tools\Performance\GetSystemStatus($wp, $validator, $avada, $logger),
            new Tools\Performance\GetPerformanceSettings($wp, $validator, $avada, $logger),
            new Tools\Performance\ResetCaches($wp, $validator, $avada, $logger),
            new Tools\Performance\RegenerateDynamicCss($wp, $validator, $avada, $logger),
        ];
    }

    /**
     * Build enabled tools (filters out admin-disabled ones).
     *
     * @return AbstractTool[]
     */
    public static function buildEnabledTools(
        WordPressService $wp,
        ValidationService $validator,
        WordPressLogger $logger,
        ?ContentPatchingService $patching = null
    ): array {
        $all = self::buildAllTools($wp, $validator, $logger, $patching);
        $disabled = self::getDisabledToolNames();
        if (empty($disabled) || empty($all)) {
            return $all;
        }
        return array_values(array_filter(
            $all,
            static fn(AbstractTool $t) => !in_array($t->getName(), $disabled, true)
        ));
    }

    /**
     * @return string[]
     */
    public static function getDisabledToolNames(): array
    {
        $stored = get_option(self::DISABLED_OPTION, []);
        return is_array($stored) ? array_values(array_filter(array_map('strval', $stored))) : [];
    }

    /**
     * @param string[] $names
     */
    public static function setDisabledToolNames(array $names): void
    {
        $clean = array_values(array_unique(array_filter(array_map('sanitize_text_field', $names))));
        update_option(self::DISABLED_OPTION, $clean);
    }

    /**
     * Stable category slug for a tool name.
     */
    public static function categoryFor(string $toolName): string
    {
        $documents = [
            'list_elementor_documents', 'get_elementor_document', 'get_document_data',
            'replace_document_data', 'duplicate_document', 'delete_elementor_document',
            'get_document_settings', 'update_document_settings', 'count_elementor_documents',
            'get_elementor_version',
        ];
        if (in_array($toolName, $documents, true)) {
            return 'documents';
        }

        $elements = [
            'find_element', 'get_element', 'list_elements', 'count_elements_in_document',
            'get_element_parent', 'get_element_path', 'find_widgets_by_type',
            'find_elements_by_class', 'insert_element', 'update_element', 'replace_element',
            'delete_element', 'duplicate_element', 'move_element',
            'wrap_element_in_container', 'unwrap_element',
        ];
        if (in_array($toolName, $elements, true)) {
            return 'elements';
        }

        $widgets = [
            'list_widget_types', 'get_widget_schema', 'list_registered_widget_categories',
            'count_widgets_by_type', 'find_unused_widget_types', 'get_widget_default_settings',
            'validate_widget_settings', 'bulk_replace_widget_type',
        ];
        if (in_array($toolName, $widgets, true)) {
            return 'widgets';
        }

        $templates = [
            'list_templates', 'get_template', 'create_template', 'update_template',
            'delete_template', 'duplicate_template', 'export_template', 'import_template',
            'apply_template_to_document', 'save_element_as_template', 'count_templates',
            'get_template_conditions',
        ];
        if (in_array($toolName, $templates, true)) {
            return 'templates';
        }

        $kit = [
            'get_active_kit', 'get_kit_settings', 'update_kit_settings', 'list_global_colors',
            'list_global_fonts', 'update_global_color', 'add_global_color',
            'delete_global_color', 'get_kit_custom_css', 'list_all_kits',
        ];
        if (in_array($toolName, $kit, true)) {
            return 'kit';
        }

        $revisions = [
            'list_document_revisions', 'get_revision_data', 'restore_revision',
            'delete_revision', 'prune_document_revisions',
        ];
        if (in_array($toolName, $revisions, true)) {
            return 'revisions';
        }

        $pageSettings = [
            'get_page_settings', 'update_page_settings', 'get_page_template', 'set_page_template',
        ];
        if (in_array($toolName, $pageSettings, true)) {
            return 'page-settings';
        }

        $customCss = [
            'get_page_custom_css', 'set_page_custom_css', 'get_element_custom_css',
        ];
        if (in_array($toolName, $customCss, true)) {
            return 'custom-css';
        }

        $dynamicTags = [
            'list_dynamic_tags', 'list_dynamic_tag_groups', 'find_dynamic_tag_usage',
            'get_dynamic_tag_config',
        ];
        if (in_array($toolName, $dynamicTags, true)) {
            return 'dynamic-tags';
        }

        $experiments = [
            'list_experiments', 'get_experiment', 'set_experiment_state',
        ];
        if (in_array($toolName, $experiments, true)) {
            return 'experiments';
        }

        $diagnostics = [
            'get_elementor_system_info', 'validate_document_data', 'find_orphaned_elementor_data',
            'get_elementor_settings', 'check_elementor_requirements', 'get_document_css_status',
        ];
        if (in_array($toolName, $diagnostics, true)) {
            return 'diagnostics';
        }

        $cache = [
            'clear_elementor_cache', 'regenerate_document_css', 'regenerate_all_css',
            'sync_global_css', 'get_cache_status',
        ];
        if (in_array($toolName, $cache, true)) {
            return 'cache';
        }

        $maintenance = ['get_maintenance_mode', 'set_maintenance_mode'];
        if (in_array($toolName, $maintenance, true)) {
            return 'maintenance';
        }

        $search = [
            'search_document_content', 'replace_in_document', 'replace_url_across_documents',
        ];
        if (in_array($toolName, $search, true)) {
            return 'search';
        }

        $roles = ['get_editor_role_access', 'set_editor_role_access'];
        if (in_array($toolName, $roles, true)) {
            return 'roles';
        }

        $fonts = ['list_fonts', 'list_font_groups', 'find_font_usage'];
        if (in_array($toolName, $fonts, true)) {
            return 'fonts';
        }

        $styleVariations = [
            'export_kit_styles', 'apply_kit_style_variation', 'compare_kit_styles',
            'save_kit_style_variation_as_kit',
        ];
        if (in_array($toolName, $styleVariations, true)) {
            return 'style-variations';
        }

        // Future categories will go here as we expand
        return 'misc';
    }

    /**
     * Human-readable label for a category slug.
     */
    public static function categoryLabel(string $slug): string
    {
        $labels = [
            'documents'  => __('Documents', 'avada-mcp'),
            'elements'   => __('Element Tree', 'avada-mcp'),
            'widgets'    => __('Widget Types', 'avada-mcp'),
            'templates'  => __('Templates & Library', 'avada-mcp'),
            'kit'        => __('Global Kit & Styles', 'avada-mcp'),
            'revisions'  => __('Revisions', 'avada-mcp'),
            'page-settings' => __('Page Settings', 'avada-mcp'),
            'custom-css' => __('Custom CSS', 'avada-mcp'),
            'dynamic-tags' => __('Dynamic Tags', 'avada-mcp'),
            'experiments' => __('Experiments', 'avada-mcp'),
            'diagnostics'=> __('Diagnostics', 'avada-mcp'),
            'cache'      => __('Cache & CSS Regen', 'avada-mcp'),
            'maintenance'=> __('Maintenance Mode', 'avada-mcp'),
            'search'     => __('Search & Replace', 'avada-mcp'),
            'roles'      => __('Editor Roles', 'avada-mcp'),
            'fonts'      => __('Fonts', 'avada-mcp'),
            'style-variations' => __('Style Variations', 'avada-mcp'),
            'misc'       => __('Misc', 'avada-mcp'),
        ];
        return $labels[$slug] ?? ucfirst(str_replace('-', ' ', $slug));
    }
}
