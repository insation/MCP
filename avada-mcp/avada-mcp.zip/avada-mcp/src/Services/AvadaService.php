<?php
/**
 * Avada Service
 *
 * Centralizes all access to the Avada theme's internals (Theme Options via the
 * Fusion_Settings singleton, the Avada CPTs, the Layout/Theme Builder, global
 * colors & typography). Every entry point is defensively guarded so that an
 * Avada version change degrades gracefully (clear RuntimeException) instead of
 * fataling.
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Services;

class AvadaService
{
    /**
     * The WordPress option key Avada/Fusion stores Theme Options under
     * (before any language suffix is applied).
     */
    public const OPTIONS_KEY = 'fusion_options';

    /**
     * Avada custom post types, keyed by slug with a human label.
     *
     * @var array<string, string>
     */
    public const AVADA_CPTS = [
        'avada_portfolio'  => 'Portfolio',
        'avada_faq'        => 'FAQ',
        'slide'            => 'Slider Slide',
        'themefusion_elastic_slides' => 'Elastic Slide',
        'fusion_tb_section'=> 'Layout Section (Theme Builder)',
        'fusion_element'   => 'Library Element',
        'fusion_form'      => 'Fusion Form',
        'fusion_icons'     => 'Custom Icon Set',
        'fusion_template'  => 'Layout Template',
    ];

    /**
     * Assert the Avada theme is active. Detection mirrors the main plugin
     * gate: AVADA_VERSION constant, the Avada class, or the active theme.
     *
     * @throws \RuntimeException
     */
    public function requireAvada(): void
    {
        if (defined('AVADA_VERSION') || class_exists('Avada')) {
            return;
        }
        if (function_exists('wp_get_theme')) {
            $theme = wp_get_theme();
            if ($theme) {
                $candidates = [
                    (string) $theme->get('Name'),
                    (string) $theme->get_template(),
                ];
                if ($theme->parent()) {
                    $candidates[] = (string) $theme->parent()->get('Name');
                }
                foreach ($candidates as $c) {
                    if (strtolower($c) === 'avada') {
                        return;
                    }
                }
            }
        }
        throw new \RuntimeException(
            'The Avada theme is not active. AvadaMCP tools require the Avada theme to be installed and active.'
        );
    }

    /**
     * Whether the Avada theme is active (non-throwing).
     */
    public function isAvadaActive(): bool
    {
        try {
            $this->requireAvada();
            return true;
        } catch (\RuntimeException $e) {
            return false;
        }
    }

    /**
     * The installed Avada theme version, or null if unknown.
     */
    public function getAvadaVersion(): ?string
    {
        if (defined('AVADA_VERSION')) {
            return (string) constant('AVADA_VERSION');
        }
        if (function_exists('wp_get_theme')) {
            $theme = wp_get_theme();
            if ($theme && strtolower((string) $theme->get_template()) === 'avada') {
                $v = $theme->get('Version');
                return $v ? (string) $v : null;
            }
        }
        return null;
    }

    /**
     * Get the Fusion_Settings singleton (the Theme Options accessor).
     *
     * @return object Fusion_Settings instance
     * @throws \RuntimeException
     */
    public function settings(): object
    {
        $this->requireAvada();

        // Avada_Settings extends Fusion_Settings; prefer the Avada subclass.
        foreach (['Avada_Settings', 'Fusion_Settings'] as $class) {
            if (class_exists($class) && method_exists($class, 'get_instance')) {
                $instance = $class::get_instance();
                if (is_object($instance)) {
                    return $instance;
                }
            }
        }
        throw new \RuntimeException(
            'Avada Theme Options API (Fusion_Settings) is unavailable. The Avada version may differ from what this tool supports.'
        );
    }

    /**
     * Resolve the actual wp_options key Avada uses (handles the language
     * suffix applied by multilingual setups).
     */
    public function optionsKey(): string
    {
        if (class_exists('Avada_Settings') && method_exists('Avada_Settings', 'get_option_name')) {
            $name = \Avada_Settings::get_option_name();
            if (is_string($name) && $name !== '') {
                return $name;
            }
        }
        if (class_exists('Fusion_Settings') && method_exists('Fusion_Settings', 'get_option_name')) {
            $name = \Fusion_Settings::get_option_name();
            if (is_string($name) && $name !== '') {
                return $name;
            }
        }
        return self::OPTIONS_KEY;
    }

    /**
     * Read all saved Theme Options as a raw associative array.
     *
     * @return array<string, mixed>
     */
    public function getAllOptions(): array
    {
        $this->requireAvada();
        $stored = get_option($this->optionsKey(), []);
        return is_array($stored) ? $stored : [];
    }

    /**
     * Get a single Theme Option value via the Fusion_Settings accessor, which
     * correctly falls back to the registered default when unset.
     *
     * @param string $setting
     * @param string|false $subset
     * @param mixed $default
     * @return mixed
     * @throws \RuntimeException
     */
    public function getOption(string $setting, $subset = false, $default = null)
    {
        $settings = $this->settings();
        if (!method_exists($settings, 'get')) {
            throw new \RuntimeException('Fusion_Settings::get() is unavailable in this Avada version.');
        }
        return $settings->get($setting, $subset, $default);
    }

    /**
     * Persist a single Theme Option. Writes through the Fusion_Settings
     * setter when available (so caches are invalidated), otherwise falls
     * back to a guarded direct option write.
     *
     * @param string $setting
     * @param mixed $value
     * @return bool
     * @throws \RuntimeException
     */
    public function setOption(string $setting, $value): bool
    {
        $settings = $this->settings();

        if (method_exists($settings, 'set')) {
            // Fusion_Settings::set() returns void in some versions; treat the
            // absence of an exception plus a verifying read as success.
            $settings->set($setting, $value);
            return true;
        }

        // Fallback: direct option array write.
        $key = $this->optionsKey();
        $all = get_option($key, []);
        if (!is_array($all)) {
            $all = [];
        }
        $all[$setting] = $value;
        return (bool) update_option($key, $all);
    }

    /**
     * Get the registered default for a setting (or all defaults).
     *
     * @param string|null $setting
     * @param string|false $subset
     * @return mixed
     */
    public function getDefault($setting = null, $subset = false)
    {
        $settings = $this->settings();
        if (!method_exists($settings, 'get_default')) {
            return null;
        }
        return $settings->get_default($setting, $subset);
    }

    /**
     * Count posts of an Avada CPT by status.
     *
     * @param string $postType
     * @return array<string, int>
     * @throws \RuntimeException
     */
    public function countCptPosts(string $postType): array
    {
        $this->requireAvada();
        if (!isset(self::AVADA_CPTS[$postType])) {
            throw new \RuntimeException(
                "'{$postType}' is not a recognized Avada custom post type."
            );
        }
        $counts = wp_count_posts($postType);
        $out = [];
        if (is_object($counts)) {
            foreach ($counts as $status => $n) {
                $out[(string) $status] = (int) $n;
            }
        }
        return $out;
    }

    /**
     * List posts of an Avada CPT.
     *
     * @param string $postType
     * @param int $perPage
     * @param int $page
     * @param string $status
     * @return array<int, array{id:int,title:string,status:string,modified:string,slug:string}>
     * @throws \RuntimeException
     */
    public function listCptPosts(
        string $postType,
        int $perPage = 25,
        int $page = 1,
        string $status = 'any'
    ): array {
        $this->requireAvada();
        if (!isset(self::AVADA_CPTS[$postType])) {
            throw new \RuntimeException(
                "'{$postType}' is not a recognized Avada custom post type."
            );
        }

        $query = new \WP_Query([
            'post_type'      => $postType,
            'post_status'    => $status,
            'posts_per_page' => max(1, min(100, $perPage)),
            'paged'          => max(1, $page),
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ]);

        $out = [];
        foreach ($query->posts as $post) {
            $out[] = [
                'id'       => (int) $post->ID,
                'title'    => $post->post_title,
                'status'   => $post->post_status,
                'modified' => $post->post_modified_gmt,
                'slug'     => $post->post_name,
            ];
        }
        return $out;
    }

    /**
     * Whether a post is one of the Avada CPTs.
     */
    public function isAvadaCpt(int $postId): bool
    {
        $post = get_post($postId);
        return $post && isset(self::AVADA_CPTS[$post->post_type]);
    }

    /* ===================================================================
     * Global Colors & Typography
     *
     * Avada stores the global color palette under the Fusion option
     * 'color_palette' and global typography sets under 'typography_sets'.
     * Both are read/merged-with-defaults through dedicated singletons:
     * AWB_Global_Colors and AWB_Global_Typography. Writes go through the
     * Fusion_Settings setter (via setOption) so Avada's option cache and
     * dynamic-CSS regeneration stay consistent.
     * ================================================================= */

    /** Fusion option key holding the global color palette. */
    public const COLOR_PALETTE_KEY = 'color_palette';

    /** Fusion option key holding the global typography sets. */
    public const TYPOGRAPHY_SETS_KEY = 'typography_sets';

    /**
     * Get the AWB_Global_Colors singleton, if available.
     *
     * @return object|null
     */
    public function globalColors(): ?object
    {
        $this->requireAvada();
        if (class_exists('AWB_Global_Colors') && method_exists('AWB_Global_Colors', 'get_instance')) {
            $i = \AWB_Global_Colors::get_instance();
            return is_object($i) ? $i : null;
        }
        return null;
    }

    /**
     * Get the AWB_Global_Typography singleton, if available.
     *
     * @return object|null
     */
    public function globalTypography(): ?object
    {
        $this->requireAvada();
        if (class_exists('AWB_Global_Typography') && method_exists('AWB_Global_Typography', 'get_instance')) {
            $i = \AWB_Global_Typography::get_instance();
            return is_object($i) ? $i : null;
        }
        return null;
    }

    /**
     * Get the global color palette (slug => color value), merged with
     * defaults exactly as Avada resolves it. Falls back to the raw Fusion
     * option if the singleton is unavailable.
     *
     * @return array<string, mixed>
     * @throws \RuntimeException
     */
    public function getColorPalette(): array
    {
        $this->requireAvada();

        $colors = $this->globalColors();
        if ($colors && method_exists($colors, 'get_palette')) {
            $palette = $colors->get_palette();
            if (is_array($palette)) {
                return $palette;
            }
        }

        // Fallback: raw Fusion option.
        $raw = $this->getOption(self::COLOR_PALETTE_KEY);
        return is_array($raw) ? $raw : [];
    }

    /**
     * Get the registered default color palette.
     *
     * @return array<string, mixed>
     */
    public function getColorPaletteDefaults(): array
    {
        $colors = $this->globalColors();
        if ($colors && method_exists($colors, 'get_defaults')) {
            $d = $colors->get_defaults();
            if (is_array($d)) {
                return $d;
            }
        }
        return [];
    }

    /**
     * Persist the global color palette. Written through the Fusion_Settings
     * setter so Avada's cache and dynamic CSS regenerate.
     *
     * @param array<string, mixed> $palette
     * @return bool
     * @throws \RuntimeException
     */
    public function setColorPalette(array $palette): bool
    {
        $this->requireAvada();
        return $this->setOption(self::COLOR_PALETTE_KEY, $palette);
    }

    /**
     * Read the palette from the RAW Fusion option, bypassing Avada's own
     * AWB_Global_Colors::get_palette() processor (which can fatal if an
     * entry is malformed — e.g. a bare string instead of {color,label}).
     * Every entry is normalized to the {color,label} object shape Avada
     * expects. This is the safe read for repair/recovery.
     *
     * @return array<string, array{color:string,label:string}>
     * @throws \RuntimeException
     */
    public function getColorPaletteRaw(): array
    {
        $this->requireAvada();

        $raw = $this->getOption(self::COLOR_PALETTE_KEY);
        if (!is_array($raw)) {
            // Fall back to registered defaults if the option is unusable.
            $defaults = $this->getColorPaletteDefaults();
            return is_array($defaults) ? $defaults : [];
        }

        $out = [];
        foreach ($raw as $slug => $entry) {
            if (is_array($entry) && isset($entry['color'])) {
                $out[$slug] = [
                    'color' => (string) $entry['color'],
                    'label' => isset($entry['label']) ? (string) $entry['label'] : ucfirst((string) $slug),
                ];
            } elseif (is_object($entry) && isset($entry->color)) {
                $out[$slug] = [
                    'color' => (string) $entry->color,
                    'label' => isset($entry->label) ? (string) $entry->label : ucfirst((string) $slug),
                ];
            } elseif (is_string($entry) && $entry !== '') {
                // Malformed (bare string) — normalize back to object shape.
                $out[$slug] = [
                    'color' => $entry,
                    'label' => ucfirst(str_replace(['_', '-'], ' ', (string) $slug)),
                ];
            }
            // else: skip an unrecoverable entry rather than propagate it
        }
        return $out;
    }

    /**
     * Repair the palette: read it raw (tolerating malformed entries),
     * normalize all entries to {color,label}, and write it back. Returns
     * the repaired palette. Used to recover from a corrupted color_palette.
     *
     * @return array<string, array{color:string,label:string}>
     * @throws \RuntimeException
     */
    public function repairColorPalette(): array
    {
        $repaired = $this->getColorPaletteRaw();
        if (empty($repaired)) {
            throw new \RuntimeException(
                'Could not reconstruct the color palette (raw option unreadable and no defaults available).'
            );
        }
        $this->setColorPalette($repaired);
        return $repaired;
    }

    /**
     * Get the global typography sets, merged with defaults exactly as Avada
     * resolves them. Falls back to the raw Fusion option.
     *
     * @return array<string, mixed>
     * @throws \RuntimeException
     */
    public function getTypographySets(): array
    {
        $this->requireAvada();

        $typo = $this->globalTypography();
        if ($typo && method_exists($typo, 'get_typography')) {
            $sets = $typo->get_typography();
            if (is_array($sets)) {
                return $sets;
            }
        }

        $raw = $this->getOption(self::TYPOGRAPHY_SETS_KEY);
        return is_array($raw) ? $raw : [];
    }

    /**
     * Get the registered default typography sets.
     *
     * @return array<string, mixed>
     */
    public function getTypographyDefaults(): array
    {
        $typo = $this->globalTypography();
        if ($typo && method_exists($typo, 'get_defaults')) {
            $d = $typo->get_defaults();
            if (is_array($d)) {
                return $d;
            }
        }
        return [];
    }

    /**
     * Persist the global typography sets through Fusion_Settings.
     *
     * @param array<string, mixed> $sets
     * @return bool
     * @throws \RuntimeException
     */
    public function setTypographySets(array $sets): bool
    {
        $this->requireAvada();
        return $this->setOption(self::TYPOGRAPHY_SETS_KEY, $sets);
    }

    /**
     * Normalize wp_count_posts output to the meaningful, non-internal
     * statuses. WordPress includes internal statuses (auto-draft,
     * request-*, inherit) that are noise for content counting.
     *
     * @param array<string,int> $counts
     * @return array<string,int>
     */
    public function meaningfulStatusCounts(array $counts): array
    {
        $internal = [
            'auto-draft', 'inherit', 'request-pending', 'request-confirmed',
            'request-failed', 'request-completed',
        ];
        $out = [];
        foreach ($counts as $status => $n) {
            if (in_array($status, $internal, true)) {
                continue;
            }
            $out[(string) $status] = (int) $n;
        }
        return $out;
    }

    /* ===================================================================
     * Avada Library  (fusion_element / fusion_template)
     *
     * The Avada Library stores reusable design blocks as two CPTs:
     *  - fusion_element  : saved "Library Elements" (sections/columns/
     *                      elements), organized by the hierarchical
     *                      taxonomy 'element_category', with the meta key
     *                      '_fusion_element_type' recording the element
     *                      type (e.g. sections, columns, elements).
     *  - fusion_template : saved full-page "Layouts", organized by the
     *                      hierarchical taxonomy 'template_category'.
     *
     * Content is the Fusion Builder shortcode string in post_content.
     * Creation mirrors Fusion_Builder_Library::create_layout() exactly:
     * wp_insert_post + add_post_meta + wp_set_object_terms, gated by the
     * 'avada_library' role-manager capability (default edit_posts).
     * ================================================================= */

    public const LIBRARY_ELEMENT_CPT  = 'fusion_element';
    public const LIBRARY_TEMPLATE_CPT = 'fusion_template';
    public const ELEMENT_CATEGORY_TAX  = 'element_category';
    public const TEMPLATE_CATEGORY_TAX = 'template_category';
    public const ELEMENT_TYPE_META     = '_fusion_element_type';

    /**
     * Map a library CPT to its category taxonomy.
     *
     * @throws \RuntimeException
     */
    public function libraryTaxonomyFor(string $postType): string
    {
        if ($postType === self::LIBRARY_ELEMENT_CPT) {
            return self::ELEMENT_CATEGORY_TAX;
        }
        if ($postType === self::LIBRARY_TEMPLATE_CPT) {
            return self::TEMPLATE_CATEGORY_TAX;
        }
        throw new \RuntimeException(
            "'{$postType}' is not an Avada Library post type. Use fusion_element or fusion_template."
        );
    }

    /**
     * Assert a post type is one of the two Library CPTs.
     *
     * @throws \RuntimeException
     */
    public function requireLibraryCpt(string $postType): void
    {
        if ($postType !== self::LIBRARY_ELEMENT_CPT
            && $postType !== self::LIBRARY_TEMPLATE_CPT) {
            throw new \RuntimeException(
                "'{$postType}' is not an Avada Library post type. Use fusion_element (Library Elements) or fusion_template (Saved Layouts)."
            );
        }
    }

    /**
     * The Avada Library capability gate, mirroring Fusion_Builder_Library:
     * apply_filters( 'awb_role_manager_access_capability', 'edit_posts',
     * 'avada_library' ).
     */
    public function canManageLibrary(): bool
    {
        $cap = 'edit_posts';
        if (function_exists('apply_filters')) {
            $cap = (string) apply_filters('awb_role_manager_access_capability', 'edit_posts', 'avada_library');
            if ($cap === '') {
                $cap = 'edit_posts';
            }
        }
        return function_exists('current_user_can') ? (bool) current_user_can($cap) : false;
    }

    /**
     * List Library categories (terms) for a given Library CPT.
     *
     * @return array<int, array{id:int,name:string,slug:string,count:int,parent:int}>
     * @throws \RuntimeException
     */
    public function listLibraryCategories(string $postType): array
    {
        $this->requireAvada();
        $tax = $this->libraryTaxonomyFor($postType);

        if (!taxonomy_exists($tax)) {
            throw new \RuntimeException(
                "Taxonomy '{$tax}' is not registered. Avada Builder may be inactive."
            );
        }

        $terms = get_terms([
            'taxonomy'   => $tax,
            'hide_empty' => false,
        ]);

        $out = [];
        if (is_array($terms)) {
            foreach ($terms as $t) {
                $out[] = [
                    'id'     => (int) $t->term_id,
                    'name'   => $t->name,
                    'slug'   => $t->slug,
                    'count'  => (int) $t->count,
                    'parent' => (int) $t->parent,
                ];
            }
        }
        return $out;
    }

    /**
     * List Library items (elements or templates), optionally filtered by
     * category term slug/id, with their type meta and categories.
     *
     * @return array<int, array<string,mixed>>
     * @throws \RuntimeException
     */
    public function listLibraryItems(
        string $postType,
        ?string $category = null,
        int $perPage = 25,
        int $page = 1,
        string $status = 'any'
    ): array {
        $this->requireAvada();
        $this->requireLibraryCpt($postType);
        $tax = $this->libraryTaxonomyFor($postType);

        $args = [
            'post_type'      => $postType,
            'post_status'    => $status,
            'posts_per_page' => max(1, min(100, $perPage)),
            'paged'          => max(1, $page),
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];

        if ($category !== null && $category !== '') {
            $field = ctype_digit($category) ? 'term_id' : 'slug';
            $args['tax_query'] = [[
                'taxonomy' => $tax,
                'field'    => $field,
                'terms'    => $field === 'term_id' ? (int) $category : $category,
            ]];
        }

        $query = new \WP_Query($args);
        $out = [];
        foreach ($query->posts as $post) {
            $terms = wp_get_object_terms($post->ID, $tax, ['fields' => 'names']);
            $out[] = [
                'id'           => (int) $post->ID,
                'title'        => $post->post_title,
                'status'       => $post->post_status,
                'slug'         => $post->post_name,
                'modified'     => $post->post_modified_gmt,
                'element_type' => get_post_meta($post->ID, self::ELEMENT_TYPE_META, true),
                'categories'   => is_array($terms) ? $terms : [],
            ];
        }
        return $out;
    }

    /**
     * Get one Library item in full — content (the Fusion shortcode string),
     * element type, and assigned categories.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getLibraryItem(int $postId): array
    {
        $this->requireAvada();
        $post = get_post($postId);

        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $this->requireLibraryCpt($post->post_type);

        $tax = $this->libraryTaxonomyFor($post->post_type);
        $terms = wp_get_object_terms($postId, $tax);
        $cats = [];
        if (is_array($terms)) {
            foreach ($terms as $t) {
                $cats[] = ['id' => (int) $t->term_id, 'name' => $t->name, 'slug' => $t->slug];
            }
        }

        return [
            'id'           => (int) $post->ID,
            'post_type'    => $post->post_type,
            'title'        => $post->post_title,
            'status'       => $post->post_status,
            'slug'         => $post->post_name,
            'modified'     => $post->post_modified_gmt,
            'element_type' => get_post_meta($postId, self::ELEMENT_TYPE_META, true),
            'categories'   => $cats,
            'content'      => $post->post_content,
        ];
    }

    /**
     * Create a Library item, mirroring Fusion_Builder_Library::create_layout()
     * (capability gate included). Returns the new post ID.
     *
     * @param array<string,string> $meta
     * @throws \RuntimeException
     */
    public function createLibraryItem(
        string $postType,
        string $name,
        string $content,
        array $meta = [],
        ?string $categoryTerm = null
    ): int {
        $this->requireAvada();
        $this->requireLibraryCpt($postType);

        if (!$this->canManageLibrary()) {
            throw new \RuntimeException(
                'Current user lacks the Avada Library capability (avada_library / edit_posts).'
            );
        }

        $status = (function_exists('current_user_can') && current_user_can('publish_posts'))
            ? 'publish' : 'pending';

        $postId = wp_insert_post([
            'post_title'   => sanitize_text_field($name),
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => $postType,
        ], true);

        if (is_wp_error($postId)) {
            throw new \RuntimeException('Failed to create Library item: ' . $postId->get_error_message());
        }

        foreach ($meta as $k => $v) {
            add_post_meta((int) $postId, (string) $k, sanitize_text_field((string) $v));
        }

        if ($categoryTerm !== null && $categoryTerm !== '') {
            wp_set_object_terms((int) $postId, $categoryTerm, $this->libraryTaxonomyFor($postType));
        }

        if (function_exists('do_action')) {
            do_action('fusion_builder_create_layout_after');
        }

        return (int) $postId;
    }

    /**
     * Update an existing Library item's title, content, type meta, and/or
     * category assignment. Only supplied fields are changed.
     *
     * @return array<string,mixed> the refreshed item
     * @throws \RuntimeException
     */
    public function updateLibraryItem(
        int $postId,
        ?string $title = null,
        ?string $content = null,
        ?string $elementType = null,
        ?string $categoryTerm = null
    ): array {
        $this->requireAvada();
        $post = get_post($postId);
        if (!$post) {
            throw new \RuntimeException("No post found with ID {$postId}.");
        }
        $this->requireLibraryCpt($post->post_type);

        if (!$this->canManageLibrary()) {
            throw new \RuntimeException(
                'Current user lacks the Avada Library capability (avada_library / edit_posts).'
            );
        }

        $update = ['ID' => $postId];
        if ($title !== null) {
            $update['post_title'] = sanitize_text_field($title);
        }
        if ($content !== null) {
            $update['post_content'] = $content;
        }
        if (count($update) > 1) {
            $res = wp_update_post($update, true);
            if (is_wp_error($res)) {
                throw new \RuntimeException('Update failed: ' . $res->get_error_message());
            }
        }

        if ($elementType !== null) {
            update_post_meta($postId, self::ELEMENT_TYPE_META, sanitize_text_field($elementType));
        }

        if ($categoryTerm !== null && $categoryTerm !== '') {
            wp_set_object_terms($postId, $categoryTerm, $this->libraryTaxonomyFor($post->post_type));
        }

        return $this->getLibraryItem($postId);
    }

    /* ===================================================================
     * Avada Layout / Theme Builder  (fusion_tb_layout / fusion_tb_section)
     *
     * The Theme Builder lets a site replace its header / page-title-bar /
     * content / footer with custom Fusion-built templates, applied via
     * display conditions.
     *
     *  - fusion_tb_layout : a "Layout" — a named grouping whose post_content
     *                       is a JSON object: {conditions:[...],
     *                       template_terms:{...}, ...}. The special id
     *                       'global' is stored in the option
     *                       'fusion_tb_layout_default' instead of a post.
     *  - fusion_tb_section: a "Section" — the actual header/footer/content/
     *                       page-title-bar template (Fusion shortcode in
     *                       post_content), categorized by the taxonomy
     *                       'fusion_tb_category' (term names: header,
     *                       page_title_bar, content, footer).
     *
     * A condition is {type, mode: include|exclude, [type]: value}. Reads go
     * through Fusion_Template_Builder; writes use update_layout_content()
     * / update_layout_title() so Fusion caches reset.
     * ================================================================= */

    public const TB_LAYOUT_CPT   = 'fusion_tb_layout';
    public const TB_SECTION_CPT  = 'fusion_tb_section';
    public const TB_CATEGORY_TAX = 'fusion_tb_category';
    public const TB_DEFAULT_OPTION = 'fusion_tb_layout_default';

    /** The section types Avada's Theme Builder supports. */
    public const TB_SECTION_TYPES = ['header', 'page_title_bar', 'content', 'footer'];

    /**
     * Get the Fusion_Template_Builder instance, defensively.
     *
     * @return object|null
     * @throws \RuntimeException
     */
    public function templateBuilder(): ?object
    {
        $this->requireAvada();

        if (function_exists('Fusion_Template_Builder')) {
            $i = \Fusion_Template_Builder();
            if (is_object($i)) {
                return $i;
            }
        }
        if (class_exists('Fusion_Template_Builder')
            && method_exists('Fusion_Template_Builder', 'get_instance')) {
            $i = \Fusion_Template_Builder::get_instance();
            if (is_object($i)) {
                return $i;
            }
        }
        return null;
    }

    /**
     * Whether the Theme Builder is available (Avada Builder providing the
     * fusion_tb_* post types).
     */
    public function themeBuilderAvailable(): bool
    {
        if (!$this->isAvadaActive()) {
            return false;
        }
        return post_type_exists(self::TB_LAYOUT_CPT)
            && post_type_exists(self::TB_SECTION_CPT);
    }

    /**
     * Decode a Theme Builder layout's JSON post_content safely.
     *
     * @return array<string,mixed>
     */
    public function decodeLayoutContent(string $postContent): array
    {
        if ($postContent === '') {
            return [];
        }
        // Mirror Fusion's own unslash handling.
        $decoded = json_decode(wp_unslash($postContent), true);
        if (!is_array($decoded)) {
            // Fusion sometimes stores with escaped single quotes.
            $decoded = json_decode(str_replace("\\'", "'", wp_unslash($postContent)), true);
        }
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * List Theme Builder Layouts (fusion_tb_layout), including the special
     * 'global' layout backed by the fusion_tb_layout_default option.
     *
     * @return array<int, array<string,mixed>>
     * @throws \RuntimeException
     */
    public function listThemeBuilderLayouts(): array
    {
        $this->requireAvada();
        if (!post_type_exists(self::TB_LAYOUT_CPT)) {
            throw new \RuntimeException(
                'The Avada Theme Builder post type (fusion_tb_layout) is not registered. Avada Builder may be inactive.'
            );
        }

        $out = [];

        // The implicit global layout.
        $globalRaw = get_option(self::TB_DEFAULT_OPTION, '');
        $globalData = is_string($globalRaw) ? $this->decodeLayoutContent($globalRaw) : [];
        $out[] = [
            'id'         => 'global',
            'title'      => 'Global Layout',
            'is_global'  => true,
            'status'     => 'active',
            'conditions' => isset($globalData['conditions']) && is_array($globalData['conditions'])
                ? $globalData['conditions'] : [],
        ];

        $query = new \WP_Query([
            'post_type'      => self::TB_LAYOUT_CPT,
            'post_status'    => 'any',
            'posts_per_page' => 100,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
        ]);

        foreach ($query->posts as $post) {
            $data = $this->decodeLayoutContent((string) $post->post_content);
            $out[] = [
                'id'         => (int) $post->ID,
                'title'      => $post->post_title,
                'is_global'  => false,
                'status'     => $post->post_status,
                'modified'   => $post->post_modified_gmt,
                'conditions' => isset($data['conditions']) && is_array($data['conditions'])
                    ? $data['conditions'] : [],
            ];
        }
        return $out;
    }

    /**
     * Get one Theme Builder Layout in full (its decoded JSON data).
     *
     * @param int|string $id Numeric post ID, or 'global'.
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getThemeBuilderLayout($id): array
    {
        $this->requireAvada();

        if ($id === 'global' || $id === 0 || $id === '0') {
            $raw = get_option(self::TB_DEFAULT_OPTION, '');
            return [
                'id'        => 'global',
                'title'     => 'Global Layout',
                'is_global' => true,
                'data'      => is_string($raw) ? $this->decodeLayoutContent($raw) : [],
            ];
        }

        $post = get_post((int) $id);
        if (!$post || $post->post_type !== self::TB_LAYOUT_CPT) {
            throw new \RuntimeException(
                "No Theme Builder layout found with ID {$id} (expected a fusion_tb_layout post or 'global')."
            );
        }

        return [
            'id'        => (int) $post->ID,
            'title'     => $post->post_title,
            'is_global' => false,
            'status'    => $post->post_status,
            'modified'  => $post->post_modified_gmt,
            'data'      => $this->decodeLayoutContent((string) $post->post_content),
        ];
    }

    /**
     * List Theme Builder Sections (fusion_tb_section), grouped by their
     * section type (header / page_title_bar / content / footer) via the
     * fusion_tb_category taxonomy.
     *
     * @return array<string, array<int, array<string,mixed>>>
     * @throws \RuntimeException
     */
    public function listThemeBuilderSections(): array
    {
        $this->requireAvada();
        if (!post_type_exists(self::TB_SECTION_CPT)) {
            throw new \RuntimeException(
                'The Avada Theme Builder post type (fusion_tb_section) is not registered. Avada Builder may be inactive.'
            );
        }

        $grouped = [];
        foreach (self::TB_SECTION_TYPES as $type) {
            $grouped[$type] = [];
        }
        $grouped['uncategorized'] = [];

        $query = new \WP_Query([
            'post_type'      => self::TB_SECTION_CPT,
            'post_status'    => 'any',
            'posts_per_page' => 200,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ]);

        foreach ($query->posts as $post) {
            $terms = wp_get_object_terms($post->ID, self::TB_CATEGORY_TAX, ['fields' => 'names']);
            $type = (is_array($terms) && !empty($terms)) ? (string) $terms[0] : 'uncategorized';
            if (!isset($grouped[$type])) {
                $grouped[$type] = [];
            }
            $grouped[$type][] = [
                'id'       => (int) $post->ID,
                'title'    => $post->post_title,
                'status'   => $post->post_status,
                'slug'     => $post->post_name,
                'modified' => $post->post_modified_gmt,
                'type'     => $type,
            ];
        }
        return $grouped;
    }

    /**
     * Get one Theme Builder Section in full (its Fusion shortcode content).
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getThemeBuilderSection(int $postId): array
    {
        $this->requireAvada();
        $post = get_post($postId);
        if (!$post || $post->post_type !== self::TB_SECTION_CPT) {
            throw new \RuntimeException(
                "No Theme Builder section found with ID {$postId} (expected a fusion_tb_section post)."
            );
        }

        $terms = wp_get_object_terms($postId, self::TB_CATEGORY_TAX, ['fields' => 'names']);

        return [
            'id'       => (int) $post->ID,
            'title'    => $post->post_title,
            'status'   => $post->post_status,
            'slug'     => $post->post_name,
            'modified' => $post->post_modified_gmt,
            'type'     => (is_array($terms) && !empty($terms)) ? (string) $terms[0] : 'uncategorized',
            'content'  => $post->post_content,
        ];
    }

    /**
     * The Theme Builder section types Avada supports, with labels.
     * Read live from Fusion_Template_Builder when possible, else the
     * known defaults.
     *
     * @return array<string, string>
     */
    public function getThemeBuilderSectionTypes(): array
    {
        try {
            $tb = $this->templateBuilder();
            if ($tb && method_exists($tb, 'get_template_terms')) {
                $types = $tb->get_template_terms();
                if (is_array($types) && !empty($types)) {
                    $out = [];
                    foreach ($types as $key => $val) {
                        $out[(string) $key] = is_array($val) && isset($val['label'])
                            ? (string) $val['label']
                            : (string) $key;
                    }
                    return $out;
                }
            }
        } catch (\RuntimeException $e) {
            // fall through to defaults
        }
        return [
            'header'         => 'Header',
            'page_title_bar' => 'Page Title Bar',
            'content'        => 'Content',
            'footer'         => 'Footer',
        ];
    }

    /* ===================================================================
     * Prebuilt Websites / Importer  (read-only)
     *
     * Avada ships "Prebuilt Websites" (demo sites) importable via the
     * AWB_Prebuilt_Websites manager. This layer exposes READ access only:
     * listing available prebuilt sites, their tags, plugin requirements,
     * and what has already been imported. The actual import action is
     * intentionally NOT exposed here — a prebuilt import is a heavy,
     * destructive, site-wide content operation and does not belong behind
     * a generic MCP tool.
     * ================================================================= */

    /**
     * Get the AWB_Prebuilt_Websites instance, defensively.
     *
     * @return object|null
     * @throws \RuntimeException
     */
    public function prebuilt(): ?object
    {
        $this->requireAvada();

        // Avada only require()s class-awb-prebuilt-websites.php when in
        // wp-admin AND on its own ?page=avada-prebuilt-websites/avada-setup
        // screen (see Avada bootstrap.php). In an MCP/REST request none of
        // that is true, so the class is absent. Load it on demand from the
        // active Avada theme directory — the class itself has no admin-only
        // dependency; only Avada's *loading* of it is screen-gated.
        if (!class_exists('AWB_Prebuilt_Websites')
            && !function_exists('AWB_Prebuilt_Websites')) {
            $themeDir = get_template_directory();
            $file = $themeDir . '/includes/class-awb-prebuilt-websites.php';
            if (is_string($themeDir) && $themeDir !== '' && file_exists($file)) {
                // Avada_Importer_Data is a dependency of the class; load it
                // first if it is not already present.
                if (!class_exists('Avada_Importer_Data')) {
                    $impFile = $themeDir . '/includes/importer/class-avada-importer-data.php';
                    if (file_exists($impFile)) {
                        require_once $impFile;
                    }
                }
                // get_plugins_info()/are_avada_plugins_active() depend on
                // Avada's TGM plugin-activation class, which Avada also only
                // loads in admin. Load it on demand too so the plugins-info
                // tool returns real data in the MCP context.
                if (!class_exists('TGM_Plugin_Activation')) {
                    foreach ([
                        $themeDir . '/includes/class-avada-tgm-plugin-activation.php',
                        $themeDir . '/includes/avada-tgm.php',
                    ] as $tgmFile) {
                        if (file_exists($tgmFile)) {
                            require_once $tgmFile;
                        }
                    }
                }
                require_once $file;
            }
        }

        if (function_exists('AWB_Prebuilt_Websites')) {
            $i = \AWB_Prebuilt_Websites();
            if (is_object($i)) {
                return $i;
            }
        }
        if (class_exists('AWB_Prebuilt_Websites')
            && method_exists('AWB_Prebuilt_Websites', 'get_instance')) {
            $i = \AWB_Prebuilt_Websites::get_instance();
            if (is_object($i)) {
                return $i;
            }
        }
        return null;
    }

    /**
     * Whether the Prebuilt Websites subsystem is available.
     */
    public function prebuiltAvailable(): bool
    {
        if (!$this->isAvadaActive()) {
            return false;
        }
        if (function_exists('AWB_Prebuilt_Websites')
            || class_exists('AWB_Prebuilt_Websites')) {
            return true;
        }
        // Not yet loaded (Avada only loads it on its own admin screens),
        // but available if the class file ships with the active theme.
        $file = get_template_directory() . '/includes/class-awb-prebuilt-websites.php';
        return is_string($file) && file_exists($file);
    }

    /**
     * List available prebuilt websites. Returns a normalized summary per
     * site (the raw structure is large; we surface the useful identifying
     * fields and keep the rest under 'meta').
     *
     * @return array<int, array<string,mixed>>
     * @throws \RuntimeException
     */
    public function listPrebuiltWebsites(): array
    {
        $this->requireAvada();
        $pb = $this->prebuilt();
        if (!$pb || !method_exists($pb, 'get_websites')) {
            throw new \RuntimeException(
                'The Avada Prebuilt Websites API is unavailable. Avada Core/Builder may be inactive, or the Avada version differs.'
            );
        }

        $sites = $pb->get_websites();
        if (!is_array($sites)) {
            return [];
        }

        $out = [];
        foreach ($sites as $key => $data) {
            if (!is_array($data)) {
                continue;
            }
            $entry = [
                'key'  => (string) $key,
                'name' => isset($data['name']) ? (string) $data['name'] : (string) $key,
            ];
            foreach (['tags', 'category', 'thumbnail', 'preview_url', 'version'] as $f) {
                if (isset($data[$f])) {
                    $entry[$f] = $data[$f];
                }
            }
            if (method_exists($pb, 'get_required_plugins')) {
                $req = $pb->get_required_plugins($key);
                $entry['required_plugins'] = is_array($req) ? array_values($req) : [];
            }
            $out[] = $entry;
        }
        return $out;
    }

    /**
     * Prebuilt website tags (the filter categories).
     *
     * @return array<int|string,mixed>
     * @throws \RuntimeException
     */
    public function getPrebuiltTags(): array
    {
        $this->requireAvada();
        $pb = $this->prebuilt();
        if (!$pb || !method_exists($pb, 'get_tags')) {
            throw new \RuntimeException('Avada Prebuilt tags API is unavailable.');
        }
        $tags = $pb->get_tags();
        return is_array($tags) ? $tags : [];
    }

    /**
     * Which prebuilt websites have already been imported on this site.
     *
     * @return array<int|string,mixed>
     * @throws \RuntimeException
     */
    public function getImportedWebsites(): array
    {
        $this->requireAvada();
        $pb = $this->prebuilt();
        if (!$pb || !method_exists($pb, 'get_imported_websites')) {
            throw new \RuntimeException('Avada imported-websites API is unavailable.');
        }
        $imported = $pb->get_imported_websites();
        return is_array($imported) ? $imported : [];
    }

    /**
     * Plugin dependency info as Avada sees it (installed/active flags for
     * the recommended/required plugins), plus the Avada-core check.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getPrebuiltPluginsInfo(): array
    {
        $this->requireAvada();
        $pb = $this->prebuilt();
        if (!$pb || !method_exists($pb, 'get_plugins_info')) {
            throw new \RuntimeException('Avada prebuilt plugins-info API is unavailable.');
        }

        $info = $pb->get_plugins_info();
        $avadaActive = method_exists($pb, 'are_avada_plugins_active')
            ? (bool) $pb->are_avada_plugins_active()
            : null;

        return [
            'avada_plugins_active' => $avadaActive,
            'plugins'              => is_array($info) ? $info : [],
        ];
    }

    /* ===================================================================
     * Performance & Maintenance
     *
     * Read: a system/status snapshot (PHP, server, WP, Avada versions and
     * limits) plus the Avada performance-related option values.
     * Operations: cache reset and dynamic-CSS regeneration. Both are
     * SAFE and REVERSIBLE — clearing a cache only forces regeneration on
     * the next request; it cannot lose content or settings. They are the
     * standard "fix display glitches after a change" actions.
     * ================================================================= */

    /** The named cache buckets Avada's Fusion_Cache::reset_all_caches accepts. */
    public const CACHE_BUCKETS = [
        'compiled_assets', 'gfonts', 'fa_font', 'demo_data',
        'po_export', 'transients', 'patcher_messages', 'other_caches',
    ];

    /**
     * A read-only system status snapshot. Uses only standard PHP/WP APIs
     * plus Avada/Fusion version constants — no Avada internals required.
     *
     * @return array<string,mixed>
     */
    public function getSystemStatus(): array
    {
        $this->requireAvada();

        global $wp_version;

        $php = defined('PHP_VERSION') ? PHP_VERSION
            : (function_exists('phpversion') ? phpversion() : null);

        $status = [
            'php' => [
                'version'             => $php,
                'memory_limit'        => function_exists('ini_get') ? ini_get('memory_limit') : null,
                'max_execution_time'  => function_exists('ini_get') ? ini_get('max_execution_time') : null,
                'max_input_vars'      => function_exists('ini_get') ? ini_get('max_input_vars') : null,
                'post_max_size'       => function_exists('ini_get') ? ini_get('post_max_size') : null,
                'upload_max_filesize' => function_exists('ini_get') ? ini_get('upload_max_filesize') : null,
            ],
            'wordpress' => [
                'version'      => isset($wp_version) ? $wp_version : (function_exists('get_bloginfo') ? get_bloginfo('version') : null),
                'multisite'    => function_exists('is_multisite') ? is_multisite() : null,
                'debug'        => defined('WP_DEBUG') ? (bool) WP_DEBUG : null,
                'memory_limit' => defined('WP_MEMORY_LIMIT') ? WP_MEMORY_LIMIT : null,
            ],
            'avada' => [
                'theme_version'   => $this->getAvadaVersion(),
                'builder_version' => defined('FUSION_BUILDER_VERSION') ? constant('FUSION_BUILDER_VERSION') : null,
                'library_version' => defined('FUSION_LIBRARY_VERSION') ? constant('FUSION_LIBRARY_VERSION') : null,
            ],
            'server' => [
                'software' => isset($_SERVER['SERVER_SOFTWARE']) ? sanitize_text_field((string) $_SERVER['SERVER_SOFTWARE']) : null,
            ],
        ];

        return $status;
    }

    /**
     * Surface the Avada performance-related Theme Options coherently
     * (these are normal Theme Options; this just groups the meaningful
     * performance keys for convenience).
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getPerformanceSettings(): array
    {
        $this->requireAvada();

        $keys = [
            'css_cache_method', 'js_compiler', 'cache_server_ip',
            'fusion_builder_set_dimensions', 'lazy_load', 'critical_css',
            'gfonts_load_method', 'block_external_scripts', 'emoji_scripts',
            'jquery_migrate', 'fusion_font_awesome_subsets',
            'status_lightbox', 'preview_search_results',
        ];

        $out = [];
        foreach ($keys as $k) {
            try {
                $v = $this->getOption($k);
                if ($v !== null) {
                    $out[$k] = $v;
                }
            } catch (\RuntimeException $e) {
                // skip keys not present in this Avada version
            }
        }
        return $out;
    }

    /**
     * Reset Avada/Fusion caches. Mirrors avada_reset_all_caches():
     * delegates to Fusion_Cache::reset_all_caches($buckets). Safe and
     * reversible — only forces regeneration.
     *
     * @param array<string,bool> $buckets Which cache buckets to clear.
     *                                     Empty = all (Avada's default).
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function resetCaches(array $buckets = []): array
    {
        $this->requireAvada();

        if (function_exists('avada_reset_all_caches')) {
            avada_reset_all_caches($buckets);
            return ['method' => 'avada_reset_all_caches', 'buckets' => $buckets ?: 'all'];
        }

        if (class_exists('Fusion_Cache')) {
            $fc = new \Fusion_Cache();
            if (method_exists($fc, 'reset_all_caches')) {
                $fc->reset_all_caches($buckets);
                return ['method' => 'Fusion_Cache::reset_all_caches', 'buckets' => $buckets ?: 'all'];
            }
        }

        throw new \RuntimeException(
            'No Avada cache-reset API is available (avada_reset_all_caches / Fusion_Cache). The Avada version may differ.'
        );
    }

    /**
     * Regenerate Avada's dynamic CSS. Mirrors the Avada
     * Fusion_Dynamic_CSS::reset_all_caches() path. Safe and reversible —
     * CSS is rebuilt on the next page load.
     *
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function regenerateDynamicCss(): array
    {
        $this->requireAvada();

        if (class_exists('Fusion_Dynamic_CSS')
            && method_exists('Fusion_Dynamic_CSS', 'get_instance')) {
            $css = \Fusion_Dynamic_CSS::get_instance();
            if (is_object($css) && method_exists($css, 'reset_all_caches')) {
                $css->reset_all_caches();
                return ['method' => 'Fusion_Dynamic_CSS::reset_all_caches'];
            }
        }

        // Fallback: a full cache reset also regenerates CSS.
        $this->resetCaches(['compiled_assets' => true]);
        return ['method' => 'fallback:resetCaches(compiled_assets)'];
    }

    /* ===================================================================
     * Theme Builder — Conditions WRITE path  (high-risk, heavily guarded)
     *
     * Display conditions decide WHERE a layout's header/footer/content/
     * page-title-bar templates apply. A bad write can make a live site's
     * header or footer vanish site-wide. Every mutation here is:
     *   - read-modify-write (never blind-set the whole blob)
     *   - snapshotted first (recoverable via restore)
     *   - routed through Avada's own Fusion_Template_Builder::
     *     update_layout_content() so Avada re-encodes + resets caches
     *     exactly as its own UI does.
     * ================================================================= */

    /** Option/meta key prefix for layout snapshots taken before a write. */
    public const TB_SNAPSHOT_OPTION = 'insationai_avmcp_tb_snapshot';

    /** Valid condition modes. */
    public const TB_CONDITION_MODES = ['include', 'exclude'];

    /**
     * Get the Fusion_Template_Builder class name if the static API is
     * present (the write API is static).
     *
     * @throws \RuntimeException
     */
    private function tbClass(): string
    {
        $this->requireAvada();
        if (class_exists('Fusion_Template_Builder')
            && method_exists('Fusion_Template_Builder', 'update_layout_content')) {
            return 'Fusion_Template_Builder';
        }
        throw new \RuntimeException(
            'Fusion_Template_Builder::update_layout_content() is unavailable. Avada Builder may be inactive or the version differs.'
        );
    }

    /**
     * Read the *raw* current layout data array (conditions + template_terms)
     * for a layout id ('global' or numeric), exactly as stored.
     *
     * @param int|string $id
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function getLayoutData($id): array
    {
        $this->requireAvada();

        if ($id === 'global' || $id === 0 || $id === '0') {
            $raw = get_option(self::TB_DEFAULT_OPTION, '');
            $data = is_string($raw) ? $this->decodeLayoutContent($raw) : [];
        } else {
            $post = get_post((int) $id);
            if (!$post || $post->post_type !== self::TB_LAYOUT_CPT) {
                throw new \RuntimeException(
                    "No Theme Builder layout found with ID {$id}."
                );
            }
            $data = $this->decodeLayoutContent((string) $post->post_content);
        }

        if (!isset($data['conditions']) || !is_array($data['conditions'])) {
            $data['conditions'] = [];
        }
        if (!isset($data['template_terms']) || !is_array($data['template_terms'])) {
            $data['template_terms'] = [];
        }
        return $data;
    }

    /**
     * Snapshot a layout's current state before mutating it. Stored as an
     * option keyed by layout id. Returns the snapshot payload.
     *
     * @param int|string $id
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function snapshotLayout($id): array
    {
        $data = $this->getLayoutData($id);
        $snapshot = [
            'layout_id'  => (string) $id,
            'taken_at'   => gmdate('c'),
            'data'       => $data,
        ];
        update_option(self::TB_SNAPSHOT_OPTION . '_' . (string) $id, $snapshot, false);
        return $snapshot;
    }

    /**
     * Get the last snapshot for a layout, if any.
     *
     * @param int|string $id
     * @return array<string,mixed>|null
     */
    public function getLayoutSnapshot($id): ?array
    {
        $snap = get_option(self::TB_SNAPSHOT_OPTION . '_' . (string) $id, null);
        return is_array($snap) ? $snap : null;
    }

    /**
     * Write a layout's data array back through Avada's own static API
     * (which re-encodes, applies defaults, and resets caches). Always
     * snapshots first.
     *
     * @param int|string $id
     * @param array<string,mixed> $data Full layout data (conditions + template_terms).
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function writeLayoutData($id, array $data): array
    {
        $cls = $this->tbClass();
        // Snapshot BEFORE writing.
        $this->snapshotLayout($id);

        // Normalize id form the way Avada expects ('global' or int).
        $writeId = ($id === 'global' || $id === '0' || $id === 0) ? 'global' : (int) $id;

        // Only pass the keys Avada cares about.
        $payload = [
            'conditions'     => isset($data['conditions']) && is_array($data['conditions'])
                ? array_values($data['conditions']) : [],
            'template_terms' => isset($data['template_terms']) && is_array($data['template_terms'])
                ? $data['template_terms'] : [],
        ];

        $result = $cls::update_layout_content($writeId, $payload);
        return is_array($result) ? $result : $payload;
    }

    /**
     * Restore a layout from its last snapshot.
     *
     * @param int|string $id
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function restoreLayoutSnapshot($id): array
    {
        $snap = $this->getLayoutSnapshot($id);
        if (!$snap || !isset($snap['data']) || !is_array($snap['data'])) {
            throw new \RuntimeException(
                "No snapshot exists for layout '{$id}'. Nothing to restore."
            );
        }
        $cls = $this->tbClass();
        $writeId = ($id === 'global' || $id === '0' || $id === 0) ? 'global' : (int) $id;

        $payload = [
            'conditions'     => isset($snap['data']['conditions']) && is_array($snap['data']['conditions'])
                ? array_values($snap['data']['conditions']) : [],
            'template_terms' => isset($snap['data']['template_terms']) && is_array($snap['data']['template_terms'])
                ? $snap['data']['template_terms'] : [],
        ];
        $result = $cls::update_layout_content($writeId, $payload);
        return [
            'restored_from' => $snap['taken_at'] ?? null,
            'data'          => is_array($result) ? $result : $payload,
        ];
    }

    /**
     * Validate and normalize a single condition. A condition is
     * {type, mode, [type]: value}.
     *
     * @param array<string,mixed> $condition
     * @return array<string,mixed>
     * @throws \RuntimeException
     */
    public function normalizeCondition(array $condition): array
    {
        $type = isset($condition['type']) ? (string) $condition['type'] : '';
        if ($type === '') {
            throw new \RuntimeException("Condition is missing required 'type'.");
        }
        $mode = isset($condition['mode']) ? (string) $condition['mode'] : 'include';
        if (!in_array($mode, self::TB_CONDITION_MODES, true)) {
            throw new \RuntimeException(
                "Condition 'mode' must be 'include' or 'exclude' (got '{$mode}')."
            );
        }
        if (!array_key_exists($type, $condition)) {
            throw new \RuntimeException(
                "Condition of type '{$type}' must include a '{$type}' value (e.g. {\"type\":\"post_type\",\"mode\":\"include\",\"post_type\":\"page\"})."
            );
        }
        return [
            'type' => $type,
            'mode' => $mode,
            $type  => $condition[$type],
        ];
    }
}
