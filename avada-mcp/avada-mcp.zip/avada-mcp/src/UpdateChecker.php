<?php

namespace AvadaMCP;

/**
 * Custom Plugin Update Checker
 *
 * Checks for plugin updates from DigitalOcean Spaces bucket
 * and integrates with WordPress plugin update system.
 *
 * @package AvadaMCP
 */
class UpdateChecker
{
    /**
     * Plugin file path (relative to plugins directory)
     *
     * @var string
     */
    private string $plugin_file;

    /**
     * Plugin slug
     *
     * @var string
     */
    private string $plugin_slug;

    /**
     * Update metadata URL
     *
     * @var string
     */
    private string $metadata_url;

    /**
     * Cache key for update transient
     *
     * @var string
     */
    private string $cache_key;

    /**
     * Cache duration in seconds (12 hours)
     *
     * @var int
     */
    private int $cache_duration = 21600;

    /**
     * Constructor
     *
     * @param string $plugin_file Plugin file path relative to plugins directory
     * @param string $metadata_url URL to update metadata JSON file
     */
    public function __construct(string $plugin_file, string $metadata_url)
    {
        $this->plugin_file = $plugin_file;
        $this->plugin_slug = dirname($plugin_file);
        $this->metadata_url = $metadata_url;
        $this->cache_key = 'insationai_avmcp_update_' . md5($this->plugin_file);

        // Hook into WordPress update system
        $this->init();
    }

    /**
     * Initialize hooks
     */
    private function init(): void
    {
        // Check for updates
        add_filter('pre_set_site_transient_update_plugins', [$this, 'checkForUpdate']);

        // Provide plugin information for "View Details" link
        add_filter('plugins_api', [$this, 'pluginInformation'], 20, 3);

        // Clear cache after plugin update
        add_action('upgrader_process_complete', [$this, 'clearUpdateCache'], 10, 2);

        // Add settings link to check for updates manually
        add_filter('plugin_action_links_' . $this->plugin_file, [$this, 'addActionLinks']);
    }

    /**
     * Check for plugin updates
     *
     * @param mixed $transient Update transient
     * @return mixed Modified transient
     */
    public function checkForUpdate($transient)
    {
        // Check if transient exists
        if (empty($transient->checked)) {
            return $transient;
        }

        // Get remote version info
        $remote = $this->getRemoteInformation();

        if (!$remote || !isset($remote->version)) {
            return $transient;
        }

        // Get current plugin version
        $plugin_data = $this->getPluginData();
        $current_version = $plugin_data['Version'] ?? '0.0.0';

        // Compare versions
        if (version_compare($remote->version, $current_version, '>')) {
            $update = (object) [
                'slug' => $this->plugin_slug,
                'plugin' => $this->plugin_file,
                'new_version' => $remote->version,
                'url' => $remote->homepage ?? '',
                'package' => $remote->download_url ?? '',
                'tested' => $remote->tested ?? '',
                'requires_php' => $remote->requires_php ?? '',
                'requires' => $remote->requires ?? '',
            ];

            $transient->response[$this->plugin_file] = $update;
        } else {
            // No update needed - add to no_update
            $no_update = (object) [
                'slug' => $this->plugin_slug,
                'plugin' => $this->plugin_file,
                'new_version' => $current_version,
                'url' => $remote->homepage ?? '',
                'package' => $remote->download_url ?? '',
            ];

            $transient->no_update[$this->plugin_file] = $no_update;
        }

        return $transient;
    }

    /**
     * Provide plugin information for WordPress plugin info popup
     *
     * @param false|object|array $result The result object or array
     * @param string $action The type of information being requested
     * @param object $args Plugin API arguments
     * @return false|object Modified result
     */
    public function pluginInformation($result, string $action, object $args)
    {
        // Check if this is our plugin
        if ($action !== 'plugin_information') {
            return $result;
        }

        if ($args->slug !== $this->plugin_slug) {
            return $result;
        }

        // Get remote version info
        $remote = $this->getRemoteInformation();

        if (!$remote) {
            return $result;
        }

        // Build plugin info object
        $info = (object) [
            'name' => $remote->name ?? 'AvadaMCP',
            'slug' => $this->plugin_slug,
            'version' => $remote->version ?? '1.0.0',
            'author' => $remote->author ?? 'AvadaMCP Team',
            'author_profile' => $remote->author_profile ?? '',
            'requires' => $remote->requires ?? '6.0',
            'tested' => $remote->tested ?? '6.7',
            'requires_php' => $remote->requires_php ?? '8.0',
            'download_link' => $remote->download_url ?? '',
            'last_updated' => $remote->last_updated ?? date('Y-m-d'),
            'sections' => $remote->sections ?? [
                'description' => 'AvadaMCP - WordPress MCP Server Plugin',
            ],
            'banners' => $remote->banners ?? [],
        ];

        return $info;
    }

    /**
     * Get remote plugin information from the WC Key Manager Software API.
     *
     * WCKM's get_version requires the license key + instance to return a
     * tokenized, license-gated download package. Its response shape differs
     * from a generic metadata JSON, so we normalize it to the fields the rest
     * of this class already consumes (->version, ->download_url, ->homepage,
     * ->sections, etc.).
     *
     * @return object|false Normalized remote info, or false on failure.
     */
    private function getRemoteInformation()
    {
        // Check cache first
        $cached = get_transient($this->cache_key);
        if ($cached !== false) {
            return $cached;
        }

        // License is required to query WCKM (the init gate already enforces
        // this, but double-check here so a stale instance can't leak a call).
        if (! class_exists('InsationAI_AVMCP_License_Service')
            || ! \InsationAI_AVMCP_License_Service::is_licensed()) {
            return false;
        }
        $state    = \InsationAI_AVMCP_License_Service::get_state();
        $key      = isset($state['key']) ? $state['key'] : '';
        $instance = \InsationAI_AVMCP_License_Service::get_instance();
        if ($key === '') {
            return false;
        }

        // WCKM get_version with key + instance (deliberately no product_id —
        // WCKM binds keys to the purchased variation and rejects a mismatched
        // product_id; same constraint the license service handles).
        $url = add_query_arg(
            array(
                'wckm-api' => 'get_version',
                'key'      => $key,
                'instance' => $instance,
            ),
            'https://insation.ai/'
        );

        $response = wp_remote_get($url, [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            error_log('[AvadaMCP Update Checker] Error fetching update info: ' . $response->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            error_log('[AvadaMCP Update Checker] HTTP error ' . $code . ' when fetching update info');
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!is_array($data) || empty($data['success']) || empty($data['new_version'])) {
            // Non-JSON, API disabled, or no software configured for the product.
            return false;
        }

        // WCKM serializes 'sections' (description/changelog) — unserialize if so.
        $sections = isset($data['sections']) ? maybe_unserialize($data['sections']) : array();
        if (!is_array($sections)) {
            $sections = array();
        }

        // Normalize WCKM's shape -> the fields checkForUpdate()/pluginInformation() expect.
        $normalized = (object) [
            'version'        => (string) $data['new_version'],
            'download_url'   => isset($data['package']) ? (string) $data['package'] : '',
            'homepage'       => isset($data['homepage']) ? (string) $data['homepage'] : '',
            'name'           => isset($data['name']) ? (string) $data['name'] : 'AvadaMCP',
            'requires'       => isset($data['min_wp']) ? (string) $data['min_wp'] : '',
            'requires_php'   => isset($data['min_php']) ? (string) $data['min_php'] : '',
            'tested'         => '',
            'last_updated'   => isset($data['last_updated']) ? (string) $data['last_updated'] : '',
            'author'         => 'InsationAI',
            'sections'       => $sections,
        ];

        set_transient($this->cache_key, $normalized, $this->cache_duration);

        return $normalized;
    }

    /**
     * Get current plugin data
     *
     * @return array Plugin data
     */
    private function getPluginData(): array
    {
        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugin_path = WP_PLUGIN_DIR . '/' . $this->plugin_file;
        return get_plugin_data($plugin_path, false, false);
    }

    /**
     * Clear update cache after plugin update
     *
     * @param \WP_Upgrader $upgrader WP_Upgrader instance
     * @param array $options Array of bulk item update data
     */
    public function clearUpdateCache($upgrader, array $options): void
    {
        if ($options['action'] === 'update' && $options['type'] === 'plugin') {
            delete_transient($this->cache_key);
        }
    }

    /**
     * Add "Check for Updates" link to plugin actions
     *
     * @param array $links Plugin action links
     * @return array Modified links
     */
    public function addActionLinks(array $links): array
    {
        $check_update_link = sprintf(
            '<a href="%s">%s</a>',
            wp_nonce_url(
                add_query_arg([
                    'insationai_avmcp_check_update' => '1',
                ], admin_url('plugins.php')),
                'insationai_avmcp_check_update'
            ),
            __('Check for Updates', 'avada-mcp')
        );

        array_unshift($links, $check_update_link);

        return $links;
    }

    /**
     * Handle manual update check request
     */
    public static function handleManualUpdateCheck(): void
    {
        if (!isset($_GET['insationai_avmcp_check_update'])) {
            return;
        }

        if (!current_user_can('update_plugins')) {
            return;
        }

        check_admin_referer('insationai_avmcp_check_update');

        // Force clear the cache
        $cache_key = 'insationai_avmcp_update_' . md5('avada-mcp/avada-mcp.php');
        delete_transient($cache_key);

        // Force WordPress to check for updates
        delete_site_transient('update_plugins');
        wp_update_plugins();

        // Redirect back to plugins page with message
        wp_safe_redirect(add_query_arg([
            'insationai_avmcp_update_checked' => '1',
        ], admin_url('plugins.php')));
        exit;
    }

    /**
     * Display admin notice after manual update check
     */
    public static function displayUpdateCheckNotice(): void
    {
        if (!isset($_GET['insationai_avmcp_update_checked'])) {
            return;
        }

        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('Plugin update check completed. If an update is available, it will appear below.', 'avada-mcp'); ?></p>
        </div>
        <?php
    }
}
