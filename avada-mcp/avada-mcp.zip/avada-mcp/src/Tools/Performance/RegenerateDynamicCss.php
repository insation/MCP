<?php
/**
 * Regenerate Dynamic CSS Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Performance;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class RegenerateDynamicCss extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'regenerate_dynamic_css';
    }

    public function getDescription(): string
    {
        return 'Regenerate Avada\'s dynamic CSS (the compiled stylesheet Avada builds from Theme Options and global styles). Safe and reversible — the CSS is simply rebuilt on the next page load. Use this when style changes (Theme Options, global colors/typography) are not showing on the front end.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('regenerating Avada dynamic CSS');

        try {
            $result = $this->avada->regenerateDynamicCss();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($result, 'Avada dynamic CSS will be regenerated on the next page load.');
    }
}
