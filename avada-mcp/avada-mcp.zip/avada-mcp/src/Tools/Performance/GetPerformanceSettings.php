<?php
/**
 * Get Performance Settings Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Performance;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetPerformanceSettings extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_performance_settings';
    }

    public function getDescription(): string
    {
        return 'Get the Avada performance-related Theme Option values grouped together (CSS/JS compilation method, lazy load, critical CSS, Google Fonts load method, script handling, etc.). These are normal Theme Options — to change one, use set_theme_option with the corresponding key.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $settings = $this->avada->getPerformanceSettings();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'count'    => count($settings),
            'settings' => $settings,
            'note'     => 'These are Theme Options; modify via set_theme_option using the key name.',
        ]);
    }
}
