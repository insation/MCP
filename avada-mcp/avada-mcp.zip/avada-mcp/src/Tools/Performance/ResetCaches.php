<?php
/**
 * Reset Caches Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.5
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Performance;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ResetCaches extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'reset_caches';
    }

    public function getDescription(): string
    {
        return 'Reset Avada/Fusion caches (compiled CSS/JS assets, Google Fonts, Font Awesome, transients, etc.). This mirrors Avada\'s own "Reset all caches" maintenance action: it is safe and reversible — it only forces regeneration on the next request and cannot lose content or settings. By default clears all cache buckets; pass specific buckets to narrow it. The common fix for display glitches after changing options or global styles.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'buckets' => [
                'optional',
                'string',
                'description' => 'Comma-separated cache buckets to clear. Valid: compiled_assets, gfonts, fa_font, demo_data, po_export, transients, patcher_messages, other_caches. Omit to clear all.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('resetting Avada caches');

        $buckets = [];
        if (isset($parameters['buckets']) && $parameters['buckets'] !== '') {
            $requested = array_map('trim', explode(',', (string) $parameters['buckets']));
            $valid = AvadaService::CACHE_BUCKETS;
            $invalid = array_diff($requested, $valid);
            if (!empty($invalid)) {
                return $this->error(
                    'Unknown cache bucket(s): ' . implode(', ', $invalid),
                    ['valid_buckets' => $valid]
                );
            }
            foreach ($requested as $b) {
                $buckets[$b] = true;
            }
        }

        try {
            $result = $this->avada->resetCaches($buckets);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($result, 'Avada caches reset. They will regenerate on the next request.');
    }
}
