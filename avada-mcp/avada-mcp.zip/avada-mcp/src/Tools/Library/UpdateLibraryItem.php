<?php
/**
 * Update Library Item Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Library;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class UpdateLibraryItem extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'update_library_item';
    }

    public function getDescription(): string
    {
        return 'Update an existing Avada Library item (fusion_element or fusion_template). Only the fields you supply are changed — title, the Fusion Builder content, the element type meta, and/or the assigned category. Returns the refreshed item.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                ['min' => 1],
                'description' => 'The post ID of the Library item to update.',
            ],
            'title' => [
                'optional',
                'string',
                'description' => 'New title. Omit to leave unchanged.',
            ],
            'content' => [
                'optional',
                'string',
                'description' => 'New Fusion Builder content (shortcode string). Omit to leave unchanged.',
            ],
            'element_type' => [
                'optional',
                'string',
                'description' => 'New element type meta (fusion_element only). Omit to leave unchanged.',
            ],
            'category' => [
                'optional',
                'string',
                'description' => 'Category term name/slug to (re)assign. Omit to leave unchanged.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('updating an Avada Library item');

        $id = (int) $parameters['id'];

        $title = array_key_exists('title', $parameters) && $parameters['title'] !== ''
            ? (string) $parameters['title'] : null;
        $content = array_key_exists('content', $parameters)
            ? (string) $parameters['content'] : null;
        $elementType = array_key_exists('element_type', $parameters) && $parameters['element_type'] !== ''
            ? (string) $parameters['element_type'] : null;
        $category = array_key_exists('category', $parameters) && $parameters['category'] !== ''
            ? (string) $parameters['category'] : null;

        if ($title === null && $content === null && $elementType === null && $category === null) {
            return $this->error('Nothing to update — supply at least one of: title, content, element_type, category.');
        }

        try {
            $item = $this->avada->updateLibraryItem($id, $title, $content, $elementType, $category);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($item, "Updated Library item #{$id}.");
    }
}
