<?php
/**
 * Get Library Item Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Library;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetLibraryItem extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_library_item';
    }

    public function getDescription(): string
    {
        return 'Get a single Avada Library item by ID — its title, status, element type, assigned categories, and the full Fusion Builder content (the shortcode string stored in post_content). Works for both fusion_element (Library Elements) and fusion_template (Saved Layouts).';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                ['min' => 1],
                'description' => 'The post ID of the Library item.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $id = (int) $parameters['id'];

        try {
            $item = $this->avada->getLibraryItem($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($item);
    }
}
