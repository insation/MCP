<?php
/**
 * Create Library Item Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Library;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class CreateLibraryItem extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'create_library_item';
    }

    public function getDescription(): string
    {
        return 'Create a new Avada Library item — a saved Library Element (fusion_element) or Layout (fusion_template). Mirrors Avada\'s own create_layout(): the content is the Fusion Builder shortcode string. For Library Elements you can set the element type (sections, columns, elements) and assign a category. Status follows the user\'s capability (publish vs pending), matching Avada behavior.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'post_type' => [
                'optional',
                'string',
                'description' => 'fusion_element (Library Element, default) or fusion_template (Saved Layout).',
            ],
            'name' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The title/name of the Library item.',
            ],
            'content' => [
                'required',
                'string',
                'description' => 'The Fusion Builder content — the shortcode string (e.g. [fusion_builder_container]...[/fusion_builder_container]). May be empty for a placeholder.',
            ],
            'element_type' => [
                'optional',
                'string',
                'description' => 'For fusion_element only: the element type — typically "sections", "columns", or "elements". Stored as _fusion_element_type.',
            ],
            'category' => [
                'optional',
                'string',
                'description' => 'Category term name/slug to assign (created if it does not exist, per WordPress term behavior).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('creating an Avada Library item');

        $postType = isset($parameters['post_type']) && $parameters['post_type'] !== ''
            ? (string) $parameters['post_type']
            : AvadaService::LIBRARY_ELEMENT_CPT;

        try {
            $this->avada->requireLibraryCpt($postType);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $name = (string) $parameters['name'];
        $content = (string) ($parameters['content'] ?? '');

        $meta = [];
        if ($postType === AvadaService::LIBRARY_ELEMENT_CPT
            && isset($parameters['element_type']) && $parameters['element_type'] !== '') {
            $meta[AvadaService::ELEMENT_TYPE_META] = (string) $parameters['element_type'];
        }

        $category = isset($parameters['category']) && $parameters['category'] !== ''
            ? (string) $parameters['category'] : null;

        try {
            $id = $this->avada->createLibraryItem($postType, $name, $content, $meta, $category);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $item = $this->avada->getLibraryItem($id);
        } catch (\RuntimeException $e) {
            $item = ['id' => $id];
        }

        return $this->success($item, "Created Library item #{$id}.");
    }
}
