<?php
/**
 * List Library Items Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Library;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ListLibraryItems extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'list_library_items';
    }

    public function getDescription(): string
    {
        return 'List Avada Library items — saved Library Elements (fusion_element) or saved Layouts (fusion_template) — optionally filtered by category. Returns id, title, status, the element type meta, and assigned categories. The Library is where Avada users save reusable design blocks for re-insertion.';
    }

    public function getSchema(): array
    {
        return [
            'post_type' => [
                'optional',
                'string',
                'description' => 'fusion_element (Library Elements, default) or fusion_template (Saved Layouts).',
            ],
            'category' => [
                'optional',
                'string',
                'description' => 'Filter by category — a term slug or numeric term ID from list_library_categories.',
            ],
            'page' => ['optional', 'int', ['min' => 1], 'description' => 'Page number (default 1).'],
            'per_page' => ['optional', 'int', ['min' => 1], ['max' => 100], 'description' => 'Per page 1-100 (default 25).'],
            'status' => ['optional', 'string', 'description' => 'Post status (publish, draft, pending, any). Default any.'],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $postType = isset($parameters['post_type']) && $parameters['post_type'] !== ''
            ? (string) $parameters['post_type']
            : AvadaService::LIBRARY_ELEMENT_CPT;

        try {
            $this->avada->requireLibraryCpt($postType);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (!post_type_exists($postType)) {
            return $this->error(
                "Post type '{$postType}' is not registered. Avada Builder may be inactive."
            );
        }

        $category = isset($parameters['category']) && $parameters['category'] !== ''
            ? (string) $parameters['category'] : null;
        $page = isset($parameters['page']) ? (int) $parameters['page'] : 1;
        $perPage = isset($parameters['per_page']) ? (int) $parameters['per_page'] : 25;
        $status = isset($parameters['status']) && $parameters['status'] !== ''
            ? (string) $parameters['status'] : 'any';

        try {
            $items = $this->avada->listLibraryItems($postType, $category, $perPage, $page, $status);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'post_type' => $postType,
            'category'  => $category,
            'page'      => $page,
            'per_page'  => $perPage,
            'returned'  => count($items),
            'items'     => $items,
        ]);
    }
}
