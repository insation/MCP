<?php
/**
 * List Library Categories Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.2
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Library;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ListLibraryCategories extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'list_library_categories';
    }

    public function getDescription(): string
    {
        return 'List the categories used to organize the Avada Library — the element_category terms for Library Elements (fusion_element) or template_category terms for Saved Layouts (fusion_template). Returns each term id, name, slug, item count, and parent. Use the slug or id to filter list_library_items.';
    }

    public function getSchema(): array
    {
        return [
            'post_type' => [
                'optional',
                'string',
                'description' => 'fusion_element (default) or fusion_template — selects which category taxonomy to list.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $postType = isset($parameters['post_type']) && $parameters['post_type'] !== ''
            ? (string) $parameters['post_type']
            : AvadaService::LIBRARY_ELEMENT_CPT;

        try {
            $categories = $this->avada->listLibraryCategories($postType);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'post_type'  => $postType,
            'taxonomy'   => $this->avada->libraryTaxonomyFor($postType),
            'count'      => count($categories),
            'categories' => $categories,
        ]);
    }
}
