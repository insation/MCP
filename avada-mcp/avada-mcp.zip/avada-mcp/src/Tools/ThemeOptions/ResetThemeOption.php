<?php
/**
 * Reset Theme Option Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeOptions;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ResetThemeOption extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'reset_theme_option';
    }

    public function getDescription(): string
    {
        return 'Reset a single Avada Theme Option back to its registered default value (the value Fusion_Settings reports as the default for that key). Useful for undoing a change without knowing the original value.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'key' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The Theme Option key to reset to its default.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('resetting an Avada Theme Option');

        $key = (string) $parameters['key'];

        $default = $this->avada->getDefault($key);
        if ($default === null) {
            return $this->error(
                "No registered default found for Theme Option '{$key}'. It may not be a valid option key, or this Avada version exposes no default for it."
            );
        }

        try {
            $previous = $this->avada->getOption($key);
            $ok = $this->avada->setOption($key, $default);
        } catch (\RuntimeException $e) {
            return $this->error('Failed to reset option: ' . $e->getMessage());
        }

        if (!$ok) {
            return $this->error("Could not reset Theme Option '{$key}'.");
        }

        return $this->success([
            'key'            => $key,
            'previous_value' => $previous,
            'default_value'  => $default,
        ], "Theme Option '{$key}' reset to its default.");
    }
}
