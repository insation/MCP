<?php
/**
 * Get Theme Options Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeOptions;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetThemeOptions extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_theme_options';
    }

    public function getDescription(): string
    {
        return 'Read Avada Theme Options. With no arguments, returns the full saved options array (the fusion_options store). Pass a key to read one option resolved through Fusion_Settings (which falls back to the registered default when the option is unset), optionally with a subset for grouped values like colors.';
    }

    public function getSchema(): array
    {
        return [
            'key' => [
                'optional',
                'string',
                'description' => 'A single Theme Option key to read, e.g. primary_color, site_width, header_layout. Omit to return all saved options.',
            ],
            'subset' => [
                'optional',
                'string',
                'description' => 'For grouped/array options, the sub-key to read (e.g. a specific value within a typography or dimension group).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        // Single key requested.
        if (isset($parameters['key']) && $parameters['key'] !== '') {
            $key = (string) $parameters['key'];
            $subset = isset($parameters['subset']) && $parameters['subset'] !== ''
                ? (string) $parameters['subset']
                : false;

            try {
                $value = $this->avada->getOption($key, $subset);
                $default = $this->avada->getDefault($key, $subset);
            } catch (\RuntimeException $e) {
                return $this->error($e->getMessage());
            }

            return $this->success([
                'key'           => $key,
                'subset'        => $subset === false ? null : $subset,
                'value'         => $value,
                'default'       => $default,
                'is_default'    => $value === $default,
            ]);
        }

        // Full dump.
        try {
            $all = $this->avada->getAllOptions();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'option_key'   => $this->avada->optionsKey(),
            'count'        => count($all),
            'options'      => $all,
        ]);
    }
}
