<?php
/**
 * Get Avada Info Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeOptions;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetAvadaInfo extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_avada_info';
    }

    public function getDescription(): string
    {
        return 'Get a summary of the Avada environment: whether the Avada theme is active, its version, the resolved Theme Options storage key, whether Avada Builder (Fusion Builder) and Avada Core are active, and counts of each Avada custom post type. A good first call to confirm the environment before using other AvadaMCP tools.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        $active = $this->avada->isAvadaActive();

        $result = [
            'avada_active'  => $active,
            'avada_version' => $this->avada->getAvadaVersion(),
        ];

        if (!$active) {
            $result['note'] = 'The Avada theme is not active. AvadaMCP tools will not function until it is.';
            return $this->success($result);
        }

        $result['options_key'] = $this->avada->optionsKey();

        // Companion plugins (branding-independent: check by plugin file).
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $result['avada_builder_active'] = is_plugin_active('fusion-builder/fusion-builder.php');
        $result['avada_core_active']    = is_plugin_active('fusion-core/fusion-core.php');

        // CPT counts.
        $cptCounts = [];
        foreach (AvadaService::AVADA_CPTS as $slug => $label) {
            if (!post_type_exists($slug)) {
                continue;
            }
            try {
                $counts = $this->avada->countCptPosts($slug);
                $cptCounts[$slug] = [
                    'label'  => $label,
                    'counts' => $this->avada->meaningfulStatusCounts($counts),
                ];
            } catch (\RuntimeException $e) {
                // skip unknown
            }
        }
        $result['custom_post_types'] = $cptCounts;

        return $this->success($result);
    }
}
