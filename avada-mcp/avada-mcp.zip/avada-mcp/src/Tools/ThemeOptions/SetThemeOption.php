<?php
/**
 * Set Theme Option Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeOptions;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class SetThemeOption extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'set_theme_option';
    }

    public function getDescription(): string
    {
        return 'Set a single Avada Theme Option. The value is written through Fusion_Settings so Avada\'s option cache is kept consistent. Value may be a scalar or, by passing value_json, a structured array/object (for grouped options like typography or dimensions). Changing Theme Options affects the whole site\'s appearance — use deliberately.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'key' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The Theme Option key to set, e.g. primary_color.',
            ],
            'value' => [
                'optional',
                'string',
                'description' => 'Scalar value to set. Use this for simple string/number/boolean-ish options. For structured values use value_json instead.',
            ],
            'value_json' => [
                'optional',
                'string',
                'description' => 'JSON-encoded value for structured options (arrays/objects). Takes precedence over "value" if both are supplied.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('changing an Avada Theme Option');

        $key = (string) $parameters['key'];

        // Resolve the value: value_json wins over value.
        if (isset($parameters['value_json']) && $parameters['value_json'] !== '') {
            $decoded = json_decode((string) $parameters['value_json'], true);
            if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                return $this->error('value_json is not valid JSON.');
            }
            $value = $decoded;
        } elseif (array_key_exists('value', $parameters)) {
            $value = $parameters['value'];
        } else {
            return $this->error('Provide either "value" (scalar) or "value_json" (structured).');
        }

        // Capture the prior value so the response shows the change.
        try {
            $previous = $this->avada->getOption($key);
        } catch (\RuntimeException $e) {
            $previous = null;
        }

        try {
            $ok = $this->avada->setOption($key, $value);
        } catch (\RuntimeException $e) {
            return $this->error('Failed to set option: ' . $e->getMessage());
        }

        if (!$ok) {
            return $this->error("Could not persist Theme Option '{$key}'.");
        }

        // Read back for informational purposes. NOTE: getOption() reads
        // through Fusion_Settings, whose in-request cache is not refreshed
        // immediately after a write — so this can return the PRE-write
        // value within the same request. It is therefore reported as a
        // separate, explicitly-labeled field, not as the authoritative
        // result. The authoritative new value is what was just written
        // ($value), since setOption() reported success.
        $cachedReadback = null;
        try {
            $cachedReadback = $this->avada->getOption($key);
        } catch (\RuntimeException $e) {
            // Non-fatal: write reported success.
        }

        return $this->success([
            'key'              => $key,
            'previous_value'   => $previous,
            'new_value'        => $value,
            'cached_readback'  => $cachedReadback,
            'readback_note'    => 'new_value is the value written (setOption reported success). cached_readback is a same-request read through Fusion_Settings and may show the pre-write cached value until the next request — this is an Avada caching behavior, not a write failure.',
        ], "Theme Option '{$key}' updated.");
    }
}
