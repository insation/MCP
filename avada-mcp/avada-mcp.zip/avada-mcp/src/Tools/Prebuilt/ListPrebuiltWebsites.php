<?php
/**
 * List Prebuilt Websites Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Prebuilt;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ListPrebuiltWebsites extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'list_prebuilt_websites';
    }

    public function getDescription(): string
    {
        return 'List the Avada Prebuilt Websites (demo sites) available to import — each with its key, name, tags/category, preview URL, and the plugins it requires. Read-only: this does not import anything; it is for discovering what prebuilt designs Avada offers.';
    }

    public function getSchema(): array
    {
        return [
            'tag' => [
                'optional',
                'string',
                'description' => 'Filter to prebuilt sites whose tags/category include this value (case-insensitive substring match).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (!$this->avada->prebuiltAvailable()) {
            return $this->error(
                'The Avada Prebuilt Websites subsystem is not available. Avada Core/Builder may be inactive.'
            );
        }

        try {
            $sites = $this->avada->listPrebuiltWebsites();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (isset($parameters['tag']) && $parameters['tag'] !== '') {
            $needle = strtolower((string) $parameters['tag']);
            $sites = array_values(array_filter($sites, static function ($s) use ($needle) {
                $hay = '';
                if (isset($s['tags'])) {
                    $hay .= is_array($s['tags']) ? implode(' ', $s['tags']) : (string) $s['tags'];
                }
                if (isset($s['category'])) {
                    $hay .= ' ' . (is_array($s['category']) ? implode(' ', $s['category']) : (string) $s['category']);
                }
                return strpos(strtolower($hay), $needle) !== false;
            }));
        }

        return $this->success([
            'count'    => count($sites),
            'websites' => $sites,
        ]);
    }
}
