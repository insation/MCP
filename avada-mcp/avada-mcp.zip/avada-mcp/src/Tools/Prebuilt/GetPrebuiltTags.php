<?php
/**
 * Get Prebuilt Tags Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Prebuilt;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetPrebuiltTags extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_prebuilt_tags';
    }

    public function getDescription(): string
    {
        return 'Get the tags/categories Avada uses to organize its Prebuilt Websites. Useful for narrowing list_prebuilt_websites by a tag.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (!$this->avada->prebuiltAvailable()) {
            return $this->error(
                'The Avada Prebuilt Websites subsystem is not available. Avada Core/Builder may be inactive.'
            );
        }

        try {
            $tags = $this->avada->getPrebuiltTags();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'count' => count($tags),
            'tags'  => $tags,
        ]);
    }
}
