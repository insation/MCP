<?php
/**
 * Get Imported Websites Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Prebuilt;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetImportedWebsites extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_imported_websites';
    }

    public function getDescription(): string
    {
        return 'Get the record of which Avada Prebuilt Websites have already been imported into this site (by import stage). Useful for understanding the site\'s provenance before making changes.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (!$this->avada->prebuiltAvailable()) {
            return $this->error(
                'The Avada Prebuilt Websites subsystem is not available. Avada Core/Builder may be inactive.'
            );
        }

        try {
            $imported = $this->avada->getImportedWebsites();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'count'    => is_countable($imported) ? count($imported) : 0,
            'imported' => $imported,
        ]);
    }
}
