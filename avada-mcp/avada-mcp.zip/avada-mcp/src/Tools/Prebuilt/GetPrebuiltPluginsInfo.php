<?php
/**
 * Get Prebuilt Plugins Info Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.4
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\Prebuilt;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetPrebuiltPluginsInfo extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_prebuilt_plugins_info';
    }

    public function getDescription(): string
    {
        return 'Get the plugin-dependency picture Avada uses for Prebuilt Websites — which recommended/required plugins are installed and active (including the Avada Core/Builder check). Useful for diagnosing why a prebuilt import would or would not work.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (!$this->avada->prebuiltAvailable()) {
            return $this->error(
                'The Avada Prebuilt Websites subsystem is not available. Avada Core/Builder may be inactive.'
            );
        }

        try {
            $info = $this->avada->getPrebuiltPluginsInfo();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($info);
    }
}
