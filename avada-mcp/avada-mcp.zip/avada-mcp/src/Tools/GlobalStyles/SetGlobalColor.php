<?php
/**
 * Set Global Color Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\GlobalStyles;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class SetGlobalColor extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'set_global_color';
    }

    public function getDescription(): string
    {
        return 'Set a single entry in the Avada global color palette by its slug (e.g. awb-color1). The new value is written through Fusion_Settings so Avada\'s cache and dynamic CSS regenerate. Because global colors cascade site-wide via CSS variables, changing one recolors everything that references it — use deliberately. Use get_global_colors first to see existing slugs and values.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'slug' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The palette entry slug to set, e.g. awb-color1. Must be an existing slug unless create=true.',
            ],
            'value' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The color value — hex (#1e73be), rgba(), or a CSS color string.',
            ],
            'create' => [
                'optional',
                'bool',
                'description' => 'Allow creating a new palette slug if it does not already exist. Default false (only modify existing entries).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('changing an Avada global color');

        $slug = (string) $parameters['slug'];
        $value = (string) $parameters['value'];
        $allowCreate = !empty($parameters['create']);

        try {
            $palette = $this->avada->getColorPaletteRaw();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $exists = array_key_exists($slug, $palette);
        if (!$exists && !$allowCreate) {
            return $this->error(
                "Global color slug '{$slug}' does not exist. Pass create=true to add it, or use get_global_colors to see valid slugs.",
                ['existing_slugs' => array_keys($palette)]
            );
        }

        $previous = $exists ? $palette[$slug] : null;

        // Avada palette entries are objects: {"color": "...", "label": "..."}.
        // Preserve that structure — only replace the color value. Writing a
        // bare string here corrupts the palette and breaks every reader.
        if ($exists && is_array($palette[$slug])) {
            // Modify in place, keeping label (and any other keys) intact.
            $palette[$slug]['color'] = $value;
        } elseif ($exists && is_object($palette[$slug])) {
            $entry = (array) $palette[$slug];
            $entry['color'] = $value;
            $palette[$slug] = $entry;
        } else {
            // New entry (create=true) or a non-structured existing value:
            // build the correct object shape with a sensible default label.
            $label = 'Color';
            if ($exists && is_string($palette[$slug]) && $palette[$slug] !== '') {
                $label = ucfirst($slug);
            } else {
                $label = ucfirst(str_replace(['_', '-'], ' ', $slug));
            }
            $palette[$slug] = [
                'color' => $value,
                'label' => $label,
            ];
        }

        try {
            $ok = $this->avada->setColorPalette($palette);
        } catch (\RuntimeException $e) {
            return $this->error('Failed to save palette: ' . $e->getMessage());
        }

        if (!$ok) {
            return $this->error("Could not persist global color '{$slug}'.");
        }

        return $this->success([
            'slug'           => $slug,
            'previous_value' => $previous,
            'new_value'      => $value,
            'created'        => !$exists,
        ], ($exists ? "Updated" : "Created") . " global color '{$slug}'.");
    }
}
