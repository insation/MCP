<?php
/**
 * Repair Global Colors Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.8
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\GlobalStyles;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class RepairGlobalColors extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'repair_global_colors';
    }

    public function getDescription(): string
    {
        return 'Repair the Avada global color palette if it has become structurally malformed (e.g. an entry stored as a bare string instead of the required {color,label} object, which breaks the normal color readers). Reads the raw palette option tolerantly, normalizes every entry back to the correct object shape, and writes it back. DRY-RUN by default — returns the repaired palette without saving unless confirm=true.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'confirm' => [
                'optional',
                'bool',
                'description' => 'Must be true to actually write the repaired palette. Omitted/false = dry-run preview.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $repaired = $this->avada->getColorPaletteRaw();
        } catch (\RuntimeException $e) {
            return $this->error('Could not read palette for repair: ' . $e->getMessage());
        }

        if (empty($repaired)) {
            return $this->error('The palette could not be reconstructed (raw option unreadable and no defaults available).');
        }

        $confirm = !empty($parameters['confirm']);
        if (!$confirm) {
            return $this->success([
                'dry_run'          => true,
                'repaired_palette' => $repaired,
                'note'             => 'Preview only. Re-call with confirm=true to write the repaired palette.',
            ]);
        }

        $this->checkSafeMode('repairing the Avada global color palette');

        try {
            $result = $this->avada->repairColorPalette();
        } catch (\RuntimeException $e) {
            return $this->error('Repair failed: ' . $e->getMessage());
        }

        return $this->success([
            'dry_run'          => false,
            'repaired_palette' => $result,
        ], 'Global color palette repaired and saved.');
    }
}
