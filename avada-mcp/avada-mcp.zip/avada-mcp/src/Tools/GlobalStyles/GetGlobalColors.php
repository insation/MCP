<?php
/**
 * Get Global Colors Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\GlobalStyles;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetGlobalColors extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_global_colors';
    }

    public function getDescription(): string
    {
        return 'Read the Avada global color palette — the named global colors (e.g. awb-color1..N) that Avada exposes as var(--awb-colorN) across the whole site. Returns the live resolved palette (slug => value) and the registered defaults, so you can see which entries have been customized.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $palette = $this->avada->getColorPalette();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $defaults = $this->avada->getColorPaletteDefaults();

        return $this->success([
            'option_key'    => AvadaService::COLOR_PALETTE_KEY,
            'count'         => count($palette),
            'palette'       => $palette,
            'defaults'      => $defaults,
        ]);
    }
}
