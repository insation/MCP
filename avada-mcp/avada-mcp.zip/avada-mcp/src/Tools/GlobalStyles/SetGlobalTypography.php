<?php
/**
 * Set Global Typography Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\GlobalStyles;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class SetGlobalTypography extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'set_global_typography';
    }

    public function getDescription(): string
    {
        return 'Update a single Avada global typography set by its slug (e.g. typography1). Supply the properties to change as a JSON object — recognized keys include font-family, font-size, variant, line-height, letter-spacing, text-transform, label. Supplied keys are merged into the existing set (other keys preserved). Written through Fusion_Settings so the change cascades site-wide. Use get_global_typography first to see existing slugs and their current values.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'slug' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The typography set slug to modify, e.g. typography1.',
            ],
            'properties_json' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'JSON object of properties to set, e.g. {"font-family":"Inter","font-size":"18px","variant":"600","line-height":"1.4"}.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $this->checkSafeMode('changing Avada global typography');

        $slug = (string) $parameters['slug'];

        $decoded = json_decode((string) $parameters['properties_json'], true);
        if (!is_array($decoded)) {
            return $this->error('properties_json is not valid JSON, or did not decode to an object.');
        }

        try {
            $sets = $this->avada->getTypographySets();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (!array_key_exists($slug, $sets) || !is_array($sets[$slug])) {
            return $this->error(
                "Typography set '{$slug}' does not exist.",
                ['existing_slugs' => array_keys($sets)]
            );
        }

        $previous = $sets[$slug];
        $sets[$slug] = array_merge($sets[$slug], $decoded);

        try {
            $ok = $this->avada->setTypographySets($sets);
        } catch (\RuntimeException $e) {
            return $this->error('Failed to save typography: ' . $e->getMessage());
        }

        if (!$ok) {
            return $this->error("Could not persist typography set '{$slug}'.");
        }

        return $this->success([
            'slug'           => $slug,
            'previous'       => $previous,
            'new'            => $sets[$slug],
            'changed_keys'   => array_keys($decoded),
        ], "Updated global typography set '{$slug}'.");
    }
}
