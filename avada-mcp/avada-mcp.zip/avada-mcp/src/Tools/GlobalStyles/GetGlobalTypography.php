<?php
/**
 * Get Global Typography Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.1
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\GlobalStyles;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetGlobalTypography extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_global_typography';
    }

    public function getDescription(): string
    {
        return 'Read the Avada global typography sets — the named, reusable type styles (typography1..N) with their font-family, size, variant/weight, line-height, letter-spacing and text-transform, that Avada exposes site-wide. Returns the live resolved sets and the registered defaults so you can see which have been customized.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $sets = $this->avada->getTypographySets();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $defaults = $this->avada->getTypographyDefaults();

        return $this->success([
            'option_key' => AvadaService::TYPOGRAPHY_SETS_KEY,
            'count'      => count($sets),
            'typography' => $sets,
            'defaults'   => $defaults,
        ]);
    }
}
