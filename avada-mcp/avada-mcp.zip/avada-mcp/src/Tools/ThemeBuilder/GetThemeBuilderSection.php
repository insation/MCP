<?php
/**
 * Get Theme Builder Section Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetThemeBuilderSection extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_theme_builder_section';
    }

    public function getDescription(): string
    {
        return 'Get a single Avada Theme Builder Section by ID — its title, status, section type (header/page_title_bar/content/footer), and the full Fusion Builder content (the shortcode string stored in post_content that defines the template).';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                ['min' => 1],
                'description' => 'The fusion_tb_section post ID.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $id = (int) $parameters['id'];

        try {
            $section = $this->avada->getThemeBuilderSection($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($section);
    }
}
