<?php
/**
 * List Theme Builder Layouts Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ListThemeBuilderLayouts extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'list_theme_builder_layouts';
    }

    public function getDescription(): string
    {
        return 'List all Avada Theme Builder Layouts (fusion_tb_layout), including the special implicit "global" layout. Each entry includes its id, title, status, and the display conditions that determine where it applies (the decoded conditions array from the layout\'s JSON).';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $layouts = $this->avada->listThemeBuilderLayouts();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'count'   => count($layouts),
            'layouts' => $layouts,
        ]);
    }
}
