<?php
/**
 * Set Theme Builder Conditions Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class SetThemeBuilderConditions extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'set_theme_builder_conditions';
    }

    public function getDescription(): string
    {
        return 'Replace the display conditions of a Theme Builder layout. HIGH IMPACT: conditions decide where a layout\'s header/footer/content templates apply site-wide — a wrong write can make a site\'s header or footer disappear. Safety: this is DRY-RUN by default (returns the resulting conditions WITHOUT writing) unless confirm=true; a snapshot is always taken before a real write and can be restored with revert_theme_builder_conditions. Each condition is {"type":...,"mode":"include|exclude","<type>":<value>}.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Numeric fusion_tb_layout post ID, or "global".',
            ],
            'conditions_json' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'JSON array of conditions, e.g. [{"type":"post_type","mode":"include","post_type":"page"},{"type":"front_page","mode":"exclude","front_page":"front_page"}]. Replaces ALL existing conditions for this layout.',
            ],
            'confirm' => [
                'optional',
                'bool',
                'description' => 'Must be true to actually write. Omitted/false = dry-run: returns the resulting conditions without saving.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $rawId = (string) $parameters['id'];
        $id = ($rawId === 'global') ? 'global' : (ctype_digit($rawId) ? (int) $rawId : $rawId);

        $decoded = json_decode((string) $parameters['conditions_json'], true);
        if (!is_array($decoded)) {
            return $this->error('conditions_json must be a JSON array of condition objects.');
        }

        // Validate/normalize every condition before doing anything.
        $normalized = [];
        foreach ($decoded as $i => $cond) {
            if (!is_array($cond)) {
                return $this->error("Condition #{$i} is not an object.");
            }
            try {
                $normalized[] = $this->avada->normalizeCondition($cond);
            } catch (\RuntimeException $e) {
                return $this->error("Condition #{$i}: " . $e->getMessage());
            }
        }

        try {
            $current = $this->avada->getLayoutData($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $confirm = !empty($parameters['confirm']);

        if (!$confirm) {
            return $this->success([
                'dry_run'            => true,
                'layout_id'          => (string) $id,
                'current_conditions' => $current['conditions'],
                'resulting_conditions' => $normalized,
                'will_replace_count' => count($current['conditions']),
                'note'               => 'No changes written. Re-call with confirm=true to apply. A snapshot will be taken before writing.',
            ]);
        }

        $this->checkSafeMode('replacing Theme Builder display conditions');

        $newData = $current;
        $newData['conditions'] = $normalized;

        try {
            $result = $this->avada->writeLayoutData($id, $newData);
        } catch (\RuntimeException $e) {
            return $this->error('Write failed: ' . $e->getMessage());
        }

        return $this->success([
            'dry_run'            => false,
            'layout_id'          => (string) $id,
            'previous_conditions' => $current['conditions'],
            'new_conditions'     => $result['conditions'] ?? $normalized,
            'snapshot_taken'     => true,
            'revert_with'        => 'revert_theme_builder_conditions',
        ], 'Theme Builder conditions updated. A snapshot was saved; use revert_theme_builder_conditions to undo.');
    }
}
