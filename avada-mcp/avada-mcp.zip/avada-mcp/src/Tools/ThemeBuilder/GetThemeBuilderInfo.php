<?php
/**
 * Get Theme Builder Info Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetThemeBuilderInfo extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_theme_builder_info';
    }

    public function getDescription(): string
    {
        return 'Get an overview of the Avada Layout/Theme Builder: whether it is available, the supported section types (header, page title bar, content, footer) with their labels, and counts of Layouts and Sections. A good first call before using the other Theme Builder tools.';
    }

    public function getSchema(): array
    {
        return [];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $available = $this->avada->themeBuilderAvailable();
        $result = [
            'theme_builder_available' => $available,
        ];

        if (!$available) {
            $result['note'] = 'The Avada Theme Builder post types are not registered. Avada Builder (Fusion Builder) may be inactive.';
            return $this->success($result);
        }

        $result['section_types'] = $this->avada->getThemeBuilderSectionTypes();

        try {
            $layouts = $this->avada->listThemeBuilderLayouts();
            $result['layout_count'] = count($layouts);
        } catch (\RuntimeException $e) {
            $result['layout_count'] = null;
        }

        try {
            $sections = $this->avada->listThemeBuilderSections();
            $secCounts = [];
            $total = 0;
            foreach ($sections as $type => $items) {
                $n = count($items);
                if ($n > 0) {
                    $secCounts[$type] = $n;
                }
                $total += $n;
            }
            $result['section_count'] = $total;
            $result['sections_by_type'] = $secCounts;
        } catch (\RuntimeException $e) {
            $result['section_count'] = null;
        }

        return $this->success($result);
    }
}
