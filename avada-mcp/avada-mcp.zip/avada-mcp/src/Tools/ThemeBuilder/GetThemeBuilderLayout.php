<?php
/**
 * Get Theme Builder Layout Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetThemeBuilderLayout extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_theme_builder_layout';
    }

    public function getDescription(): string
    {
        return 'Get a single Avada Theme Builder Layout in full — its decoded JSON data including the display conditions and the section/template assignments. Pass a numeric fusion_tb_layout post ID, or the string "global" for the implicit site-wide layout stored in the fusion_tb_layout_default option.';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'A numeric fusion_tb_layout post ID, or "global" for the site-wide layout.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $rawId = (string) $parameters['id'];
        $id = ($rawId === 'global') ? 'global' : (ctype_digit($rawId) ? (int) $rawId : $rawId);

        try {
            $layout = $this->avada->getThemeBuilderLayout($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success($layout);
    }
}
