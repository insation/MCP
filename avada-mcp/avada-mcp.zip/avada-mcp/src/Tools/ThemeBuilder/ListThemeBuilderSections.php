<?php
/**
 * List Theme Builder Sections Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.3
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ListThemeBuilderSections extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'list_theme_builder_sections';
    }

    public function getDescription(): string
    {
        return 'List all Avada Theme Builder Sections (fusion_tb_section), grouped by their section type — header, page_title_bar, content, footer (via the fusion_tb_category taxonomy). Each entry returns id, title, status, slug, and modified date. Sections are the actual templates that replace parts of the site.';
    }

    public function getSchema(): array
    {
        return [
            'type' => [
                'optional',
                'string',
                'description' => 'Return only one section type: header, page_title_bar, content, or footer. Omit for all, grouped.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $grouped = $this->avada->listThemeBuilderSections();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        if (isset($parameters['type']) && $parameters['type'] !== '') {
            $type = (string) $parameters['type'];
            if (!array_key_exists($type, $grouped)) {
                return $this->error(
                    "Unknown section type '{$type}'.",
                    ['valid_types' => array_keys($grouped)]
                );
            }
            return $this->success([
                'type'     => $type,
                'count'    => count($grouped[$type]),
                'sections' => $grouped[$type],
            ]);
        }

        $total = 0;
        foreach ($grouped as $items) {
            $total += count($items);
        }

        return $this->success([
            'total'             => $total,
            'sections_by_type'  => $grouped,
        ]);
    }
}
