<?php
/**
 * Add Theme Builder Condition Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class AddThemeBuilderCondition extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'add_theme_builder_condition';
    }

    public function getDescription(): string
    {
        return 'Append a single display condition to a Theme Builder layout, preserving existing conditions (safer than set_theme_builder_conditions, which replaces all). Still HIGH IMPACT. DRY-RUN by default unless confirm=true; a snapshot is taken before a real write. Condition is {"type":...,"mode":"include|exclude","<type>":<value>}.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Numeric fusion_tb_layout post ID, or "global".',
            ],
            'condition_json' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'A single condition object, e.g. {"type":"post_type","mode":"include","post_type":"page"}.',
            ],
            'confirm' => [
                'optional',
                'bool',
                'description' => 'Must be true to actually write. Omitted/false = dry-run.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $rawId = (string) $parameters['id'];
        $id = ($rawId === 'global') ? 'global' : (ctype_digit($rawId) ? (int) $rawId : $rawId);

        $cond = json_decode((string) $parameters['condition_json'], true);
        if (!is_array($cond)) {
            return $this->error('condition_json must be a single JSON condition object.');
        }

        try {
            $normalized = $this->avada->normalizeCondition($cond);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        try {
            $current = $this->avada->getLayoutData($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $resulting = array_values($current['conditions']);
        $resulting[] = $normalized;

        $confirm = !empty($parameters['confirm']);

        if (!$confirm) {
            return $this->success([
                'dry_run'              => true,
                'layout_id'            => (string) $id,
                'current_conditions'   => $current['conditions'],
                'resulting_conditions' => $resulting,
                'note'                 => 'No changes written. Re-call with confirm=true to apply.',
            ]);
        }

        $this->checkSafeMode('adding a Theme Builder display condition');

        $newData = $current;
        $newData['conditions'] = $resulting;

        try {
            $result = $this->avada->writeLayoutData($id, $newData);
        } catch (\RuntimeException $e) {
            return $this->error('Write failed: ' . $e->getMessage());
        }

        return $this->success([
            'dry_run'         => false,
            'layout_id'       => (string) $id,
            'added_condition' => $normalized,
            'new_conditions'  => $result['conditions'] ?? $resulting,
            'snapshot_taken'  => true,
            'revert_with'     => 'revert_theme_builder_conditions',
        ], 'Condition added. Snapshot saved; revert with revert_theme_builder_conditions.');
    }
}
