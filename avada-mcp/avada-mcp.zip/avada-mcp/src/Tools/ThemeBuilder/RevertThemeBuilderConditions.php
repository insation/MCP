<?php
/**
 * Revert Theme Builder Conditions Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class RevertThemeBuilderConditions extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'revert_theme_builder_conditions';
    }

    public function getDescription(): string
    {
        return 'Restore a Theme Builder layout\'s conditions from the snapshot automatically taken before the last conditions write (set_theme_builder_conditions / add_theme_builder_condition). The escape hatch if a conditions change broke the site\'s header/footer/content targeting.';
    }

    public function getRequiredScope(): string
    {
        return 'mcp:write';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Numeric fusion_tb_layout post ID, or "global" — the layout to restore.',
            ],
            'confirm' => [
                'optional',
                'bool',
                'description' => 'Must be true to actually restore. Omitted/false = preview what would be restored.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $rawId = (string) $parameters['id'];
        $id = ($rawId === 'global') ? 'global' : (ctype_digit($rawId) ? (int) $rawId : $rawId);

        $snapshot = $this->avada->getLayoutSnapshot($id);
        if ($snapshot === null) {
            return $this->error(
                "No snapshot exists for layout '{$id}'. A snapshot is only created when a conditions write is performed."
            );
        }

        $confirm = !empty($parameters['confirm']);

        if (!$confirm) {
            return $this->success([
                'dry_run'             => true,
                'layout_id'           => (string) $id,
                'snapshot_taken'      => $snapshot['taken_at'] ?? null,
                'would_restore_conditions' => $snapshot['data']['conditions'] ?? [],
                'note'                => 'Preview only. Re-call with confirm=true to restore.',
            ]);
        }

        $this->checkSafeMode('reverting Theme Builder conditions to the last snapshot');

        try {
            $result = $this->avada->restoreLayoutSnapshot($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'dry_run'        => false,
            'layout_id'      => (string) $id,
            'restored_from'  => $result['restored_from'] ?? null,
            'restored_data'  => $result['data'] ?? null,
        ], 'Layout conditions restored from snapshot.');
    }
}
