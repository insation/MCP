<?php
/**
 * Get Theme Builder Conditions Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.7
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ThemeBuilder;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetThemeBuilderConditions extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_theme_builder_conditions';
    }

    public function getDescription(): string
    {
        return 'Read the raw display conditions of a Theme Builder layout (numeric fusion_tb_layout id, or "global"). Returns the exact conditions array and template_terms as stored. Use this before any conditions write to see the current state — the write tools also require you to have the current picture.';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'Numeric fusion_tb_layout post ID, or "global".',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $rawId = (string) $parameters['id'];
        $id = ($rawId === 'global') ? 'global' : (ctype_digit($rawId) ? (int) $rawId : $rawId);

        try {
            $data = $this->avada->getLayoutData($id);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $snapshot = $this->avada->getLayoutSnapshot($id);

        return $this->success([
            'layout_id'      => (string) $id,
            'conditions'     => $data['conditions'],
            'template_terms' => $data['template_terms'],
            'has_snapshot'   => $snapshot !== null,
            'snapshot_taken' => $snapshot['taken_at'] ?? null,
        ]);
    }
}
