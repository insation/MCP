<?php
/**
 * Get Avada Content Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ContentTypes;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class GetAvadaContent extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'get_avada_content';
    }

    public function getDescription(): string
    {
        return 'Get a single Avada custom-post-type item by ID — its title, status, content, slug, and the Fusion/Avada page-option post meta (the _fusion meta and any fusion_* meta keys that drive per-item layout and design). Works for Portfolio, FAQ, Slides, Library elements, Layout sections, Fusion Forms, etc.';
    }

    public function getSchema(): array
    {
        return [
            'id' => [
                'required',
                'int',
                ['min' => 1],
                'description' => 'The post ID of the Avada CPT item.',
            ],
            'include_meta' => [
                'optional',
                'bool',
                'description' => 'Include the Fusion/Avada post meta (default true).',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $id = (int) $parameters['id'];
        $post = get_post($id);

        if (!$post) {
            return $this->error("No post found with ID {$id}.");
        }

        if (!isset(AvadaService::AVADA_CPTS[$post->post_type])) {
            return $this->error(
                "Post {$id} is type '{$post->post_type}', which is not an Avada custom post type. Use the WordpressMCP content tools for standard posts/pages."
            );
        }

        $result = [
            'id'        => $id,
            'post_type' => $post->post_type,
            'label'     => AvadaService::AVADA_CPTS[$post->post_type],
            'title'     => $post->post_title,
            'status'    => $post->post_status,
            'slug'      => $post->post_name,
            'modified'  => $post->post_modified_gmt,
            'content'   => $post->post_content,
        ];

        $includeMeta = !isset($parameters['include_meta']) || (bool) $parameters['include_meta'];
        if ($includeMeta) {
            $allMeta = get_post_meta($id);
            $fusionMeta = [];
            if (is_array($allMeta)) {
                foreach ($allMeta as $metaKey => $metaVals) {
                    // Surface the Fusion/Avada-relevant meta only.
                    if (strpos($metaKey, 'fusion') !== false
                        || strpos($metaKey, '_fusion') === 0
                        || strpos($metaKey, 'pyre_') === 0
                        || strpos($metaKey, 'avada') !== false
                        || strpos($metaKey, 'sbg_') === 0) {
                        // Unserialize single-value meta for readability.
                        $val = (is_array($metaVals) && count($metaVals) === 1)
                            ? maybe_unserialize($metaVals[0])
                            : array_map('maybe_unserialize', (array) $metaVals);
                        $fusionMeta[$metaKey] = $val;
                    }
                }
            }
            $result['fusion_meta'] = $fusionMeta;
        }

        return $this->success($result);
    }
}
