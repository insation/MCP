<?php
/**
 * List Avada Content Tool
 *
 * @package InsationAI\AvadaMCP
 * @since 1.0.0
 *
 * phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
 */

declare(strict_types=1);

namespace InsationAI\AvadaMCP\Tools\ContentTypes;

use InsationAI\AvadaMCP\Services\AvadaService;
use InsationAI\AvadaMCP\Services\ValidationService;
use InsationAI\AvadaMCP\Services\WordPressService;
use Psr\Log\LoggerInterface;
use InsationAI\AvadaMCP\Tools\AbstractTool;

class ListAvadaContent extends AbstractTool
{
    protected AvadaService $avada;

    public function __construct(
        WordPressService $wp,
        ValidationService $validator,
        AvadaService $avada,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($wp, $validator, $logger);
        $this->avada = $avada;
    }

    public function getName(): string
    {
        return 'list_avada_content';
    }

    public function getDescription(): string
    {
        return 'List posts of an Avada custom post type — Portfolio (avada_portfolio), FAQ (avada_faq), Slider slides (slide), Library elements (fusion_element), Layout sections (fusion_tb_section), Fusion Forms (fusion_form), and more. Returns id, title, status, slug and modified date, paginated.';
    }

    public function getSchema(): array
    {
        return [
            'post_type' => [
                'required',
                'string',
                ['notEmpty' => true],
                'description' => 'The Avada CPT slug, e.g. avada_portfolio, avada_faq, slide, fusion_element, fusion_tb_section, fusion_form.',
            ],
            'page' => [
                'optional',
                'int',
                ['min' => 1],
                'description' => 'Page number (default 1).',
            ],
            'per_page' => [
                'optional',
                'int',
                ['min' => 1],
                ['max' => 100],
                'description' => 'Results per page, 1-100 (default 25).',
            ],
            'status' => [
                'optional',
                'string',
                'description' => 'Post status filter (publish, draft, any). Default any.',
            ],
        ];
    }

    protected function doExecute(array $parameters): array
    {
        try {
            $this->avada->requireAvada();
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        $postType = (string) $parameters['post_type'];

        if (!isset(AvadaService::AVADA_CPTS[$postType])) {
            return $this->error(
                "'{$postType}' is not a recognized Avada custom post type.",
                ['valid_types' => array_keys(AvadaService::AVADA_CPTS)]
            );
        }

        if (!post_type_exists($postType)) {
            return $this->error(
                "The post type '{$postType}' is not registered on this site. The relevant Avada component (e.g. Avada Core) may be inactive."
            );
        }

        $page = isset($parameters['page']) ? (int) $parameters['page'] : 1;
        $perPage = isset($parameters['per_page']) ? (int) $parameters['per_page'] : 25;
        $status = isset($parameters['status']) && $parameters['status'] !== ''
            ? (string) $parameters['status']
            : 'any';

        try {
            $posts = $this->avada->listCptPosts($postType, $perPage, $page, $status);
            $counts = $this->avada->countCptPosts($postType);
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage());
        }

        return $this->success([
            'post_type'  => $postType,
            'label'      => AvadaService::AVADA_CPTS[$postType],
            'page'       => $page,
            'per_page'   => $perPage,
            'returned'   => count($posts),
            'counts'     => $counts,
            'items'      => $posts,
        ]);
    }
}
